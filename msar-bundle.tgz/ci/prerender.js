// مسار — توليد صفحات الموقع التعريفي مسبقاً (SEO / GEO): index.html, en.html, terms/privacy/guide.html, sitemap.xml, robots.txt, llms.txt
// التشغيل: node ci/prerender.js [BASE_URL]
const fs = require("fs"), path = require("path");
const WEB = path.join(__dirname, "..", "web");
const BASE = (process.argv[2] || "https://msarpro.com/").replace(/\/?$/, "/");
const D = require(path.join(WEB, "js/site-data.js"));
const DOCS = require(path.join(WEB, "js/site-docs.js"));
const S = require(path.join(WEB, "js/site-render.js"));
const esc = S.esc;
const V = Date.now().toString(36); // كسر الكاش للملفات

const REDIRECT = `<script>(function(){var h=location.hash,s=location.search;if(/^#(live|map|orders|reports|staff|routing|branches|settings)\\b/.test(h)||/[?&]store=/.test(s)||/(access_token|error_description|type=recovery)/.test(h)){location.replace("app.html"+s+h);}})();</script>`;

function head({ lang, title, desc, keywords, canonical, alts, ogImage, jsonld, type = "website" }) {
  const ogLocale = lang === "en" ? "en_US" : "ar_SA";
  return `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${keywords ? `<meta name="keywords" content="${esc(keywords)}">` : ""}
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="${canonical}">
${alts.map(([l, u]) => `<link rel="alternate" hreflang="${l}" href="${u}">`).join("\n")}
<meta name="theme-color" content="#144F74">
<meta name="application-name" content="${esc(D.brand[`name_${lang}`])}">
<link rel="icon" href="icons/icon-192.png" type="image/png">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<meta property="og:type" content="${type}">
<meta property="og:site_name" content="${esc(D.brand.name_ar)} | ${esc(D.brand.name_en)}">
<meta property="og:locale" content="${ogLocale}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${canonical}">
<meta property="og:image" content="${BASE}${ogImage}">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(desc)}">
<meta name="twitter:image" content="${BASE}${ogImage}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;600;700&display=swap">
<link rel="stylesheet" href="css/site.css?v=${V}">
${jsonld ? `<script type="application/ld+json">${jsonld}</script>` : ""}`;
}

function page({ lang, dir, headHtml, bodyHtml, pageType, docKey, extraHead = "" }) {
  return `<!doctype html>
<html lang="${lang}" dir="${dir}">
<head>
${REDIRECT}
${headHtml}
${extraHead}
</head>
<body data-page="${pageType}"${docKey ? ` data-doc="${docKey}"` : ""}>
<a class="skip" href="#main">${lang === "en" ? "Skip to content" : "تخطَّ إلى المحتوى"}</a>
<div class="progress" aria-hidden="true"></div>
<div id="site" data-prerendered="${lang}">${bodyHtml}</div>
<button class="to-top" aria-label="${lang === "en" ? "Back to top" : "للأعلى"}">${S.ic("arrow")}</button>
<script src="js/config.js?v=${V}"></script>
<script src="js/site-data.js?v=${V}"></script>
${pageType === "doc" ? `<script src="js/site-docs.js?v=${V}"></script>` : ""}
<script src="js/site-render.js?v=${V}"></script>
<script src="js/site.js?v=${V}" defer></script>
</body>
</html>
`;
}

// ---------------------------------------------------------------- الصفحة الرئيسية (عربي + إنجليزي)
for (const lang of ["ar", "en"]) {
  const file = lang === "en" ? "en.html" : "index.html";
  const canonical = lang === "en" ? BASE + "en.html" : BASE;
  const html = page({
    lang, dir: lang === "en" ? "ltr" : "rtl", pageType: "landing",
    headHtml: head({ lang, title: D.seo[`title_${lang}`], desc: D.seo[`desc_${lang}`], keywords: D.seo[`keywords_${lang}`], canonical,
      alts: [["ar", BASE], ["en", BASE + "en.html"], ["x-default", BASE]], ogImage: D.seo.og_image, jsonld: S.jsonLd(D, lang, BASE) }),
    bodyHtml: S.landing(D, lang),
    extraHead: `<link rel="preload" as="image" href="${D.hero.image}" fetchpriority="high">`,
  });
  fs.writeFileSync(path.join(WEB, file), html);
  console.log("wrote", file, html.length);
}

// ---------------------------------------------------------------- صفحات الوثائق (عربي مسبقاً، والإنجليزي ?lang=en)
for (const key of ["terms", "privacy", "guide"]) {
  const d = DOCS[key], file = key + ".html";
  const firstPara = (d.ar.split("\n").find((l) => l.trim() && !/^[#>\-\d]/.test(l.trim())) || "").replace(/\*\*/g, "").slice(0, 155);
  const ld = JSON.stringify({ "@context": "https://schema.org", "@type": key === "guide" ? "TechArticle" : "WebPage", headline: d.title_ar, name: d.title_ar, inLanguage: "ar",
    dateModified: d.updated, url: BASE + file, isPartOf: { "@type": "WebSite", url: BASE, name: D.brand.name_ar }, publisher: { "@type": "Organization", name: "Msar — مسار", url: BASE } }).replace(/</g, "\\u003c");
  const html = page({
    lang: "ar", dir: "rtl", pageType: "doc", docKey: key,
    headHtml: head({ lang: "ar", title: `${d.title_ar} — ${D.brand.name_ar} | ${d.title_en}`, desc: firstPara, canonical: BASE + file,
      alts: [["ar", BASE + file], ["en", `${BASE}${file}?lang=en`], ["x-default", BASE + file]], ogImage: D.seo.og_image, jsonld: ld, type: "article" }),
    bodyHtml: S.docPage(D, d, "ar"),
  });
  fs.writeFileSync(path.join(WEB, file), html);
  console.log("wrote", file, html.length);
}

// ---------------------------------------------------------------- sitemap / robots / llms.txt
const today = new Date().toISOString().slice(0, 10);
const urls = [
  ["", "en.html", "1.0", "weekly"], ["en.html", "", "0.9", "weekly"],
  ...["guide", "terms", "privacy"].flatMap((k) => [[`${k}.html`, `${k}.html?lang=en`, k === "guide" ? "0.8" : "0.4", "monthly"], [`${k}.html?lang=en`, `${k}.html`, k === "guide" ? "0.7" : "0.3", "monthly"]]),
  ["support.html", "", "0.4", "monthly"],
];
const x = (u) => u.replace(/&/g, "&amp;");
fs.writeFileSync(path.join(WEB, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urls.map(([u, alt, p, f]) => `  <url><loc>${x(BASE + u)}</loc><lastmod>${today}</lastmod><changefreq>${f}</changefreq><priority>${p}</priority>${alt !== undefined && (u === "" || u === "en.html" || u.includes(".html")) && alt ? `
    <xhtml:link rel="alternate" hreflang="${u.includes("en") ? "en" : "ar"}" href="${x(BASE + u)}"/><xhtml:link rel="alternate" hreflang="${u.includes("en") ? "ar" : "en"}" href="${x(BASE + alt)}"/>` : ""}</url>`).join("\n")}
</urlset>
`);
fs.writeFileSync(path.join(WEB, "robots.txt"), `User-agent: *
Allow: /
Disallow: /app.html
Disallow: /owner.html
Disallow: /driver.html
Disallow: /setup.html
Disallow: /join.html
Disallow: /reset.html
Disallow: /msg.html
Disallow: /setup/

Sitemap: ${BASE}sitemap.xml
`);
const L = (o, k, l) => o[`${k}_${l}`];
fs.writeFileSync(path.join(WEB, "llms.txt"), `# ${D.brand.name_en} (${D.brand.name_ar}) — ${D.brand.tagline_en}

> ${D.seo.desc_en}

${D.seo.desc_ar}

## What Msar does
${D.features.map((f) => `- **${f.t_en}**: ${f.d_en}`).join("\n")}

## How it works
${D.steps.map((s, i) => `${i + 1}. ${s.t_en} — ${s.d_en}`).join("\n")}

## Who it's for
${D.roles.map((r) => `- ${r.t_en}: ${r.en.join("; ")}`).join("\n")}

## Pricing (SAR / month, excl. VAT)
${D.pricing.plans.map((p) => `- ${p.name_en}: ${p.price === null ? "custom" : p.price + " SAR"} — ${p.f_en.join(", ")}`).join("\n")}
${D.pricing.note_en}

## FAQ
${D.faq.map((f) => `### ${f.q_en}\n${f.a_en}`).join("\n\n")}

## Arabic FAQ
${D.faq.map((f) => `### ${f.q_ar}\n${f.a_ar}`).join("\n\n")}

## Links
- Home (Arabic): ${BASE}
- Home (English): ${BASE}en.html
- User guide: ${BASE}guide.html?lang=en
- Terms: ${BASE}terms.html?lang=en
- Privacy: ${BASE}privacy.html?lang=en
- Contact: ${D.links.email}
`);
console.log("wrote sitemap.xml robots.txt llms.txt");
