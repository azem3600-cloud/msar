// مسار — توليد صفحات الموقع التعريفي مسبقاً (SEO / GEO): index.html, en.html, terms/privacy/guide.html, sitemap.xml, robots.txt, llms.txt
// التشغيل: node ci/prerender.js [BASE_URL]
const fs = require("fs"), path = require("path");
const WEB = path.join(__dirname, "..", "web");
const BASE = (process.argv[2] || "https://msarpro.com/").replace(/\/?$/, "/");
const D = require(path.join(WEB, "js/site-data.js"));
const DOCS = require(path.join(WEB, "js/site-docs.js"));
const S = require(path.join(WEB, "js/site-render.js"));
const esc = S.esc;
const V = Date.now().toString(36); // كسر الكاش للملفات

const ANCHORS = `<script>(function(){var h=location.hash.slice(1),p=location.pathname.replace(/\\/+$/,""),m={features:"features",how:"how-it-works",roles:"roles",demo:"demo",pricing:"pricing",security:"security",faq:"faq",contact:"contact",integrations:"features"};if(h&&m[h]&&(p===""||p==="/index.html"||p==="/en"||p==="/en.html")){location.replace((/^\\/en/.test(p)?"/en/":"/")+m[h]);}})();</script>`;
const REDIRECT = `<script>(function(){try{var P=location.pathname;if(/\\.html$/.test(P))history.replaceState(history.state,"",P.replace(/(index)?\\.html$/,"")+location.search+location.hash);}catch(e){}var h=location.hash,s=location.search;if(/^#(live|map|orders|reports|staff|routing|branches|settings)\\b/.test(h)||/[?&]store=/.test(s)||/(access_token|error_description|type=recovery)/.test(h)){location.replace("app"+s+h);}})();</script>`;

function head({ lang, title, desc, keywords, canonical, alts, ogImage, jsonld, type = "website" }) {
  const ogLocale = lang === "en" ? "en_US" : "ar_SA";
  return `<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>${esc(title)}</title>
<meta name="description" content="${esc(desc)}">
${keywords ? `<meta name="keywords" content="${esc(keywords)}">` : ""}
<meta name="robots" content="index, follow, max-image-preview:large">
<link rel="canonical" href="${canonical}">
${alts.map(([l, u]) => `<link rel="alternate" hreflang="${l}" href="${u}">`).join("\n")}
<meta name="theme-color" content="#144F74">
<meta name="application-name" content="${esc(D.brand[`name_${lang}`])}">
<link rel="icon" href="icons/icon-192.png" type="image/png">
<link rel="apple-touch-icon" href="icons/icon-192.png">
<meta property="og:type" content="${type}">
<meta property="og:site_name" content="${esc(D.brand.name_ar)} | ${esc(D.brand.name_en)}">
<meta property="og:locale" content="${ogLocale}">
<meta property="og:title" content="${esc(title)}">
<meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${canonical}">
<meta property="og:image" content="${BASE}${ogImage}">
<meta property="og:image:width" content="1200"><meta property="og:image:height" content="630">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="${esc(title)}">
<meta name="twitter:description" content="${esc(desc)}">
<meta name="twitter:image" content="${BASE}${ogImage}">
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;600;700&display=swap">
<link rel="stylesheet" href="css/site.css?v=${V}">
${jsonld ? `<script type="application/ld+json">${jsonld}</script>` : ""}`;
}

function page({ lang, dir, headHtml, bodyHtml, pageType, docKey, extraHead = "", base = false, sec = "", skipHref = "#main", anchors = false }) {
  return `<!doctype html>
<html lang="${lang}" dir="${dir}">
<head>
${base ? '<base href="/">' : ""}
${REDIRECT}
${anchors ? ANCHORS : ""}
${headHtml}
${extraHead}
</head>
<body data-page="${pageType}"${sec ? ` data-sec="${sec}"` : ""}${docKey ? ` data-doc="${docKey}"` : ""}>
<a class="skip" href="${skipHref}">${lang === "en" ? "Skip to content" : "تخطَّ إلى المحتوى"}</a>
<div class="progress" aria-hidden="true"></div>
<div id="site" data-prerendered="${lang}">${bodyHtml}</div>
<button class="to-top" aria-label="${lang === "en" ? "Back to top" : "للأعلى"}">${S.ic("arrow")}</button>
<script src="js/config.js?v=${V}"></script>
<script src="js/site-data.js?v=${V}"></script>
${pageType === "doc" ? `<script src="js/site-docs.js?v=${V}"></script>` : ""}
<script src="js/site-render.js?v=${V}"></script>
<script src="js/site.js?v=${V}" defer></script>
</body>
</html>
`;
}

// ---------------------------------------------------------------- الصفحة الرئيسية (عربي + إنجليزي)
for (const lang of ["ar", "en"]) {
  const file = lang === "en" ? "en.html" : "index.html";
  const canonical = lang === "en" ? BASE + "en" : BASE;
  const html = page({
    lang, dir: lang === "en" ? "ltr" : "rtl", pageType: "landing",
    headHtml: head({ lang, title: D.seo[`title_${lang}`], desc: D.seo[`desc_${lang}`], keywords: D.seo[`keywords_${lang}`], canonical,
      alts: [["ar", BASE], ["en", BASE + "en"], ["x-default", BASE]], ogImage: D.seo.og_image, jsonld: S.jsonLd(D, lang, BASE) }),
    bodyHtml: S.landing(D, lang), anchors: true,
    extraHead: `<link rel="preload" as="image" href="${D.hero.image}" fetchpriority="high">`,
  });
  fs.writeFileSync(path.join(WEB, file), html);
  console.log("wrote", file, html.length);
}

// ---------------------------------------------------------------- صفحات الأقسام المستقلة (عربي: /features ... ، إنجليزي: /en/features ...)
const secUrls = [];
for (const lang of ["ar", "en"]) {
  for (const key of S.PAGES) {
    if (D.sections && D.sections[key] === false) continue;
    const slug = S.SLUG[key], file = lang === "en" ? path.join("en", slug + ".html") : slug + ".html";
    const url = BASE + (lang === "en" ? "en/" : "") + slug, alt = BASE + (lang === "en" ? "" : "en/") + slug;
    const [title, desc] = S.META[key][lang];
    const crumbs = { "@type": "BreadcrumbList", itemListElement: [
      { "@type": "ListItem", position: 1, name: D.brand[`name_${lang}`], item: lang === "en" ? BASE + "en" : BASE },
      { "@type": "ListItem", position: 2, name: title.split(":")[0], item: url }] };
    const graph = [{ "@type": "WebPage", name: title, description: desc, url, inLanguage: lang, isPartOf: { "@type": "WebSite", url: BASE, name: D.brand[`name_${lang}`] } }, crumbs];
    if (key === "faq") graph.push({ "@type": "FAQPage", mainEntity: (D.faq || []).map((f) => ({ "@type": "Question", name: f[`q_${lang}`], acceptedAnswer: { "@type": "Answer", text: f[`a_${lang}`] } })) });
    if (key === "how") graph.push({ "@type": "HowTo", name: S.T[lang].how_t, step: (D.steps || []).map((x, i) => ({ "@type": "HowToStep", position: i + 1, name: x[`t_${lang}`], text: x[`d_${lang}`] })) });
    const ld = JSON.stringify({ "@context": "https://schema.org", "@graph": graph }).replace(/</g, "\\u003c");
    const html = page({
      lang, dir: lang === "en" ? "ltr" : "rtl", pageType: "landing", sec: key, base: lang === "en", skipHref: url + "#main",
      headHtml: head({ lang, title: `${title} | ${D.brand[`name_${lang}`]}`, desc, canonical: url,
        alts: [[lang, url], [lang === "en" ? "ar" : "en", alt], ["x-default", lang === "en" ? alt : url]], ogImage: D.seo.og_image, jsonld: ld }),
      bodyHtml: S.landing(D, lang, key),
    });
    if (lang === "en") fs.mkdirSync(path.join(WEB, "en"), { recursive: true });
    fs.writeFileSync(path.join(WEB, file), html);
    secUrls.push([lang === "en" ? "en/" + slug : slug, lang === "en" ? slug : "en/" + slug, lang]);
    console.log("wrote", file, html.length);
  }
}

// ---------------------------------------------------------------- صفحات الوثائق (عربي مسبقاً، والإنجليزي ?lang=en)
for (const key of ["terms", "privacy", "guide"]) {
  const d = DOCS[key], file = key + ".html", slug = key;
  const firstPara = (d.ar.split("\n").find((l) => l.trim() && !/^[#>\-\d]/.test(l.trim())) || "").replace(/\*\*/g, "").slice(0, 155);
  const ld = JSON.stringify({ "@context": "https://schema.org", "@type": key === "guide" ? "TechArticle" : "WebPage", headline: d.title_ar, name: d.title_ar, inLanguage: "ar",
    dateModified: d.updated, url: BASE + slug, isPartOf: { "@type": "WebSite", url: BASE, name: D.brand.name_ar }, publisher: { "@type": "Organization", name: "Msar — مسار", url: BASE } }).replace(/</g, "\\u003c");
  const html = page({
    lang: "ar", dir: "rtl", pageType: "doc", docKey: key,
    headHtml: head({ lang: "ar", title: `${d.title_ar} — ${D.brand.name_ar} | ${d.title_en}`, desc: firstPara, canonical: BASE + slug,
      alts: [["ar", BASE + slug], ["en", `${BASE}${slug}?lang=en`], ["x-default", BASE + slug]], ogImage: D.seo.og_image, jsonld: ld, type: "article" }),
    bodyHtml: S.docPage(D, d, "ar"),
  });
  fs.writeFileSync(path.join(WEB, file), html);
  console.log("wrote", file, html.length);
}

// ---------------------------------------------------------------- sitemap / robots / llms.txt
const today = new Date().toISOString().slice(0, 10);
const urls = [
  ["", "en", "1.0", "weekly"], ["en", "", "0.9", "weekly"],
  ...["guide", "terms", "privacy"].flatMap((k) => [[k, `${k}?lang=en`, k === "guide" ? "0.8" : "0.4", "monthly"], [`${k}?lang=en`, k, k === "guide" ? "0.7" : "0.3", "monthly"]]),
  ...secUrls.map(([u, alt]) => [u, alt, "0.8", "weekly"]),
  ["support", null, "0.4", "monthly"],
];
const x = (u) => u.replace(/&/g, "&amp;");
const isEn = (u) => u === "en" || u.startsWith("en/") || u.includes("lang=en");
fs.writeFileSync(path.join(WEB, "sitemap.xml"), `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${urls.map(([u, alt, p, f]) => `  <url><loc>${x(BASE + u)}</loc><lastmod>${today}</lastmod><changefreq>${f}</changefreq><priority>${p}</priority>${alt !== null ? `
    <xhtml:link rel="alternate" hreflang="${isEn(u) ? "en" : "ar"}" href="${x(BASE + u)}"/><xhtml:link rel="alternate" hreflang="${isEn(u) ? "ar" : "en"}" href="${x(BASE + alt)}"/>` : ""}</url>`).join("\n")}
</urlset>
`);
fs.writeFileSync(path.join(WEB, "robots.txt"), `User-agent: *
Allow: /
Disallow: /app
Disallow: /owner
Disallow: /driver
Disallow: /setup
Disallow: /join
Disallow: /reset
Disallow: /msg
Disallow: /track
Disallow: /setup/

Sitemap: ${BASE}sitemap.xml
`);
const L = (o, k, l) => o[`${k}_${l}`];
fs.writeFileSync(path.join(WEB, "llms.txt"), `# ${D.brand.name_en} (${D.brand.name_ar}) — ${D.brand.tagline_en}

> ${D.seo.desc_en}

${D.seo.desc_ar}

## What Msar does
${D.features.map((f) => `- **${f.t_en}**: ${f.d_en}`).join("\n")}

## How it works
${D.steps.map((s, i) => `${i + 1}. ${s.t_en} — ${s.d_en}`).join("\n")}

## Who it's for
${D.roles.map((r) => `- ${r.t_en}: ${r.en.join("; ")}`).join("\n")}

## Pricing (SAR / month, excl. VAT)
${D.pricing.plans.map((p) => `- ${p.name_en}: ${p.price === null ? "custom" : p.price + " SAR"} — ${p.f_en.join(", ")}`).join("\n")}
${D.pricing.note_en}

## FAQ
${D.faq.map((f) => `### ${f.q_en}\n${f.a_en}`).join("\n\n")}

## Arabic FAQ
${D.faq.map((f) => `### ${f.q_ar}\n${f.a_ar}`).join("\n\n")}

## Links
- Home (Arabic): ${BASE}
- Home (English): ${BASE}en
${S.PAGES.map((k) => `- ${S.META[k].en[0]}: ${BASE}en/${S.SLUG[k]}`).join("\n")}
- User guide: ${BASE}guide?lang=en
- Terms: ${BASE}terms?lang=en
- Privacy: ${BASE}privacy?lang=en
- Contact: ${D.links.email}
`);
console.log("wrote sitemap.xml robots.txt llms.txt");
