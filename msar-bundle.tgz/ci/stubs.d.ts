// أنواع وهمية لفحص دوال Supabase (Deno) بـ TypeScript بدون Deno
declare module "jsr:@supabase/supabase-js@2" { export function createClient(...a: any[]): any; }
declare const Deno: { env: { get(k: string): string | undefined }; serve(h: (req: Request) => Promise<Response> | Response): void };
