#!/usr/bin/env bash
# مسار — بناء الموقع + تطبيق المندوب APK (يُشغَّل تلقائياً من GitHub Actions)
set -euxo pipefail
ROOT="$(pwd)"
RUN_NUMBER="${RUN_NUMBER:-1}"

# ---------------------------------------------------------------- 1) المكتبات
mkdir -p /tmp/v && cd /tmp/v && npm init -y >/dev/null
npm i --no-audit --no-fund @supabase/supabase-js@2.45.4 leaflet@1.9.4 xlsx@0.18.5
cd "$ROOT"
mkdir -p web/vendor/leaflet
cp /tmp/v/node_modules/@supabase/supabase-js/dist/umd/supabase.js web/vendor/supabase.js
cp -r /tmp/v/node_modules/leaflet/dist/* web/vendor/leaflet/
cp /tmp/v/node_modules/xlsx/dist/xlsx.full.min.js web/vendor/xlsx.full.min.js
ls -la web/vendor

# صفحات الموقع التعريفي (SEO): توليد مسبق من المحتوى الافتراضي
node ci/prerender.js "${SITE_URL:-https://msarpro.com/}"

# كسر الكاش: كل نشر يضيف رقم إصدار لملفات js/css عشان التحديث يوصل للمستخدمين فوراً
python3 - "$RUN_NUMBER" <<'PY'
import re, glob, sys
v = sys.argv[1]
for f in glob.glob("web/*.html"):
    s = open(f, encoding="utf-8").read()
    s2 = re.sub(r'((?:src|href)=")((?:js|css)/[^"?#]+\.(?:js|css))(")', lambda m: f"{m.group(1)}{m.group(2)}?v={v}{m.group(3)}", s)
    if s2 != s: open(f, "w", encoding="utf-8").write(s2); print("versioned", f)
PY

# أصوات التنبيه
python3 ci/make_sounds.py web/sounds

# ---------------------------------------------------------------- 2) مشروع أندرويد (Capacitor)
cd "$ROOT/android"
npm install --no-audit --no-fund
rm -rf www && mkdir www
cp -r ../web/* www/
cp www/driver.html www/index.html
rm -f www/sw.js www/manifest.json
npx cap add android
mkdir -p android/app/src/main/res/raw && cp ../web/sounds/driver.wav android/app/src/main/res/raw/msar_driver.wav
mkdir -p assets && cp icon.png assets/icon-only.png
npx capacitor-assets generate --android --iconBackgroundColor "#ffffff" --splashBackgroundColor "#ffffff" || echo "assets generation skipped"

python3 - <<'PY'
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
perms = """
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
    <uses-permission android:name="android.permission.FOREGROUND_SERVICE_LOCATION" />
    <uses-permission android:name="android.permission.POST_NOTIFICATIONS" />
    <uses-permission android:name="android.permission.WAKE_LOCK" />
    <uses-permission android:name="android.permission.VIBRATE" />
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED" />
    <uses-feature android:name="android.hardware.location.gps" android:required="false" />
"""
tag = '<uses-permission android:name="android.permission.INTERNET" />'
assert tag in s, "INTERNET permission line not found"
s = s.replace(tag, tag + perms, 1)
open(p, "w", encoding="utf-8").write(s)
sp = "android/app/src/main/res/values/strings.xml"
t = open(sp, encoding="utf-8").read()
t = t.replace("</resources>", '    <string name="capacitor_background_geolocation_notification_channel_name">تتبع الموقع</string>\n</resources>')
open(sp, "w", encoding="utf-8").write(t)
PY

sed -i "s/versionCode 1$/versionCode ${RUN_NUMBER}/; s/versionName \"1.0\"/versionName \"1.0.${RUN_NUMBER}\"/" android/app/build.gradle
# إشعارات Push (Firebase): لو ملف android/google-services.json موجود نفعّلها، وإلا يبقى التطبيق يشتغل بالتنبيه المحلي فقط
cd "$ROOT/android"
if [ -s google-services.json ]; then
  cp google-services.json android/app/google-services.json
  echo 'window.MSAR_PUSH = true;' >> www/js/config.js
  echo "push enabled"
else
  echo "push disabled (no google-services.json)"
fi
npx cap sync android
cat android/app/src/main/AndroidManifest.xml

# ---------------------------------------------------------------- 3) بناء APK موقّع
cd "$ROOT/android/android"
chmod +x gradlew
./gradlew assembleRelease --no-daemon --stacktrace
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
"$BT/zipalign" -f -p 4 app/build/outputs/apk/release/app-release-unsigned.apk /tmp/aligned.apk
# مفتاح التوقيع من أسرار GitHub (KEYSTORE_B64 / KEYSTORE_PASS / KEYSTORE_ALIAS) — لا يُحفظ في المستودع
set +x
if [ -n "${KEYSTORE_B64:-}" ]; then
  printf '%s' "$KEYSTORE_B64" | base64 -d > /tmp/release.jks
  KS=/tmp/release.jks; KP="${KEYSTORE_PASS:?KEYSTORE_PASS secret missing}"; KA="${KEYSTORE_ALIAS:-msar}"
else
  echo "::error::أضف أسرار KEYSTORE_B64 و KEYSTORE_PASS في إعدادات المستودع (Settings → Secrets → Actions)"; exit 1
fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$KA" --ks-pass "pass:$KP" --key-pass "pass:$KP" \
  --out "$ROOT/web/msar-driver.apk" /tmp/aligned.apk
rm -f /tmp/release.jks
set -x
"$BT/apksigner" verify "$ROOT/web/msar-driver.apk"
ls -la "$ROOT/web/msar-driver.apk"

# ---------------------------------------------------------------- 4) ملفات الإعداد مع الموقع
cd "$ROOT"
mkdir -p web/setup && cp -r supabase/* web/setup/
REF=$(grep -o "https://[a-z0-9]*\.supabase\.co" web/js/config.js | head -1 | sed "s#https://##; s#\.supabase\.co##")
sed -i "s/__PROJECT_REF__/$REF/" web/setup/cron.sql
grep -n "functions_url" web/setup/cron.sql
