// مسار — توليد المدونة (صفحات ثابتة مسبقة التوليد للأرشفة SEO / GEO)
// يُستدعى من prerender.js. المقالات في ci/blog/*.js (عربي + إنجليزي في ملف واحد لكل مقال).
const fs = require("fs"), path = require("path");

const MONTHS = {
  ar: ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"],
  en: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
};
const fmtDate = (iso, lang) => { const [y, m, d] = iso.split("-").map(Number); return lang === "en" ? `${MONTHS.en[m - 1]} ${d}, ${y}` : `${d} ${MONTHS.ar[m - 1]} ${y}`; };

const TX = {
  ar: {
    blog: "المدونة", home: "الرئيسية", by: "فريق مسار برو", published: "نُشر", updated: "آخر تحديث", read: "دقيقة قراءة",
    tldr: "الخلاصة السريعة", faq: "أسئلة شائعة", sources: "المصادر", related: "مقالات ذات صلة", toc: "محتويات المقال",
    idx_t: "مدونة مسار برو: دليل التجار لتوصيل الطلبات وإدارة الفروع",
    idx_d: "مقالات عملية بمصادر موثّقة للمتاجر الإلكترونية في السعودية: طلبات واتساب، الدفع عند الاستلام، تكلفة التوصيل، تسعير التوصيل للعميل، إدارة المناديب، تأخر الطلبات، وتوجيه الطلبات بين الفروع.",
    idx_h: "مدونة مسار برو", idx_p: "مقالات عملية لأصحاب المتاجر الإلكترونية في السعودية. كل مقال يذكر مصادره، وما لم نجد له مصدراً موثقاً نكتب أنه غير متوفر بدل ما نخمّنه.",
    method: "كيف أُعدّ هذا المقال؟ جمعنا المعلومات من المصادر المذكورة أعلاه وقرأناها بتاريخ النشر. الأرقام والأحكام المنسوبة لجهة معيّنة وردت من صفحاتها، وما لم نجد له مصدراً موثقاً ذكرنا ذلك صراحةً. أُعدّ المقال بمساعدة أدوات ذكاء اصطناعي. وهو معلومات عامة وليس استشارة قانونية أو مالية، فراجع الجهة المختصة قبل أي قرار.",
    cta_t: "تبغى تطبّق هذا على متجرك؟", cta_p: "مسار برو يوجّه كل طلب لأقرب فرع ويتابع المناديب لحظة بلحظة.", cta_a: "شوف المميزات", cta_b: "شوف الأسعار",
    all: "كل المقالات", read_more: "اقرأ المقال", fig: "رسم توضيحي",
  },
  en: {
    blog: "Blog", home: "Home", by: "The Msar Pro team", published: "Published", updated: "Last updated", read: "min read",
    tldr: "Quick summary", faq: "Frequently asked questions", sources: "Sources", related: "Related articles", toc: "In this article",
    idx_t: "Msar Pro Blog: merchant guides to delivery and multi-branch order management",
    idx_d: "Practical, sourced articles for online stores in Saudi Arabia: WhatsApp orders, cash on delivery, delivery cost, delivery fee pricing, managing drivers, late orders, and routing orders between branches.",
    idx_h: "Msar Pro Blog", idx_p: "Practical articles for online store owners in Saudi Arabia. Every article lists its sources, and where we could not find a verifiable source we say so instead of guessing.",
    method: "How was this article prepared? We gathered the information from the sources listed above and read them on the publication date. Figures and rules attributed to an organization come from its own pages, and where we could not find a verifiable source we say so. The article was prepared with the help of AI tools. It is general information, not legal or financial advice; check with the relevant authority before deciding.",
    cta_t: "Want to apply this in your store?", cta_p: "Msar Pro routes every order to the nearest branch and tracks drivers in real time.", cta_a: "See features", cta_b: "See pricing",
    all: "All articles", read_more: "Read article", fig: "Illustration",
  },
};

const wc = (s) => String(s).split(/\s+/).filter(Boolean).length;

function table(rows, esc, inline) {
  const cells = (r) => r.replace(/^\||\|$/g, "").split("|").map((c) => c.trim());
  const head = cells(rows[0]), body = rows.slice(2).map(cells);
  return `<div class="tbl-wrap" tabindex="0"><table><thead><tr>${head.map((c) => `<th scope="col">${inline(c)}</th>`).join("")}</tr></thead><tbody>${body.map((r) => `<tr>${r.map((c) => `<td>${inline(c)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}

function figure(fig, lang, esc) {
  if (!fig) return "";
  const cap = `<figcaption>${esc(fig.caption)}</figcaption>`;
  if (fig.type === "flow") {
    return `<figure class="fig fig-flow" aria-label="${esc(fig.title)}"><ol class="flow">${fig.steps.map(([t, d], i) => `<li style="--i:${i}"><span class="flow-n" aria-hidden="true">${i + 1}</span><b>${esc(t)}</b><span>${esc(d)}</span></li>`).join("")}</ol>${cap}</figure>`;
  }
  if (fig.type === "map") {
    const L = fig.labels;
    const br = [[110, 70, L.a], [330, 52, L.b], [545, 92, L.c]];
    return `<figure class="fig fig-map"><svg viewBox="0 0 640 300" role="img" aria-labelledby="mt md"><title id="mt">${esc(fig.title)}</title><desc id="md">${esc(fig.desc)}</desc>
      <rect x="1" y="1" width="638" height="298" rx="18" fill="#F4F9FB" stroke="#e3eef3"/>
      ${br.map(([x, y], i) => `<line x1="320" y1="232" x2="${x}" y2="${y + 18}" stroke="${i === 1 ? "#73AE46" : "#9db3bb"}" stroke-width="${i === 1 ? 4 : 2}" ${i === 1 ? 'class="route-on"' : 'stroke-dasharray="6 6"'}/>`).join("")}
      ${br.map(([x, y, t], i) => `<g><rect x="${x - 54}" y="${y - 22}" width="108" height="40" rx="12" fill="${i === 1 ? "#73AE46" : "#fff"}" stroke="${i === 1 ? "#73AE46" : "#9db3bb"}"/><text x="${x}" y="${y + 3}" text-anchor="middle" font-size="15" font-weight="700" fill="${i === 1 ? "#fff" : "#144F74"}">${esc(t)}</text></g>`).join("")}
      <g><circle cx="320" cy="244" r="16" fill="#F5A126" class="pin"/><circle cx="320" cy="244" r="6" fill="#fff"/><text x="320" y="285" text-anchor="middle" font-size="15" font-weight="700" fill="#144F74">${esc(L.cust)}</text></g>
      <text x="${(320 + 330) / 2 + 12}" y="150" font-size="14" font-weight="700" fill="#4e7f24">${esc(L.near)}</text></svg>${cap}</figure>`;
  }
  return "";
}

module.exports = function build(ctx) {
  const { S, D, BASE, WEB, head, page, esc } = ctx;
  const dir = path.join(__dirname, "blog");
  const posts = fs.readdirSync(dir).filter((f) => f.endsWith(".js")).map((f) => require(path.join(dir, f)))
    .sort((a, b) => (a.order || 0) - (b.order || 0));
  const urlOf = (lang, slug) => BASE + (lang === "en" ? "en/" : "") + "blog" + (slug ? "/" + slug : "");
  const entries = [];
  const inline = (s) => S.md(s).html.replace(/^<p>|<\/p>$/g, "");
  fs.mkdirSync(path.join(WEB, "blog"), { recursive: true });
  fs.mkdirSync(path.join(WEB, "en", "blog"), { recursive: true });

  const org = { "@type": "Organization", "@id": BASE + "#org", name: "Msar Pro — مسار برو", url: BASE, logo: BASE + "icons/icon-512.png" };

  for (const lang of ["ar", "en"]) {
    const t = TX[lang], dirn = lang === "en" ? "ltr" : "rtl", other = lang === "en" ? "ar" : "en";
    // ---------------------------------------------------------------- المقالات
    for (const p of posts) {
      const a = p[lang], url = urlOf(lang, p.slug), alt = urlOf(other, p.slug);
      const tables = [];
      let src = a.body.replace(/(^\|.*\|\s*\n?)+/gm, (m) => { tables.push(m.trim().split("\n")); return `\n\n@@T${tables.length - 1}@@\n\n`; });
      const md = S.md(src);
      let html = md.html.replace(/<p>@@T(\d+)@@<\/p>/g, (_, i) => table(tables[+i], esc, inline));
      const toc = md.toc.filter((x) => x.lvl === 2);
      const tocAll = [{ id: "tldr", t: t.tldr }, ...toc, { id: "faq", t: t.faq }, { id: "sources", t: t.sources }];
      const words = wc(a.tldr.join(" ") + " " + a.body + " " + a.faq.map((f) => f.join(" ")).join(" "));
      const mins = Math.max(3, Math.round(words / (lang === "en" ? 210 : 170)));
      p._mins = p._mins || {}; p._mins[lang] = mins;
      const faqHtml = a.faq.map(([q, ans]) => `<h3>${esc(q)}</h3><p>${inline(ans)}</p>`).join("");
      const srcHtml = a.sources.map(([title, u, note]) => `<li><a href="${esc(encodeURI(u))}" target="_blank" rel="noopener">${esc(title)}</a> — ${esc(note)}</li>`).join("");
      const rel = posts.filter((x) => x.slug !== p.slug).slice(0, 3).map((x) => `<a class="bl-card" href="${lang === "en" ? "en/" : ""}blog/${x.slug}"><b>${esc(x[lang].title)}</b><span>${esc(x[lang].desc)}</span></a>`).join("");
      const ld = JSON.stringify({ "@context": "https://schema.org", "@graph": [org,
        { "@type": "BlogPosting", "@id": url + "#post", headline: a.title, description: a.desc, inLanguage: lang, url, mainEntityOfPage: url,
          datePublished: p.date, dateModified: p.updated || p.date, image: BASE + D.seo.og_image, keywords: a.keywords,
          author: { "@id": BASE + "#org" }, publisher: { "@id": BASE + "#org" }, isPartOf: { "@type": "Blog", "@id": urlOf(lang) + "#blog", name: t.idx_h, url: urlOf(lang) },
          citation: a.sources.map(([title, u]) => ({ "@type": "CreativeWork", name: title, url: encodeURI(u) })),
          about: a.about.map((n) => ({ "@type": "Thing", name: n })) },
        { "@type": "BreadcrumbList", itemListElement: [
          { "@type": "ListItem", position: 1, name: t.home, item: lang === "en" ? BASE + "en" : BASE },
          { "@type": "ListItem", position: 2, name: t.blog, item: urlOf(lang) },
          { "@type": "ListItem", position: 3, name: a.title, item: url }] },
        { "@type": "FAQPage", mainEntity: a.faq.map(([q, ans]) => ({ "@type": "Question", name: q, acceptedAnswer: { "@type": "Answer", text: ans.replace(/\*\*|\[([^\]]+)\]\([^)]+\)/g, "$1") } })) },
      ] }).replace(/</g, "\\u003c");
      const body = `${S.header(D, lang, false, alt)}<main id="main" class="docs"><div class="wrap doc-wrap">
        <aside class="doc-toc post-toc"><h4>${t.toc}</h4>${tocAll.map((x) => `<a href="#${x.id}">${esc(x.t)}</a>`).join("")}</aside>
        <article class="doc post" lang="${lang}"><nav class="crumbs" aria-label="breadcrumb"><a href="${lang === "en" ? "en" : "./"}">${t.home}</a> / <a href="${lang === "en" ? "en/" : ""}blog">${t.blog}</a> / <span>${esc(a.crumb || a.title)}</span></nav>
          <h1>${esc(a.title)}</h1>
          <p class="post-meta"><span>${esc(t.by)}</span> · <span>${t.published}: <time datetime="${p.date}">${fmtDate(p.date, lang)}</time></span> · <span>${t.updated}: <time datetime="${p.updated || p.date}">${fmtDate(p.updated || p.date, lang)}</time></span> · <span>${mins} ${t.read}</span></p>
          <section class="tldr" aria-labelledby="tldr"><h2 id="tldr">${t.tldr}</h2><ul>${a.tldr.map((x) => `<li>${inline(x)}</li>`).join("")}</ul></section>
          ${figure(a.fig, lang, esc)}
          ${html}
          <section class="post-faq" aria-labelledby="faq"><h2 id="faq">${t.faq}</h2>${faqHtml}</section>
          <section class="post-src" aria-labelledby="sources"><h2 id="sources">${t.sources}</h2><ol>${srcHtml}</ol><p class="method">${t.method}</p></section>
          <aside class="post-cta"><h2>${t.cta_t}</h2><p>${t.cta_p}</p><div><a class="btn-s btn-pri" href="${lang === "en" ? "en/features" : "features"}">${t.cta_a}</a> <a class="btn-s btn-ghost" href="${lang === "en" ? "en/pricing" : "pricing"}">${t.cta_b}</a></div></aside>
          <section class="post-rel" aria-labelledby="rel"><h2 id="rel">${t.related}</h2><div class="bl-grid">${rel}</div></section>
        </article></div></main>${S.footer(D, lang)}`;
      const file = path.join(WEB, lang === "en" ? "en" : "", "blog", p.slug + ".html");
      fs.writeFileSync(file, page({ lang, dir: dirn, pageType: "blog", base: true, skipHref: url + "#main",
        headHtml: head({ lang, title: `${a.title} | ${D.brand[`name_${lang}`]}`, desc: a.desc, keywords: a.keywords, canonical: url,
          alts: [[lang, url], [other, alt], ["x-default", urlOf("ar", p.slug)]], ogImage: D.seo.og_image, jsonld: ld, type: "article" }),
        bodyHtml: body }));
      console.log("wrote blog", lang, p.slug, words, "words");
      entries.push({ lang, slug: p.slug, url, alt, title: a.title, desc: a.desc, date: p.date });
    }
    // ---------------------------------------------------------------- فهرس المدونة
    const url = urlOf(lang), alt = urlOf(other);
    const cards = posts.map((p) => `<a class="bl-card bl-big" href="${lang === "en" ? "en/" : ""}blog/${p.slug}"><span class="bl-date"><time datetime="${p.date}">${fmtDate(p.date, lang)}</time> · ${p._mins[lang]} ${t.read}</span><b>${esc(p[lang].title)}</b><span>${esc(p[lang].desc)}</span><span class="bl-go">${t.read_more}</span></a>`).join("");
    const ld = JSON.stringify({ "@context": "https://schema.org", "@graph": [org,
      { "@type": "Blog", "@id": url + "#blog", name: t.idx_h, description: t.idx_d, url, inLanguage: lang, publisher: { "@id": BASE + "#org" },
        blogPost: posts.map((p) => ({ "@type": "BlogPosting", headline: p[lang].title, url: urlOf(lang, p.slug), datePublished: p.date })) },
      { "@type": "BreadcrumbList", itemListElement: [
        { "@type": "ListItem", position: 1, name: t.home, item: lang === "en" ? BASE + "en" : BASE },
        { "@type": "ListItem", position: 2, name: t.blog, item: url }] }] }).replace(/</g, "\\u003c");
    const body = `${S.header(D, lang, false, alt)}<main id="main" class="docs"><div class="wrap">
      <nav class="crumbs" aria-label="breadcrumb"><a href="${lang === "en" ? "en" : "./"}">${t.home}</a> / <span>${t.blog}</span></nav>
      <h1 class="bl-h1">${t.idx_h}</h1><p class="bl-lead">${t.idx_p}</p><div class="bl-grid bl-grid-big">${cards}</div></div></main>${S.footer(D, lang)}`;
    fs.writeFileSync(path.join(WEB, lang === "en" ? "en" : "", "blog.html"), page({ lang, dir: dirn, pageType: "blog", base: true, skipHref: url + "#main",
      headHtml: head({ lang, title: t.idx_t, desc: t.idx_d, canonical: url, alts: [[lang, url], [other, alt], ["x-default", urlOf("ar")]], ogImage: D.seo.og_image, jsonld: ld }),
      bodyHtml: body }));
    console.log("wrote blog index", lang);
  }
  return { posts, entries, urlOf, TX };
};
