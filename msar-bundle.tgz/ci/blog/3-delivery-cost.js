// مقال 3: تكلفة التوصيل — مندوبين خاصين أم شركات شحن
module.exports = {
  slug: "delivery-cost-own-drivers-vs-carriers", order: 3, date: "2026-11-18",
  ar: {
    title: "كم تكلفة التوصيل على متجرك؟ كيف تحسبها وتقارن بين المندوبين الخاصين وشركات الشحن",
    crumb: "تكلفة التوصيل",
    desc: "معادلة حساب تكلفة التوصيل للطلب الواحد، ومقارنة تقريبية لأسعار شركات شحن في السعودية بتاريخها ومصدرها، وما يقوله الإعلام عن اشتراطات هيئة النقل، وضريبة القيمة المضافة على التوصيل.",
    keywords: "تكلفة التوصيل, أسعار شركات الشحن في السعودية, مندوبين خاصين, هيئة النقل, ضريبة القيمة المضافة على التوصيل, تكلفة التوصيل للطلب, مسار برو",
    about: ["تكلفة التوصيل", "شركات الشحن في السعودية", "التوصيل بمندوبين خاصين"],
    tldr: [
      "تكلفة التوصيل للطلب = إجمالي تكاليف الميل الأخير ÷ عدد الطلبات المسلّمة في نفس الفترة.",
      "في مقارنة منشورة (يونيو 2025) تراوح سعر الشحنة الداخلية بين 10 و22.20 ريال بحسب الشركة، مع رسوم دفع عند الاستلام تختلف. المصدر وسيط وليس الشركات نفسها، فتحقق من الأسعار الحالية.",
      "وفق تقارير صحفية تنقل عن هيئة النقل، التوصيل بمركبات يملكها المتجر يحتاج ترخيص مركبات يناسب النشاط. لم نتمكن من قراءة النص الرسمي، فراجع الهيئة.",
      "نص دليل هيئة الزكاة للتجارة الإلكترونية لا ينص صراحةً على معاملة رسوم التوصيل المنفصلة، ويحيل لطلب قرار تفسيري.",
      "**مسار برو** لا يغيّر تكلفة المندوب، لكنه يعطيك صورة عن أداء المناديب والمسافات لتحسب تكلفتك الفعلية.",
    ],
    fig: {
      type: "flow", title: "مكونات تكلفة التوصيل للطلب", caption: "رسم توضيحي: المكونات التي تذكرها المصادر ضمن تكلفة الميل الأخير. أضف رسوم فشل التوصيل والتحصيل لحسابك.",
      steps: [["أجر المندوب", "راتب أو عمولة لكل طلب"], ["الوقود والمركبة", "وقود وصيانة وتأجير"], ["التأمين والتراخيص", "حسب نشاطك"], ["البرامج والإدارة", "تتبع وتوزيع وجزء من المصاريف"], ["الفشل والإرجاع", "طلب لم يُسلَّم أو رُفض"]],
    },
    body: `## كيف تحسب تكلفة التوصيل للطلب الواحد؟

المعادلة المتداولة في مصادر اللوجستيات (مثل قاموس SmartRoutes): **تكلفة التوصيل للطلب = إجمالي تكاليف الميل الأخير ÷ عدد الطلبات المسلّمة في نفس الفترة.** والمكونات التي تذكرها: أجر السائق، الوقود، المركبة (صيانة وتأجير)، التأمين، التغليف، برامج التوجيه، مناولة المستودع، ونصيب من المصاريف العامة. وبعض الحسابات تضيف تكلفة التوصيلات الفاشلة والمرتجعات.

مثال بأرقام **افتراضية** لتوضيح المعادلة فقط: لو كانت تكاليف شهر 2,000 ريال وسلّمت 100 طلب، فالتكلفة 20 ريالاً للطلب. أما رقمك الحقيقي فاحسبه من فواتيرك أنت.

## كم أسعار شركات الشحن تقريباً؟

أقرب جدول منشور وجدناه من **OTO** (وسيط يجمع شركات الشحن، وليس الشركات نفسها). التاريخ: 15 يونيو 2025، لشحنة داخلية بين الرياض وجدة بوزن 10-15 كجم. الصفحة نفسها تنبه إلى أن الأسعار تحتاج تحديثاً، فاعتبرها **تقديرية**:

| الشركة | سعر الشحنة (ريال) | رسوم الدفع عند الاستلام (ريال) |
|---|---|---|
| OMNI | 10 | 8 |
| SPL | 14 | 8 |
| Shipa | 17 | 3 |
| J&T | 18 | 8 |
| Aramex | 19.26 | 6 |
| Naqel | 19.80 | 14 |
| SMSA | 22.20 | غير متاح |

تنبيه من المصدر: الشركات تحاسب على **الوزن الحجمي** (الطول × العرض × الارتفاع ÷ 5000) إذا كان أعلى من الوزن الفعلي. لم نجد صفحات أسعار رسمية للشركات، وعقود التجار غالباً تختلف عن الأسعار المعلنة.

## هل يسمح النظام بتوصيل المتجر بمندوبين خاصين؟

النص الرسمي لتنظيم هيئة النقل ما انفتح معنا، فنعتمد على تقارير صحفية تنقل عن الهيئة، **وتحقق منها مباشرة مع الهيئة**:

- ذكرت **Zawya** أن المتجر الذي يبيع منتجاته ويوصلها بمركبات يملكها يحتاج ترخيص مركبات يتوافق مع النشاط، وأن استخدام مركبات الغير يتطلب التعاقد مع شركات نقل مرخصة. ومن يبيع منتجات لا يملكها يحتاج ترخيص "توصيل الطلبات" وتراخيص المركبات.
- ذكرت **Gulf News** (5 أبريل 2024) أن العاملين غير السعوديين في التوصيل يعملون عبر شركات مرخصة (مع فترة انتقالية 14 شهراً)، وأن السعوديين يمكنهم العمل لحسابهم، مع تحقق بالوجه مرتبط بالهيئة وزيّ موحّد.

لا يتناول المصدران حالة سائقي المتجر بالتحديد، لذلك لا نقدر نقول إن التوصيل بمندوبين خاصين مسموح أو ممنوع بإطلاق. هذه نقطة امتثال تحتاج جواباً من الهيئة.

## ماذا عن ضريبة القيمة المضافة على التوصيل؟

دليل هيئة الزكاة والضريبة والجمارك للتجارة الإلكترونية يعامل توصيل المورّد جزءاً من توريد واحد للسلع، والتوصيل المجاني عنصراً ثانوياً وليس توريداً مستقلاً. لكنه **لا ينص صراحةً** على كيفية فرض الضريبة على رسوم توصيل تُحصَّل بشكل منفصل، ويحيل لطلب "قرار تفسيري" من الهيئة. لذلك لا نقول إن 15% تنطبق على الرسوم؛ استشر محاسبك.

## متى المندوب الخاص ومتى شركة الشحن؟

هذا تحليلنا العام وليس من دراسة:

- **المندوب الخاص** يناسب التوصيل داخل المدينة وفي نفس اليوم، لأنك تتحكم بالجودة والوقت، بشرط الاستيفاء النظامي.
- **شركة الشحن** تناسب المسافات الطويلة والأحجام الصغيرة والطلبات المتفرقة بين المدن.
- كثير من المتاجر تجمع الاثنين، وتحسب لكل خيار تكلفته الفعلية.

وهنا يفيدك **مسار برو**: يوزّع الطلب على أقرب فرع بحسب موقع العميل، فتقل المسافة التي يقطعها المندوب، ويعطيك الخريطة وسجل المناديب لتحسب تكلفة التوصيل الفعلية بدل التخمين.

بعد ما تعرف تكلفتك، اقرأ [كيف تسعّر التوصيل لعملائك](blog/delivery-fee-pricing-for-customers)، و[كيف تدير مناديبك الخاصين](blog/managing-own-delivery-drivers).`,
    faq: [
      ["ما معادلة تكلفة التوصيل للطلب؟", "إجمالي تكاليف الميل الأخير (أجر السائق والوقود والمركبة والتأمين والبرامج والمصاريف) مقسوماً على عدد الطلبات المسلّمة في نفس الفترة."],
      ["كم تكلفة الشحن الداخلي في السعودية؟", "في جدول منشور في يونيو 2025 من وسيط الشحن OTO تراوحت بين 10 و22.20 ريال لشحنة 10-15 كجم بين الرياض وجدة. الأرقام تقديرية وتحتاج تحقق من الشركات."],
      ["هل أقدر أوصل بمندوبين تابعين للمتجر؟", "بحسب تقارير صحفية تنقل عن هيئة النقل، التوصيل بمركبات المتجر يحتاج ترخيصاً يناسب النشاط. لم نتحقق من النص الرسمي، فراجع الهيئة."],
      ["هل أضيف 15% على رسوم التوصيل؟", "دليل الهيئة لا ينص صراحةً على رسوم التوصيل المنفصلة ويحيل لقرار تفسيري. استشر محاسباً."],
      ["هل **مسار برو** يخفض تكلفة التوصيل؟", "لا نعد بنسبة. يوجّه الطلب لأقرب فرع ويعرض أداء المناديب والمسافات، وهذا يساعدك على قياس تكلفتك وتحسينها."],
    ],
    sources: [
      ["SmartRoutes: Cost per delivery", "https://smartroutes.io/glossary/cost-per-delivery/", "معادلة تكلفة التوصيل ومكوناتها"],
      ["OTO: أرخص شركة شحن داخلي في السعودية (15 يونيو 2025)", "https://www.tryoto.com/otopedia/blog/ارخص-شركة-شحن-داخلي-في-السعودية", "أسعار شحن ورسوم دفع عند الاستلام تقديرية والوزن الحجمي"],
      ["Zawya: Saudi TGA warns of penalizing delivery apps...", "https://www.zawya.com/en/world/middle-east/saudi-tga-warns-of-penalizing-delivery-apps-that-ship-their-products-through-unlicensed-carriers-i8eo2zsq", "اشتراطات التراخيص كما نقلت عن هيئة النقل (غير مؤرخة)"],
      ["Gulf News: Saudi Arabia new rules for delivery services sector take effect", "https://gulfnews.com/amp/world/gulf/saudi/saudi-arabia-new-rules-for-delivery-services-sector-take-effect-1.101979587", "قواعد عمال التوصيل (5 أبريل 2024)"],
      ["ZATCA: Guideline on Electronic Commerce under VAT Provisions", "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/Guideline-on-Electronic-Commerce-under-VAT-Provisions.pdf", "معاملة التوصيل ضمن التوريد، والإحالة للقرار التفسيري"],
    ],
  },
  en: {
    title: "What does delivery cost your store? How to calculate it and compare own drivers with carriers",
    crumb: "Delivery cost",
    desc: "A formula for delivery cost per order, a rough comparison of Saudi carrier prices with their date and source, what the press reports about Transport General Authority requirements, and VAT on delivery.",
    keywords: "delivery cost, carrier prices Saudi Arabia, own delivery drivers, Transport General Authority, VAT on delivery, cost per delivery, Msar Pro",
    about: ["delivery cost", "shipping companies in Saudi Arabia", "own-driver delivery"],
    tldr: [
      "Cost per delivery = total last-mile costs ÷ deliveries completed in the same period.",
      "In a published comparison (June 2025) domestic shipment prices ranged from SAR 10 to 22.20 depending on the carrier, with different cash-on-delivery fees. The source is an aggregator, not the carriers, so verify current prices.",
      "Per press reports quoting the Transport General Authority, delivering with vehicles the store owns needs a vehicle license matching the activity. We could not read the official text, so check with the Authority.",
      "ZATCA's e-commerce VAT guideline does not explicitly address a separately charged delivery fee and points to requesting an interpretive decision.",
      "**Msar Pro** does not change what a driver costs, but it gives you driver performance and distances so you can compute your real cost.",
    ],
    fig: {
      type: "flow", title: "Components of delivery cost per order", caption: "Illustration: the components sources list within last-mile cost. Add failed-delivery and collection costs for your own case.",
      steps: [["Driver pay", "Salary or per-order commission"], ["Fuel and vehicle", "Fuel, maintenance, leasing"], ["Insurance and licenses", "Depending on your activity"], ["Software and admin", "Tracking, dispatch and a share of overhead"], ["Failures and returns", "Orders not delivered or refused"]],
    },
    body: `## How do you calculate delivery cost per order?

The widely used formula in logistics sources (for example SmartRoutes' glossary): **cost per delivery = total last-mile costs ÷ deliveries completed in the same period.** The components it lists: driver labor, fuel, vehicle (maintenance and leasing), insurance, packaging, routing software, depot handling and a share of overhead. Some calculations add the cost of failed deliveries and returns.

An example with **hypothetical** numbers, only to illustrate the formula: if a month's costs are SAR 2,000 and you delivered 100 orders, cost is SAR 20 per order. Calculate your real number from your own invoices.

## Roughly how much do carriers charge?

The closest published table we found is from **OTO** (an aggregator of carriers, not the carriers themselves). It is dated June 15, 2025, for a domestic Riyadh–Jeddah shipment of 10-15 kg. The page itself says its prices need updating, so treat them as **indicative**:

| Carrier | Shipment price (SAR) | Cash-on-delivery fee (SAR) |
|---|---|---|
| OMNI | 10 | 8 |
| SPL | 14 | 8 |
| Shipa | 17 | 3 |
| J&T | 18 | 8 |
| Aramex | 19.26 | 6 |
| Naqel | 19.80 | 14 |
| SMSA | 22.20 | not available |

A note from the source: carriers charge by **dimensional weight** (length × width × height ÷ 5000) when it is higher than actual weight. We found no official carrier rate pages, and merchant contracts often differ from public prices.

## Are stores allowed to deliver with their own drivers?

The official Transport General Authority regulation text would not load for us, so we rely on press reports quoting the Authority, **and you should verify directly with it**:

- **Zawya** reported that a store selling its own products and delivering them with vehicles it owns needs a vehicle license matching the activity, and that using third-party vehicles requires contracting licensed transport companies. A business selling products it does not own needs a "delivery of orders" license plus vehicle licenses.
- **Gulf News** (April 5, 2024) reported that non-Saudi delivery workers must work through licensed companies (with a 14-month transition), while Saudis may be self-employed, with face verification linked to the Authority and a uniform.

Neither source addresses a store's own drivers specifically, so we cannot say that own-driver delivery is allowed or banned outright. This is a compliance point that needs an answer from the Authority.

## What about VAT on delivery?

The Zakat, Tax and Customs Authority's e-commerce guideline treats a supplier's delivery as part of a single supply of the goods, and free delivery as a secondary element rather than a separate supply. But it **does not explicitly state** how a separately collected delivery fee is taxed, and refers to requesting an "interpretive decision" from the Authority. So we do not claim 15% applies to the fee; consult your accountant.

## When do own drivers make sense, and when do carriers?

This is our general analysis, not from a study:

- **Own drivers** suit in-city and same-day delivery, because you control quality and timing, provided you meet the regulatory requirements.
- **Carriers** suit long distances, small volumes and scattered intercity orders.
- Many stores combine both and compute each option's real cost.

This is where **Msar Pro** helps: it routes each order to the nearest branch by customer location, which shortens the distance a driver covers, and it gives you the map and driver records to compute real delivery cost instead of guessing.

Once you know your cost, read [how to price delivery for your customers](en/blog/delivery-fee-pricing-for-customers) and [how to manage your own drivers](en/blog/managing-own-delivery-drivers).`,
    faq: [
      ["What is the formula for delivery cost per order?", "Total last-mile costs (driver pay, fuel, vehicle, insurance, software, overhead) divided by deliveries completed in the same period."],
      ["How much does domestic shipping cost in Saudi Arabia?", "In a June 2025 table from the shipping aggregator OTO, prices ranged from SAR 10 to 22.20 for a 10-15 kg Riyadh–Jeddah shipment. The figures are indicative and need verification with carriers."],
      ["Can I deliver with drivers who work for my store?", "Per press reports quoting the Transport General Authority, delivery with store-owned vehicles needs a license matching the activity. We did not verify the official text, so check with the Authority."],
      ["Should I add 15% VAT to delivery fees?", "The Authority's guideline does not explicitly address separately charged delivery fees and points to an interpretive decision. Ask an accountant."],
      ["Does **Msar Pro** reduce delivery cost?", "We do not promise a percentage. It routes orders to the nearest branch and shows driver performance and distances, which helps you measure and improve your cost."],
    ],
    sources: [
      ["SmartRoutes: Cost per delivery", "https://smartroutes.io/glossary/cost-per-delivery/", "Cost-per-delivery formula and components"],
      ["OTO: cheapest domestic shipping company in Saudi Arabia (June 15, 2025)", "https://www.tryoto.com/otopedia/blog/ارخص-شركة-شحن-داخلي-في-السعودية", "Indicative shipment prices, COD fees and dimensional weight"],
      ["Zawya: Saudi TGA warns of penalizing delivery apps...", "https://www.zawya.com/en/world/middle-east/saudi-tga-warns-of-penalizing-delivery-apps-that-ship-their-products-through-unlicensed-carriers-i8eo2zsq", "Licensing requirements as quoted from the Transport General Authority (undated)"],
      ["Gulf News: Saudi Arabia new rules for delivery services sector take effect", "https://gulfnews.com/amp/world/gulf/saudi/saudi-arabia-new-rules-for-delivery-services-sector-take-effect-1.101979587", "Rules for delivery workers (April 5, 2024)"],
      ["ZATCA: Guideline on Electronic Commerce under VAT Provisions", "https://zatca.gov.sa/en/HelpCenter/guidelines/Documents/Guideline-on-Electronic-Commerce-under-VAT-Provisions.pdf", "Treatment of delivery within a supply, and the interpretive-decision referral"],
    ],
  },
};
