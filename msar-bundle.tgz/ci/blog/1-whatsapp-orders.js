// مقال 1: استقبال طلبات المتجر عبر واتساب. (لا يذكر أي منصة تجارة بعينها — صفحة عامة عن واتساب)
module.exports = {
  slug: "whatsapp-orders-for-online-stores", order: 1, date: "2026-11-18",
  ar: {
    title: "كيف تستقبل طلبات متجرك عبر واتساب وتنظّمها؟ دليل عملي بقواعد ميتا الفعلية",
    crumb: "طلبات واتساب للمتاجر",
    desc: "الفرق بين تطبيق واتساب للأعمال ومنصة واتساب (API)، وكيف تُحسب الرسائل، وقواعد ميتا للقوالب والموافقة، وخطوات عملية لتنظيم الطلبات وتوزيعها على الفروع.",
    keywords: "طلبات واتساب, واتساب للأعمال, منصة واتساب API, قوالب واتساب, نافذة 24 ساعة, استقبال الطلبات عبر واتساب, مسار برو",
    about: ["WhatsApp Business Platform", "الطلب عبر واتساب", "إدارة الطلبات"],
    tldr: [
      "كثير من المتاجر في السعودية تستقبل الطلبات في واتساب، لكن إدارتها يدوياً تتعب مع زيادة الطلبات والفروع.",
      "ميتا تفرّق بين **تطبيق واتساب للأعمال** و**منصة واتساب للأعمال** الموجّهة للشركات التي تريد أتمتة وربط بأنظمتها.",
      "منذ 1 يوليو 2025 تُحسب رسائل المنصة **لكل رسالة**، والتسعير يختلف حسب نوع الرسالة والدولة، وللسعودية سعر سوق خاص.",
      "خارج نافذة الـ24 ساعة بعد رسالة العميل لا تُرسل إلا **قوالب معتمدة** من ميتا.",
      "**مسار برو** يعمل على خدمة الطلب عبر واتساب وتوزيع الطلب على أقرب فرع، وهي حالياً \"قريباً\" وغير متاحة للتجار بعد.",
    ],
    fig: {
      type: "flow", title: "مسار الطلب عبر واتساب", caption: "رسم توضيحي: مراحل الطلب عبر واتساب من رسالة العميل حتى التسليم.",
      steps: [["رسالة العميل", "يتصفح الأقسام ويختار أصنافه"], ["تأكيد الطلب", "موقع العميل، الدفع، وملخص الطلب"], ["توجيه للفرع", "الطلب يصل لأقرب فرع"], ["تحديثات الحالة", "قوالب إشعار بالتجهيز والتوصيل"], ["التسليم", "تأكيد التسليم وسجل الطلب"]],
    },
    body: `## ما الفرق بين تطبيق واتساب للأعمال ومنصة واتساب للأعمال؟

**تطبيق واتساب للأعمال** هو التطبيق الذي تستخدمه من جوالك للرد على العملاء. أما **منصة واتساب للأعمال (Business Platform)** فهي واجهات برمجية (API) تصفها ميتا بأنها موجهة للشركات لإدارة التفاعل والتسويق والتجارة والدعم، وتتيح قوالب رسائل معتمدة، ومسارات آلية، وربطاً مع أنظمة الشركة مثل إدارة العملاء والخلفية. التركيب يتم مباشرة (برقم وفريق تطوير) أو عبر شريك معتمد.

اللي يهم التاجر: التطبيق مناسب للبداية، لكن لما تصير الطلبات كثيرة وتحتاج أن يصل الطلب تلقائياً لفرع معيّن ويتتبعه أكثر من موظف، تحتاج نظاماً يعتمد على المنصة.

## كيف تُحسب رسائل المنصة؟

بحسب صفحة التسعير الرسمية لميتا (قرأناها بتاريخ النشر):

- من 1 يوليو 2025 صار التسعير **لكل رسالة** بدل التسعير حسب المحادثة.
- فئات رسائل القوالب ثلاث: **تسويقية** و**خدمية (Utility)** و**توثيق (Authentication)**.
- السعر يختلف حسب الفئة وحجم الاستخدام والدولة، وللسعودية (+966) سعر سوق خاص. ذكرت ميتا خفض أسعار الرسائل الخدمية والتوثيق للسعودية اعتباراً من 1 أكتوبر 2025، وإتاحة الريال كعملة فوترة للحسابات الجديدة من 1 أبريل 2026.
- الأسعار تتغير فقط في 1 يناير و1 أبريل و1 يوليو و1 أكتوبر، بإشعار شهر على الأقل.
- عندما يراسلك العميل تُفتح **نافذة خدمة 24 ساعة**، والرد ضمنها لا يُحاسب. وإذا جاء العميل من إعلان "انقر للمحادثة في واتساب" أو زر صفحة فيسبوك تُفتح نافذة 72 ساعة للرسائل المجانية.

> لم نذكر أرقام الريال هنا لأن جداول الأسعار في صفحة ميتا تفاعلية وما قدرنا نتحقق منها. ارجع للجدول الرسمي الحالي قبل أي حساب.

## ما قواعد ميتا قبل أن تستقبل الطلبات؟

القواعد من سياسة واتساب للأعمال وصفحات ميتا للمطورين:

- راسل فقط من أعطاك رقمه ووافق على استقبال رسائلك (opt-in)، وأعطه طريقة للإيقاف والتزم بها.
- ابدأ المحادثة خارج نافذة الـ24 ساعة بـ**قالب معتمد** يُستخدم للغرض المحدد له فقط. ميتا قد تراجع القوالب أو توقفها أو ترفضها.
- الأتمتة مسموحة بشرط أن يجد العميل طريقاً لموظف بشري أو اتصال أو إيميل.
- واتساب **لا يعالج الدفع ولا ينفذ الطلبات**؛ الشروط والمدفوعات والضرائب مسؤوليتك.
- لا تطلب ولا تشارك أرقام بطاقات كاملة أو أرقام حسابات أو هويات.
- ممنوعات تشمل: الأسلحة والتبغ والأدوية الموصوفة والمنتجات الطبية والعملات والمنتجات الجنسية وغيرها. راجع القائمة الكاملة قبل ما تبيع.
- المخالفات تبدأ بتنبيهات ثم قد تصل إلى إيقاف مؤقت للإرسال.

عن حماية البيانات في السعودية: لم نتمكن من قراءة النص الرسمي لنظام حماية البيانات الشخصية أثناء إعداد المقال، فتحقق من موقع الهيئة السعودية للبيانات والذكاء الاصطناعي (سدايا) بخصوص الموافقة على الرسائل.

## ما مشاكل استقبال الطلبات يدوياً؟

ما وجدنا دراسة موثقة تقيس مشاكل الطلب اليدوي عبر واتساب، فهذا القسم **قراءتنا العملية** وليس نتيجة بحث:

- الطلب يضيع بين المحادثات ولا يوجد رقم موحّد له.
- موقع العميل يُكتب نصاً بدل دبوس دقيق، فيتأخر الفرع في الوصول.
- موظفان يردان على نفس العميل بمعلومات مختلفة.
- لا يوجد سجل بحالة الطلب، فيسأل العميل "وين طلبي؟".

## كيف تنظّم الطلبات عبر واتساب خطوة بخطوة؟

1. أعطِ كل طلب **رقماً** وسجّله في مكان واحد مشترك بين الفريق.
2. اطلب **موقع العميل** بدبوس الخريطة لا بوصف نصي.
3. أرسل ملخصاً (الأصناف والمبلغ وطريقة الدفع) واطلب تأكيداً صريحاً.
4. وجّه الطلب لأقرب فرع بدل ما يقرر الموظف بالتقدير.
5. أرسل تحديثات الحالة بقوالب خدمية معتمدة (قيد التجهيز، خرج للتوصيل).
6. سجّل التسليم، وراجع الطلبات المتأخرة يومياً.

## أين يأتي مسار برو من هذا؟

**مسار برو** يعمل على إضافة الطلب عبر واتساب: العميل يتصفح الأقسام ويختار الأصناف ويؤكد داخل المحادثة، والطلب يدخل نظام مسار برو ويُوجَّه لأقرب فرع ويظهر على شاشة الكاشير. الخدمة حالياً **قريباً** ولم تُفتح للتجار بعد، ونحدّث هذا المقال عند إطلاقها. المقال أعلاه يصلح لك سواء استخدمت مسار برو أو غيره.`,
    faq: [
      ["هل أحتاج منصة واتساب (API) أم يكفيني تطبيق الأعمال؟", "التطبيق يكفي في البداية بطلبات قليلة. تحتاج المنصة عندما تريد قوالب معتمدة وأتمتة وربطاً بنظام يوزّع الطلبات على الفروع، لأنها الواجهة الموجّهة للشركات بحسب ميتا."],
      ["هل الرد على العميل مجاني؟", "الرد داخل نافذة الخدمة (24 ساعة من آخر رسالة للعميل) لا يُحاسب بحسب ميتا. الرسائل التي تبدأها خارج النافذة تحتاج قالباً معتمداً ويُحاسب حسب فئته."],
      ["كم سعر الرسالة في السعودية؟", "للسعودية سعر سوق خاص يختلف حسب فئة الرسالة وحجم الاستخدام، ولم نتمكن من التحقق من أرقام الريال، فارجع لجدول أسعار ميتا الرسمي."],
      ["هل أقدر أبيع أي منتج عبر واتساب؟", "لا. لميتا قائمة ممنوعات تشمل الأسلحة والتبغ والأدوية الموصوفة والمنتجات الطبية والعملات وغيرها."],
      ["هل خدمة الطلب عبر واتساب من مسار برو متاحة الآن؟", "لا، هي قريباً. سنعلن عنها في موقع **مسار برو** ونحدّث المقال عند الإطلاق."],
    ],
    sources: [
      ["WhatsApp Business Platform — whatsappbusiness.com", "https://whatsappbusiness.com/products/business-platform/", "تعريف المنصة وقوالب الرسائل والربط مع الأنظمة"],
      ["WhatsApp Business Platform pricing — whatsappbusiness.com", "https://whatsappbusiness.com/products/platform-pricing/", "نافذة الخدمة 24 ساعة ونافذة 72 ساعة"],
      ["Pricing on the WhatsApp Business Platform — Meta for Developers", "https://developers.facebook.com/docs/whatsapp/pricing", "التسعير لكل رسالة وفئات القوالب وسعر السعودية (قُرئت في 18 نوفمبر 2026)"],
      ["WhatsApp Business Messaging Policy — whatsappbusiness.com", "https://whatsappbusiness.com/policy/", "الموافقة على الرسائل والقوالب والأتمتة والممنوعات"],
      ["Policy enforcement — Meta for Developers", "https://developers.facebook.com/docs/whatsapp/overview/policy-enforcement/violations", "آلية التنبيه والإيقاف عند المخالفة"],
    ],
  },
  en: {
    title: "How to receive and organize store orders on WhatsApp: a practical guide based on Meta's actual rules",
    crumb: "WhatsApp orders for stores",
    desc: "The difference between the WhatsApp Business app and the WhatsApp Business Platform (API), how messages are priced, Meta's template and consent rules, and practical steps to organize orders and route them to branches.",
    keywords: "WhatsApp orders, WhatsApp Business, WhatsApp Business Platform API, message templates, 24-hour window, taking orders on WhatsApp, Msar Pro",
    about: ["WhatsApp Business Platform", "WhatsApp ordering", "order management"],
    tldr: [
      "Many stores in Saudi Arabia take orders on WhatsApp, but handling them by hand gets hard as orders and branches grow.",
      "Meta separates the **WhatsApp Business app** from the **WhatsApp Business Platform**, which is aimed at companies that want automation and integration with their systems.",
      "Since July 1, 2025 the Platform is priced **per message**; rates depend on message category and country, and Saudi Arabia has its own market rate.",
      "Outside the 24-hour window that follows a customer message you can only send **Meta-approved templates**.",
      "**Msar Pro** is building WhatsApp ordering with routing to the nearest branch. It is \"coming soon\" and not yet available to merchants.",
    ],
    fig: {
      type: "flow", title: "The WhatsApp order path", caption: "Illustration: the stages of a WhatsApp order from the customer's message to delivery.",
      steps: [["Customer message", "Browses categories and picks items"], ["Order confirmation", "Location, payment and an order summary"], ["Routed to a branch", "The order reaches the nearest branch"], ["Status updates", "Template notices for preparing and delivery"], ["Delivery", "Delivery confirmed and the order logged"]],
    },
    body: `## What is the difference between the WhatsApp Business app and the WhatsApp Business Platform?

The **WhatsApp Business app** is the phone app you use to answer customers. The **WhatsApp Business Platform** is a set of APIs that Meta describes as built for companies to run engagement, marketing, commerce and support, with approved message templates, automated flows and integration with company systems such as CRM and back-end. It is set up directly (with your own number and developers) or through an approved partner.

What this means for a merchant: the app is fine to start with. Once orders multiply and you need each order to reach a specific branch and be followed by several staff, you need a system built on the Platform.

## How are Platform messages priced?

According to Meta's official pricing page (read on the publication date):

- From July 1, 2025 pricing is **per message** instead of per conversation.
- Template messages fall into three categories: **marketing**, **utility** and **authentication**.
- Price depends on category, volume and country. Saudi Arabia (+966) has its own market rate. Meta noted lower utility and authentication rates for Saudi Arabia from October 1, 2025, and SAR as a billing currency for new accounts from April 1, 2026.
- Rates change only on January 1, April 1, July 1 and October 1, with at least one month's notice.
- When a customer messages you, a **24-hour customer service window** opens, and replies inside it are not charged. If the customer arrives from a click-to-WhatsApp ad or a Facebook Page button, a 72-hour window of free messages opens.

> We did not quote SAR figures because the rate tables on Meta's page are interactive and we could not verify them. Check the current official table before doing any math.

## What Meta rules should you know before taking orders?

These come from WhatsApp's business policy and Meta's developer pages:

- Message only people who gave you their number and opted in, and give them a way to opt out and honor it.
- Start a conversation outside the 24-hour window with an **approved template** used only for its intended purpose. Meta can review, pause or reject templates.
- Automation is allowed as long as the customer can reach a human, a phone line or an email.
- WhatsApp **does not process payments or fulfill orders**; terms, payments and taxes are your responsibility.
- Never request or share full card numbers, account numbers or ID numbers.
- Prohibited items include firearms, tobacco, prescription drugs, medical products, currency, adult products and more. Check the full list before you sell.
- Violations start with warnings and can lead to temporary messaging blocks.

On data protection in Saudi Arabia: we could not read the official text of the Personal Data Protection Law while preparing this article, so check the Saudi Data and AI Authority (SDAIA) about consent for messaging.

## What goes wrong when you take orders by hand?

We found no documented study measuring problems of manual WhatsApp ordering, so this section is **our practical reading**, not a research result:

- Orders get lost between chats and have no single number.
- The customer's location is typed as text rather than an exact pin, so the branch loses time finding it.
- Two staff members answer the same customer with different information.
- There is no order status record, so customers ask "where is my order?".

## How do you organize WhatsApp orders step by step?

1. Give every order a **number** and log it in one place shared by the team.
2. Ask for the customer's **location as a map pin**, not a text description.
3. Send a summary (items, amount, payment method) and ask for explicit confirmation.
4. Route the order to the nearest branch instead of letting staff guess.
5. Send status updates with approved utility templates (preparing, out for delivery).
6. Log the delivery and review late orders every day.

## Where does Msar Pro fit in?

**Msar Pro** is building WhatsApp ordering: the customer browses categories, picks items and confirms inside the chat, and the order enters Msar Pro, is routed to the nearest branch and appears on the cashier screen. The service is currently **coming soon** and has not been opened to merchants; we will update this article when it launches. The steps above are useful whether you use Msar Pro or anything else.`,
    faq: [
      ["Do I need the WhatsApp Platform (API) or is the Business app enough?", "The app is enough to start with few orders. You need the Platform when you want approved templates, automation and integration with a system that routes orders to branches, since Meta positions it as the company-grade interface."],
      ["Are replies to customers free?", "Per Meta, replies inside the service window (24 hours from the customer's last message) are not charged. Messages you start outside the window need an approved template and are charged by category."],
      ["How much does a message cost in Saudi Arabia?", "Saudi Arabia has its own market rate that varies by message category and volume. We could not verify SAR figures, so check Meta's official pricing table."],
      ["Can I sell any product through WhatsApp?", "No. Meta has a list of prohibited items including firearms, tobacco, prescription drugs, medical products and currency."],
      ["Is Msar Pro's WhatsApp ordering available now?", "No, it is coming soon. We will announce it on the **Msar Pro** site and update this article at launch."],
    ],
    sources: [
      ["WhatsApp Business Platform — whatsappbusiness.com", "https://whatsappbusiness.com/products/business-platform/", "Platform definition, message templates and system integration"],
      ["WhatsApp Business Platform pricing — whatsappbusiness.com", "https://whatsappbusiness.com/products/platform-pricing/", "24-hour service window and 72-hour entry-point window"],
      ["Pricing on the WhatsApp Business Platform — Meta for Developers", "https://developers.facebook.com/docs/whatsapp/pricing", "Per-message pricing, template categories and Saudi rate notes (read on November 18, 2026)"],
      ["WhatsApp Business Messaging Policy — whatsappbusiness.com", "https://whatsappbusiness.com/policy/", "Opt-in, templates, automation and prohibited items"],
      ["Policy enforcement — Meta for Developers", "https://developers.facebook.com/docs/whatsapp/overview/policy-enforcement/violations", "Warning and blocking process for violations"],
    ],
  },
};
