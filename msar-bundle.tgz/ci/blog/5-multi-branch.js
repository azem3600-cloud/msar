// مقال 5: متجر بعدة فروع وتوجيه الطلبات لأقرب فرع
module.exports = {
  slug: "multi-branch-order-routing", order: 5, date: "2026-11-18",
  ar: {
    title: "متجر بأكثر من فرع: كيف توزّع الطلبات الإلكترونية على الفروع بدون فوضى؟",
    crumb: "توجيه الطلبات بين الفروع",
    desc: "كيف تعمل قواعد توجيه الطلبات بين المواقع في منصات التجارة، الفرق بين المسافة المستقيمة ومسافة الطريق، مخاطر تضارب المخزون، وماذا تقدّم زد في المخزون المتعدد.",
    keywords: "توجيه الطلبات, متجر متعدد الفروع, أقرب فرع, المخزون المتعدد, أولوية التنفيذ, المسافة المستقيمة, مسار برو",
    about: ["توجيه الطلبات", "المخزون المتعدد", "التوصيل من الفروع"],
    tldr: [
      "منصات مثل Shopify توجّه الطلب افتراضياً إلى الموقع الأقرب مع تقليل تقسيم الطلب بين المواقع.",
      "مخزون زد المتعدد يتيح مواقع مخزون وكميات لكل موقع وتحويلات وأولوية تنفيذ، وصفحة زد لا تذكر توجيهاً حسب المسافة.",
      "المسافة المستقيمة (هافرساين) لا تعكس الطرق: مثال من Google Maps Platform: 0.60 ميل مستقيماً مقابل 1.6 ميل بالسيارة.",
      "أكثر أسباب بيع كمية غير متوفرة: عدم مشاركة المخزون بين القنوات وتأخر تحديثه.",
      "**مسار برو** يوجّه الطلب لأقرب فرع بحسب موقع العميل ولا يدير المخزون.",
    ],
    fig: {
      type: "map", title: "توجيه الطلب إلى أقرب فرع",
      desc: "ثلاثة فروع وعميل واحد. خط أخضر متحرك من العميل إلى الفرع الأقرب، وخطوط متقطعة للفرعين الآخرين.",
      caption: "رسم توضيحي (ليس على مقياس): الطلب يذهب للفرع الأقرب لموقع العميل، بشرط أن يكون الصنف متوفراً فيه.",
      labels: { a: "فرع أ", b: "فرع ب", c: "فرع ج", cust: "العميل", near: "الأقرب" },
    },
    body: `## كيف توجّه المنصات الطلب بين المواقع؟

وثّقت **Shopify** في صفحة "Order routing" أن التوجيه يحتاج موقعين نشطين أو أكثر، وأن القواعد تُقيَّم بالترتيب لترتيب المواقع ثم يتولى الطلب أعلاها. القواعد الافتراضية: تقليل **تقسيم** الطلب (اختيار موقع يغطي كل الأصناف)، والبقاء داخل سوق الوجهة، والشحن من **الأقرب** لتقليل مدة التوصيل. ويمكن تخصيص الأولوية. الصفحة لا تشرح كيف تُحسب القرب ولا ماذا يحدث إذا لم يغطِّ موقع واحد كل الأصناف.

## ماذا تقدّم زد للمتاجر متعددة المواقع؟

من صفحة "إدارة المخزون" الرسمية في زد: **مواقع مخزون** (مستودعات وفروع من لوحة واحدة)، وكمية لكل موقع لكل منتج بما فيها المتغيرات، **طلبات تحويل مخزون** (موافقة وإرسال واستلام)، **قواعد إعادة التخزين**، وربط المستودعات بقنوات البيع، و**أولوية التنفيذ**، وإظهار المنتجات المتوفرة في **مدينة العميل**، وجرد المخزون، وسجل تغييرات المخزون.

أولوية التنفيذ في زد تعني ترتيب المواقع: يُسحب الطلب من أعلى موقع أولوية ثم يُقسَّم الباقي على غيره. الصفحة لا تذكر توجيهاً حسب المسافة (ولا تنفيه صراحةً). وفي سجل تحديثات زد للشركاء إعلان "Multi-Inventory" بحد خمسة مواقع، لكن النص المقروء مبتور فتأكد من الحد الحالي.

## هل المسافة المستقيمة كافية لاختيار الأقرب؟

بحسب Google Maps Platform: المسافة المستقيمة تُحسب من الإحداثيات بمعادلة **هافرساين** ولا تراعي الطرق ولا الازدحام، وتصفها بأنها غير كافية لكثير من الاستخدامات داخل المدن. مثالهم: 0.60 ميل مستقيماً مقابل 1.6 ميل على الطريق (نحو 2.5 ضعف). مسافة المسار تأتي من خدمة الاتجاهات وتعكس الطرق والوقت.

لم نجد رقماً موثقاً لنسبة الفرق بين المستقيمة والطريق في المدن السعودية، فلا نخمّن.

## ما مخاطر المخزون في تعدد الفروع؟

مدونة **Cin7** (شركة برمجيات، مصدر تجاري معتبر) تذكر أسباب بيع كمية غير موجودة منها: عدم مشاركة القنوات لرقم مخزون واحد، وتحديث المخزون دفعات متأخرة (كل ساعة أو آخر اليوم)، وانفصال نقطة البيع عن المتجر الإلكتروني، وغياب رؤية فورية للمستودعات، وارتفاع الطلب في العروض، وحساب البضاعة في الطريق كأنها متاحة، وأخطاء الجداول اليدوية.

لم نجد إحصاءات موثقة عن نسب الطلبات غير المكتملة بين الفروع.

## كيف تنظّم التوجيه عملياً؟

**رأينا العملي:**

1. حدّد لكل فرع **نطاق خدمة** يعكس ما يغطيه واقعياً.
2. اعتمد موقع العميل بدبوس خريطة لا بنص.
3. تأكد أن الفرع الأقرب **يملك الصنف** قبل التوجيه، وإلا وجّه لثاني أقرب فرع.
4. اجعل للطلب خارج النطاق أو بدون إحداثيات مساراً واضحاً للمراجعة اليدوية.
5. تابع عدد الطلبات وزمن التجهيز لكل فرع أسبوعياً لتعديل النطاقات.

## أين يقف مسار برو؟

**مسار برو** يربط متجرك في زد بفروعك ومناديبك: يوجّه كل طلب لأقرب فرع بحسب موقع العميل، ولكل فرع شاشة كاشير ونطاق توصيل. الطلب خارج النطاق يُوجَّه لأقرب فرع ويُعلَّم بأنه خارج النطاق، والطلب بدون إحداثيات يُنبَّه لمراجعة العنوان. **مسار برو لا يدير المخزون**؛ مخزون كل فرع يبقى في نظام متجرك، فاحرص على صحته قبل الاعتماد على التوجيه.`,
    faq: [
      ["ما المقصود بتوجيه الطلبات؟", "اختيار الفرع أو المستودع الذي سيجهّز الطلب تلقائياً بحسب قواعد مثل القرب والتوفر وعدم تقسيم الطلب، بدل ما يقرر موظف بالتقدير."],
      ["هل زد توجّه الطلب لأقرب فرع؟", "صفحة زد الرسمية عن المخزون تذكر أولوية تنفيذ ترتّب المواقع، ولا تذكر توجيهاً حسب المسافة. راجع زد للتأكد من التفاصيل الحالية."],
      ["كم موقع مخزون تسمح زد؟", "إعلان زد للشركاء ذكر خمسة مواقع، لكن النص مبتور في ما قرأناه، فتأكد من الحد الحالي."],
      ["هل المسافة المستقيمة كافية؟", "لا دائماً. Google Maps Platform تصفها بأنها غير كافية داخل المدن وتذكر مثالاً: 0.60 ميل مستقيماً مقابل 1.6 ميل على الطريق."],
      ["هل يدير مسار برو المخزون؟", "لا. **مسار برو** يوجّه الطلب ويديره ويتابع التوصيل، والمخزون يبقى في نظام متجرك."],
    ],
    sources: [
      ["Shopify Help: Order routing", "https://help.shopify.com/en/manual/fulfillment/setup/order-routing", "قواعد التوجيه الافتراضية وترتيب المواقع"],
      ["Zid: Inventory management", "https://zid.sa/en/solutions/inventory-management/", "ميزات المخزون المتعدد وأولوية التنفيذ"],
      ["Zid Partner Changelog: Multi-Inventory", "https://changelog.partner.zid.sa/changelog/26903", "إعلان المخزون المتعدد وحد خمسة مواقع (النص مبتور)"],
      ["Google Maps Platform: how to calculate distances", "https://mapsplatform.google.com/intl/en_in/resources/blog/how-calculate-distances-map-maps-javascript-api/", "هافرساين مقابل مسافة الطريق"],
      ["Cin7: Overselling in e-commerce", "https://www.cin7.com/blog/overselling-ecommerce/", "أسباب بيع كمية غير متوفرة"],
    ],
  },
  en: {
    title: "A store with several branches: how to route online orders to branches without chaos",
    crumb: "Routing orders between branches",
    desc: "How order-routing rules between locations work on commerce platforms, straight-line versus road distance, stock-mismatch risks, and what Zid offers for multi-location inventory.",
    keywords: "order routing, multi-branch store, nearest branch, multi-location inventory, fulfillment priority, straight-line distance, Msar Pro",
    about: ["order routing", "multi-location inventory", "ship from store"],
    tldr: [
      "Platforms such as Shopify route an order by default to the closest location while minimizing splitting an order across locations.",
      "Zid's multi-location inventory offers stock locations, per-location quantities, transfers and fulfilment priority; Zid's page does not mention distance-based routing.",
      "Straight-line distance (Haversine) ignores roads: Google Maps Platform's example is 0.60 miles straight versus 1.6 miles by car.",
      "Common overselling causes include channels not sharing one stock count and delayed stock updates.",
      "**Msar Pro** routes each order to the nearest branch by customer location and does not manage inventory.",
    ],
    fig: {
      type: "map", title: "Routing an order to the nearest branch",
      desc: "Three branches and one customer. A moving green line runs from the customer to the nearest branch, with dashed lines to the other two.",
      caption: "Illustration (not to scale): the order goes to the branch nearest the customer, provided the item is in stock there.",
      labels: { a: "Branch A", b: "Branch B", c: "Branch C", cust: "Customer", near: "Nearest" },
    },
    body: `## How do platforms route an order between locations?

**Shopify** documents on its "Order routing" page that routing needs two or more active locations, and that rules are evaluated in sequence to rank locations, with the top-ranked one fulfilling the order. The default rules: minimize **split** fulfillment (pick a location that can fulfill all items), stay within the destination market where possible, and ship from the **closest** location to cut delivery time. Priority can be customized. The page does not explain how proximity is calculated or what happens when no single location covers every item.

## What does Zid offer multi-location stores?

From Zid's official inventory-management page: **stock locations** (warehouses and branches managed from one dashboard), per-location quantity for each product including variants, **stock transfer requests** (approval, sending, receiving), **restocking rules**, assigning warehouses to sales channels, **fulfilment priority**, showing products available in the **customer's city**, stock counts, and a stock change log.

Fulfilment priority in Zid ranks locations: an order draws from the highest-priority location first, and the remainder is split across others. The page does not mention distance-based routing (nor does it rule it out). Zid's partner changelog announces "Multi-Inventory" with up to five stock locations, but the text we read was truncated, so confirm the current limit.

## Is straight-line distance enough to pick the nearest?

According to Google Maps Platform: straight-line distance is computed from coordinates with the **Haversine** formula and does not account for roads or traffic, and they call it insufficient for many uses, especially within cities. Their example: 0.60 miles straight-line versus 1.6 miles by road (about 2.5 times). Route distance comes from the Directions service and reflects roads and time.

We found no verifiable figure for the straight-line-to-road gap in Saudi cities, so we do not guess.

## What are the inventory risks of multiple branches?

**Cin7's** blog (a software vendor; a credible but commercial source) lists causes of overselling, including channels not sharing one stock count, stock updated in delayed batches (hourly or end of day), a POS disconnected from the online store, no real-time view across warehouses, spikes during sales, counting in-transit stock as sellable, and manual spreadsheet errors.

We found no documented statistics on incomplete-order rates across branches.

## How do you organize routing in practice?

**Our practical view:**

1. Define a **service range** for each branch that reflects what it realistically covers.
2. Capture the customer's location as a map pin, not text.
3. Check that the nearest branch **has the item** before routing; otherwise route to the second nearest.
4. Give out-of-range orders or orders without coordinates a clear manual-review path.
5. Review each branch's order count and preparation time weekly to adjust ranges.

## Where does Msar Pro stand?

**Msar Pro** connects your Zid store to your branches and drivers: it routes each order to the nearest branch by customer location, and each branch gets a cashier screen and a delivery range. An out-of-range order is routed to the nearest branch and marked as out of range, and an order without coordinates is flagged so the address is checked. **Msar Pro does not manage inventory**; each branch's stock stays in your store system, so keep it accurate before relying on routing.`,
    faq: [
      ["What is order routing?", "Automatically choosing which branch or warehouse will prepare an order, based on rules such as proximity, availability and not splitting the order, instead of staff guessing."],
      ["Does Zid route an order to the nearest branch?", "Zid's official inventory page describes a fulfilment priority that ranks locations and does not mention distance-based routing. Check with Zid for current details."],
      ["How many stock locations does Zid allow?", "Zid's partner changelog mentioned five locations, but the text we read was truncated, so confirm the current limit."],
      ["Is straight-line distance enough?", "Not always. Google Maps Platform calls it insufficient within cities and gives an example: 0.60 miles straight-line versus 1.6 miles by road."],
      ["Does Msar Pro manage inventory?", "No. **Msar Pro** routes and manages the order and tracks delivery; inventory stays in your store system."],
    ],
    sources: [
      ["Shopify Help: Order routing", "https://help.shopify.com/en/manual/fulfillment/setup/order-routing", "Default routing rules and location ranking"],
      ["Zid: Inventory management", "https://zid.sa/en/solutions/inventory-management/", "Multi-location inventory features and fulfilment priority"],
      ["Zid Partner Changelog: Multi-Inventory", "https://changelog.partner.zid.sa/changelog/26903", "Multi-Inventory announcement and five-location limit (text truncated)"],
      ["Google Maps Platform: how to calculate distances", "https://mapsplatform.google.com/intl/en_in/resources/blog/how-calculate-distances-map-maps-javascript-api/", "Haversine versus road distance"],
      ["Cin7: Overselling in e-commerce", "https://www.cin7.com/blog/overselling-ecommerce/", "Causes of overselling"],
    ],
  },
};
