// مقال 6: تسعير التوصيل للعميل (رسم ثابت / شحن مجاني فوق حد أدنى / محسوب). لا يذكر أي منصة تجارة بعينها.
module.exports = {
  slug: "delivery-fee-pricing-for-customers", order: 6, date: "2026-11-22",
  ar: {
    title: "كيف تسعّر التوصيل لعملائك؟ رسم ثابت أم شحن مجاني فوق حد أدنى أم رسم حسب المنطقة",
    crumb: "تسعير التوصيل للعميل",
    desc: "مقارنة بين ثلاث طرق لتسعير الشحن في المتجر الإلكتروني، ومتى تناسب كل طريقة، وكيف تحدد حد الشحن المجاني، وأخطاء تجعل العميل يترك الطلب عند الدفع.",
    keywords: "كيف أحسب رسوم التوصيل, رسوم التوصيل للعميل, الشحن المجاني, حد الشحن المجاني, تسعير الشحن, رسوم التوصيل حسب المنطقة, مسار برو",
    about: ["رسوم التوصيل", "الشحن المجاني", "المتاجر الإلكترونية"],
    tldr: [
      "المصادر التي قرأناها (Shopify وShippo) تذكر ثلاث طرق: **رسم ثابت**، و**شحن مجاني** (غالباً فوق حد أدنى للطلب)، و**رسم محسوب** حسب شركة الشحن أو الوزن أو قيمة الطلب.",
      "الرسم الثابت واضح للعميل قبل الدفع لكنك تقدّر تكلفته. الشحن المجاني يرفع التحويل لكنك تتحمل تكلفته في الأسعار. المحسوب دقيق لكنه قد لا يظهر إلا في آخر الدفع.",
      "تذكر Baymard في مقال منشور سنة 2017 أن 55% من المستخدمين المشاركين تركوا طلباً في آخر ربع بسبب تكاليف إضافية مرتفعة. الرقم قديم، فاعتبره اتجاهاً وليس قياساً لمتجرك.",
      "إذا كان التوصيل بمناديب متجرك، ابدأ من **تكلفتك الفعلية للطلب** ثم اختر النموذج، لا العكس.",
      "**مسار برو** لا يحدد رسوم التوصيل عنك، لكنه يوضّح لك أداء المناديب والفروع لتحسب تكلفتك بدقة.",
    ],
    fig: {
      type: "flow", title: "خطوات تسعير التوصيل", caption: "رسم توضيحي: ترتيب القرارات عند تسعير التوصيل لعملائك.",
      steps: [["احسب تكلفتك", "تكلفة الطلب الواحد فعلياً"], ["اعرف متوسط السلة", "قيمة الطلب المعتادة"], ["اختر النموذج", "ثابت أو مجاني فوق حد أو حسب المنطقة"], ["اعرض الرسم مبكراً", "في صفحة المنتج وقبل الدفع"], ["راجع كل شهر", "قارن التكلفة بالإيراد"]],
    },
    body: `## ما طرق تسعير الشحن المتاحة؟

تصف صفحات Shopify (دليل استراتيجية الشحن وإعداد الأسعار) ثلاث طرق رئيسية، وتتفق معها مدونة Shippo في التصنيف:

| الطريقة | المزايا | العيوب |
|---|---|---|
| رسم ثابت | يعرف العميل المبلغ قبل الدفع، ويمكن تقسيمه إلى شرائح حسب قيمة السلة | عليك تقدير التكلفة، وقد يقلّل تنافسية المتجر إذا كان أعلى من المنافسين |
| شحن مجاني | يرفع التحويل ويشجع على الولاء | تتحمل تكلفته في أسعار المنتجات، وقد لا يناسب المنتجات ذات هامش الربح المنخفض |
| رسم محسوب (حسب الشركة أو الوزن) | تكلفة دقيقة بدون تقدير | قد لا يظهر السعر إلا متأخراً، وتحتاج أوزاناً وأبعاداً دقيقة |

الشحن المجاني يمكن دمجه مع أي طريقة، وغالباً يُربط بحد أدنى لقيمة الطلب.

## كيف تحدد حد الشحن المجاني؟

تقترح Shippo أن يكون الحد أعلى قليلاً من متوسط قيمة الطلب، لتشجع العميل على إضافة منتج. وتنصح Baymard بإظهار شرط الشحن المجاني بوضوح قرب منطقة الشراء، لا في شريط علوي فقط.

خطوات عملية:

1. استخرج متوسط قيمة الطلب من آخر 2-3 أشهر.
2. احسب تكلفة التوصيل لطلب واحد (راجع [مقالنا عن تكلفة التوصيل](blog/delivery-cost-own-drivers-vs-carriers)).
3. اجعل الحد أعلى قليلاً من المتوسط، وتأكد أن هامش الطلب عند الحد يغطي تكلفة التوصيل.
4. اعرض الحد في صفحة المنتج والسلة: "أضف 40 ريال للشحن المجاني" كمثال على الأسلوب.

## هل أسعّر حسب المنطقة أو المسافة؟

المصادر التي قرأناها تتحدث عن مناطق شحن وأسعار حسب الوزن أو قيمة الطلب أو شركة الشحن. **التسعير حسب المسافة بين الفرع والعميل ليس مذكوراً فيها، وهو قراءتنا العملية** للمتاجر التي توصّل بمناديبها داخل المدينة:

- قسّم المدينة إلى مناطق قريبة وبعيدة من الفرع، ولكل منطقة رسم.
- اعتمد أرقامك الفعلية: متوسط زمن التوصيل وتكلفة المندوب لكل منطقة.
- إذا كان لديك أكثر من فرع، فالمسافة تُحسب من الفرع الأقرب للعميل، وهذا يخفض الرسم الذي تحتاجه.

## أخطاء تجعل العميل يترك الطلب

- **إظهار الرسم متأخراً.** تذكر Baymard (مقال 2017) أن 64% من المستخدمين المشاركين يبدأون التفكير في تكلفة الشحن من صفحة المنتج.
- **إعلان الشحن المجاني في شريط علوي فقط.** وجدت Baymard أن بعض المستخدمين لم ينتبهوا له (حتى 27% في اختبارها).
- **شرائح لا تغطي كل المدى.** تحذّر Shopify أن الشرائح إذا لم تغطِّ كل قيم الطلب ظهر خطأ شحن عند الدفع.
- **صياغة غامضة.** وجدت Baymard مواقع تكتب شروط الشحن المجاني بشكل متضارب.

> أرقام Baymard من اختبار مستخدمين قديم نسبياً (2017)، وأرقام Shippo تنقل عن جهات أخرى. استخدمها للفهم وليس كمعيار لمتجرك، وقِس نتائجك بنفسك.

## كيف تعرف أن التسعير يناسبك؟

قارن شهرياً بين: عدد الطلبات المتروكة عند الدفع، ومتوسط قيمة الطلب، وتكلفة التوصيل الفعلية للطلب، وعدد الطلبات التي وصلت للحد المجاني. إذا زادت التكلفة عن الهامش، عدّل الحد أو الرسم.`,
    faq: [
      ["هل الأفضل أن أجعل الشحن مجانياً دائماً؟", "تذكر المصادر أنه يرفع التحويل، لكن تكلفته تُحمّل على الأسعار ولا يناسب المنتجات منخفضة الهامش. الحل الشائع هو شحن مجاني فوق حد أدنى للطلب."],
      ["كم يجب أن يكون حد الشحن المجاني؟", "تقترح Shippo أن يكون أعلى قليلاً من متوسط قيمة الطلب. احسبه من بياناتك، وتأكد أن هامش الطلب يغطي تكلفة التوصيل."],
      ["هل أعرض رسم التوصيل قبل الدفع؟", "نعم. تشير Baymard إلى أن كثيراً من المستخدمين يفكرون في الشحن من صفحة المنتج، وأن التكاليف المفاجئة سبب شائع لترك الطلب."],
      ["كيف أسعّر إذا وصّلت بمناديبي؟", "احسب تكلفة الطلب الفعلية أولاً (أجر المندوب والوقود والفشل في التسليم)، ثم اختر رسماً ثابتاً أو حسب المنطقة. هذا الجزء قراءتنا العملية وليس من المصادر."],
    ],
    sources: [
      ["Shopify Help: Creating a shipping strategy", "https://help.shopify.com/en/manual/fulfillment/setup/shipping-rates/shipping-strategy", "الطرق الثلاث ومزايا وعيوب كل واحدة"],
      ["Shopify Help: Setting up shipping rates", "https://help.shopify.com/manual/fulfillment/setup/shipping-rates/flat-shipping-rate", "أنواع الأسعار والشرائح، والشحن المجاني فوق حد أدنى"],
      ["Shippo: How to price e-commerce shipping (أبريل 2022)", "https://goshippo.com/blog/how-to-price-e-commerce-shipping", "اقتراح حد الشحن المجاني بالنسبة لمتوسط الطلب"],
      ["Baymard Institute: Avoid showing free shipping only in a banner (أغسطس 2017)", "https://baymard.com/blog/avoid-banners-only-free-shipping", "أين تُعرض معلومة الشحن المجاني وأرقام اختبار المستخدمين"],
    ],
  },
  en: {
    title: "How to price delivery for your customers: flat fee, free shipping over a minimum, or zone-based fees",
    crumb: "Delivery fee pricing",
    desc: "A comparison of three ways to price shipping in an online store, when each one fits, how to set a free-shipping threshold, and mistakes that make shoppers abandon at checkout.",
    keywords: "how to calculate delivery fee, delivery fee for customers, free shipping threshold, shipping pricing, zone-based delivery fees, Msar Pro",
    about: ["Delivery fees", "Free shipping", "Online stores"],
    tldr: [
      "The sources we read (Shopify and Shippo) describe three approaches: a **flat fee**, **free shipping** (usually above a minimum order), and a **calculated rate** based on carrier, weight or order value.",
      "A flat fee is clear before checkout but you estimate its cost. Free shipping lifts conversion but you absorb the cost in prices. Calculated rates are accurate but may only appear late in checkout.",
      "Baymard, in an article published in 2017, reports that 55% of the users in its study had abandoned an order in the last quarter because extra costs were too high. The figure is old, so treat it as a direction, not a measurement of your store.",
      "If you deliver with your own drivers, start from your **actual cost per order**, then pick the model, not the other way around.",
      "**Msar Pro** does not set your delivery fees, but it shows driver and branch performance so you can calculate your cost accurately.",
    ],
    fig: {
      type: "flow", title: "Steps to price delivery", caption: "Illustration: the order of decisions when pricing delivery for your customers.",
      steps: [["Work out your cost", "The real cost of one order"], ["Know your average cart", "Your usual order value"], ["Pick a model", "Flat, free above a minimum, or by zone"], ["Show the fee early", "On the product page, before checkout"], ["Review monthly", "Compare cost with revenue"]],
    },
    body: `## What shipping pricing models exist?

Shopify's help pages (the shipping strategy guide and the rates setup page) describe three main approaches, and Shippo's blog uses a similar split:

| Model | Pros | Cons |
|---|---|---|
| Flat fee | The customer knows the amount before paying, and it can be tiered by cart value | You estimate the cost, and it can make the store less competitive if higher than rivals |
| Free shipping | Lifts conversion and supports loyalty | You absorb the cost in product prices, and it may not suit low-margin products |
| Calculated (carrier or weight) | Accurate cost with no guessing | The price may appear late, and you need accurate weights and dimensions |

Free shipping can be combined with any model, and is usually tied to a minimum order value.

## How do you set a free-shipping threshold?

Shippo suggests setting it slightly above your average order value, so customers are nudged to add an item. Baymard advises showing the free-shipping condition clearly near the buying area, not only in a top banner.

Practical steps:

1. Pull your average order value from the last 2-3 months.
2. Work out the delivery cost for one order (see [our article on delivery cost](en/blog/delivery-cost-own-drivers-vs-carriers)).
3. Set the threshold slightly above the average, and check the order margin at that value covers delivery.
4. Show the threshold on the product page and cart, for example "Add 40 SAR for free shipping" as a style of message.

## Should you price by zone or distance?

The sources we read talk about shipping zones and rates by weight, order value or carrier. **Pricing by distance between the branch and the customer is not in them, and is our practical reading** for stores that deliver with their own drivers inside a city:

- Split the city into zones near and far from the branch, with a fee for each.
- Base each zone on your own numbers: average delivery time and driver cost.
- With several branches, distance is measured from the branch nearest to the customer, which lowers the fee you need to charge.

## Mistakes that make customers abandon

- **Showing the fee late.** Baymard (2017 article) reports that 64% of its study users start thinking about shipping cost as early as the product page.
- **Announcing free shipping only in a top banner.** Baymard found some users missed it (as many as 27% in its test).
- **Tiers that do not cover the full range.** Shopify warns that if tiers do not cover every order value, checkout shows a shipping error.
- **Unclear wording.** Baymard found sites that word free-shipping conditions in conflicting ways.

> Baymard's numbers come from a relatively old user test (2017), and Shippo's figures cite other organizations. Use them to understand the issue, not as a benchmark for your store, and measure your own results.

## How do you know your pricing works?

Each month compare: abandoned checkouts, average order value, actual delivery cost per order, and how many orders reached the free threshold. If cost exceeds margin, adjust the threshold or the fee.`,
    faq: [
      ["Should shipping always be free?", "The sources say it lifts conversion, but its cost is carried in prices and it does not suit low-margin products. A common solution is free shipping above a minimum order."],
      ["What should the free-shipping threshold be?", "Shippo suggests slightly above your average order value. Calculate it from your data and make sure the order margin covers delivery."],
      ["Should I show the delivery fee before checkout?", "Yes. Baymard notes that many users think about shipping from the product page, and that surprise costs are a common reason for abandoning."],
      ["How do I price if I deliver with my own drivers?", "Work out the real cost per order first (driver pay, fuel, failed deliveries), then choose a flat or zone-based fee. This part is our practical reading, not from the sources."],
    ],
    sources: [
      ["Shopify Help: Creating a shipping strategy", "https://help.shopify.com/en/manual/fulfillment/setup/shipping-rates/shipping-strategy", "The three models and the pros and cons of each"],
      ["Shopify Help: Setting up shipping rates", "https://help.shopify.com/manual/fulfillment/setup/shipping-rates/flat-shipping-rate", "Rate types and tiers, and free shipping above a minimum"],
      ["Shippo: How to price e-commerce shipping (April 2022)", "https://goshippo.com/blog/how-to-price-e-commerce-shipping", "Suggestion to set the free-shipping threshold relative to average order value"],
      ["Baymard Institute: Avoid showing free shipping only in a banner (August 2017)", "https://baymard.com/blog/avoid-banners-only-free-shipping", "Where to show free-shipping information, and user-test figures"],
    ],
  },
};
