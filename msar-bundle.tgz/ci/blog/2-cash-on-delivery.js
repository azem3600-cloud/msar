// مقال 2: الدفع عند الاستلام وتقليل الطلبات الملغية
module.exports = {
  slug: "cash-on-delivery-reduce-cancellations", order: 2, date: "2026-11-18",
  ar: {
    title: "الدفع عند الاستلام: كيف تقلل الطلبات الملغية والمرفوضة في متجرك؟",
    crumb: "الدفع عند الاستلام",
    desc: "ما الأرقام الموثقة عن الدفع عند الاستلام في المنطقة، وماذا يقول نظام التجارة الإلكترونية السعودي عن الإلغاء والإرجاع، وأي ممارسات توصي بها DHL وشركات لوجستية لتقليل الرفض.",
    keywords: "الدفع عند الاستلام, الطلبات المرفوضة, إلغاء الطلبات, تأكيد الطلب, نظام التجارة الإلكترونية السعودي, مسار برو",
    about: ["الدفع عند الاستلام", "إلغاء الطلبات", "التجارة الإلكترونية في السعودية"],
    tldr: [
      "تقرير Checkout.com لعام 2024 ذكر أن تفضيل الدفع عند الاستلام في المنطقة انخفض من 41% (2020) إلى 20% (2023)، لكنه لا يقيس نسبة الدفع عند الاستلام من طلبات السعودية.",
      "ما وجدنا مصدراً موثقاً لنسبة الرفض أو الإرجاع في السعودية. رقم 20-30% المتداول مصدره مدونة تجارية بدون مرجع.",
      "الممارسات الموثقة: تأكيد الطلب قبل الشحن، فرز الطلبات عالية المخاطرة، حوافز للدفع المسبق، وتذكير يوم التسليم.",
      "نظام التجارة الإلكترونية يعطي المستهلك 7 أيام للعدول بعد الاستلام بشروط، ويحدد أحكام التأخر.",
      "**مسار برو** يعطي العميل رابط تتبع، وفيه ميزة اختيارية لرمز تسليم يؤكد استلام العميل.",
    ],
    fig: {
      type: "flow", title: "رحلة الطلب بالدفع عند الاستلام", caption: "رسم توضيحي: نقاط التحقق التي توصي بها المصادر قبل الشحن وأثناء التوصيل.",
      steps: [["الطلب", "فحص العنوان والجوال والطلبات الأولى الكبيرة"], ["تأكيد", "اتصال أو رسالة قبل الشحن"], ["حافز للدفع المسبق", "خصم أو توصيل مجاني"], ["تذكير التسليم", "رسالة في يوم التوصيل"], ["التسليم", "التحقق عند الباب وتسجيل طريقة التحصيل"]],
    },
    body: `## كم نسبة الدفع عند الاستلام فعلاً في السعودية؟

الجواب الصريح: **ما وجدنا مصدراً موثقاً** لنسبة الدفع عند الاستلام من إجمالي الطلبات في السعودية. اللي وجدناه:

- تقرير **Checkout.com** "حالة التجارة الرقمية في الشرق الأوسط وشمال أفريقيا 2024" (نُشر 14 مايو 2024، بيانات 2020-2023): تفضيل الدفع عند الاستلام في المنطقة نزل من **41% إلى 20%**، وفي السعودية والإمارات والكويت وصل تفضيل النقد إلى نحو **10%**. الصفحة لا توضح هل الـ10% للدفع عند الاستلام تحديداً أم للنقد عموماً، ولا تذكر حجم العينة. وهو رأي معالج مدفوعات وليس نسبة طلبات.
- مدونة **eGrow** (شركة تجارية، 2026) تقول إن معدلات الإرجاع في الدفع عند الاستلام "غالباً 20-30%" مقابل 5-10% للمدفوع مسبقاً. لا تذكر مصدراً، فاعتبره ادعاءً تجارياً غير موثق.

## ماذا يقول نظام التجارة الإلكترونية السعودي؟

من نص النظام المنشور على موقع وزارة الاستثمار (لم نقرأ اللائحة التنفيذية، فراجعها):

- **المادة 13:** للمستهلك 7 أيام للعدول بعد استلام المنتج بشرط ألا يكون استخدمه، ويتحمل تكلفة الإرجاع ما لم يُتفق على غير ذلك. وتُستثنى حالات مثل المنتجات المصنوعة حسب طلبه.
- **المادة 14:** للمستهلك فسخ العقد إذا تأخر التسليم أكثر من 15 يوماً عن الموعد، مع استرداد المبالغ. وعلى مقدّم الخدمة إشعاره بأي تأخر متوقع.
- **المادتان 7 و8:** بيان السعر الإجمالي شاملاً رسوم التوصيل قبل إبرام العقد، وفاتورة تتضمن موعد التسليم ومكانه.

أما حكم الرفض عند الباب تحديداً فلم نجد له نصاً صريحاً فيما قرأناه، ويحتاج مراجعة قانونية.

## ما الممارسات الموثقة لتقليل الرفض؟

مقال **DHL** (موجّه لتجار باكستان لكن ممارساته عامة) ومدونة **eGrow** (سعودية الطابع) يوصيان بما يلي:

- **تأكيد الطلب قبل الشحن:** باتصال أو رسالة نصية برمز أو رد على واتساب (DHL)، أو واتساب/اتصال آلي (eGrow).
- **فرز الطلبات عالية المخاطرة:** عنوان ناقص، طلب أول كبير، جوال لا يرد، عميل سبق وألغى. تُوقف للتأكيد الثاني أو الدفع المسبق (DHL).
- **حوافز للدفع المسبق:** خصم 5-10% أو استرجاع نقدي أو توصيل مجاني (DHL)، وإرسال رابط دفع بـمدى أو STC Pay لتحويل الطلب من الدفع عند الاستلام (eGrow).
- **رسائل التسليم:** نافذة زمنية وتذكير يوم التسليم وتتبع مباشر (DHL)، ورسالة بعد فشل التوصيل مع خيار إعادة الجدولة (eGrow).

ما لم نجده في المصادر المقروءة: الدفع المقدّم الجزئي (العربون) كممارسة موثقة، والقائمة السوداء للعملاء بشكل صريح (DHL يذكر فقط تمييز من يكرر الإلغاء)، ورمز التسليم عند الباب (DHL يذكر رمزاً عند الدفع فقط).

## كيف تطبّق ذلك بدون ما تتعب الفريق؟

**رأينا العملي، وليس من مصدر:**

1. أنشئ قاعدة بسيطة: أي طلب بدون إحداثيات أو بعنوان قصير يُراجع قبل الشحن.
2. أرسل للعميل رابط تتبع ليشوف التقدم بدل ما يتصل ويسأل.
3. اجعل المندوب يسجّل طريقة التحصيل (نقد أو شبكة) عند التسليم لتتطابق الحسابات.
4. راجع أسباب الرفض أسبوعياً؛ لو تكررت (مثلاً العنوان) عالجها من أصلها.

في **مسار برو** يظهر لكل طلب رابط تتبع للعميل، ويسجل المندوب طريقة التحصيل عند التسليم، وفيه ميزة اختيارية لرمز تسليم يعطيه العميل للمندوب (تُفعَّل من إدارة المنصة).`,
    faq: [
      ["هل الدفع عند الاستلام ينقرض في السعودية؟", "لا يوجد دليل قاطع. تقرير Checkout.com يذكر انخفاض تفضيله في المنطقة من 41% إلى 20% بين 2020 و2023، لكنه لا يقيس نسبة الطلبات في السعودية."],
      ["كم نسبة رفض الطلبات في الدفع عند الاستلام؟", "ما وجدنا رقماً سعودياً موثقاً. مدونة eGrow التجارية تذكر 20-30% بلا مصدر، فلا تعتمد عليها في قرار قبل ما تقيس رقمك من طلباتك."],
      ["هل للعميل حق إرجاع الطلب بعد الاستلام؟", "بحسب المادة 13 من نظام التجارة الإلكترونية: 7 أيام بعد الاستلام بشرط عدم الاستخدام، ويتحمل تكلفة الإرجاع ما لم يُتفق على غير ذلك، مع استثناءات. راجع اللائحة التنفيذية."],
      ["هل تأكيد الطلب بالواتساب مقبول؟", "DHL وeGrow يوصيان بالتأكيد برسالة أو واتساب. تأكد أن رسائل واتساب التجارية تلتزم بسياسة ميتا، ومنها الموافقة على الرسائل."],
      ["ماذا يضيف مسار برو في هذا؟", "رابط تتبع للعميل، وتسجيل المندوب لطريقة التحصيل عند التسليم، وميزة رمز تسليم اختيارية. لا يضمن **مسار برو** خفض الرفض بنسبة محددة."],
    ],
    sources: [
      ["Checkout.com: State of digital commerce in MENA 2024", "https://www.checkout.com/newsroom/checkout-coms-4th-annual-mena-report-finds-cash-on-delivery-usage-halved-amongst-maturing-digital-economy", "انخفاض تفضيل الدفع عند الاستلام من 41% إلى 20% (2020-2023)"],
      ["نظام التجارة الإلكترونية — E-Commerce Law (PDF) — وزارة الاستثمار", "https://misa.gov.sa/app/uploads/2025/07/E-Commerce-Law.pdf", "المواد 7 و8 و13 و14"],
      ["DHL: How e-commerce sellers can reduce COD returns", "https://www.dhl.com/discover/en-pk/e-commerce-advice/e-commerce-best-practice/subscription-marketing/how-pakistani-e-commerce-sellers-can-reduce-cod-returns", "ممارسات التأكيد والفرز والحوافز (سياق باكستان)"],
      ["eGrow: Saudi Arabia COD e-commerce guide 2026", "https://www.egrow.com/en/blog/saudi-arabia-cod-ecommerce-guide-2026", "ممارسات التأكيد وروابط الدفع، وادعاء 20-30% (غير موثق)"],
    ],
  },
  en: {
    title: "Cash on delivery: how to reduce cancelled and refused orders in your store",
    crumb: "Cash on delivery",
    desc: "What documented numbers exist on cash on delivery in the region, what the Saudi E-Commerce Law says about cancellation and returns, and which practices DHL and logistics firms recommend to reduce refusals.",
    keywords: "cash on delivery, refused orders, order cancellation, order confirmation, Saudi e-commerce law, Msar Pro",
    about: ["cash on delivery", "order cancellation", "e-commerce in Saudi Arabia"],
    tldr: [
      "Checkout.com's 2024 report says preference for cash on delivery in the region fell from 41% (2020) to 20% (2023), but it does not measure COD's share of Saudi orders.",
      "We found no verifiable source for a Saudi refusal or return rate. The 20-30% figure that circulates comes from a commercial blog with no reference.",
      "Documented practices: confirm orders before shipping, screen high-risk orders, incentivize prepayment, and remind on delivery day.",
      "The E-Commerce Law gives consumers 7 days to rescind after receipt under conditions, and sets rules for late delivery.",
      "**Msar Pro** gives the customer a tracking link and offers an optional delivery code that confirms the customer received the order.",
    ],
    fig: {
      type: "flow", title: "The journey of a cash-on-delivery order", caption: "Illustration: the checkpoints the sources recommend before shipping and during delivery.",
      steps: [["Order", "Check address, phone and large first orders"], ["Confirm", "A call or message before shipping"], ["Prepay incentive", "A discount or free delivery"], ["Delivery reminder", "A message on delivery day"], ["Handover", "Verify at the door and record how it was collected"]],
    },
    body: `## What share of Saudi orders is actually cash on delivery?

The honest answer: **we found no verifiable source** for cash on delivery's share of all orders in Saudi Arabia. What we did find:

- **Checkout.com's** "State of digital commerce in MENA 2024" (published May 14, 2024, data from 2020-2023): preference for cash on delivery in the region fell from **41% to 20%**, and in Saudi Arabia, the UAE and Kuwait preference for cash went as low as about **10%**. The page does not say whether the 10% refers to cash on delivery specifically or to cash in general, and gives no sample size. It is a payments processor's view, not a share of orders.
- **eGrow's** blog (a commercial company, 2026) says COD return rates are "often 20-30%" versus 5-10% for prepaid. It cites no source, so treat it as an unverified commercial claim.

## What does the Saudi E-Commerce Law say?

From the law text published on the Ministry of Investment's site (we did not read the Executive Regulations, so check them):

- **Article 13:** the consumer has 7 days after receiving the product to rescind, provided it was not used, and bears the return cost unless agreed otherwise. Exceptions apply, such as products made to the consumer's order.
- **Article 14:** the consumer may cancel if delivery is more than 15 days late against the agreed date, with a refund. The provider must warn the consumer of any expected delay.
- **Articles 7 and 8:** the total price including delivery fees must be stated before the contract is concluded, and an invoice must state the delivery date and place.

Exact legal wording for a refusal at the door needs legal review.

## Which practices are documented for reducing refusals?

**DHL's** article (aimed at Pakistani merchants but the practices are general) and **eGrow's** blog (Saudi-focused) recommend:

- **Confirm before shipping:** by call, SMS code or a WhatsApp reply (DHL), or WhatsApp / automated call (eGrow).
- **Screen high-risk orders:** incomplete address, a large first order, an unresponsive phone, a customer who cancelled before. Hold them for a second confirmation or prepayment (DHL).
- **Prepayment incentives:** 5-10% off, cashback or free delivery (DHL), and sending a Mada or STC Pay payment link to convert the order from cash on delivery (eGrow).
- **Delivery messaging:** a time slot, a delivery-day reminder and live tracking (DHL), plus a message after a failed delivery with a reschedule option (eGrow).

What we did not find in the sources we read: partial deposits as a documented practice, an explicit customer blacklist (DHL only mentions flagging repeat cancellers), and a code at the door (DHL mentions a code at checkout only).

## How do you apply this without exhausting your team?

**Our practical view, not from a source:**

1. Set a simple rule: any order without coordinates or with a very short address is reviewed before shipping.
2. Send the customer a tracking link so they see progress instead of calling to ask.
3. Have the driver record the collection method (cash or card) at delivery so accounts match.
4. Review refusal reasons weekly; if one repeats (say, addresses), fix it at the root.

In **Msar Pro** every order has a customer tracking link, the driver records the collection method at delivery, and there is an optional delivery code the customer gives the driver (enabled by the platform admin).`,
    faq: [
      ["Is cash on delivery disappearing in Saudi Arabia?", "There is no conclusive evidence. Checkout.com reports its preference fell from 41% to 20% in the region between 2020 and 2023, but it does not measure Saudi order share."],
      ["What is the refusal rate for cash-on-delivery orders?", "We found no verified Saudi figure. eGrow's commercial blog cites 20-30% without a source, so measure your own numbers before basing a decision on it."],
      ["Can the customer return an order after receiving it?", "Under Article 13 of the E-Commerce Law: 7 days after receipt if unused, with the customer bearing return cost unless agreed otherwise, and with exceptions. Check the Executive Regulations."],
      ["Is confirming orders on WhatsApp acceptable?", "DHL and eGrow both recommend confirming by message or WhatsApp. Make sure business WhatsApp messaging follows Meta's policy, including opt-in."],
      ["What does Msar Pro add here?", "A customer tracking link, driver recording of the collection method at delivery, and an optional delivery code. **Msar Pro** does not promise a specific reduction in refusals."],
    ],
    sources: [
      ["Checkout.com: State of digital commerce in MENA 2024", "https://www.checkout.com/newsroom/checkout-coms-4th-annual-mena-report-finds-cash-on-delivery-usage-halved-amongst-maturing-digital-economy", "Cash-on-delivery preference falling from 41% to 20% (2020-2023)"],
      ["E-Commerce Law (PDF) — Ministry of Investment (MISA)", "https://misa.gov.sa/app/uploads/2025/07/E-Commerce-Law.pdf", "Articles 7, 8, 13 and 14"],
      ["DHL: How e-commerce sellers can reduce COD returns", "https://www.dhl.com/discover/en-pk/e-commerce-advice/e-commerce-best-practice/subscription-marketing/how-pakistani-e-commerce-sellers-can-reduce-cod-returns", "Confirmation, screening and incentive practices (Pakistan context)"],
      ["eGrow: Saudi Arabia COD e-commerce guide 2026", "https://www.egrow.com/en/blog/saudi-arabia-cod-ecommerce-guide-2026", "Confirmation and payment-link practices, and the unverified 20-30% claim"],
    ],
  },
};
