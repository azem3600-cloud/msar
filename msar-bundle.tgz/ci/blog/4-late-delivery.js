// مقال 4: تأخر الطلبات وشكاوى العملاء
module.exports = {
  slug: "late-delivery-complaints-cancellations", order: 4, date: "2026-11-18",
  ar: {
    title: "تأخر التوصيل وشكاوى العملاء: ما الأسباب وما الذي يقلل الإلغاء فعلاً؟",
    crumb: "تأخر التوصيل والشكاوى",
    desc: "إحصاءات موثقة عن تأخر التوصيل وتوقعات العملاء، وأحكام نظام التجارة الإلكترونية السعودي عن التأخر، وقنوات الشكوى الرسمية في وزارة التجارة، وممارسات عملية لتقليل الشكاوى.",
    keywords: "تأخر التوصيل, شكاوى العملاء, إلغاء الطلبات, تتبع الطلب, نظام التجارة الإلكترونية, وزارة التجارة 1900, مسار برو",
    about: ["تأخر التوصيل", "شكاوى العملاء", "نظام التجارة الإلكترونية"],
    tldr: [
      "استطلاع Narvar لعام 2025 (3,461 مستهلكاً أمريكياً): 74% واجهوا تأخراً واحداً على الأقل في سنة، ونحو النصف أقل ميلاً للشراء من نفس المتجر بعد التأخر.",
      "نفس الاستطلاع: 73% قالوا إن تاريخ التسليم المتوقع أثّر على قرار الشراء. الأرقام أمريكية، ولا نعتبرها نسباً سعودية.",
      "في السعودية: للمستهلك فسخ العقد إذا تأخر التسليم أكثر من 15 يوماً، وعلى المتجر إشعاره بأي تأخر متوقع (المادة 14).",
      "وزارة التجارة تحدد 1900 وتطبيق بلاغ تجاري كقناتين رسميتين للإبلاغ عن المخالفات التجارية.",
      "**مسار برو** يعطي العميل رابط تتبع ويعطيك تنبيهاً للطلبات المتأخرة، وهي أدوات تساعد على الإشعار المبكر لا أكثر.",
    ],
    fig: {
      type: "flow", title: "نقاط إشعار العميل أثناء الطلب", caption: "رسم توضيحي: نقاط الإشعار المقترحة. إشعار التأخر المتوقع واجب نظاماً بحسب المادة 14.",
      steps: [["عند الطلب", "تاريخ تسليم متوقع واقعي"], ["قيد التجهيز", "إشعار بأن الطلب بدأ"], ["خرج للتوصيل", "رابط التتبع واسم المندوب"], ["عند التأخر", "إشعار فوري مع السبب والموعد الجديد"], ["بعد التسليم", "تأكيد وتقييم"]],
    },
    body: `## ما أسباب شكاوى التوصيل؟

لم نجد دراسة سعودية تحصي أسباب الشكاوى، فاعتمدنا على أبحاث أجنبية (ننبه لكل رقم لمن يخص):

- **Narvar** (شركة تتبع، استطلاع 2025 لـ3,461 مستهلكاً أمريكياً، بيانات ذاتية): **74%** واجهوا تأخراً واحداً على الأقل خلال سنة، و**73%** قالوا إن تاريخ التسليم المتوقع أثّر على قرار الشراء، و**45%** أكثر ميلاً للشراء إذا عُرض التاريخ عند الدفع. نحو النصف أقل ميلاً للشراء مجدداً بعد التأخر، و6% توقفوا عن الشراء من المتجر.
- **Narvar 2020** نقلاً عن Retail Dive: 36% واجهوا تأخراً كبيراً، و19% فقط قالوا إن المتاجر أبقتهم على اطلاع. وتقترح الدراسة أن العملاء يتسامحون مع التأخر إذا أُخبروا.
- **Baymard** (سنة الاستطلاع وحجم العينة غير مذكورين في الصفحة): 20% من حالات ترك السلة سببها أن التوصيل بطيء (من غير المتصفحين فقط)، و40% بسبب ارتفاع التكاليف الإضافية.

لم نجد مصدراً موثقاً عن نسب العناوين الخاطئة.

## ماذا يقول نظام التجارة الإلكترونية في التأخر؟

من نص النظام (موقع وزارة الاستثمار، ولم نقرأ اللائحة التنفيذية):

- **المادة 14(1):** للمستهلك فسخ العقد إذا تأخر مقدّم الخدمة عن التسليم أكثر من 15 يوماً من موعد العقد أو الموعد المتفق عليه (إلا في حال التمديد المتفق عليه أو القوة القاهرة)، واسترداد المبالغ والتكاليف الناتجة عن التأخر.
- **المادة 14(2):** على مقدّم الخدمة **إشعار المستهلك** بأي تأخر متوقع أو ظروف تؤثر على التسليم.
- **المادة 8:** الفاتورة تتضمن موعد التسليم ومكانه.

وأكدت وزارة التجارة قاعدة الـ15 يوماً في صفحتها الإخبارية. وفي 2022 أعلنت الوزارة تغريم 12 متجراً إلكترونياً لعدم الاستجابة لطلبات الفسخ بعد التأخر وعدم إبلاغ المستهلكين بالتأخر المتوقع وعدم إصدار الفواتير، بعد استلام 418 بلاغاً، مع إلزامهم بالاسترداد. وهناك **مسودة تعديل** معروضة للاستطلاع تتحدث عن استرداد خلال 14 يوماً؛ لم نتحقق من وضعها الحالي.

## أين يشتكي العميل رسمياً؟

بحسب وزارة التجارة، الوسيلتان المعتمدتان للإبلاغ عن المخالفات التجارية هما تطبيق **بلاغ تجاري** والرقم **1900**، وتنبّه أن مواقع تدّعي غير ذلك احتيالية. معنى هذا لك كتاجر: شكوى غير محلولة قد تنتهي هناك، فالأفضل معالجتها مبكراً. (لم نتحقق من صفحة رسمية عن منصة "معروف"، فلم نذكرها.)

## ما الممارسات التي تقلل الشكاوى؟

الموثق نظامياً: **إشعار العميل بالتأخر المتوقع** (المادة 14). والموثق بحثياً: عرض تاريخ تسليم واقعي (Narvar)، وأن عدم الإبلاغ هو ما يزعج العميل. أما الباقي فرأينا العملي:

1. اعرض تاريخاً **واقعياً** ولو أطول قليلاً، وأوفِ به.
2. أرسل رابط تتبع عند خروج الطلب للتوصيل.
3. راقب الطلبات المتأخرة يومياً وأخبر العميل **قبل** أن يسأل.
4. اطلب دبوس الموقع بدل العنوان النصي لتقليل الضياع.

في **مسار برو** تُلوَّن الطلبات المتأخرة في شاشة الكاشير، ويفتح العميل رابط تتبع بحالة الطلب، ويعرض الوقت المتوقع للوصول عند تفعيل الميزة. المنصة لا تغني عن إبلاغ العميل، لكنها تسهّل معرفتك بالتأخر مبكراً.`,
    faq: [
      ["ما نسبة التأخر في التوصيل؟", "لا يوجد رقم سعودي موثق وجدناه. استطلاع Narvar الأمريكي 2025 ذكر أن 74% واجهوا تأخراً واحداً على الأقل في سنة، وهو لا يمثل السعودية."],
      ["هل يلزمني نظاماً إخبار العميل بالتأخر؟", "نعم، المادة 14(2) من نظام التجارة الإلكترونية تلزم مقدّم الخدمة بإشعار المستهلك بأي تأخر متوقع."],
      ["متى يحق للعميل فسخ الطلب بسبب التأخر؟", "إذا تجاوز التأخر 15 يوماً عن الموعد المتفق عليه، بحسب المادة 14(1)، مع استثناءات كالقوة القاهرة والتمديد المتفق عليه."],
      ["أين يقدّم العميل بلاغاً عن مخالفة تجارية؟", "وزارة التجارة تعتمد تطبيق بلاغ تجاري والرقم 1900 كقناتين رسميتين."],
      ["كيف يساعد مسار برو في التأخر؟", "يعرض الطلبات المتأخرة لفريقك ويعطي العميل رابط تتبع. إبلاغ العميل بالتأخر يبقى مسؤوليتك."],
    ],
    sources: [
      ["Narvar: 2025 State of Post-Purchase Report", "https://corp.narvar.com/blog/nightmare-on-main-street-anxious-online-shoppers-want-a-happy-ending", "74% تأخر واحد على الأقل، 73% تاريخ التسليم، 45% (مستهلكون أمريكيون)"],
      ["Retail Dive: study on shipping delays (19 Oct 2020)", "https://www.retaildive.com/news/study-over-one-third-of-shoppers-experience-substantial-shipping-delays/587196/", "36% تأخر كبير و19% أُبقوا على اطلاع"],
      ["Baymard: cart abandonment rate statistics", "https://baymard.com/blog/cart-abandonment-rate-statistics", "التوصيل البطيء 20% من حالات ترك السلة"],
      ["نظام التجارة الإلكترونية (PDF) — وزارة الاستثمار", "https://misa.gov.sa/app/uploads/2025/07/E-Commerce-Law.pdf", "المادتان 8 و14"],
      ["وزارة التجارة: قاعدة الـ15 يوماً", "https://mc.gov.sa/en/mediacenter/News/Pages/10-07-19-01.aspx", "تأكيد حق الفسخ عند التأخر 15 يوماً"],
      ["وزارة التجارة: غرامات 12 متجراً (2022)", "https://mc.gov.sa/en/mediacenter/News/Pages/06-03-22-01.aspx", "12 متجراً و418 بلاغاً"],
      ["وزارة التجارة: القنوات الرسمية للإبلاغ", "https://mc.gov.sa/en/mediacenter/News/Pages/09-05-23-01.aspx", "بلاغ تجاري و1900"],
      ["وزارة التجارة: مسودة تعديل (استطلاع)", "https://mc.gov.sa/en/mediacenter/News/Pages/24-11-20-01.aspx", "مسودة الاسترداد خلال 14 يوماً (وضعها غير مؤكد)"],
    ],
  },
  en: {
    title: "Late delivery and customer complaints: what causes them and what actually reduces cancellations?",
    crumb: "Late delivery and complaints",
    desc: "Documented statistics on late delivery and customer expectations, what the Saudi E-Commerce Law says about delays, the Ministry of Commerce's official complaint channels, and practical ways to reduce complaints.",
    keywords: "late delivery, customer complaints, order cancellation, order tracking, Saudi e-commerce law, Ministry of Commerce 1900, Msar Pro",
    about: ["late delivery", "customer complaints", "Saudi E-Commerce Law"],
    tldr: [
      "Narvar's 2025 survey (3,461 US consumers): 74% had at least one late delivery in a year, and about half are less likely to shop again with that retailer after a delay.",
      "Same survey: 73% said the estimated delivery date affected a purchase decision. These are US figures, not Saudi shares.",
      "In Saudi Arabia, a consumer may cancel if delivery is more than 15 days late, and the store must notify the consumer of any expected delay (Article 14).",
      "The Ministry of Commerce names 1900 and the Commercial Violation app as its official channels for reporting commercial violations.",
      "**Msar Pro** gives the customer a tracking link and flags late orders for your team: tools that support early notification, nothing more.",
    ],
    fig: {
      type: "flow", title: "Points to notify the customer during an order", caption: "Illustration: suggested notification points. Notifying of an expected delay is a legal duty under Article 14.",
      steps: [["At order", "A realistic delivery date"], ["Preparing", "A notice that work has started"], ["Out for delivery", "Tracking link and driver name"], ["If late", "An immediate notice with the reason and new time"], ["After delivery", "Confirmation and a rating"]],
    },
    body: `## What causes delivery complaints?

We found no Saudi study counting complaint causes, so we rely on foreign research (we flag whom each figure covers):

- **Narvar** (a tracking vendor; 2025 survey of 3,461 US consumers; self-reported): **74%** had at least one late delivery in a year, **73%** said the estimated delivery date affected a purchase decision, and **45%** were more likely to buy if the date was shown at checkout. About half are less likely to shop again after a delay, and 6% stopped shopping with that retailer.
- **Narvar 2020**, as reported by Retail Dive: 36% experienced substantial delays and only 19% said retailers kept them well informed. The report suggests shoppers tolerate delays when told.
- **Baymard** (survey year and sample size not stated on the page): 20% of cart abandonments cite slow delivery (excluding mere browsers), and 40% cite extra costs being too high.

We found no verifiable source on wrong-address rates.

## What does the E-Commerce Law say about delays?

From the law text (Ministry of Investment site; we did not read the Executive Regulations):

- **Article 14(1):** the consumer may rescind if the provider delays delivery by more than 15 days from the contract date or the agreed date (unless an extension was agreed or force majeure applies), and may demand a refund of amounts and costs caused by the delay.
- **Article 14(2):** the provider must **notify the consumer** of any expected delay or circumstance affecting delivery.
- **Article 8:** the invoice must state the delivery date and place.

The Ministry of Commerce confirmed the 15-day rule on its news page. In 2022 the Ministry announced penalties on 12 online stores for not honoring termination requests after delays, not informing consumers of expected delays and not issuing invoices, after receiving 418 reports, and ordered refunds. A **draft amendment** was put out for consultation mentioning refunds within 14 days; we did not verify its current status.

## Where can a customer officially complain?

Per the Ministry of Commerce, the authorized means of reporting commercial violations are the **Commercial Violation app** and the number **1900**, and it warns that sites claiming otherwise are fraudulent. For you as a merchant this means an unresolved complaint may end up there, so handle it early. (We could not verify an official page on the "Maroof" platform, so we do not cover it.)

## Which practices reduce complaints?

Legally documented: **notify the customer of an expected delay** (Article 14). Documented by research: showing a realistic delivery date (Narvar), and that not being informed is what bothers customers. The rest is our practical view:

1. Show a **realistic** date even if slightly longer, and keep it.
2. Send a tracking link when the order goes out for delivery.
3. Watch late orders daily and tell the customer **before** they ask.
4. Ask for a map pin instead of a text address to reduce losses.

In **Msar Pro**, late orders are color-flagged on the cashier screen, the customer opens a tracking link with the order status, and an estimated arrival time shows when that feature is enabled. The platform does not replace informing the customer, but it makes it easier to know early that an order is late.`,
    faq: [
      ["What share of deliveries are late?", "We found no verified Saudi figure. Narvar's US 2025 survey says 74% had at least one late delivery in a year, which does not represent Saudi Arabia."],
      ["Does the law require me to tell the customer about a delay?", "Yes. Article 14(2) of the E-Commerce Law requires the provider to notify the consumer of any expected delay."],
      ["When can a customer cancel because of a delay?", "When the delay exceeds 15 days from the agreed date, per Article 14(1), with exceptions such as force majeure and agreed extensions."],
      ["Where does a customer report a commercial violation?", "The Ministry of Commerce names the Commercial Violation app and the number 1900 as its official channels."],
      ["How does Msar Pro help with delays?", "It flags late orders to your team and gives the customer a tracking link. Informing the customer of a delay remains your responsibility."],
    ],
    sources: [
      ["Narvar: 2025 State of Post-Purchase Report", "https://corp.narvar.com/blog/nightmare-on-main-street-anxious-online-shoppers-want-a-happy-ending", "74% at least one delay, 73% delivery date, 45% (US consumers)"],
      ["Retail Dive: study on shipping delays (Oct 19, 2020)", "https://www.retaildive.com/news/study-over-one-third-of-shoppers-experience-substantial-shipping-delays/587196/", "36% substantial delays and 19% kept informed"],
      ["Baymard: cart abandonment rate statistics", "https://baymard.com/blog/cart-abandonment-rate-statistics", "Slow delivery cited in 20% of abandonments"],
      ["E-Commerce Law (PDF) — Ministry of Investment (MISA)", "https://misa.gov.sa/app/uploads/2025/07/E-Commerce-Law.pdf", "Articles 8 and 14"],
      ["Ministry of Commerce: the 15-day rule", "https://mc.gov.sa/en/mediacenter/News/Pages/10-07-19-01.aspx", "Confirms the right to rescind after a 15-day delay"],
      ["Ministry of Commerce: 12 stores penalized (2022)", "https://mc.gov.sa/en/mediacenter/News/Pages/06-03-22-01.aspx", "12 stores and 418 reports"],
      ["Ministry of Commerce: official reporting channels", "https://mc.gov.sa/en/mediacenter/News/Pages/09-05-23-01.aspx", "Commercial Violation app and 1900"],
      ["Ministry of Commerce: draft amendment (consultation)", "https://mc.gov.sa/en/mediacenter/News/Pages/24-11-20-01.aspx", "Draft 14-day refund (status unconfirmed)"],
    ],
  },
};
