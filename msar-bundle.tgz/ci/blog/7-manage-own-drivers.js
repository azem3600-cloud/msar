// مقال 7: إدارة مناديب المتجر الخاصين (إسناد، تتبع، إثبات تسليم، تحصيل الدفع عند الاستلام).
module.exports = {
  slug: "managing-own-delivery-drivers", order: 7, date: "2026-11-22",
  ar: {
    title: "كيف تدير مناديب متجرك الخاصين؟ الإسناد والتتبع وإثبات التسليم وتحصيل الدفع عند الاستلام",
    crumb: "إدارة المناديب الخاصين",
    desc: "ممارسات عملية لإدارة مناديب التوصيل التابعين لمتجرك: إسناد الطلبات، التتبع المباشر، إثبات التسليم، مطابقة المبالغ المحصّلة عند الاستلام، ومؤشرات الأداء، من مصادر موثقة.",
    keywords: "إدارة مناديب التوصيل, تتبع المناديب, إثبات التسليم, تحصيل الدفع عند الاستلام, مطابقة المبالغ المحصلة, توزيع الطلبات على المناديب, مسار برو",
    about: ["إدارة مناديب التوصيل", "إثبات التسليم", "الدفع عند الاستلام"],
    tldr: [
      "المصادر التي قرأناها (Spoke وLocate2u وPidge) مدونات شركات برامج، فتوصياتها ممارسات مقترحة وليست أبحاثاً مستقلة.",
      "تتفق على أربعة أمور: **إسناد منظم** حسب توفر كل مندوب، و**تتبع مباشر** يعطي العميل وقت وصول، و**إثبات تسليم** بصورة أو توقيع مع الوقت والموقع، و**مطابقة** المبالغ المحصّلة مع الطلبات.",
      "في الدفع عند الاستلام تقترح Pidge ربط الطلب بالمندوب وحالة التسليم والمبلغ المحصّل في سجل واحد، ومتابعة المبالغ التي لم تُسلَّم بعد لكل مندوب.",
      "لم نجد في المصادر قواعد رقمية لمواعيد تسليم النقد. فكرة التسوية اليومية أدناه قراءتنا العملية.",
      "**مسار برو** يعطي المندوب تطبيقاً يستلم فيه الطلب ويسجّل التسليم والتحصيل، مع تتبع مباشر للتاجر.",
    ],
    fig: {
      type: "flow", title: "دورة الطلب مع مندوبك", caption: "رسم توضيحي: مراحل الطلب من الإسناد إلى مطابقة المبلغ المحصّل.",
      steps: [["إسناد", "حسب توفر المندوب والمنطقة"], ["تتبع", "موقع مباشر ووقت وصول"], ["تسليم", "صورة أو توقيع بوقت وموقع"], ["تحصيل", "تسجيل المبلغ عند الاستلام"], ["مطابقة", "المبالغ المحصّلة مقابل الطلبات"]],
    },
    body: `## لماذا لا تكفي المحادثات والجداول؟

> هذا القسم قراءتنا العملية وليس نتيجة بحث. عندما يكثر عدد الطلبات والمناديب يصعب في المحادثات معرفة من أخذ أي طلب، وأين وصل، وكم حصّل. لذلك تدعو المصادر إلى تنظيم الدورة كاملة في نظام واحد.

## كيف تسند الطلبات للمناديب؟

- تنصح Spoke وLocate2u بحفظ ملف لكل مندوب فيه أوقات توفره، والرجوع إليه عند الإسناد اليومي، لتجنب طلبات بلا مندوب أو مندوب مثقل.
- استخدم مسارات مرتبة تراعي نوافذ الوقت والأولويات، وأعد ترتيبها في نفس اليوم إذا طلب العميل تغييراً (Spoke).
- إذا كان لك أكثر من فرع، يبدأ الإسناد من الفرع الأقرب للعميل (هذا ما يفعله مسار برو).

## ماذا يفيدك التتبع المباشر؟

ترى Locate2u أن الموقع المباشر يتيح إعطاء العميل وقت وصول فورياً، ومعالجة التأخير، ومتابعة الالتزام بالمسار، والاطمئنان على سلامة المندوب. وتضيف Spoke أن التتبع داخل سياق المسار (آخر محطة منجزة والتالية) يساعدك في إعادة إسناد محطة جديدة للمندوب الأقل تأثراً.

## كيف توثّق التسليم؟

توصي Locate2u بعشر ممارسات لإثبات التسليم، أهمها:

- صورة واضحة للطرد مع ظهور بيانات الطلب، ولقطة أوسع تُظهر المكان.
- توقيع إلكتروني للطلبات عالية القيمة.
- تسجيل الوقت والموقع مع كل إثبات.
- توثيق الحالات الفاشلة وملاحظات العميل.
- إرسال إشعار فوري للعميل برابط الإثبات.
- حفظ الإثباتات رقمياً وتوحيد طريقتها بين كل المناديب.

## كيف تتعامل مع الدفع عند الاستلام؟

تعرض Pidge فكرة ربط وسم الدفع عند الاستلام بالمندوب وحالة التسليم والمبلغ المحصّل والمحاولات الفاشلة والتسليم النقدي في سير عمل واحد، ومتابعة المبالغ المحصّلة والمعلّقة والمنازعات لكل مندوب، ومطابقتها مع سجلات التسوية بدل الاعتماد على الجداول اليدوية.

لم نجد في المصادر قواعد محددة لمواعيد تسليم النقد. قراءتنا العملية:

- حدّد موعداً ثابتاً لتسليم المندوب ما حصّله (يومياً مثلاً) وسجّله.
- قارن مجموع التحصيل في سجل المندوب بمجموع الطلبات المسلَّمة بالدفع عند الاستلام.
- اجعل الفروقات ظاهرة في اليوم نفسه لا آخر الشهر.

## ما المؤشرات التي تتابعها؟

تقترح Locate2u استخدام تقييمات العملاء لمعرفة المناديب المتميزين وملاحظة أي تراجع مبكراً وتحديد من يحتاج تدريباً. مؤشرات أخرى مقترحة من قراءتنا: نسبة الطلبات المسلّمة من أول محاولة، ومتوسط زمن التسليم، وعدد الطلبات المتأخرة.

> بعض المصادر تعرض حالات عملاء (مثل تقليل زمن المحطة) لكنها شهادات من الشركات نفسها. لا نذكر أرقامها هنا لأنها لا تثبت نتيجة مماثلة لمتجرك.`,
    faq: [
      ["هل أحتاج تطبيقاً للمندوب أم يكفي الاتصال بالجوال؟", "تذكر المصادر التتبع بالموقع وتسجيل التسليم بصورة أو توقيع من تطبيق المندوب. الاتصال وحده لا يعطيك سجلاً قابلاً للمراجعة."],
      ["كيف أتجنب فروقات النقد من الدفع عند الاستلام؟", "اربط كل طلب نقدي بمندوب وحالة تسليم ومبلغ مسجّل، وتابع المبالغ التي لم تُسلَّم لكل مندوب، وطابقها بالسجلات (فكرة Pidge). الموعد اليومي للتسوية اقتراحنا العملي."],
      ["هل صورة التسليم كافية؟", "تنصح Locate2u بصورة واضحة مع الوقت والموقع، وبتوقيع للطلبات عالية القيمة، وبحفظ الإثباتات رقمياً."],
      ["ماذا يقدّم مسار برو للمندوب؟", "تطبيق أندرويد يستلم فيه المندوب الطلب ويفتح الملاحة ويتصل بالعميل ويسجّل التسليم والتحصيل، مع تتبع مباشر على الخريطة لدى التاجر."],
    ],
    sources: [
      ["Spoke Dispatch: How to manage delivery drivers (محدّث أكتوبر 2026)", "https://spoke.com/dispatch/blog/how-to-manage-delivery-drivers", "الإسناد والمسارات والتتبع وإثبات التسليم"],
      ["Locate2u: How to manage your drivers (يونيو 2024، محدّث أكتوبر 2026)", "https://locate2u.com/blog/delivery-management/how-to-manage-your-drivers/", "جداول المناديب والتتبع وإثبات التسليم والتقييمات"],
      ["Locate2u: 10 best practices for proof of delivery (فبراير 2025، محدّث أكتوبر 2026)", "https://locate2u.com/blog/delivery-management/10-best-practices-for-capturing-clear-and-reliable-proof-of-delivery/", "عشر ممارسات لإثبات التسليم"],
      ["Pidge: Automated COD reconciliation for delivery businesses", "https://pidge.in/blog/cod-reconciliation-automation-delivery-businesses", "ربط التحصيل بالمندوب والتسليم ومطابقته"],
    ],
  },
  en: {
    title: "How to manage your own delivery drivers: dispatch, tracking, proof of delivery and cash on delivery",
    crumb: "Managing own drivers",
    desc: "Practical ways to manage the delivery drivers who work for your store: assigning orders, live tracking, proof of delivery, reconciling cash collected on delivery, and performance indicators, from cited sources.",
    keywords: "manage delivery drivers, driver tracking, proof of delivery, cash on delivery collection, COD reconciliation, dispatch orders to drivers, Msar Pro",
    about: ["Delivery driver management", "Proof of delivery", "Cash on delivery"],
    tldr: [
      "The sources we read (Spoke, Locate2u and Pidge) are software-vendor blogs, so their advice is suggested practice, not independent research.",
      "They agree on four things: **organized dispatch** based on each driver's availability, **live tracking** that gives customers an ETA, **proof of delivery** with a photo or signature plus time and location, and **reconciling** cash collected against orders.",
      "For cash on delivery, Pidge suggests linking the order, the driver, the delivery status and the collected amount in one record, and tracking each driver's pending cash submissions.",
      "We found no numeric rules in the sources on when cash should be handed in. The daily settlement idea below is our practical reading.",
      "**Msar Pro** gives the driver an app to receive the order and record delivery and collection, with live tracking for the merchant.",
    ],
    fig: {
      type: "flow", title: "An order's cycle with your driver", caption: "Illustration: stages from dispatch to reconciling the collected amount.",
      steps: [["Dispatch", "By driver availability and area"], ["Track", "Live location and ETA"], ["Deliver", "Photo or signature with time and location"], ["Collect", "Record the amount on delivery"], ["Reconcile", "Collected amounts against orders"]],
    },
    body: `## Why are chats and spreadsheets not enough?

> This section is our practical reading, not a research finding. As orders and drivers grow, chats make it hard to know who took which order, where it is, and how much was collected. That is why the sources push for running the whole cycle in one system.

## How do you assign orders to drivers?

- Spoke and Locate2u advise keeping a profile for each driver with availability, and checking it when assigning each day's routes, to avoid unassigned stops or overloaded drivers.
- Use ordered routes that respect time windows and priorities, and re-plan the same day if a customer asks for a change (Spoke).
- With several branches, assignment starts from the branch nearest to the customer (this is what Msar Pro does).

## What does live tracking give you?

Locate2u says live location lets you give customers an instant ETA, handle delays, follow route compliance, and check on driver safety. Spoke adds that tracking in the context of the route (last completed stop and the next) helps you reassign a new stop to the least-affected driver.

## How do you document delivery?

Locate2u recommends ten proof-of-delivery practices, mainly:

- A clear photo of the parcel with its label visible, plus a wider shot showing the place.
- An e-signature for high-value orders.
- Time and location recorded with every proof.
- Failed deliveries and customer notes documented.
- An instant notification to the customer with a link to the proof.
- Proofs stored digitally and standardized across all drivers.

## How do you handle cash on delivery?

Pidge describes linking the COD tag, driver, delivery status, collected amount, failed attempts and cash submission in one workflow, tracking collected and pending amounts and disputes for each driver, and reconciling them with settlement records instead of manual spreadsheets.

We found no specific rules in the sources on when cash must be handed in. Our practical reading:

- Set a fixed time for drivers to hand in what they collected (daily, for example) and record it.
- Compare the total in a driver's record with the total of delivered cash-on-delivery orders.
- Make differences visible the same day, not at month end.

## Which indicators should you track?

Locate2u suggests using customer ratings to find top drivers, spot declines early, and decide who needs training. Other indicators from our own reading: the share of orders delivered on the first attempt, average delivery time, and the number of late orders.

> Some sources show customer cases (such as shorter time per stop), but they are the vendors' own testimonials. We do not quote their numbers because they do not prove the same result for your store.`,
    faq: [
      ["Do I need a driver app, or is a phone call enough?", "The sources describe location tracking and recording delivery with a photo or signature from a driver app. A call alone gives you no reviewable record."],
      ["How do I avoid cash differences on cash on delivery?", "Link every cash order to a driver, a delivery status and a recorded amount, track each driver's unsubmitted amounts, and match them against records (Pidge's idea). A daily settlement time is our practical suggestion."],
      ["Is a delivery photo enough?", "Locate2u recommends a clear photo with time and location, a signature for high-value orders, and storing proofs digitally."],
      ["What does Msar Pro offer the driver?", "An Android app where the driver receives the order, opens navigation, calls the customer and records delivery and collection, with live map tracking for the merchant."],
    ],
    sources: [
      ["Spoke Dispatch: How to manage delivery drivers (updated October 2026)", "https://spoke.com/dispatch/blog/how-to-manage-delivery-drivers", "Dispatch, routes, tracking and proof of delivery"],
      ["Locate2u: How to manage your drivers (June 2024, updated October 2026)", "https://locate2u.com/blog/delivery-management/how-to-manage-your-drivers/", "Driver schedules, tracking, proof of delivery and ratings"],
      ["Locate2u: 10 best practices for proof of delivery (February 2025, updated October 2026)", "https://locate2u.com/blog/delivery-management/10-best-practices-for-capturing-clear-and-reliable-proof-of-delivery/", "Ten proof-of-delivery practices"],
      ["Pidge: Automated COD reconciliation for delivery businesses", "https://pidge.in/blog/cod-reconciliation-automation-delivery-businesses", "Linking collection to the driver and delivery, and reconciling it"],
    ],
  },
};
