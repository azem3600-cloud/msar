#!/usr/bin/env python3
"""توليد أصوات التنبيه — صوت "صرّافة" (كاشير: كا-تشينغ) عالي وواضح، بدون مكتبات خارجية.
order.wav  : لوحة التحكم / الكاشير — كا-تشينغ مرتين
driver.wav : جوال المندوب — كا-تشينغ ثلاث مرات متتالية (مميز)
"""
import math, os, random, struct, sys, wave

SR = 44100
OUT = sys.argv[1] if len(sys.argv) > 1 else "web/sounds"
random.seed(7)


def add(buf, i0, sig):
    for k, v in enumerate(sig):
        if 0 <= i0 + k < len(buf):
            buf[i0 + k] += v


def lowpass(sig, fc):
    a = math.exp(-2 * math.pi * fc / SR); y = 0.0; out = []
    for x in sig:
        y = (1 - a) * x + a * y; out.append(y)
    return out


def thunk(dur=0.07, amp=1.0):
    """"كا" — صوت درج الصرّافة: ضربة خشنة منخفضة بدون صفير"""
    n = int(dur * SR)
    noise = lowpass([random.uniform(-1, 1) for _ in range(n)], 1400)
    out = []
    for k in range(n):
        t = k / SR
        body = math.sin(2 * math.pi * 170 * t) * math.exp(-t / 0.03)
        out.append(amp * (2.2 * noise[k] * math.exp(-t / 0.015) + 0.8 * body))
    return out


def bell(f, dur, amp=1.0):
    """"تشينغ" — جرس دافئ (توافقيات قليلة ومنخفضة — بدون صفير حاد)"""
    partials = ((1.0, 1.0, 0.55), (2.0, 0.28, 0.30), (2.76, 0.12, 0.18))
    n = int(dur * SR); out = []
    for k in range(n):
        t = k / SR; att = min(1.0, t / 0.004); s = 0.0
        for r, a, d in partials:
            s += a * math.sin(2 * math.pi * f * r * t) * math.exp(-t / d)
        out.append(amp * att * s)
    return out


def ka_ching(buf, at, bell_f=1320, scale=1.0):
    i = int(at * SR)
    add(buf, i, thunk(amp=0.9 * scale))
    add(buf, i + int(0.06 * SR), thunk(0.05, amp=0.5 * scale))
    add(buf, i + int(0.11 * SR), bell(bell_f, 1.0, amp=1.0 * scale))
    add(buf, i + int(0.13 * SR), bell(bell_f * 1.25, 0.8, amp=0.5 * scale))


def write(buf, path):
    buf = lowpass(buf, 4500)                                   # إزالة أي حدة/صفير
    peak = max(abs(x) for x in buf) or 1.0
    out = [math.tanh(x / peak * 1.8) for x in buf]          # ضغط لرفع العلو
    peak = max(abs(x) for x in out) or 1.0
    data = b"".join(struct.pack("<h", int(x / peak * 0.95 * 32767)) for x in out)
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data)


os.makedirs(OUT, exist_ok=True)

b = [0.0] * int(2.6 * SR)
ka_ching(b, 0.0)
ka_ching(b, 1.15)
write(b, os.path.join(OUT, "order.wav"))

b = [0.0] * int(2.7 * SR)
for j in range(3):
    ka_ching(b, j * 0.75, bell_f=1480)
write(b, os.path.join(OUT, "driver.wav"))
print("sounds ->", OUT)


# ================================================================ أصوات ناعمة (قائمة الاختيار في الإعدادات)
def tone(f, dur, amp=1.0, att=0.012, dec=0.35, harm=((1, 1.0), (2, 0.18), (3, 0.05))):
    """نغمة ناعمة: بداية لطيفة (att) وخفوت تدريجي (dec) — بدون حدة"""
    n = int(dur * SR); out = []
    for k in range(n):
        t = k / SR; env = min(1.0, t / att) * math.exp(-t / dec)
        out.append(amp * env * sum(a * math.sin(2 * math.pi * f * h * t) for h, a in harm))
    return out


def drop(f0=900, f1=420, dur=0.28, amp=1.0):
    """قطرة ماء: نغمة تنزل بسرعة"""
    n = int(dur * SR); out = []; ph = 0.0
    for k in range(n):
        t = k / SR; f = f1 + (f0 - f1) * math.exp(-t / 0.05)
        ph += 2 * math.pi * f / SR
        out.append(amp * math.sin(ph) * min(1.0, t / 0.004) * math.exp(-t / 0.09))
    return out


def soft_write(buf, name, peak=0.55):
    buf = lowpass(buf, 5200)
    m = max(abs(x) for x in buf) or 1.0
    data = b"".join(struct.pack("<h", int(x / m * peak * 32767)) for x in buf)
    with wave.open(os.path.join(OUT, name), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(data)


def mk(length):
    return [0.0] * int(length * SR)


# 1) هادئ (الافتراضي): نغمتان لطيفتان صاعدتان
b = mk(1.5); add(b, 0, tone(523.25, 0.9, 1.0, dec=0.28)); add(b, int(0.20 * SR), tone(659.25, 1.0, 0.9, dec=0.32)); soft_write(b, "s-soft.wav", 0.5)
# 2) قطرة: قطرتان خفيفتان
b = mk(1.0); add(b, 0, drop()); add(b, int(0.32 * SR), drop(1050, 520, amp=0.8)); soft_write(b, "s-drop.wav", 0.55)
# 3) جرس ناعم: ضربة جرس دافئة واحدة
b = mk(1.7); add(b, 0, bell(784, 1.6, 1.0)); add(b, int(0.01 * SR), bell(1176, 1.0, 0.25)); soft_write(b, "s-bell.wav", 0.5)
# 4) رنين: ثلاث نغمات صاعدة (ماريمبا خفيفة)
b = mk(1.6)
for i, f in enumerate((587.33, 698.46, 880.0)):
    add(b, int(i * 0.17 * SR), tone(f, 0.7, 1.0, att=0.006, dec=0.16, harm=((1, 1.0), (4, 0.12))))
soft_write(b, "s-chime.wav", 0.55)
# 5) واضح: نغمة مزدوجة تتكرر مرتين — أوضح من الباقي (مناسب للمندوب) لكنها ناعمة
b = mk(2.2)
for j in range(2):
    for i, f in enumerate((659.25, 880.0, 1046.5)):
        add(b, int((j * 0.95 + i * 0.14) * SR), tone(f, 0.55, 1.0, att=0.008, dec=0.2))
soft_write(b, "s-clear.wav", 0.7)
# صوت صامت (قناة "كتم الصوت" في أندرويد: اهتزاز فقط)
with wave.open(os.path.join(OUT, "s-silent.wav"), "wb") as w:
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(b"\x00\x00" * int(0.2 * SR))
print("soft sounds ->", OUT)
