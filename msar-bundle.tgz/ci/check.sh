#!/usr/bin/env bash
# مسار — فحوصات سريعة قبل أي Pull Request
# الاستخدام: bash ci/check.sh
# فحص SQL (اختياري): شغّل Postgres 16 محلياً، أنشئ الأدوار anon/authenticated/service_role
# و schema باسم auth فيه جدول users(id uuid, email text, raw_app_meta_data jsonb, raw_user_meta_data jsonb)
# والدالتين auth.uid() و auth.jwt()، ثم شغّل supabase/schema.sql وبعده كل ملفات supabase/migrations بالترتيب (مرتين للتأكد إنها آمنة لإعادة التشغيل).
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
echo "== web JS"
for f in web/js/*.js web/sw.js; do node --check "$f"; done
echo "== build script"
bash -n ci/build.sh
echo "== edge functions (TypeScript)"
TMP="$(mktemp -d)"
for fn in zid admin support salla; do cp "supabase/functions/$fn/index.ts" "$TMP/$fn.ts"; done
cp ci/stubs.d.ts "$TMP/stubs.d.ts"
${TSC:-npx -y -p typescript@5.6.3 tsc} --noEmit --target es2022 --lib es2022,dom --strict false --skipLibCheck \
  "$TMP/stubs.d.ts" "$TMP/zid.ts" "$TMP/admin.ts" "$TMP/support.ts" "$TMP/salla.ts"
rm -rf "$TMP"
echo "✅ all checks passed"
