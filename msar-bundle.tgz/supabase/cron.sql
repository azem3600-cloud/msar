-- =====================================================================
--  مسار — المهام المجدولة (تُشغل بعد schema.sql)
--  __PROJECT_REF__ يُستبدل تلقائياً بمعرّف مشروع Supabase
-- =====================================================================
create extension if not exists pg_cron;
create extension if not exists pg_net;

insert into public.app_settings(key, value) values ('functions_url', '"https://__PROJECT_REF__.supabase.co/functions/v1"')
on conflict (key) do update set value = excluded.value;

create or replace function public.call_zid_function(p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare v_url text; v_key text;
begin
  select value #>> '{}' into v_url from public.app_settings where key = 'functions_url';
  select value #>> '{}' into v_key from public.app_settings where key = 'cron_key';
  perform net.http_post(
    url := v_url || '/zid?action=' || p_action,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-key', v_key),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000);
end $$;
revoke execute on function public.call_zid_function(text) from public, anon, authenticated;

-- إرسال تحديث الحالة لزد فوراً
create or replace function public.zid_outbox_notify() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.call_zid_function('push');
  return null;
end $$;
drop trigger if exists zid_outbox_notify_trg on public.zid_outbox;
create trigger zid_outbox_notify_trg after insert on public.zid_outbox
  for each statement execute function public.zid_outbox_notify();

do $$ begin perform cron.unschedule('msar-zid-cron'); exception when others then null; end $$;
do $$ begin perform cron.unschedule('msar-housekeeping'); exception when others then null; end $$;
select cron.schedule('msar-zid-cron', '* * * * *', $$
  select public.call_zid_function('cron')
  where exists (select 1 from public.store_secrets where zid_tokens ? 'access_token')
$$);
select cron.schedule('msar-housekeeping', '15 0 * * *', $$ select public.housekeeping() $$);
