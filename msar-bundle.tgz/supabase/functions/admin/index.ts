// =====================================================================
//  مسار (MSAR) — إدارة المستخدمين والهوية (Supabase Edge Function: admin)
//  صاحب المنصة : owner_status | owner_bootstrap | owner_create_store | owner_reset_admin
//  مدير المتجر : create_user | set_password | staff_reset_link | delete_user | set_active
//                invite_create | invite_revoke
//  عام (بالرابط): invite_info | invite_accept_password | invite_prepare_google
//  المستخدم     : invite_accept | set_my_email
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT" (نتحقق داخلياً)
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false, autoRefreshToken: false } });
const EMAIL_DOMAIN = "msar.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });

const cleanUsername = (u: string) => String(u ?? "").trim().toLowerCase();
const validUsername = (u: string) => /^[a-z0-9._-]{3,32}$/.test(u);
const cleanEmail = (e: string) => String(e ?? "").trim().toLowerCase();
const validEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(e);
const isInternal = (e?: string | null) => !e || e.endsWith(`.${EMAIL_DOMAIN}`);
const ROLES = ["admin", "cashier", "driver"];

async function webUrl() {
  const { data } = await db.from("app_settings").select("value").eq("key", "web_url").maybeSingle();
  return String(data?.value ?? "").replace(/\/?$/, "/");
}

// المستخدم الحالي من التوكن
async function authUser(req: Request) {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data } = await db.auth.getUser(token);
  return data?.user ?? null;
}
// ملفه النشط (المتجر الحالي والدور)
async function me(req: Request) {
  const u = await authUser(req);
  if (!u) return null;
  const { data: p } = await db.from("profiles").select("*").eq("id", u.id).maybeSingle();
  return p?.is_active ? { ...p, email: u.email } : null;
}
async function requireAdmin(req: Request) {
  const p = await me(req);
  if (p?.role !== "admin" || !p.store_id) throw Object.assign(new Error("غير مصرح"), { status: 401 });
  return p;
}
async function requireOwner(req: Request) {
  const p = await me(req);
  if (p?.role !== "owner") throw Object.assign(new Error("غير مصرح"), { status: 401 });
  return p;
}

async function findUserByEmail(email: string) {
  const { data: id, error } = await db.rpc("user_id_by_email", { p_email: email });
  if (error) throw new Error(error.message);
  if (!id) return null;
  const { data } = await db.auth.admin.getUserById(String(id));
  return data?.user ?? null;
}

async function membership(userId: string, storeId: number) {
  const { data } = await db.from("store_members").select("*").eq("user_id", userId).eq("store_id", storeId).maybeSingle();
  return data;
}
async function otherMemberships(userId: string, storeId: number) {
  const { data } = await db.from("store_members").select("store_id, is_active").eq("user_id", userId).neq("store_id", storeId);
  return data ?? [];
}
// الموظف "حصري" لهذا المتجر؟ (عشان ما يقدر مدير متجر يتحكم بحساب يستخدمه متجر ثاني)
async function exclusiveTo(userId: string, storeId: number) {
  return (await otherMemberships(userId, storeId)).length === 0;
}
// تفعيل العضوية كمتجر نشط في الملف
async function activate(userId: string, email: string, m: any) {
  const username = m.username ?? email ?? userId;
  const { error } = await db.from("profiles").upsert({
    id: userId, store_id: m.store_id, username, full_name: m.full_name, phone: m.phone ?? null,
    role: m.role, branch_id: m.branch_id ?? null, vehicle: m.vehicle ?? null, is_active: true, is_online: false,
  }, { onConflict: "id" });
  if (error) throw new Error(error.message);
}

async function createLegacyUser(store: any, b: any, role: string) {
  const username = cleanUsername(b.username);
  if (!validUsername(username)) throw new Error("اسم المستخدم لازم يكون إنجليزي (حروف/أرقام) من 3 إلى 32 حرف");
  if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
  if (!ROLES.includes(role)) throw new Error("الدور غير صحيح");
  const branchId = await checkBranch(store.id, role, b.branch_id);
  const { data: exists } = await db.from("store_members").select("id").eq("store_id", store.id).ilike("username", username).maybeSingle();
  if (exists) throw new Error("اسم المستخدم مستخدم من قبل");
  const fullName = String(b.full_name ?? username).trim();
  const { data, error } = await db.auth.admin.createUser({
    email: `${username}@${store.code}.${EMAIL_DOMAIN}`, password: String(b.password), email_confirm: true,
    app_metadata: { role, store_id: String(store.id), branch_id: branchId ? String(branchId) : null },
    user_metadata: { username, full_name: fullName, phone: b.phone ?? null, vehicle: b.vehicle ?? null },
  });
  if (error) throw new Error(/already/i.test(error.message) ? "اسم المستخدم مستخدم من قبل" : error.message);
  // Supabase يضيف app_metadata بعد إنشاء الصف، فالـ trigger ما يلحق — ننشئ العضوية والملف هنا مباشرة
  await db.from("store_members").upsert({ store_id: store.id, user_id: data.user!.id, role, branch_id: branchId, username,
    full_name: fullName, phone: b.phone ?? null, vehicle: b.vehicle ?? null, is_active: true }, { onConflict: "store_id,user_id" });
  await activate(data.user!.id, `${username}@${store.code}.${EMAIL_DOMAIN}`, { store_id: store.id, username, full_name: fullName,
    phone: b.phone ?? null, role, branch_id: branchId, vehicle: b.vehicle ?? null });
  return data.user!.id;
}

async function checkBranch(storeId: number, role: string, branchIdRaw: unknown) {
  if (role === "admin" && !branchIdRaw) return null;
  if (!branchIdRaw) throw new Error("حدد الفرع");
  const { data: br } = await db.from("branches").select("id").eq("id", Number(branchIdRaw)).eq("store_id", storeId).maybeSingle();
  if (!br) throw new Error("الفرع غير صحيح");
  return br.id as number;
}

async function inviteRow(token: string) {
  if (!/^[a-f0-9]{48}$/.test(String(token ?? ""))) return null;
  const { data } = await db.from("invites").select("*, store:stores(id, name, code, status), branch:branches(name)").eq("token", token).maybeSingle();
  if (!data || data.accepted_at || Date.parse(data.expires_at) < Date.now()) return null;
  if (!["trial", "active"].includes(data.store?.status)) return null;
  return data;
}
async function acceptInvite(inv: any, userId: string, email: string) {
  await db.from("store_members").upsert({
    store_id: inv.store_id, user_id: userId, role: inv.role, branch_id: inv.branch_id, username: null,
    full_name: inv.full_name, phone: inv.phone, vehicle: inv.vehicle, is_active: true,
  }, { onConflict: "store_id,user_id" });
  const m = await membership(userId, inv.store_id);
  // نخلي المتجر الجديد هو النشط (إلا لو كان صاحب المنصة)
  const { data: prof } = await db.from("profiles").select("role").eq("id", userId).maybeSingle();
  if (prof?.role !== "owner") await activate(userId, email, m);
  await db.from("invites").update({ accepted_at: new Date().toISOString() }).eq("token", inv.token);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const b = await req.json().catch(() => ({}));
    switch (b.action) {
      // ---------------------------------------------------------------- صاحب المنصة
      case "owner_status": {
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "owner");
        return json({ needs_bootstrap: (count ?? 0) === 0 });
      }
      case "owner_bootstrap": {
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "owner");
        if ((count ?? 0) > 0) return json({ error: "تم إنشاء حساب صاحب المنصة مسبقاً" }, 403);
        const username = cleanUsername(b.username);
        if (!validUsername(username)) throw new Error("اسم المستخدم لازم يكون إنجليزي من 3 إلى 32 حرف");
        if (!b.password || String(b.password).length < 8) throw new Error("كلمة المرور لازم تكون 8 أحرف أو أكثر");
        const { data, error } = await db.auth.admin.createUser({
          email: `${username}@owner.${EMAIL_DOMAIN}`, password: String(b.password), email_confirm: true,
          app_metadata: { role: "owner" }, user_metadata: { username, full_name: String(b.full_name ?? username) },
        });
        if (error) throw new Error(error.message);
        await db.from("profiles").upsert({ id: data.user!.id, store_id: null, username, role: "owner", full_name: String(b.full_name ?? username) }, { onConflict: "id" });
        if (b.web_url) await db.from("app_settings").upsert({ key: "web_url", value: String(b.web_url) });
        return json({ ok: true });
      }
      case "owner_create_store": {
        await requireOwner(req);
        const code = String(b.code ?? "").trim().toLowerCase();
        if (!/^[a-z0-9-]{2,30}$/.test(code)) throw new Error("رمز المتجر: حروف إنجليزية صغيرة وأرقام فقط");
        const { data: s, error } = await db.from("stores").insert({
          code, name: String(b.name ?? code), store_url: b.store_url ?? null,
          settings: { radius_km: 5, push_status: false, import_statuses: ["new", "preparing", "ready"] },
        }).select("*").single();
        if (error) throw new Error(/duplicate/i.test(error.message) ? "رمز المتجر مستخدم" : error.message);
        await createLegacyUser(s, { username: b.admin_username, password: b.admin_password, full_name: b.admin_name }, "admin");
        return json({ ok: true, store: s });
      }
      case "owner_reset_admin": {
        // صاحب المنصة يساعد تاجر نسي دخوله: رابط استعادة (للإيميل الحقيقي) أو كلمة مرور مؤقتة
        await requireOwner(req);
        const { data: adm } = await db.from("store_members").select("user_id, full_name").eq("store_id", Number(b.store_id)).eq("role", "admin").eq("is_active", true).order("id").limit(1).maybeSingle();
        if (!adm) throw new Error("ما فيه مدير لهذا المتجر");
        const { data: u } = await db.auth.admin.getUserById(adm.user_id);
        const email = u?.user?.email ?? "";
        if (!isInternal(email)) {
          const { data, error } = await db.auth.admin.generateLink({ type: "recovery", email, options: { redirectTo: `${await webUrl()}reset.html` } });
          if (error) throw new Error(error.message);
          return json({ ok: true, kind: "link", name: adm.full_name, email, link: data.properties?.action_link });
        }
        const temp = crypto.randomUUID().replace(/-/g, "").slice(0, 10);
        const { error } = await db.auth.admin.updateUserById(adm.user_id, { password: temp });
        if (error) throw new Error(error.message);
        return json({ ok: true, kind: "password", name: adm.full_name, username: email.split("@")[0], password: temp });
      }

      // ---------------------------------------------------------------- مدير المتجر
      case "create_user": {
        const p = await requireAdmin(req);
        const { data: s } = await db.from("stores").select("*").eq("id", p.store_id).single();
        const id = await createLegacyUser(s, b, b.role);
        return json({ ok: true, id });
      }
      case "set_password": {
        const p = await requireAdmin(req);
        const m = await membership(b.user_id, p.store_id);
        if (!m) throw new Error("المستخدم غير موجود");
        const { data: u } = await db.auth.admin.getUserById(b.user_id);
        if (!isInternal(u?.user?.email) || !(await exclusiveTo(b.user_id, p.store_id))) {
          throw new Error("هذا الحساب مربوط بإيميل — استخدم \"رابط استعادة\" بدل تغيير كلمة المرور");
        }
        if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
        const { error } = await db.auth.admin.updateUserById(b.user_id, { password: String(b.password) });
        if (error) throw new Error(error.message);
        return json({ ok: true });
      }
      case "staff_reset_link": {
        const p = await requireAdmin(req);
        const m = await membership(b.user_id, p.store_id);
        if (!m) throw new Error("المستخدم غير موجود");
        if (!(await exclusiveTo(b.user_id, p.store_id))) throw new Error("هذا الشخص عضو في متاجر أخرى — يقدر يستعيد كلمة المرور بنفسه من \"نسيت كلمة المرور\"");
        const { data: u } = await db.auth.admin.getUserById(b.user_id);
        const email = u?.user?.email ?? "";
        if (isInternal(email)) throw new Error("هذا الحساب باسم مستخدم — غيّر كلمة المرور مباشرة 🔑");
        const { data, error } = await db.auth.admin.generateLink({ type: "recovery", email, options: { redirectTo: `${await webUrl()}reset.html` } });
        if (error) throw new Error(error.message);
        return json({ ok: true, link: data.properties?.action_link, email });
      }
      case "delete_user": {
        const p = await requireAdmin(req);
        if (p.id === b.user_id) throw new Error("لا يمكنك حذف حسابك");
        const m = await membership(b.user_id, p.store_id);
        if (!m) throw new Error("المستخدم غير موجود");
        const others = await otherMemberships(b.user_id, p.store_id);
        const { count } = await db.from("orders").select("id", { count: "exact", head: true }).eq("driver_id", b.user_id).eq("store_id", p.store_id);
        if ((count ?? 0) > 0) {
          // عنده طلبات سابقة: نوقف عضويته بس عشان يبقى السجل
          await db.from("store_members").update({ is_active: false }).eq("id", m.id);
          await db.from("profiles").update({ is_active: false, is_online: false }).eq("id", b.user_id).eq("store_id", p.store_id);
          if (!others.some((o: any) => o.is_active)) await db.auth.admin.updateUserById(b.user_id, { ban_duration: "876000h" });
          return json({ ok: true, deactivated: true });
        }
        await db.from("store_members").delete().eq("id", m.id);
        if (others.length) {
          await db.from("profiles").update({ is_active: false, is_online: false }).eq("id", b.user_id).eq("store_id", p.store_id);
          return json({ ok: true, removed: true });
        }
        await db.from("profiles").delete().eq("id", b.user_id);
        const { error } = await db.auth.admin.deleteUser(b.user_id);
        if (error) throw new Error(error.message);
        return json({ ok: true, deleted: true });
      }
      case "set_active": {
        const p = await requireAdmin(req);
        const m = await membership(b.user_id, p.store_id);
        if (!m) throw new Error("المستخدم غير موجود");
        await db.from("store_members").update({ is_active: !!b.active }).eq("id", m.id);
        await db.from("profiles").update({ is_active: !!b.active, ...(b.active ? {} : { is_online: false }) }).eq("id", b.user_id).eq("store_id", p.store_id);
        // الحظر الكامل فقط إذا ما عنده أي متجر ثاني
        if (await exclusiveTo(b.user_id, p.store_id)) await db.auth.admin.updateUserById(b.user_id, { ban_duration: b.active ? "none" : "876000h" });
        return json({ ok: true });
      }
      case "invite_create": {
        const p = await requireAdmin(req);
        const email = cleanEmail(b.email);
        if (!validEmail(email) || isInternal(email)) throw new Error("اكتب إيميل صحيح");
        const role = String(b.role ?? "");
        if (!ROLES.includes(role)) throw new Error("الدور غير صحيح");
        const fullName = String(b.full_name ?? "").trim();
        if (fullName.length < 2) throw new Error("اكتب الاسم");
        const branchId = await checkBranch(p.store_id, role, b.branch_id);
        const existing = await findUserByEmail(email);
        if (existing && (await membership(existing.id, p.store_id))) throw new Error("هذا الإيميل مضاف للمتجر من قبل");
        await db.from("invites").delete().eq("store_id", p.store_id).ilike("email", email).is("accepted_at", null);
        const { data: inv, error } = await db.from("invites").insert({
          store_id: p.store_id, email, role, branch_id: branchId, full_name: fullName,
          phone: b.phone ?? null, vehicle: b.vehicle ?? null, invited_by: p.id,
        }).select("token").single();
        if (error) throw new Error(error.message);
        return json({ ok: true, token: inv.token, link: `${await webUrl()}join.html?i=${inv.token}` });
      }
      case "invite_revoke": {
        const p = await requireAdmin(req);
        await db.from("invites").delete().eq("token", String(b.token ?? "")).eq("store_id", p.store_id);
        return json({ ok: true });
      }

      // ---------------------------------------------------------------- الدعوات (عام بالرابط)
      case "invite_info": {
        const inv = await inviteRow(b.token);
        if (!inv) return json({ ok: false, error: "رابط الدعوة غير صالح أو منتهي" }, 400);
        const has = !!(await findUserByEmail(cleanEmail(inv.email)));
        return json({ ok: true, store: inv.store.name, role: inv.role, email: inv.email, full_name: inv.full_name,
          branch: inv.branch?.name ?? null, has_account: has });
      }
      case "invite_accept_password": {
        const inv = await inviteRow(b.token);
        if (!inv) throw new Error("رابط الدعوة غير صالح أو منتهي");
        if (!b.password || String(b.password).length < 8) throw new Error("كلمة المرور لازم تكون 8 أحرف أو أكثر");
        const email = cleanEmail(inv.email);
        if (await findUserByEmail(email)) throw new Error("عندك حساب بهذا الإيميل — سجّل دخول أولاً ثم اقبل الدعوة");
        const { data, error } = await db.auth.admin.createUser({
          email, password: String(b.password), email_confirm: true,
          user_metadata: { full_name: inv.full_name, phone: inv.phone ?? null },
        });
        if (error) throw new Error(error.message);
        await acceptInvite(inv, data.user!.id, email);
        return json({ ok: true, email });
      }
      case "invite_prepare_google": {
        // نجهّز الحساب (بدون كلمة مرور) عشان الدخول بقوقل يرتبط فيه، مع بقاء التسجيل العام مقفل
        const inv = await inviteRow(b.token);
        if (!inv) throw new Error("رابط الدعوة غير صالح أو منتهي");
        const email = cleanEmail(inv.email);
        if (!(await findUserByEmail(email))) {
          const { error } = await db.auth.admin.createUser({ email, email_confirm: true, user_metadata: { full_name: inv.full_name } });
          if (error) throw new Error(error.message);
        }
        return json({ ok: true, email });
      }
      case "invite_accept": {
        const u = await authUser(req);
        if (!u) return json({ error: "سجّل الدخول أولاً" }, 401);
        const inv = await inviteRow(b.token);
        if (!inv) throw new Error("رابط الدعوة غير صالح أو منتهي");
        if (cleanEmail(u.email ?? "") !== cleanEmail(inv.email)) throw new Error(`هذي الدعوة لـ ${inv.email} — سجّل دخول بنفس الإيميل`);
        await acceptInvite(inv, u.id, u.email!);
        return json({ ok: true, store_id: inv.store_id });
      }

      // ---------------------------------------------------------------- حسابي
      case "set_my_email": {
        // ربط إيميل حقيقي بحساب قديم (اسم مستخدم) عشان الدخول بقوقل واستعادة كلمة المرور
        const u = await authUser(req);
        if (!u) return json({ error: "سجّل الدخول أولاً" }, 401);
        if (!isInternal(u.email)) throw new Error("حسابك مربوط بإيميل من قبل");
        const email = cleanEmail(b.email);
        if (!validEmail(email) || isInternal(email)) throw new Error("اكتب إيميل صحيح");
        if (await findUserByEmail(email)) throw new Error("هذا الإيميل مستخدم في حساب ثاني");
        const { error } = await db.auth.admin.updateUserById(u.id, { email, email_confirm: true });
        if (error) throw new Error(error.message);
        return json({ ok: true, email });
      }

      default:
        return json({ error: "unknown action" }, 400);
    }
  } catch (e) {
    const err = e as Error & { status?: number };
    return json({ error: err.message }, err.status ?? 400);
  }
});
