// =====================================================================
//  مسار (MSAR) — إدارة المستخدمين (Supabase Edge Function: admin)
//  owner_status | owner_bootstrap      : إنشاء حساب صاحب المنصة (مرة وحدة)
//  create_user | set_password | delete_user | set_active : لمدير المتجر (داخل متجره فقط)
//  owner_create_store                  : صاحب المنصة ينشئ متجر يدوي + مديره
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT" (نتحقق داخلياً)
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false, autoRefreshToken: false } });
const EMAIL_DOMAIN = "msar.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });

const cleanUsername = (u: string) => String(u ?? "").trim().toLowerCase();
const validUsername = (u: string) => /^[a-z0-9._-]{3,32}$/.test(u);

async function me(req: Request) {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data } = await db.auth.getUser(token);
  if (!data?.user) return null;
  const { data: p } = await db.from("profiles").select("*").eq("id", data.user.id).maybeSingle();
  return p?.is_active ? p : null;
}

async function createUser(store: any, b: any, role: string) {
  const username = cleanUsername(b.username);
  if (!validUsername(username)) throw new Error("اسم المستخدم لازم يكون إنجليزي (حروف/أرقام) من 3 إلى 32 حرف");
  if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
  if (!["admin", "cashier", "driver"].includes(role)) throw new Error("الدور غير صحيح");
  let branchId: number | null = null;
  if (role !== "admin") {
    if (!b.branch_id) throw new Error("حدد الفرع");
    const { data: br } = await db.from("branches").select("id").eq("id", Number(b.branch_id)).eq("store_id", store.id).maybeSingle();
    if (!br) throw new Error("الفرع غير صحيح");
    branchId = br.id;
  }
  const { data: exists } = await db.from("profiles").select("id").eq("store_id", store.id).eq("username", username).maybeSingle();
  if (exists) throw new Error("اسم المستخدم مستخدم من قبل");
  const fullName = String(b.full_name ?? username).trim();
  const { data, error } = await db.auth.admin.createUser({
    email: `${username}@${store.code}.${EMAIL_DOMAIN}`,
    password: String(b.password),
    email_confirm: true,
    app_metadata: { role, store_id: String(store.id), branch_id: branchId ? String(branchId) : null },
    user_metadata: { username, full_name: fullName, phone: b.phone ?? null, vehicle: b.vehicle ?? null },
  });
  if (error) throw new Error(/already/i.test(error.message) ? "اسم المستخدم مستخدم من قبل" : error.message);
  await db.from("profiles").upsert({
    id: data.user!.id, store_id: store.id, username, role, full_name: fullName,
    phone: b.phone ?? null, branch_id: branchId, vehicle: b.vehicle ?? null,
  }, { onConflict: "id" });
  return data.user!.id;
}

async function targetInStore(userId: string, storeId: number) {
  const { data } = await db.from("profiles").select("id, store_id, role").eq("id", userId).maybeSingle();
  if (!data || data.store_id !== storeId) throw new Error("المستخدم غير موجود");
  return data;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  try {
    const b = await req.json().catch(() => ({}));
    switch (b.action) {
      case "owner_status": {
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "owner");
        return json({ needs_bootstrap: (count ?? 0) === 0 });
      }
      case "owner_bootstrap": {
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("role", "owner");
        if ((count ?? 0) > 0) return json({ error: "تم إنشاء حساب صاحب المنصة مسبقاً" }, 403);
        const username = cleanUsername(b.username);
        if (!validUsername(username)) throw new Error("اسم المستخدم لازم يكون إنجليزي من 3 إلى 32 حرف");
        if (!b.password || String(b.password).length < 8) throw new Error("كلمة المرور لازم تكون 8 أحرف أو أكثر");
        const { data, error } = await db.auth.admin.createUser({
          email: `${username}@owner.${EMAIL_DOMAIN}`, password: String(b.password), email_confirm: true,
          app_metadata: { role: "owner" }, user_metadata: { username, full_name: String(b.full_name ?? username) },
        });
        if (error) throw new Error(error.message);
        await db.from("profiles").upsert({ id: data.user!.id, store_id: null, username, role: "owner", full_name: String(b.full_name ?? username) }, { onConflict: "id" });
        if (b.web_url) await db.from("app_settings").upsert({ key: "web_url", value: String(b.web_url) });
        return json({ ok: true });
      }
      case "owner_create_store": {
        const p = await me(req);
        if (p?.role !== "owner") return json({ error: "غير مصرح" }, 401);
        const code = String(b.code ?? "").trim().toLowerCase();
        if (!/^[a-z0-9-]{2,30}$/.test(code)) throw new Error("رمز المتجر: حروف إنجليزية صغيرة وأرقام فقط");
        const { data: s, error } = await db.from("stores").insert({
          code, name: String(b.name ?? code), store_url: b.store_url ?? null,
          settings: { radius_km: 5, push_status: false, import_statuses: ["new", "preparing", "ready"] },
        }).select("*").single();
        if (error) throw new Error(/duplicate/i.test(error.message) ? "رمز المتجر مستخدم" : error.message);
        await createUser(s, { username: b.admin_username, password: b.admin_password, full_name: b.admin_name }, "admin");
        return json({ ok: true, store: s });
      }
      case "create_user": {
        const p = await me(req);
        if (p?.role !== "admin") return json({ error: "غير مصرح" }, 401);
        const { data: s } = await db.from("stores").select("*").eq("id", p.store_id).single();
        const id = await createUser(s, b, b.role);
        return json({ ok: true, id });
      }
      case "set_password": {
        const p = await me(req);
        if (p?.role !== "admin") return json({ error: "غير مصرح" }, 401);
        await targetInStore(b.user_id, p.store_id);
        if (!b.password || String(b.password).length < 6) throw new Error("كلمة المرور لازم تكون 6 أحرف أو أكثر");
        const { error } = await db.auth.admin.updateUserById(b.user_id, { password: String(b.password) });
        if (error) throw new Error(error.message);
        return json({ ok: true });
      }
      case "delete_user": {
        const p = await me(req);
        if (p?.role !== "admin") return json({ error: "غير مصرح" }, 401);
        if (p.id === b.user_id) throw new Error("لا يمكنك حذف حسابك");
        await targetInStore(b.user_id, p.store_id);
        const { count } = await db.from("orders").select("id", { count: "exact", head: true }).eq("driver_id", b.user_id);
        if ((count ?? 0) > 0) {
          await db.from("profiles").update({ is_active: false, is_online: false }).eq("id", b.user_id);
          await db.auth.admin.updateUserById(b.user_id, { ban_duration: "876000h" });
          return json({ ok: true, deactivated: true });
        }
        await db.from("profiles").delete().eq("id", b.user_id);
        const { error } = await db.auth.admin.deleteUser(b.user_id);
        if (error) throw new Error(error.message);
        return json({ ok: true, deleted: true });
      }
      case "set_active": {
        const p = await me(req);
        if (p?.role !== "admin") return json({ error: "غير مصرح" }, 401);
        await targetInStore(b.user_id, p.store_id);
        await db.from("profiles").update({ is_active: !!b.active, ...(b.active ? {} : { is_online: false }) }).eq("id", b.user_id);
        await db.auth.admin.updateUserById(b.user_id, { ban_duration: b.active ? "none" : "876000h" });
        return json({ ok: true });
      }
      default:
        return json({ error: "unknown action" }, 400);
    }
  } catch (e) {
    return json({ error: (e as Error).message }, 400);
  }
});
