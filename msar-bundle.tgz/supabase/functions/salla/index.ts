// =====================================================================
//  مسار (MSAR) — الربط مع سلة لكل المتاجر (Supabase Edge Function: salla)
//  POST (بدون action) : Webhooks سلة (تثبيت/تفويض/اشتراك/حذف + الطلبات) — موقّعة بـ X-Salla-Signature
//  claim  : ربط حساب التاجر (دخول قوقل بنفس إيميل متجر سلة) بمتجره كمدير
//  cron   : إرسال الحالات لسلة + تجديد التوكنات + مزامنة احتياطية (x-cron-key)
//  sync/import/status : لمدير المتجر من لوحة التحكم
//  الوضع: Easy Mode — التوكن يوصل بحدث app.store.authorize (ما فيه callback)
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT"
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const db = createClient(SB_URL, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const API = "https://api.salla.dev/admin/v2";
const ACCOUNTS = "https://accounts.salla.sa/oauth2";
const EMAIL_DOMAIN = "msar.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });

// ------------------------------------------------------------------ helpers
async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data } = await db.from("app_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? null) as T | null;
}
async function setSetting(key: string, value: unknown) { await db.from("app_settings").upsert({ key, value, updated_at: new Date().toISOString() }); }
async function log(store: number | null, kind: string, ok: boolean, message: string, payload?: unknown) {
  try { await db.from("zid_log").insert({ store_id: store, kind, ok, message: String(message ?? "").slice(0, 1000), payload: payload ?? null }); } catch (_) { /* ignore */ }
}
const webUrl = async () => String((await getSetting<string>("web_url")) ?? "https://msarpro.com/").replace(/\/?$/, "/");
const randomToken = () => Array.from(crypto.getRandomValues(new Uint8Array(24))).map((b) => b.toString(16).padStart(2, "0")).join("");

type Tokens = { access_token: string; refresh_token?: string; expires_at?: string; obtained_at?: string; scope?: string; refreshing_at?: string | null };
async function getTokens(store: number): Promise<Tokens | null> {
  const { data } = await db.from("store_secrets").select("salla_tokens").eq("store_id", store).maybeSingle();
  return (data?.salla_tokens ?? null) as Tokens | null;
}
async function saveSecrets(store: number, patch: Record<string, unknown>) {
  await db.from("store_secrets").upsert({ store_id: store, ...patch, updated_at: new Date().toISOString() });
}
async function storeRow(store: number) { return (await db.from("stores").select("*").eq("id", store).maybeSingle()).data; }

async function salla(path: string, t: Tokens | null, init: RequestInit = {}): Promise<any> {
  if (!t?.access_token) throw new Error("المتجر غير مربوط بسلة");
  const res = await fetch(path.startsWith("http") ? path : `${API}${path}`, {
    ...init, signal: AbortSignal.timeout(20000),
    headers: { Authorization: `Bearer ${t.access_token}`, Accept: "application/json", "Accept-Language": "ar", "Content-Type": "application/json", ...(init.headers ?? {}) },
  });
  const text = await res.text();
  let body: any; try { body = JSON.parse(text); } catch { body = text; }
  if (!res.ok) throw new Error(`Salla ${res.status} ${path}: ${typeof body === "string" ? body.slice(0, 300) : JSON.stringify(body).slice(0, 300)}`);
  return body;
}
const isAuthDead = (m: string) => /Salla 401/.test(m);

// HMAC-SHA256 (hex)
async function hmacHex(key: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
function safeEq(a: string, b: string) {
  if (a.length !== b.length) return false;
  let r = 0; for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}
async function verifyWebhook(req: Request, raw: string) {
  const secret = String((await getSetting<string>("salla_webhook_secret")) ?? "");
  if (!secret) return false;
  const strategy = (req.headers.get("x-salla-security-strategy") ?? "Signature").toLowerCase();
  const sig = (req.headers.get("x-salla-signature") ?? "").trim().toLowerCase();
  if (strategy === "token") {
    const tok = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "").trim();
    return !!tok && safeEq(tok, secret);
  }
  return !!sig && safeEq(sig, await hmacHex(secret, raw));
}

// ------------------------------------------------------------------ التوكنات
function toIso(v: unknown) {
  const n = Number(v);
  if (!Number.isFinite(n) || n <= 0) return new Date(Date.now() + 13 * 86400000).toISOString();
  // سلة ترسل expires كطابع زمني (ثواني) أو مدة بالثواني
  return new Date(n > 1e9 ? n * 1000 : Date.now() + n * 1000).toISOString();
}
async function refreshTokens(store: number, force = false) {
  const t = await getTokens(store);
  if (!t?.refresh_token) return false;
  const left = t.expires_at ? Date.parse(t.expires_at) - Date.now() : 0;
  if (!force && left > 3 * 86400000) return false;
  if (t.refreshing_at && Date.now() - Date.parse(t.refreshing_at) < 5 * 60000) return false;
  // قفل: الـ refresh token يُستخدم مرة وحدة فقط — نحجز السطر قبل الطلب
  const { data: lock } = await db.from("store_secrets").update({ salla_tokens: { ...t, refreshing_at: new Date().toISOString() } })
    .eq("store_id", store).filter("salla_tokens->>refresh_token", "eq", t.refresh_token).select("store_id");
  if (!lock?.length) return false;
  try {
    const form = new URLSearchParams({
      grant_type: "refresh_token", refresh_token: t.refresh_token,
      client_id: String((await getSetting<string>("salla_client_id")) ?? ""), client_secret: String((await getSetting<string>("salla_client_secret")) ?? ""),
    });
    const res = await fetch(`${ACCOUNTS}/token`, { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "application/json" }, body: form, signal: AbortSignal.timeout(20000) });
    const b = await res.json().catch(() => ({}));
    if (!res.ok || !b.access_token) throw new Error(`(${res.status}) ${JSON.stringify(b).slice(0, 300)}`);
    await saveSecrets(store, { salla_tokens: { access_token: b.access_token, refresh_token: b.refresh_token ?? t.refresh_token, scope: b.scope ?? t.scope,
      expires_at: new Date(Date.now() + (Number(b.expires_in) || 1209600) * 1000).toISOString(), obtained_at: new Date().toISOString(), refreshing_at: null } });
    await log(store, "salla_oauth", true, "تم تجديد توكن سلة");
    return true;
  } catch (e) {
    await saveSecrets(store, { salla_tokens: { ...t, refreshing_at: null } });
    await log(store, "salla_oauth", false, `فشل تجديد توكن سلة: ${(e as Error).message}`);
    return false;
  }
}

// ------------------------------------------------------------------ حالة المتجر والباقة
async function markUninstalled(store: number, reason: string) {
  await db.from("stores").update({ status: "uninstalled", uninstalled_at: new Date().toISOString() }).eq("id", store);
  await saveSecrets(store, { salla_tokens: null, setup_token: null, setup_expires: null });
  await log(store, "salla_uninstall", true, `تم إيقاف المتجر: ${reason}`);
}
function mapPlan(name: unknown): string | null {
  const n = String(name ?? "").toLowerCase();
  if (/pro|احتراف|unlimited|غير محدود|enterprise/.test(n)) return "pro";
  if (/grow|نمو/.test(n)) return "growth";
  if (/start|basic|أساس|اساس/.test(n)) return "starter";
  return null;
}
const dateIso = (v: unknown) => { if (!v) return null; const d = new Date(String(v).replace(" ", "T")); return isNaN(d.getTime()) ? null : d.toISOString(); };

// ------------------------------------------------------------------ تطبيع الطلب
const num = (v: unknown) => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
};
const round2 = (n: number | null) => (n === null ? null : Math.round(n * 100) / 100);
const coord = (v: unknown) => { const n = num(v); return n === null || n === 0 ? null : n; };
function normPhone(p?: string | null) {
  if (!p) return null;
  let s = String(p).replace(/[^\d+]/g, "");
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (/^05\d{8}$/.test(s)) s = "+966" + s.slice(1);
  if (/^5\d{8}$/.test(s)) s = "+966" + s;
  if (/^966\d{9}$/.test(s)) s = "+" + s;
  return s || null;
}
// حالات سلة → مفردات مسار الموحّدة (نفس زد)
const STATUS_IN: Record<string, string> = {
  payment_pending: "pending", under_review: "new", in_progress: "preparing", completed: "ready",
  delivering: "indelivery", shipped: "indelivery", delivered: "delivered", canceled: "cancelled", cancelled: "cancelled",
  restoring: "cancelled", restored: "cancelled", refunded: "cancelled",
};
const STATUS_OUT: Record<string, string> = { preparing: "in_progress", ready: "completed", indelivery: "delivering", delivered: "delivered", cancelled: "canceled" };
function sallaTime(d: any) {
  const s = typeof d === "string" ? d : d?.date;
  if (!s) return null;
  if (/[zZ]|[+\-]\d\d:?\d\d$/.test(s)) return new Date(s).toISOString();
  const x = new Date(String(s).slice(0, 19).replace(" ", "T") + "+03:00"); // سلة ترجّع توقيت الرياض
  return isNaN(x.getTime()) ? null : x.toISOString();
}
function optText(o: any) {
  const v = o?.value;
  const val = Array.isArray(v) ? v.map((x: any) => x?.name ?? x).join("، ") : (v?.name ?? v ?? "");
  return `${o?.name ?? ""}: ${val}`;
}
function normalizeOrder(o: any) {
  const addr = o?.shipping?.address ?? {};
  const recv = o?.shipping?.receiver ?? {};
  const shipTo = (o?.shipments ?? []).map((x: any) => x?.ship_to).find((x: any) => x) ?? {};
  const c = o?.customer ?? {};
  const pm = String(o?.payment_method ?? "");
  const items = (o?.items ?? []).map((i: any) => ({
    name: i?.name ?? "منتج",
    sku: i?.sku ?? null,
    quantity: num(i?.quantity) ?? 1,
    price: round2(num(i?.amounts?.price_without_tax?.amount ?? i?.amounts?.price?.amount ?? i?.price?.amount)),
    total: round2(num(i?.amounts?.total?.amount ?? i?.total?.amount)),
    image: i?.product?.thumbnail ?? i?.thumbnail ?? i?.images?.[0]?.image ?? null,
    product_id: i?.product?.id ?? i?.product_id ?? null,
    options: Array.isArray(i?.options) ? i.options.map(optText).filter((s: string) => s.trim() !== ":") : [],
  }));
  const slug = String(o?.status?.slug ?? o?.status ?? "").toLowerCase();
  const city = addr?.city ?? shipTo?.city ?? null;
  const district = addr?.block ?? shipTo?.block ?? null;
  const street = addr?.street_number ?? shipTo?.street_number ?? null;
  const parts = [addr?.shipping_address, street, district, city].filter((x: any) => x && String(x).trim().length > 1);
  const total = num(o?.amounts?.total?.amount ?? o?.total?.amount);
  const name = (recv?.name || [c?.first_name, c?.last_name].filter(Boolean).join(" ") || "").trim() || null;
  const phone = normPhone(recv?.phone ? String(recv.phone) : c?.mobile ? `${c?.mobile_code ?? ""}${c.mobile}` : null);
  return {
    source: "salla",
    zid_order_id: o?.id,
    invoice_number: String(o?.reference_id ?? o?.id ?? ""),
    customer_name: name,
    customer_phone: phone,
    customer_email: recv?.email ?? c?.email ?? null,
    address_text: [...new Set(parts)].join("، ") || null,
    district, city,
    short_address: addr?.short_address ?? shipTo?.short_address ?? null,
    lat: coord(addr?.geo_coordinates?.lat ?? addr?.latitude ?? shipTo?.latitude),
    lon: coord(addr?.geo_coordinates?.lng ?? addr?.longitude ?? shipTo?.longitude),
    items,
    subtotal: round2(num(o?.amounts?.sub_total?.amount) ?? items.reduce((a: number, x: any) => a + (x.total ?? 0), 0)),
    shipping_fee: round2(num(o?.amounts?.shipping_cost?.amount)),
    total: round2(total ?? items.reduce((a: number, x: any) => a + (x.total ?? 0), 0)),
    currency: o?.amounts?.total?.currency ?? o?.total?.currency ?? o?.currency ?? "SAR",
    payment_method: pm || null,
    payment_status: o?.is_pending_payment ? "pending" : (o?.payment_status ?? null),
    is_cod: /cod|cash_on_delivery|الاستلام/i.test(pm),
    shipping_method: o?.shipping?.company ?? o?.shipping?.shipping_company ?? o?.shipments?.[0]?.courier_name ?? null,
    customer_note: o?.notes ?? o?.customer_note ?? null,
    zid_status: STATUS_IN[slug] ?? (slug || "new"),
    order_created_at: sallaTime(o?.date ?? o?.created_at),
    raw: o,
  };
}

async function fetchOrderFull(t: Tokens, id: number | string, base: any = null) {
  const o = base?.items?.length && base?.shipping ? { ...base } : { ...(base ?? {}), ...((await salla(`/orders/${id}`, t))?.data ?? {}) };
  if (!o.items?.length) { try { o.items = (await salla(`/orders/items?order_id=${id}`, t))?.data ?? []; } catch (_) { /* ignore */ } }
  const hasCoord = coord(o?.shipping?.address?.geo_coordinates?.lat) !== null;
  if (!hasCoord && !o.shipments?.length) { try { o.shipments = (await salla(`/shipments?order_id=${id}`, t))?.data ?? []; } catch (_) { /* ignore */ } }
  return o;
}

async function upsertOrder(store: number, o: any, force = false) {
  const n: any = normalizeOrder(o);
  if (!n.zid_order_id) throw new Error("طلب بدون رقم");
  const s = await storeRow(store);
  const filter = s?.settings?.shipping_filter as string[] | undefined;
  if (!force && Array.isArray(filter) && filter.length && n.shipping_method && !filter.includes(n.shipping_method)) {
    const { data: ex } = await db.from("orders").select("id").eq("store_id", store).eq("zid_order_id", n.zid_order_id).maybeSingle();
    if (!ex) return { skipped: true, reason: "shipping_method" };
  }
  const { data, error } = await db.rpc("zid_upsert_order", { p_store: store, p: n, p_force: force });
  if (error) throw new Error(error.message);
  return data;
}

async function syncRecent(store: number, perPage = 20) {
  const t = await getTokens(store);
  const st = await storeRow(store);
  const imp: string[] = st?.settings?.import_statuses ?? ["new", "preparing", "ready"];
  const r = await salla(`/orders?per_page=${Math.min(perPage, 30)}&sort_by=id-desc`, t);
  const list: any[] = r?.data ?? [];
  let added = 0, updated = 0, skipped = 0;
  if (!list.length) return { added, updated, skipped };
  const ids = list.map((o) => o.id);
  const { data: existing } = await db.from("orders").select("zid_order_id, zid_status").eq("store_id", store).in("zid_order_id", ids);
  const ex = new Map((existing ?? []).map((e: any) => [Number(e.zid_order_id), e.zid_status]));
  for (const o of list) {
    const stt = STATUS_IN[String(o?.status?.slug ?? "").toLowerCase()] ?? String(o?.status?.slug ?? "");
    try {
      if (ex.has(Number(o.id))) {
        if (ex.get(Number(o.id)) !== stt) {
          const { error } = await db.rpc("zid_upsert_order", { p_store: store, p: { source: "salla", zid_order_id: o.id, zid_status: stt }, p_force: false });
          if (!error) updated++;
        }
        continue;
      }
      if (!imp.includes(stt)) { skipped++; continue; }
      const res: any = await upsertOrder(store, await fetchOrderFull(t!, o.id));
      if (res?.skipped) skipped++; else added++;
    } catch (e) { await log(store, "salla_sync", false, `طلب ${o?.id}: ${(e as Error).message}`); }
  }
  return { added, updated, skipped };
}

async function pool<T>(items: T[], n: number, fn: (x: T) => Promise<void>, deadline = Infinity) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) { if (Date.now() > deadline) return; const x = items[i++]; try { await fn(x); } catch (_) { /* ignore */ } }
  }));
}

// إرسال تغييرات الحالة لسلة (من نفس صف الإرسال، platform = salla)
async function pushOutbox(deadline = Date.now() + 20000) {
  const { data: rows } = await db.from("zid_outbox").select("*").eq("done", false).eq("platform", "salla").lt("attempts", 5).order("id").limit(150);
  if (!rows?.length) return { pushed: 0 };
  const latest = new Map<string, any>();
  for (const r of rows) latest.set(`${r.store_id}:${r.zid_order_id}`, r);
  const superseded = rows.filter((r) => latest.get(`${r.store_id}:${r.zid_order_id}`)?.id !== r.id).map((r) => r.id);
  if (superseded.length) await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "تجاوزه تحديث أحدث" }).in("id", superseded);
  const byStore = new Map<number, any[]>();
  for (const r of latest.values()) { if (!byStore.has(r.store_id)) byStore.set(r.store_id, []); byStore.get(r.store_id)!.push(r); }
  let pushed = 0;
  await pool([...byStore.entries()], 5, async ([storeId, list]) => {
    const t = await getTokens(storeId);
    const s = await storeRow(storeId);
    for (const r of list) {
      if (Date.now() > deadline) return;
      const slug = STATUS_OUT[r.zid_status];
      if (!t?.access_token || s?.settings?.push_status !== true || !slug) {
        await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "التحديث في سلة موقوف لهذا المتجر" }).eq("id", r.id);
        continue;
      }
      const { data: claimed } = await db.from("zid_outbox").update({ attempts: r.attempts + 1 }).eq("id", r.id).eq("attempts", r.attempts).eq("done", false).select("id");
      if (!claimed?.length) continue;
      try {
        await salla(`/orders/${r.zid_order_id}/status`, t, { method: "POST", body: JSON.stringify({ slug }) });
        await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: null }).eq("id", r.id);
        await db.from("orders").update({ zid_status: r.zid_status }).eq("id", r.order_id);
        pushed++;
      } catch (e) {
        const msg = (e as Error).message;
        await db.from("zid_outbox").update({ last_error: msg.slice(0, 500) }).eq("id", r.id);
        if (r.attempts + 1 >= 5) await db.from("order_events").insert({ order_id: r.order_id, type: "zid_push_error", note: `تعذر تحديث الحالة في سلة: ${msg.slice(0, 200)}` });
        await log(r.store_id, "salla_push", false, msg, { order: r.zid_order_id, status: r.zid_status });
        if (isAuthDead(msg)) { await refreshTokens(storeId, true); return; }
      }
    }
  }, deadline);
  return { pushed };
}

// ------------------------------------------------------------------ تثبيت المتجر (app.store.authorize)
function slugCode(s: string) {
  return String(s ?? "").toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/\.(salla\.sa|com|sa|net|store)(\/.*)?$/, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 20);
}
async function uniqueCode(base: string, fallback: string) {
  let c = slugCode(base); if (c.length < 2) c = fallback;
  for (let i = 0; i < 50; i++) {
    const cand = i ? `${c}-${i + 1}` : c;
    const { data } = await db.from("stores").select("id").eq("code", cand).maybeSingle();
    if (!data) return cand;
  }
  return `${fallback}-${Date.now() % 100000}`;
}
async function hasAdmin(store: number) {
  const { count } = await db.from("store_members").select("id", { count: "exact", head: true }).eq("store_id", store).eq("role", "admin").eq("is_active", true);
  return (count ?? 0) > 0;
}
async function ensureSetupToken(store: number) {
  const { data: sec } = await db.from("store_secrets").select("setup_token, setup_expires").eq("store_id", store).maybeSingle();
  if (sec?.setup_token && sec.setup_expires && Date.parse(sec.setup_expires) > Date.now() + 86400000) return sec.setup_token;
  const tok = randomToken();
  await saveSecrets(store, { setup_token: tok, setup_expires: new Date(Date.now() + 7 * 86400000).toISOString() });
  return tok;
}

async function onAuthorize(merchant: number, d: any) {
  const t: Tokens = { access_token: d.access_token, refresh_token: d.refresh_token, scope: d.scope, expires_at: toIso(d.expires), obtained_at: new Date().toISOString(), refreshing_at: null };
  let info: any = {};
  try { const u = await fetch(`${ACCOUNTS}/user/info`, { headers: { Authorization: `Bearer ${t.access_token}`, Accept: "application/json" }, signal: AbortSignal.timeout(15000) }).then((r) => r.json()); info = u?.data ?? {}; } catch (_) { /* ignore */ }
  let si: any = {};
  try { si = (await salla(`/store/info`, t))?.data ?? {}; } catch (_) { /* ignore */ }
  const m = info?.merchant ?? {};
  const name = si?.name ?? m?.name ?? "متجر سلة";
  const domain = si?.domain ?? m?.domain ?? null;
  const email = String(si?.email ?? info?.email ?? "").trim().toLowerCase() || null;
  const phone = normPhone(info?.mobile ? String(info.mobile) : null);
  let { data: s } = await db.from("stores").select("*").eq("salla_merchant_id", merchant).maybeSingle();
  if (!s) {
    const code = await uniqueCode(m?.username ?? domain ?? name, `sl${merchant}`.slice(0, 20));
    const ins = await db.from("stores").insert({
      code, name, platform: "salla", salla_merchant_id: merchant, store_url: domain, logo_url: si?.avatar ?? m?.avatar ?? null,
      owner_email: email, owner_phone: phone, installed_at: new Date().toISOString(),
      settings: { radius_km: 5, push_status: false, import_statuses: ["new", "preparing", "ready"] },
    }).select("*").single();
    if (ins.error) throw new Error(ins.error.message);
    s = ins.data;
  } else {
    await db.from("stores").update({ status: s.status === "uninstalled" ? "trial" : s.status, uninstalled_at: null, installed_at: s.status === "uninstalled" ? new Date().toISOString() : s.installed_at,
      store_url: domain ?? s.store_url, logo_url: si?.avatar ?? s.logo_url, owner_email: s.owner_email ?? email, owner_phone: s.owner_phone ?? phone }).eq("id", s.id);
  }
  await saveSecrets(s.id, { salla_tokens: t });
  if (!(await hasAdmin(s.id))) await ensureSetupToken(s.id);
  await log(s.id, "salla_oauth", true, `تم ربط متجر سلة ${name} (${merchant})`);
  return s.id as number;
}

// ------------------------------------------------------------------ مستخدم مسجّل
async function caller(req: Request) {
  const auth = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!auth || auth.split(".").length !== 3) return null;
  const { data } = await db.auth.getUser(auth);
  return data?.user ?? null;
}
async function requireStoreAdmin(req: Request): Promise<number | null> {
  const u = await caller(req); if (!u) return null;
  const { data: p } = await db.from("profiles").select("role, store_id, is_active").eq("id", u.id).maybeSingle();
  if (!(p?.is_active && p.role === "admin" && p.store_id)) return null;
  const s = await storeRow(p.store_id);
  return s?.platform === "salla" ? p.store_id : null;
}
async function checkCronKey(req: Request) {
  const key = await getSetting<string>("cron_key");
  return !!key && req.headers.get("x-cron-key") === key;
}
const bg = (p: Promise<unknown>) => { try { (globalThis as any).EdgeRuntime?.waitUntil?.(p); } catch (_) { /* ignore */ } return p; };

// ------------------------------------------------------------------ handler
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? (req.method === "POST" ? "webhook" : "");
  try {
    switch (action) {
      case "webhook": {
        const raw = await req.text();
        if (!(await verifyWebhook(req, raw))) { await log(null, "salla_webhook", false, "توقيع غير صالح — تم الرفض"); return json({ error: "unauthorized" }, 401); }
        const b = JSON.parse(raw || "{}");
        const ev = String(b?.event ?? "");
        const merchant = Number(b?.merchant ?? 0);
        const d = b?.data ?? {};
        if (!merchant) return json({ ok: true, ping: true });
        if (ev === "app.store.authorize") {
          const id = await onAuthorize(merchant, d);
          bg(syncRecent(id, 20).then((r) => log(id, "salla_sync", true, `مزامنة أولية: ${JSON.stringify(r)}`)).catch((e) => log(id, "salla_sync", false, (e as Error).message)));
          return json({ ok: true });
        }
        const { data: s } = await db.from("stores").select("*").eq("salla_merchant_id", merchant).maybeSingle();
        if (ev.startsWith("app.")) {
          await log(s?.id ?? null, "salla_app", true, `${ev} (merchant ${merchant})`, { ev, data: d });
          if (!s) return json({ ok: true, unknown_store: true });
          const plan = mapPlan(d?.plan_name);
          if (ev === "app.uninstalled") await markUninstalled(s.id, "حذف التطبيق من سلة");
          else if (ev === "app.trial.started") await db.from("stores").update({ status: s.status === "uninstalled" ? s.status : "trial", trial_ends_at: dateIso(d?.end_date) ?? s.trial_ends_at, plan_status: "trial", ...(plan ? { plan } : {}), plan_checked_at: new Date().toISOString() }).eq("id", s.id);
          else if (ev === "app.subscription.started" || ev === "app.subscription.renewed") await db.from("stores").update({ status: s.status === "uninstalled" ? s.status : "active", plan_status: "active", plan_ends_at: dateIso(d?.end_date), ...(plan ? { plan } : {}), plan_checked_at: new Date().toISOString() }).eq("id", s.id);
          else if (ev === "app.subscription.expired" || ev === "app.subscription.canceled" || ev === "app.trial.expired" || ev === "app.trial.canceled") {
            await db.from("stores").update({ plan_status: ev.split(".").pop(), plan_checked_at: new Date().toISOString(), ...(s.status === "uninstalled" ? {} : { status: "suspended" }) }).eq("id", s.id);
          }
          return json({ ok: true });
        }
        if (ev.startsWith("order.")) {
          if (!s) return json({ ok: true, unknown_store: true });
          if (!["trial", "active"].includes(s.status)) return json({ ok: true, ignored: "store " + s.status });
          const o = d?.order ?? d;
          const id = o?.id ?? d?.order_id;
          if (!id) return json({ ok: true });
          const t = await getTokens(s.id);
          let full = o;
          if (!o?.items?.length || !o?.customer) { try { full = await fetchOrderFull(t!, id, o); } catch (_) { /* نستخدم الـ payload */ } }
          else if (coord(o?.shipping?.address?.geo_coordinates?.lat) === null) { try { full = await fetchOrderFull(t!, id, o); } catch (_) { /* ignore */ } }
          const r = await upsertOrder(s.id, full);
          await log(s.id, "salla_webhook", true, `${ev} — طلب ${full?.reference_id ?? id} (${full?.status?.slug ?? ""})`, { result: r });
          return json({ ok: true, result: r });
        }
        await log(s?.id ?? null, "salla_webhook", true, `حدث غير مستخدم: ${ev}`);
        return json({ ok: true });
      }

      case "prepare": {
        // نجهّز حساب بدون كلمة مرور لإيميل متجر سلة (عشان دخول قوقل يرتبط فيه — التسجيل العام مقفل)
        const b = await req.json().catch(() => ({}));
        const email = String(b?.email ?? "").trim().toLowerCase();
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return json({ ok: false, error: "اكتب إيميل صحيح" }, 400);
        const { data: st } = await db.from("stores").select("id").eq("platform", "salla").eq("owner_email", email).neq("status", "uninstalled").limit(1);
        if (!st?.length) return json({ ok: false, error: "ما لقينا متجر سلة مثبّت فيه مسار برو بهذا الإيميل. تأكد إنك ثبّت التطبيق، وإن الإيميل نفس إيميل حسابك في سلة." }, 404);
        const { data: existing } = await db.rpc("user_id_by_email", { p_email: email });
        if (!existing) {
          const { error } = await db.auth.admin.createUser({ email, email_confirm: true, user_metadata: { full_name: String(b?.full_name ?? "").slice(0, 80) || null } });
          if (error && !/already/i.test(error.message)) return json({ ok: false, error: error.message }, 400);
        }
        return json({ ok: true });
      }
      case "claim": {
        // التاجر يدخل بقوقل بنفس إيميل متجر سلة → نربطه مديراً لكل متاجره اللي ما لها مدير
        const u = await caller(req);
        if (!u?.email || String(u.email).endsWith(`.${EMAIL_DOMAIN}`)) return json({ ok: false, error: "سجّل دخولك بقوقل أولاً" }, 401);
        // نقبل فقط إيميل موثّق من قوقل (يثبت ملكية الإيميل)
        const viaGoogle = (u.identities ?? []).some((i: any) => i?.provider === "google" && String(i?.identity_data?.email ?? "").toLowerCase() === String(u.email).toLowerCase());
        if (!viaGoogle) return json({ ok: false, error: "لازم تدخل بحساب قوقل نفسه المسجّل في سلة" }, 403);
        const email = String(u.email).toLowerCase();
        const { data: list } = await db.from("stores").select("*").eq("platform", "salla").eq("owner_email", email).neq("status", "uninstalled");
        const linked: any[] = [];
        for (const s of list ?? []) {
          if (await hasAdmin(s.id)) {
            const { data: mine } = await db.from("store_members").select("id").eq("store_id", s.id).eq("user_id", u.id).maybeSingle();
            if (mine) linked.push({ code: s.code, name: s.name, already: true });
            continue;
          }
          const fullName = String(u.user_metadata?.full_name ?? u.user_metadata?.name ?? email.split("@")[0]).slice(0, 80);
          await db.from("store_members").upsert({ store_id: s.id, user_id: u.id, role: "admin", branch_id: null, username: null, full_name: fullName, phone: s.owner_phone ?? null, is_active: true }, { onConflict: "store_id,user_id" });
          await db.from("profiles").upsert({ id: u.id, store_id: s.id, username: email, role: "admin", full_name: fullName, phone: s.owner_phone ?? null, branch_id: null, is_active: true, is_online: false }, { onConflict: "id" });
          await saveSecrets(s.id, { setup_token: null, setup_expires: null });
          await log(s.id, "salla_setup", true, `تم ربط مدير المتجر ${email} (دخول قوقل)`);
          linked.push({ code: s.code, name: s.name });
        }
        if (!linked.length) return json({ ok: false, error: `ما لقينا متجر سلة مثبّت فيه مسار برو بالإيميل ${email}. ثبّت التطبيق من متجر تطبيقات سلة أولاً، أو ادخل بنفس إيميل حسابك في سلة.` }, 404);
        return json({ ok: true, stores: linked });
      }

      case "cron": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        const deadline = Date.now() + 40000;
        const push = await pushOutbox(Date.now() + 15000);
        // تجديد التوكنات قبل انتهائها بـ 3 أيام
        const { data: secs } = await db.from("store_secrets").select("store_id, salla_tokens").not("salla_tokens", "is", null).limit(500);
        const soon = (secs ?? []).filter((x: any) => x.salla_tokens?.expires_at && Date.parse(x.salla_tokens.expires_at) - Date.now() < 3 * 86400000).map((x: any) => x.store_id);
        await pool(soon, 4, async (id: number) => { await refreshTokens(id); }, deadline);
        // مزامنة احتياطية: كل متجر سلة كل 15 دقيقة
        const has = new Set((secs ?? []).map((x: any) => x.store_id));
        const cutoff = new Date(Date.now() - 15 * 60000).toISOString();
        const { data: due } = await db.from("stores").select("id").eq("platform", "salla").in("status", ["trial", "active"])
          .or(`last_synced_at.is.null,last_synced_at.lt."${cutoff}"`).order("last_synced_at", { ascending: true, nullsFirst: true }).limit(40);
        const work = (due ?? []).filter((d: any) => has.has(d.id));
        if (work.length) await db.from("stores").update({ last_synced_at: new Date().toISOString() }).in("id", work.map((w: any) => w.id));
        let synced = 0;
        await pool(work, 6, async (s: any) => {
          try { const r = await syncRecent(s.id, 20); synced++; if (r.added || r.updated) await log(s.id, "salla_sync", true, `مزامنة دورية: ${JSON.stringify(r)}`); }
          catch (e) { const m = (e as Error).message; if (isAuthDead(m)) await refreshTokens(s.id, true); else await log(s.id, "salla_sync", false, m); }
        }, deadline);
        await setSetting("salla_cron_last_run", new Date().toISOString());
        return json({ ok: true, push, refreshed: soon.length, synced });
      }

      case "push": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        return json({ ok: true, ...(await pushOutbox()) });
      }
      case "sync": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const r = await syncRecent(store, 30);
        await log(store, "salla_sync", true, `مزامنة يدوية: ${JSON.stringify(r)}`);
        return json({ ok: true, ...r });
      }
      case "import": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const ref = String(url.searchParams.get("id") ?? "").replace(/[^\d]/g, "");
        if (!ref) return json({ error: "رقم الطلب مطلوب" }, 400);
        const t = await getTokens(store);
        let id: string | number = ref;
        try { const r = await salla(`/orders?reference_id=${ref}&per_page=5`, t); const hit = (r?.data ?? []).find((o: any) => String(o.reference_id) === ref); if (hit) id = hit.id; } catch (_) { /* نجرب كرقم داخلي */ }
        const r = await upsertOrder(store, await fetchOrderFull(t!, id), true);
        return json({ ok: true, result: r });
      }
      case "status": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const t = await getTokens(store);
        if (!t?.access_token) return json({ connected: false });
        try { const r = await salla(`/orders?per_page=1`, t); return json({ connected: true, ok: true, total_orders: r?.pagination?.total ?? null, expires_at: t.expires_at }); }
        catch (e) { return json({ connected: true, ok: false, error: (e as Error).message }); }
      }
      default:
        return json({ ok: true, service: "msar-salla" });
    }
  } catch (e) {
    const msg = (e as Error).message;
    await log(null, `salla_${action || "error"}`, false, msg);
    return json({ ok: false, error: msg }, 500);
  }
});
