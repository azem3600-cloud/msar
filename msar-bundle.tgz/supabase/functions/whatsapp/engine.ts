// =====================================================================
//  مسار — محرك محادثة الواتساب (بدون أي اعتماد على Deno أو الشبكة، قابل للاختبار)
//  step(): يستقبل رسالة العميل ويرجّع الرسائل اللي تنرسل + الإجراء المطلوب.
//  حدود ميتا: 3 أزرار، 10 صفوف في القائمة، عنوان الزر 20 حرف، عنوان الصف 24، وصفه 72.
// =====================================================================

export type Cat = { id: number; name: string; emoji?: string | null };
export type Item = { id: number; cat: number | null; name: string; desc?: string | null; price: number; img?: string | null; emoji?: string | null; pop?: boolean; aliases?: string | null };
export type Menu = { store: string; cats: Cat[]; items: Item[]; branches?: { name: string; lat?: number | null; lon?: number | null; city?: string | null }[] };
export type Line = { id: number; name: string; price: number; qty: number };
export type Sess = {
  state: string; cart: Line[]; ctx: Record<string, any>; name?: string | null; human?: boolean; webToken?: string;
  lastCart?: Line[] | null; lastLat?: number | null; lastLon?: number | null; lastAddress?: string | null;
};
export type In = { kind: "text" | "button" | "list" | "location" | "other"; text?: string; id?: string; lat?: number; lon?: number; addr?: string };

export type Out =
  | { t: "text"; body: string }
  | { t: "buttons"; body: string; footer?: string; img?: string; buttons: { id: string; title: string }[] }
  | { t: "list"; body: string; footer?: string; button: string; sections: { title?: string; rows: { id: string; title: string; desc?: string }[] }[] }
  | { t: "cta"; body: string; label: string; url: string; footer?: string }
  | { t: "loc"; lat: number; lon: number; name?: string; address?: string };

export type Action =
  | { type: "create_order"; lines: Line[]; subtotal: number; fee: number; lat?: number | null; lon?: number | null; address?: string | null }
  | { type: "handoff" }
  | null;

export type Cfg = {
  methods: { popular: boolean; categories: boolean; text: boolean; web: boolean; repeat: boolean };
  auto: boolean;
  welcome_order: string[];
  quick_add: boolean;
  delivery_fee: number;
  free_over: number;
  min_order: number;
  require_location: boolean;
  hours: { enabled: boolean; open: string; close: string };
  texts: Record<string, string>;
};

export const DEFAULT_CFG: Cfg = {
  methods: { popular: true, categories: true, text: true, web: true, repeat: true },
  auto: true,
  welcome_order: ["repeat", "popular", "categories", "web", "info"],
  quick_add: true,
  delivery_fee: 0,
  free_over: 0,
  min_order: 0,
  require_location: true,
  hours: { enabled: false, open: "12:00", close: "24:00" },
  texts: {
    welcome: "أهلاً وسهلاً فيك في {store} 👋\nوش تحب نخدمك فيه؟",
    welcome_back: "أهلاً فيك من جديد 👋\nوش تبي اليوم؟",
    hint: "✍️ أو اكتب طلبك مباشرة، مثل: «٢ برجر وبطاطس»",
    closed: "نعتذر، حالياً خارج أوقات الدوام. نداوم من {open} إلى {close} 🌙",
    ask_location: "📍 أرسل لنا موقعك عشان نتأكد إنه ضمن نطاق التوصيل ونحسب الرسوم.",
    out_of_range: "نعتذر، موقعك خارج نطاق التوصيل 🙏",
    min_order: "الحد الأدنى للطلب {min} ر.س. أضف أصناف إضافية وكمّل.",
    confirm_note: "طلبك ما يتسجّل إلا بعد تأكيدك",
    order_done: "🎉 تم استلام طلبك رقم {n}\nالمجموع: {total} ر.س — الدفع عند الاستلام.",
    status_preparing: "👨‍🍳 طلبك {n} قيد التجهيز الحين.",
    status_out: "🛵 طلبك {n} في الطريق إليك.",
    status_delivered: "✅ تم تسليم طلبك {n}. بالعافية! 🌷",
    status_cancelled: "❌ تم إلغاء طلبك {n}. لو فيه استفسار كلمنا.",
    handoff: "تمام، حوّلنا محادثتك لأحد الموظفين وبيرد عليك بأقرب وقت 🙏",
    unknown: "ما قدرت أفهم الأصناف من رسالتك 🙏\nجرّب تكتبها مثل: «٢ برجر وبطاطس»، أو اختر من الأزرار.",
    empty_menu: "المنيو غير جاهز حالياً. تواصل معنا مباشرة 🙏",
    info: "",
  },
};

// ---------- أدوات ----------
const AR = "٠١٢٣٤٥٦٧٨٩";
export const ar = (n: number | string) => String(n).replace(/\d/g, (d) => AR[+d]);
const clip = (s: string, n: number) => { s = String(s ?? ""); return s.length <= n ? s : s.slice(0, n - 1) + "…"; };
const money = (n: number) => ar(Math.round(n * 100) / 100 === Math.round(n) ? Math.round(n) : (Math.round(n * 100) / 100).toFixed(2));
const fill = (t: string, v: Record<string, string | number>) => t.replace(/\{(\w+)\}/g, (_, k) => (v[k] != null ? String(v[k]) : ""));
export function mergeCfg(raw: any): Cfg {
  const r = raw && typeof raw === "object" ? raw : {};
  const c: Cfg = JSON.parse(JSON.stringify(DEFAULT_CFG));
  Object.assign(c.methods, r.methods || {});
  Object.assign(c.hours, r.hours || {});
  Object.assign(c.texts, Object.fromEntries(Object.entries(r.texts || {}).filter(([, v]) => typeof v === "string" && String(v).trim() !== "")));
  if (typeof r.auto === "boolean") c.auto = r.auto;
  if (Array.isArray(r.welcome_order) && r.welcome_order.length) c.welcome_order = r.welcome_order.map(String);
  if (typeof r.quick_add === "boolean") c.quick_add = r.quick_add;
  for (const k of ["delivery_fee", "free_over", "min_order"] as const) if (r[k] != null && !isNaN(+r[k])) c[k] = Math.max(0, +r[k]);
  if (typeof r.require_location === "boolean") c.require_location = r.require_location;
  return c;
}
export const subtotal = (cart: Line[]) => cart.reduce((a, l) => a + l.price * l.qty, 0);
export function feeFor(cfg: Cfg, sub: number) { return cfg.free_over > 0 && sub >= cfg.free_over ? 0 : cfg.delivery_fee; }
function cartText(cart: Line[]) { return cart.map((l) => `${ar(l.qty)} × ${l.name} — ${money(l.qty * l.price)} ر.س`).join("\n"); }

/** هل المتجر مفتوح الآن؟ (توقيت الرياض) */
export function isOpen(cfg: Cfg, now = new Date()) {
  if (!cfg.hours.enabled) return true;
  const h = new Intl.DateTimeFormat("en-GB", { timeZone: "Asia/Riyadh", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).format(now);
  const cur = toMin(h), o = toMin(cfg.hours.open), c = toMin(cfg.hours.close);
  if (o === c) return true;
  return o < c ? cur >= o && cur < c : cur >= o || cur < c;
}
function toMin(s: string) { const [h, m] = String(s).split(":").map(Number); return (h || 0) * 60 + (m || 0); }

// ---------- فهم الطلب المكتوب ----------
const NW: Record<string, number> = { "واحد": 1, "وحده": 1, "اثنين": 2, "اثنان": 2, "ثنتين": 2, "ثلاث": 3, "ثلاثه": 3, "اربع": 4, "اربعه": 4, "خمس": 5, "خمسه": 5, "ست": 6, "ستة": 6 };
export function norm(x: string) {
  return String(x ?? "").replace(/[٠-٩]/g, (d) => String(AR.indexOf(d))).replace(/[أإآ]/g, "ا").replace(/ة/g, "ه").replace(/ى/g, "ي")
    .replace(/[ً-ْـ]/g, "").toLowerCase();
}
export function parseOrder(text: string, items: Item[]): { id: number; qty: number }[] {
  const t = " " + norm(text) + " ";
  const pairs: [number, string][] = [];
  for (const it of items) {
    const names = [it.name, ...(String(it.aliases || "").split(/[,،]/))].map((s) => norm(s).trim()).filter((s) => s.length >= 2);
    for (const n of new Set(names)) pairs.push([it.id, n]);
  }
  pairs.sort((a, b) => b[1].length - a[1].length);
  const cov: [number, number][] = [], out: { id: number; qty: number; at: number }[] = [];
  const qre = /(\d+|واحد|وحده|اثنين|اثنان|ثنتين|ثلاثه|ثلاث|اربعه|اربع|خمسه|خمس|ستة|ست)\s*(?:x|×|حبه|حبات|قطعه|قطع|علبه|كوب)?\s*$/;
  for (const [id, name] of pairs) {
    let from = 0, i: number;
    while ((i = t.indexOf(name, from)) > -1) {
      const e = i + name.length; from = e;
      // لازم يكون حد كلمة (أو بادئة "و"/"ال")
      const prev = t[i - 1], next = t[e];
      if (next && /[ء-ي0-9]/.test(next) && !/^(ين|ان|ات|ه)/.test(t.slice(e, e + 2))) continue;
      if (cov.some(([a, b]) => i < b && e > a)) continue;
      cov.push([i, e]);
      const before = t.slice(0, i).trimEnd().replace(/\s*و$/, (m) => m);
      const m = before.match(qre);
      let q = 1;
      if (m) q = /^\d+$/.test(m[1]) ? +m[1] : NW[m[1]] || 1;
      else { const a = t.slice(e).trimStart().match(/^(\d+)(?!\d)/); if (a) q = +a[1]; }
      out.push({ id, qty: Math.max(1, Math.min(q, 30)), at: i });
    }
  }
  out.sort((a, b) => a.at - b.at);
  const merged = new Map<number, number>();
  for (const o of out) merged.set(o.id, (merged.get(o.id) || 0) + o.qty);
  return [...merged].map(([id, qty]) => ({ id, qty }));
}

// ---------- قوائم ----------
function popularItems(menu: Menu): Item[] {
  const f = menu.items.filter((i) => i.pop);
  return (f.length ? f : menu.items).slice(0, 9);
}
function itemRow(i: Item) { return { id: `i:${i.id}`, title: clip(i.name, 24), desc: clip(`${money(i.price)} ر.س${i.desc ? " — " + i.desc : ""}`, 72) }; }
const backRow = (id: string, title: string) => ({ id, title: clip(title, 24) });

function listItems(title: string, body: string, items: Item[], page: number, base: string, back?: { id: string; title: string }): Out {
  const per = back ? 8 : 9;
  let rows: any[];
  if (items.length <= (back ? 9 : 10)) rows = items.map(itemRow);
  else {
    const slice = items.slice(page * per, page * per + per);
    rows = slice.map(itemRow);
    if ((page + 1) * per < items.length) rows.push({ id: `${base}:p:${page + 1}`, title: "المزيد ▶", desc: "عرض باقي الأصناف" });
  }
  if (back) rows.push(backRow(back.id, back.title));
  return { t: "list", body, button: "عرض الأصناف", sections: [{ title: clip(title, 24), rows }] };
}
function listCats(menu: Menu, page: number): Out {
  const cats = menu.cats.filter((c) => menu.items.some((i) => i.cat === c.id));
  const uncat = menu.items.some((i) => i.cat == null);
  const all = [...cats.map((c) => ({ id: `c:${c.id}`, title: clip(`${c.emoji ? c.emoji + " " : ""}${c.name}`, 24), desc: `${ar(menu.items.filter((i) => i.cat === c.id).length)} أصناف` })),
    ...(uncat ? [{ id: "c:0", title: "أصناف أخرى", desc: `${ar(menu.items.filter((i) => i.cat == null).length)} أصناف` }] : [])];
  let rows = all;
  if (all.length > 10) {
    rows = all.slice(page * 9, page * 9 + 9);
    if ((page + 1) * 9 < all.length) rows.push({ id: `c:p:${page + 1}`, title: "المزيد ▶", desc: "عرض باقي التصنيفات" });
  }
  return { t: "list", body: "تفضل قائمتنا، اختر التصنيف اللي يعجبك 👇", footer: clip(menu.store, 60), button: "عرض التصنيفات", sections: [{ title: "التصنيفات", rows }] };
}

// ---------- الترحيب والتلقائي ----------
type WCtx = { webUrl?: (token: string) => string };
function welcomeButtons(cfg: Cfg, menu: Menu, s: Sess, x: WCtx) {
  const n = menu.items.length, m = cfg.methods;
  const has: Record<string, { id: string; title: string } | null> = {
    repeat: m.repeat && s.lastCart && s.lastCart.length ? { id: "m:rep", title: "🔁 كرر طلبي السابق" } : null,
    popular: m.popular && n > 0 ? { id: "m:pop", title: "⭐ الأكثر طلباً" } : null,
    categories: m.categories && menu.cats.length ? { id: "m:cats", title: "📂 التصنيفات" } : null,
    all: n > 0 && n <= 10 ? { id: "m:all", title: "🛒 ابدأ الطلب" } : null,
    web: m.web && x.webUrl && n > 0 ? { id: "m:web", title: "🌐 المنيو الكامل" } : null,
    info: { id: "m:info", title: "📍 الموقع والدوام" },
  };
  let order: string[];
  if (cfg.auto) {
    order = ["repeat"];
    if (n <= 10) order.push("all");
    else { order.push("popular"); if (n <= 30) order.push("categories"); order.push("web"); order.push("categories"); }
    order.push("web", "info");
  } else order = cfg.welcome_order.slice();
  const out: { id: string; title: string }[] = [], seen = new Set<string>();
  for (const k of order) { const b = has[k]; if (b && !seen.has(b.id)) { seen.add(b.id); out.push(b); } }
  if (!out.length && has.all) out.push(has.all!);
  if (!out.length && menu.items.length) out.push({ id: "m:cats", title: "🛒 ابدأ الطلب" });
  return out.slice(0, 3);
}
function welcome(cfg: Cfg, menu: Menu, s: Sess, x: WCtx, back = false): Out[] {
  if (!menu.items.length) return [{ t: "text", body: cfg.texts.empty_menu }];
  if (!isOpen(cfg)) {
    return [{ t: "buttons", body: fill(cfg.texts.closed, { open: cfg.hours.open, close: cfg.hours.close }), buttons: [{ id: "m:info", title: "📍 الموقع والدوام" }] }];
  }
  const t = (s.lastCart && s.lastCart.length && cfg.methods.repeat ? cfg.texts.welcome_back : cfg.texts.welcome);
  const body = fill(back ? "تحت أمرك، وش تحب؟" : t, { store: menu.store }) + (cfg.methods.text ? "\n\n" + cfg.texts.hint : "");
  return [{ t: "buttons", body: clip(body, 1000), buttons: welcomeButtons(cfg, menu, s, x) }];
}
function infoOut(cfg: Cfg, menu: Menu): Out[] {
  const hrs = cfg.hours.enabled ? `\n🕒 نداوم من ${cfg.hours.open} إلى ${cfg.hours.close}` : "";
  const outs: Out[] = [{ t: "text", body: (cfg.texts.info || `📍 ${menu.store}${menu.branches && menu.branches.length ? "\n" + menu.branches.map((b) => `• ${b.name}${b.city ? " — " + b.city : ""}`).join("\n") : ""}`) + hrs }];
  const b = (menu.branches || []).find((b) => b.lat != null && b.lon != null);
  if (b) outs.push({ t: "loc", lat: +b.lat!, lon: +b.lon!, name: b.name, address: b.city || undefined });
  return outs;
}

// ---------- السلة والملخص ----------
function addLine(s: Sess, it: Item, q: number) {
  const f = s.cart.find((l) => l.id === it.id);
  if (f) f.qty += q; else s.cart.push({ id: it.id, name: it.name, price: it.price, qty: q });
}
function afterAdd(s: Sess, it: Item, q: number, cfg: Cfg): Out[] {
  const total = subtotal(s.cart);
  return [{ t: "buttons", body: `✅ أضفت ${ar(q)} × ${it.name}\nمجموع السلة: ${money(total)} ر.س\n\nتبي تضيف شي ثاني؟`, buttons: [
    { id: "a:more", title: "➕ صنف ثاني" }, { id: "a:cart", title: "🧾 السلة والكميات" }, { id: "a:go", title: "✅ إتمام الطلب" }] }];
}
function cartOut(s: Sess): Out[] {
  if (!s.cart.length) return [{ t: "text", body: "السلة فاضية 🛒" }];
  return [{ t: "buttons", body: `🧾 سلتك\n${cartText(s.cart)}\n\nالمجموع: ${money(subtotal(s.cart))} ر.س`, buttons: [
    { id: "a:more", title: "➕ إضافة صنف" }, { id: "a:go", title: "✅ إتمام الطلب" }, { id: "a:clear", title: "🗑 تفريغ السلة" }] }];
}
function summaryOut(cfg: Cfg, s: Sess, addr?: string | null): Out[] {
  const sub = subtotal(s.cart), fee = feeFor(cfg, sub);
  const body = `ملخص طلبك\n${cartText(s.cart)}\n${fee ? `التوصيل — ${money(fee)} ر.س\n` : "التوصيل — مجاني\n"}${addr ? `📍 ${clip(addr, 120)}\n` : ""}\nالمجموع: ${money(sub + fee)} ر.س\nالدفع: عند الاستلام`;
  return [{ t: "buttons", body, footer: cfg.texts.confirm_note, buttons: [
    { id: "a:confirm", title: "✅ تأكيد الطلب" }, { id: "a:edit", title: "✏️ تعديل" }, { id: "a:cancel", title: "❌ إلغاء" }] }];
}
function toCheckout(cfg: Cfg, menu: Menu, s: Sess): Out[] {
  if (!s.cart.length) return [{ t: "text", body: "السلة فاضية 🛒" }, ...welcome(cfg, menu, s, {}, true)];
  const sub = subtotal(s.cart);
  if (cfg.min_order > 0 && sub < cfg.min_order) {
    s.state = "browsing";
    return [{ t: "buttons", body: fill(cfg.texts.min_order, { min: money(cfg.min_order) }), buttons: [{ id: "a:more", title: "➕ إضافة صنف" }, { id: "a:cart", title: "🧾 السلة" }] }];
  }
  if (cfg.require_location) { s.state = "await_loc"; return [{ t: "text", body: cfg.texts.ask_location + "\n\nاضغط 📎 ثم «الموقع» وأرسله." }]; }
  s.state = "confirm"; return summaryOut(cfg, s);
}
function pickItemOut(it: Item, cfg: Cfg): Out {
  const head = `*${it.name}* — ${money(it.price)} ر.س${it.desc ? "\n" + it.desc : ""}`;
  return { t: "buttons", body: head, img: it.img || undefined, footer: "اختر الكمية", buttons: [
    { id: `q:${it.id}:1`, title: "أضف ١ للسلة" }, { id: `q:${it.id}:2`, title: "أضف ٢ للسلة" }, { id: "a:back", title: "↩ رجوع" }] };
}

// ---------- المحرك ----------
export type StepCtx = {
  webUrl?: (token: string) => string;
  checkLoc?: (lat: number, lon: number) => Promise<{ ok: boolean; km?: number | null } | null>;
  ai?: (text: string, menu: Menu) => Promise<{ id: number; qty: number }[] | null>;
  /** مساعد ذكي: يفهم أي رسالة، يستخرج طلباً أو يجاوب من بيانات المتجر */
  chat?: (text: string, menu: Menu, cfg: Cfg, s: Sess) => Promise<{ intent?: string; items?: { id: number; qty: number }[]; reply?: string } | null>;
};
export type StepRes = { out: Out[]; sess: Sess; action: Action };

const RX = {
  thanks: /^(?:شكرا|شكراً|مشكور|يعطيك العافيه|يعطيك العافية|تسلم|يسلمو|الله يعافيك|ممتاز|تمام شكرا|thanks|thank you|thx)/,
  bye: /^(?:مع السلامه|مع السلامة|باي|الى اللقاء|bye)/,
  human: /(?:موظف|خدمه العملاء|خدمة العملاء|ادارة|كلمني|ابغى اكلم|ابي اكلم|مسؤول|شكوى|شكويه|مشكله|مشكلة|human|agent)/,
  info: /(?:وين موقع|موقعكم|عنوانكم|وين مكانكم|اين موقع|فرعكم|فروعكم|دوامكم|اوقات الدوام|ساعات العمل|متى تفتحون|متى تقفلون|مفتوح|وين انتم|location|hours)/,
  delivery: /(?:توصيل|رسوم|مجاني|الحد الادني|الحد الأدنى|كم المشوار|delivery)/,
  price: /(?:بكم|كم سعر|كم يكلف|كم ثمن|سعر|الاسعار|الأسعار|price)/,
  menu: /(?:^|\s)(?:منيو|المنيو|قائمه|القائمه|قائمة|القائمة|وش عندكم|ايش عندكم|شو عندكم|وش فيه|ايش فيه|الاصناف|الأصناف|اكلات|الاكل|what do you have)/,
  cart: /(?:سلتي|السله|سلتى|طلبي الحالي|وش طلبت|ايش طلبت)/,
  yes: /^(?:ايوه|ايوا|أيوه|نعم|اي|تمام|صح|صحيح|كمل|كمّل|اكمل|أكمل|اكد|أكد|ماشي|اوكي|ok|okay|yes|يلا|زين|طيب|موافق)(?:\s|$)/,
  no: /^(?:لا|لا شكرا|الغي|الغِ|إلغاء|الغاء|كنسل|cancel|no|ما ابغى|ما ابي)(?:\s|$)/,
};
const GREET = /^(?:\s*)(?:السلام|سلام|هلا|اهلا|أهلا|مرحبا|مرحباً|hi|hello|start|menu|قائمه|قائمة|المنيو|منيو|ابدا|ابدأ|الطلب)/i;

export async function step(cfg: Cfg, menu: Menu, s: Sess, inp: In, x: StepCtx = {}): Promise<StepRes> {
  const R = (out: Out[], action: Action = null): StepRes => ({ out, sess: s, action });
  s.cart = Array.isArray(s.cart) ? s.cart : [];
  s.ctx = s.ctx || {};
  if (s.human) return R([]);
  if (!menu.items.length) return R([{ t: "text", body: cfg.texts.empty_menu }]);

  const byId = (id: number) => menu.items.find((i) => i.id === id);
  const id = inp.kind === "button" || inp.kind === "list" ? String(inp.id || "") : "";

  // ---- الموقع
  if (inp.kind === "location" && inp.lat != null && inp.lon != null) {
    if (!s.cart.length) return R(welcome(cfg, menu, s, x));
    s.ctx.lat = inp.lat; s.ctx.lon = inp.lon; s.ctx.addr = inp.addr || null;
    if (x.checkLoc) {
      const r = await x.checkLoc(inp.lat, inp.lon);
      if (r && !r.ok) {
        s.state = "await_loc";
        return R([{ t: "buttons", body: cfg.texts.out_of_range + (r.km != null ? `\nأقرب فرع يبعد ${ar(r.km)} كم.` : ""), buttons: [{ id: "a:human", title: "👤 أحتاج موظف" }, { id: "a:cancel", title: "❌ إلغاء" }] }]);
      }
    }
    s.state = "confirm";
    return R(summaryOut(cfg, s, s.ctx.addr));
  }

  // ---- أزرار وقوائم
  if (id) {
    const [k, a, b] = id.split(":");
    if (id === "a:human") { s.human = true; return R([{ t: "text", body: cfg.texts.handoff }], { type: "handoff" }); }
    if (id === "m:pop") { s.state = "browsing"; s.ctx.from = "pop"; return R([listItems("الأكثر طلباً", "⭐ الأكثر طلباً عندنا\nاختر الصنف 👇", popularItems(menu), 0, "pop")]); }
    if (id === "m:all") { s.state = "browsing"; s.ctx.from = "all"; return R([listItems(menu.store, "تفضل قائمتنا، اختر الصنف 👇", menu.items, 0, "all")]); }
    if (id === "m:cats" || id === "a:more" || id === "a:back") {
      s.state = "browsing";
      if (id !== "m:cats" && s.ctx.from === "pop") return R([listItems("الأكثر طلباً", "⭐ الأكثر طلباً عندنا\nاختر الصنف 👇", popularItems(menu), 0, "pop")]);
      if (id !== "m:cats" && s.ctx.from === "all") return R([listItems(menu.store, "تفضل قائمتنا، اختر الصنف 👇", menu.items, 0, "all")]);
      if (id === "a:back" && s.ctx.cat != null) { const cid = s.ctx.cat; const its = menu.items.filter((i) => (i.cat ?? 0) === cid); return R([listItems("الأصناف", "اختر الصنف اللي تبغاه 👇", its, 0, `c:${cid}`, { id: "m:cats", title: "↩ رجوع للتصنيفات" })]); }
      s.ctx.from = "cat";
      return R([listCats(menu, 0)]);
    }
    if (id === "m:web" && x.webUrl && s.webToken) return R([{ t: "cta", body: "افتح المنيو الكامل بالصور، اختر أصنافك وأرسل الطلب 👇", label: "فتح المنيو", url: x.webUrl(s.webToken) }]);
    if (id === "m:info") return R([...infoOut(cfg, menu), ...welcome(cfg, menu, s, x, true)]);
    if (id === "m:rep") {
      const lc = (s.lastCart || []).map((l) => { const it = byId(l.id); return it ? { id: it.id, name: it.name, price: it.price, qty: l.qty } : null; }).filter(Boolean) as Line[];
      if (!lc.length) return R([{ t: "text", body: "ما لقيت طلب سابق متاح 🙏" }, ...welcome(cfg, menu, s, x, true)]);
      s.cart = lc;
      if (s.lastLat != null && s.lastLon != null) {
        s.ctx.lat = s.lastLat; s.ctx.lon = s.lastLon; s.ctx.addr = s.lastAddress || null; s.state = "confirm";
        const sub = subtotal(lc), fee = feeFor(cfg, sub);
        return R([{ t: "buttons", body: `🔁 طلبك السابق\n${cartText(lc)}\n\nالتوصيل إلى: ${s.lastAddress ? "📍 " + clip(s.lastAddress, 100) : "📍 موقعك المحفوظ"}\nالمجموع: ${money(sub + fee)} ر.س شامل التوصيل — الدفع عند الاستلام`, footer: cfg.texts.confirm_note,
          buttons: [{ id: "a:confirm", title: "✅ أكّد نفس الطلب" }, { id: "a:cart", title: "✏️ أعدّل الطلب" }, { id: "a:cancel", title: "❌ إلغاء" }] }]);
      }
      return R(toCheckout(cfg, menu, s));
    }
    if (k === "c" && a === "p") { return R([listCats(menu, +b || 0)]); }
    if (k === "c" && id.split(":")[2] === "p") {
      const cid = +a, pg = +id.split(":")[3] || 0, its = menu.items.filter((i) => (i.cat ?? 0) === cid);
      return R([listItems("الأصناف", "اختر الصنف اللي تبغاه 👇", its, pg, `c:${cid}`, { id: "m:cats", title: "↩ رجوع للتصنيفات" })]);
    }
    if (k === "c") {
      const cid = +a; s.ctx.cat = cid; s.ctx.from = "cat"; s.state = "browsing";
      const its = menu.items.filter((i) => (i.cat ?? 0) === cid);
      const cat = menu.cats.find((c) => c.id === cid);
      if (!its.length) return R([listCats(menu, 0)]);
      return R([listItems(cat?.name || "أصناف", `*${cat ? (cat.emoji ? cat.emoji + " " : "") + cat.name : "أصناف أخرى"}*\nاختر الصنف اللي تبغاه 👇`, its, 0, `c:${cid}`, { id: "m:cats", title: "↩ رجوع للتصنيفات" })]);
    }
    if ((k === "pop" || k === "all") && a === "p") {
      const pg = +b || 0;
      if (k === "pop") return R([listItems("الأكثر طلباً", "⭐ الأكثر طلباً عندنا\nاختر الصنف 👇", popularItems(menu), pg, "pop")]);
      return R([listItems(menu.store, "تفضل قائمتنا، اختر الصنف 👇", menu.items, pg, "all")]);
    }
    if (k === "i") {
      const it = byId(+a); if (!it) return R(welcome(cfg, menu, s, x, true));
      if (cfg.quick_add && (s.ctx.from === "pop" || s.ctx.from === "all")) { addLine(s, it, 1); s.state = "browsing"; return R(afterAdd(s, it, 1, cfg)); }
      s.state = "item"; s.ctx.item = it.id; return R([pickItemOut(it, cfg)]);
    }
    if (k === "q") { const it = byId(+a); if (!it) return R(welcome(cfg, menu, s, x, true)); const q = Math.max(1, Math.min(30, +b || 1)); addLine(s, it, q); s.state = "browsing"; return R(afterAdd(s, it, q, cfg)); }
    if (id === "a:cart") return R(cartOut(s));
    if (id === "a:clear") { s.cart = []; s.state = "idle"; return R([{ t: "text", body: "تم تفريغ السلة." }, ...welcome(cfg, menu, s, x, true)]); }
    if (id === "a:go") return R(toCheckout(cfg, menu, s));
    if (id === "a:edit") { s.state = "browsing"; return R(cartOut(s)); }
    if (id === "a:cancel") { s.cart = []; s.state = "idle"; s.ctx = {}; return R([{ t: "text", body: "تم إلغاء الطلب. نتشرف بخدمتك في أي وقت 🌷" }]); }
    if (id === "a:confirm") {
      if (!s.cart.length) return R(welcome(cfg, menu, s, x, true));
      const sub = subtotal(s.cart), fee = feeFor(cfg, sub);
      return R([], { type: "create_order", lines: s.cart.map((l) => ({ ...l })), subtotal: sub, fee, lat: s.ctx.lat ?? null, lon: s.ctx.lon ?? null, address: s.ctx.addr ?? null });
    }
    return R(welcome(cfg, menu, s, x, true));
  }

  // ---- نص حر
  if (inp.kind === "text") {
    const text = (inp.text || "").trim();
    const nt = norm(text).trim();
    const feeInfo = () => `🛵 التوصيل: ${cfg.delivery_fee ? money(cfg.delivery_fee) + " ر.س" : "مجاني"}${cfg.free_over > 0 ? ` (مجاني للطلبات فوق ${money(cfg.free_over)} ر.س)` : ""}${cfg.min_order > 0 ? `\n🧾 الحد الأدنى للطلب: ${money(cfg.min_order)} ر.س` : ""}\n💵 الدفع عند الاستلام`;
    if (s.state === "await_loc" && !GREET.test(text) && !RX.human.test(nt) && !RX.no.test(nt)) return R([{ t: "text", body: cfg.texts.ask_location + "\n\nاضغط 📎 ثم «الموقع» وأرسله." }]);
    // ردود سريعة بدون ذكاء اصطناعي
    if (RX.human.test(nt)) { s.human = true; return R([{ t: "text", body: cfg.texts.handoff }], { type: "handoff" }); }
    if (s.cart.length && (s.state === "confirm_text" || s.state === "confirm") && RX.yes.test(nt)) {
      if (s.state === "confirm_text") return R(toCheckout(cfg, menu, s));
      const sub = subtotal(s.cart), fee = feeFor(cfg, sub);
      return R([], { type: "create_order", lines: s.cart.map((l) => ({ ...l })), subtotal: sub, fee, lat: s.ctx.lat ?? null, lon: s.ctx.lon ?? null, address: s.ctx.addr ?? null });
    }
    if (s.cart.length && RX.no.test(nt)) { s.cart = []; s.state = "idle"; s.ctx = {}; return R([{ t: "text", body: "تم إلغاء الطلب. نتشرف بخدمتك في أي وقت 🌷" }]); }
    if (nt.length < 40 && RX.thanks.test(nt) && !parseOrder(text, menu.items).length) return R([{ t: "text", body: "العفو! نتشرف بخدمتك دايماً 🌷" }]);
    if (nt.length < 30 && RX.bye.test(nt)) return R([{ t: "text", body: "في أمان الله 🌷 ننتظرك دايماً." }]);
    if (RX.info.test(nt)) return R([...infoOut(cfg, menu), { t: "text", body: feeInfo() }, ...welcome(cfg, menu, s, x, true)]);
    if (RX.delivery.test(nt) && !RX.price.test(nt)) return R([{ t: "text", body: feeInfo() }, ...welcome(cfg, menu, s, x, true)]);
    if (s.cart.length && RX.cart.test(nt)) return R(cartOut(s));
    const isGreet = GREET.test(text) && !/\d/.test(text) && text.length < 14;
    if (RX.price.test(nt)) {
      const f = parseOrder(text, menu.items).map((q) => byId(q.id)).filter(Boolean) as Item[];
      if (f.length) return R([{ t: "text", body: f.map((i) => `• ${i.name}: ${money(i.price)} ر.س`).join("\n") }, ...welcome(cfg, menu, s, x, true)]);
    }
    if (RX.menu.test(nt) && !parseOrder(text, menu.items).length) return R(welcome(cfg, menu, s, x));
    if (cfg.methods.text && text && !isGreet) {
      const apply = (found: { id: number; qty: number }[]): Out[] | null => {
        found = found.filter((f) => byId(f.id));
        if (!found.length) return null;
        for (const f of found) addLine(s, byId(f.id)!, f.qty);
        s.state = "confirm_text";
        return [{ t: "buttons", body: `فهمت طلبك كذا 👇\n${cartText(s.cart)}\n\nالمجموع: ${money(subtotal(s.cart))} ر.س`, footer: "إذا في شي غلط اضغط تعديل", buttons: [
          { id: "a:go", title: "✅ صح، كمّل" }, { id: "a:edit", title: "✏️ تعديل" }, { id: "a:cancel", title: "❌ إلغاء" }] }];
      };
      const local = apply(parseOrder(text, menu.items));
      if (local) return R(local);
      if (x.chat) {
        let r: Awaited<ReturnType<NonNullable<StepCtx["chat"]>>> = null;
        try { r = await x.chat(text, menu, cfg, s); } catch { /* */ }
        if (r) {
          if (r.intent === "human") { s.human = true; return R([{ t: "text", body: cfg.texts.handoff }], { type: "handoff" }); }
          const o = r.items && r.items.length ? apply(r.items) : null;
          if (o) return R(r.reply ? [{ t: "text", body: clip(r.reply, 500) }, ...o] : o);
          if (r.reply) return R([{ t: "text", body: clip(r.reply, 900) }, ...welcome(cfg, menu, s, x, true)]);
        }
      } else if (x.ai) {
        let found: { id: number; qty: number }[] = []; try { found = (await x.ai(text, menu)) || []; } catch { /* */ }
        const o = apply(found); if (o) return R(o);
      }
    }
    if (isGreet || !cfg.methods.text) return R(welcome(cfg, menu, s, x));
    return R([{ t: "text", body: cfg.texts.unknown }, ...welcome(cfg, menu, s, x, true)]);
  }
  if (inp.kind === "other") return R([{ t: "text", body: "حالياً أفهم الرسائل المكتوبة والأزرار 🙏 اكتب طلبك أو اختر من الأزرار." }, ...welcome(cfg, menu, s, x, true)]);
  return R(welcome(cfg, menu, s, x));
}

/** بعد ما العميل يرسل طلبه من صفحة المنيو الكامل */
export function webSubmitted(cfg: Cfg, menu: Menu, s: Sess, lines: { id: number; qty: number }[]): Out[] {
  s.cart = [];
  for (const l of lines) { const it = menu.items.find((i) => i.id === l.id); if (it && l.qty > 0) addLine(s, it, Math.min(30, Math.floor(l.qty))); }
  if (!s.cart.length) return welcome(cfg, menu, s, {}, true);
  s.state = "confirm_text";
  return [{ t: "buttons", body: `استلمنا طلبك من المنيو ✅\n${cartText(s.cart)}\n\nالمجموع: ${money(subtotal(s.cart))} ر.س`, buttons: [
    { id: "a:go", title: "✅ صح، كمّل" }, { id: "a:edit", title: "✏️ تعديل" }, { id: "a:cancel", title: "❌ إلغاء" }] }];
}

/** رسالة بعد إنشاء الطلب */
export function orderDoneOut(cfg: Cfg, invoice: string, total: number, trackUrl?: string): Out[] {
  const body = fill(cfg.texts.order_done, { n: "#" + invoice, total: money(total) });
  return trackUrl ? [{ t: "cta", body, label: "تتبّع طلبي", url: trackUrl }] : [{ t: "text", body }];
}
export function statusText(cfg: Cfg, status: string, invoice: string): string | null {
  const k = ({ preparing: "status_preparing", out_for_delivery: "status_out", delivered: "status_delivered", cancelled: "status_cancelled" } as Record<string, string>)[status];
  return k ? fill(cfg.texts[k], { n: "#" + invoice }) : null;
}
