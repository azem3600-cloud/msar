// =====================================================================
//  مسار (MSAR) — طلبات الواتساب (Supabase Edge Function: whatsapp)
//  يربط رقم التاجر مع Meta WhatsApp Cloud API مباشرة:
//    GET  ?hub.mode=subscribe...   → التحقق من الويب هوك (Meta)
//    POST (بدون action)            → رسائل العملاء من Meta (موقّعة بـ X-Hub-Signature-256)
//    GET  ?action=web_menu&t=      → بيانات صفحة المنيو الكامل (m.html)
//    POST ?action=web_submit       → إرسال الطلب من صفحة المنيو
//    POST ?action=reply            → رد الموظف من لوحة التاجر (JWT)
//    POST ?action=flush            → إرسال تحديثات الحالة للعملاء (x-cron-key)
//    GET  ?action=health
//  الأسرار (Supabase → Edge Functions → Secrets): WA_VERIFY_TOKEN, WA_APP_SECRET
//    اختياري: WA_ACCESS_TOKEN (توكن احتياطي لكل القنوات)، WA_GRAPH_VERSION (الافتراضي v23.0)،
//    GEMINI_API_KEY (لفهم الكتابة الحرة)، SITE_URL (الافتراضي https://msarpro.com)
//  انشر بدون "Verify JWT" — الدالة تتحقق بنفسها (توقيع ميتا / رمز الجلسة / JWT / مفتاح الكرون).
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";
import { step, welcome, webSubmitted, orderDoneOut, statusText, mergeCfg, subtotal } from "./engine.ts";
import type { Out, Menu, Sess, In, Cfg } from "./engine.ts";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });
const env = (k: string) => Deno.env.get(k) || "";
const GRAPH = () => `https://graph.facebook.com/${env("WA_GRAPH_VERSION") || "v23.0"}`;
const SITE = () => (env("SITE_URL") || "https://msarpro.com").replace(/\/+$/, "");

async function logErr(store_id: number | null, kind: string, ok: boolean, message: string) {
  try { await db.from("zid_log").insert({ store_id, kind, ok, message: String(message).slice(0, 900) }); } catch { /* */ }
}

// ---------- التوقيع ----------
async function validSignature(raw: string, header: string | null) {
  const secret = env("WA_APP_SECRET");
  if (!secret || !header || !header.startsWith("sha256=")) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)));
  const hex = [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
  const given = header.slice(7);
  if (given.length !== hex.length) return false;
  let d = 0; for (let i = 0; i < hex.length; i++) d |= hex.charCodeAt(i) ^ given.charCodeAt(i);
  return d === 0;
}
async function cronOk(req: Request) {
  const { data } = await db.from("app_settings").select("value").eq("key", "cron_key").maybeSingle();
  const key = data?.value as string | undefined;
  return !!key && req.headers.get("x-cron-key") === key;
}

// ---------- تحميل بيانات المتجر ----------
const storeCache = new Map<number, { t: number; v: any }>();
const menuSig = (m: Menu) => m.items.map((i) => `${i.id}:${i.price}:${i.cat ?? 0}`).join(",");
async function loadStore(store_id: number, fresh = false) {
  const c = storeCache.get(store_id);
  if (!fresh && c && Date.now() - c.t < 30000) return c.v as { menu: Menu; cfg: Cfg; flow?: { id: string; published?: boolean }; catalogId?: string; raw: any };
  const v = await loadStoreRaw(store_id);
  storeCache.set(store_id, { t: Date.now(), v });
  return v;
}
async function loadStoreRaw(store_id: number) {
  const [st, cats, items, br, cf] = await Promise.all([
    db.from("stores").select("name").eq("id", store_id).maybeSingle(),
    db.from("wa_categories").select("id,name,emoji,sort,is_active").eq("store_id", store_id).eq("is_active", true).order("sort").order("id"),
    db.from("wa_items").select("id,category_id,name,description,price,image_url,emoji,is_popular,aliases,sort,created_at").eq("store_id", store_id).eq("is_active", true).order("sort").order("id"),
    db.from("branches").select("name,lat,lon,city").eq("store_id", store_id).eq("is_active", true).limit(10),
    db.from("wa_config").select("config").eq("store_id", store_id).maybeSingle(),
  ]);
  const catIds = new Set((cats.data || []).map((c: any) => c.id));
  const menu: Menu = {
    store: st.data?.name || "المتجر",
    cats: (cats.data || []).map((c: any) => ({ id: c.id, name: c.name, emoji: c.emoji })),
    items: (items.data || []).filter((i: any) => i.category_id == null || catIds.has(i.category_id)).map((i: any) => ({
      id: i.id, cat: i.category_id, name: i.name, desc: i.description, price: Number(i.price), img: i.image_url, emoji: i.emoji, pop: i.is_popular, aliases: i.aliases, ts: i.created_at })),
    branches: br.data || [],
  };
  const fl = (cf.data?.config as any)?.flow;
  const flow = fl && fl.id && fl.sig === menuSig(menu) ? { id: String(fl.id), published: !!fl.published } : undefined;
  const ctl = (cf.data?.config as any)?.catalog;
  return { menu, cfg: mergeCfg(cf.data?.config), flow, catalogId: ctl?.id && ctl.ready ? String(ctl.id) : undefined, raw: (cf.data?.config || {}) as any };
}

// ---------- الإرسال لميتا ----------
const tokenCache = new Map<number, string>();
async function channelToken(channel_id: number) {
  if (tokenCache.has(channel_id)) return tokenCache.get(channel_id)!;
  const { data } = await db.from("wa_secrets").select("access_token").eq("channel_id", channel_id).maybeSingle();
  const t = data?.access_token || env("WA_ACCESS_TOKEN");
  if (t) tokenCache.set(channel_id, t);
  return t;
}
function toPayload(to: string, o: Out): any {
  const base = { messaging_product: "whatsapp", recipient_type: "individual", to };
  const mo = o as any;
  if (mo.t === "media") return { ...base, type: mo.kind, [mo.kind]: { id: mo.id, ...(mo.caption ? { caption: String(mo.caption).slice(0, 1000) } : {}), ...(mo.kind === "document" && mo.filename ? { filename: mo.filename } : {}) } };
  if (o.t === "text") return { ...base, type: "text", text: { body: o.body.slice(0, 4000), preview_url: false } };
  if (o.t === "loc") return { ...base, type: "location", location: { latitude: o.lat, longitude: o.lon, name: o.name, address: o.address } };
  if (o.t === "buttons") return { ...base, type: "interactive", interactive: {
    type: "button", ...(o.img ? { header: { type: "image", image: { link: o.img } } } : {}),
    body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { buttons: o.buttons.slice(0, 3).map((b) => ({ type: "reply", reply: { id: b.id.slice(0, 256), title: b.title.slice(0, 20) } })) } } };
  if (o.t === "list") return { ...base, type: "interactive", interactive: {
    type: "list", body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { button: o.button.slice(0, 20), sections: o.sections.map((s) => ({ ...(s.title ? { title: s.title.slice(0, 24) } : {}), rows: s.rows.map((r) => ({ id: r.id.slice(0, 200), title: r.title.slice(0, 24), ...(r.desc ? { description: r.desc.slice(0, 72) } : {}) })) })) } } };
  if (o.t === "catalog") return { ...base, type: "interactive", interactive: {
    type: "product_list", header: { type: "text", text: (o.footer || "قائمتنا").slice(0, 60) }, body: { text: o.body.slice(0, 1024) },
    action: { catalog_id: o.catalogId, sections: o.sections.map((s) => ({ title: s.title.slice(0, 24), product_items: s.ids.map((id) => ({ product_retailer_id: String(id) })) })) } } };
  if (o.t === "flow") return { ...base, type: "interactive", interactive: {
    type: "flow", body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { name: "flow", parameters: { flow_message_version: "3", flow_token: "msar", flow_id: o.flowId, flow_cta: o.cta.slice(0, 20), flow_action: "navigate", flow_action_payload: { screen: o.screen }, ...(o.draft ? { mode: "draft" } : {}) } } } };
  return { ...base, type: "interactive", interactive: {
    type: "cta_url", body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { name: "cta_url", parameters: { display_text: o.label.slice(0, 20), url: o.url } } } };
}
const summary = (o: Out) => (o as any).t === "media" ? ((o as any).kind === "image" ? "📷 " : "📎 ") + ((o as any).caption || (o as any).filename || "") :  o.t === "text" ? o.body : o.t === "loc" ? "📍 موقع" : o.t === "list" ? `${o.body}\n[قائمة: ${o.button}]` : o.t === "cta" ? `${o.body}\n[رابط: ${o.label}]` : o.t === "catalog" ? `${o.body}\n[كتالوج]` : o.t === "flow" ? `${o.body}\n[نموذج: ${o.cta}]` : `${o.body}\n[${o.buttons.map((b) => b.title).join(" | ")}]`;

async function sendOut(ch: { id: number; phone_number_id: string; store_id: number }, session_id: number, to: string, outs: Out[], kind = "bot", senderName: string | null = null) {
  const token = await channelToken(ch.id);
  if (!token) { await logErr(ch.store_id, "wa_send", false, "لا يوجد توكن للقناة " + ch.phone_number_id); return false; }
  let okAll = true;
  const logs: any[] = [];
  for (const o of outs) {
    let wamid: string | null = null, ok = false;
    try {
      const r = await fetch(`${GRAPH()}/${ch.phone_number_id}/messages`, { method: "POST", signal: AbortSignal.timeout(12000),
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(toPayload(to, o)) });
      const j = await r.json().catch(() => ({}));
      ok = r.ok; wamid = j?.messages?.[0]?.id || null;
      if (!r.ok) { okAll = false; await logErr(ch.store_id, "wa_send", false, `${r.status} ${JSON.stringify(j?.error || j).slice(0, 600)}`); if (r.status === 401 || r.status === 190) tokenCache.delete(ch.id); }
    } catch (e) { okAll = false; await logErr(ch.store_id, "wa_send", false, String(e)); }
    const mo = o as any;
    logs.push({ store_id: ch.store_id, session_id, dir: "out", kind, body: summary(o), payload: mo.t === "media" ? { media: { id: mo.id, mime: mo.mime, filename: mo.filename, kind: mo.kind }, ...(ok ? {} : { failed: true }) } : ok ? null : { failed: true }, wamid, sender_name: senderName, status: ok ? "sent" : "failed" });
  }
  if (logs.length) await db.from("wa_messages").insert(logs);
  return okAll;
}

// ---------- فهم النص بالذكاء الاصطناعي (اختياري) ----------
async function aiParse(text: string, menu: Menu) {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const list = menu.items.slice(0, 120).map((i) => `${i.id}|${i.name}${i.aliases ? "|" + i.aliases : ""}`).join("\n");
  const prompt = `أنت تستخرج طلب عميل من رسالة واتساب لمطعم. القائمة (id|الاسم|أسماء بديلة):\n${list}\n\nرسالة العميل: """${text.slice(0, 500)}"""\n\nأرجع JSON فقط بالشكل {"items":[{"id":رقم,"qty":رقم}]} وبس الأصناف الموجودة في القائمة. لو ما فهمت أي صنف أرجع {"items":[]}.`;
  const call = async (thinking: boolean) => fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${key}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(8000),
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0, responseMimeType: "application/json", ...(thinking ? { thinkingConfig: { thinkingBudget: 0 } } : {}) } }) });
  let r = await call(true); if (r.status === 400) r = await call(false);
  if (!r.ok) return null;
  const j = await r.json(); const t = j?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  try { const p = JSON.parse(t); return (p.items || []).map((x: any) => ({ id: Number(x.id), qty: Math.max(1, Math.min(30, Number(x.qty) || 1)) })).filter((x: any) => menu.items.some((i) => i.id === x.id)); } catch { return null; }
}

async function aiChat(text: string, menu: Menu, cfg: any, sess: any) {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const catName = (id: number | null) => menu.cats.find((c) => c.id === id)?.name || "";
  const list = menu.items.slice(0, 120).map((i) => `${i.id}|${i.name}|${i.price} ر.س|${catName(i.cat)}${i.pop ? "|⭐ الأكثر مبيعاً" : ""}${i.desc ? "|" + i.desc : ""}${i.aliases ? "|يسمّونه: " + i.aliases : ""}`).join("\n");
  const cart = (sess?.cart || []).map((l: any) => `${l.qty}×${l.name}`).join("، ");
  const prompt = `أنت مسوّق ومندوب مبيعات ممتاز وودود لـ "${menu.store}" ترد على واتساب بلهجة سعودية بيضاء، مختصر (٢-٣ جمل)، حماس خفيف وإيموجي قليل.
تعرف كل أصناف المنيو وتفاصيلها ومميزاتها، وتعرف الأكثر مبيعاً (⭐). مهمتك: تساعد العميل يختار، ترشّح بثقة (ابدأ بالأكثر مبيعاً)، تقترح إضافة تكمّل طلبه (بطاطس/مشروب/حلا)، وتشجعه يفتح المنيو ويطلب. لا تخترع أصنافاً أو أسعاراً أو عروضاً غير الموجودة.
القائمة (id|الاسم|السعر|القسم|الأكثر مبيعاً|الوصف|أسماء بديلة):
${list}
رسوم التوصيل: ${cfg?.delivery_fee ?? 0} ر.س. الدفع عند الاستلام.${cart ? "\nسلة العميل الحالية: " + cart : ""}
رسالة العميل: """${text.slice(0, 500)}"""
أرجع JSON فقط: {"intent":"order|answer|human","items":[{"id":رقم,"qty":رقم}],"reply":"ردك"}.
- order: العميل يطلب أصناف محددة (items فقط من القائمة) ورد قصير مع اقتراح إضافة.
- answer: سؤال/ترشيح/سوالف؛ جاوب من القائمة وسوّق بلطافة.
- human: يبغى موظف أو شكوى جدية.`;
  const call = async (thinking: boolean) => fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${key}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(6000),
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0.3, responseMimeType: "application/json", ...(thinking ? { thinkingConfig: { thinkingBudget: 0 } } : {}) } }) });
  let r: Response; try { r = await call(true); if (r.status === 400) r = await call(false); } catch (e) { await logErr(null, "wa_ai", false, "fetch " + String(e)); return null; }
  if (!r.ok) { await logErr(null, "wa_ai", false, r.status + " " + (await r.text()).slice(0, 500)); return null; }
  const j = await r.json(); const t = j?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  try {
    const p = JSON.parse(t);
    const items = (p.items || []).map((x: any) => ({ id: Number(x.id), qty: Math.max(1, Math.min(30, Number(x.qty) || 1)) })).filter((x: any) => menu.items.some((i) => i.id === x.id));
    return { intent: String(p.intent || "answer"), items, reply: p.reply ? String(p.reply) : undefined };
  } catch { await logErr(null, "wa_ai", false, "parse " + String(t).slice(0, 300)); return null; }
}

// ---------- Gemini: سباق بين نموذجين (الأسرع يفوز) ----------
const GEM_MODELS = ["gemini-3.5-flash", "gemini-3.1-flash-lite"];
async function gemini(prompt: string, temperature = 0.5): Promise<string | null> {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const call = async (m: string) => {
    const body = (think: boolean) => JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature, responseMimeType: "application/json", ...(think ? { thinkingConfig: { thinkingBudget: 0 } } : {}) } });
    const go = (think: boolean) => fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${key}`, { method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(9000), body: body(think) });
    let r = await go(true); if (r.status === 400) r = await go(false);
    if (!r.ok) throw new Error(`${m} ${r.status} ${(await r.text()).slice(0, 160)}`);
    const j = await r.json(); const t = j?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!t) throw new Error(`${m} empty`); return t as string;
  };
  return await new Promise<string | null>((resolve) => {
    let done = false, fails = 0; const errs: string[] = []; const started = new Set<number>();
    const start = (k: number) => {
      if (started.has(k) || k >= GEM_MODELS.length) return; started.add(k);
      call(GEM_MODELS[k]).then((t) => { if (!done) { done = true; resolve(t); } }).catch((er) => {
        errs.push(String(er)); fails++;
        if (fails >= GEM_MODELS.length) { if (!done) { done = true; logErr(null, "wa_ai", false, errs.join(" | ").slice(0, 700)); resolve(null); } } else start(k + 1);
      });
    };
    start(0); setTimeout(() => { if (!done) start(1); }, 3500);
  });
}

async function aiAgent(text: string, menu: Menu, cfg: any, sess: any, who?: { wa: string; store: number }) {
  const ai: any = (cfg && cfg.ai) || {};
  const botName = String(ai.name || "").trim().slice(0, 40) || "مساعد " + menu.store;
  const TONES: Record<string, string> = { saudi: "لهجة سعودية بيضاء قريبة من القلب", formal: "عربية فصحى مبسطة مهذبة ورسمية بدون عامية", youth: "لهجة سعودية شبابية مرحة وخفيفة", gulf: "لهجة خليجية ودودة", english: "English only, friendly and concise (reply in English even if the customer writes Arabic)", auto: "نفس لغة ولهجة العميل (عربي أو إنجليزي) بأسلوب ودود" };
  const toneTxt = TONES[ai.tone] || TONES.saudi;
  const UPS: Record<string, string> = { off: " لا تقترح أي أصناف أو إضافات إلا إذا طلبها العميل أو سأل عن توصية.", light: "", active: " كن نشطاً في التسويق: اقترح إضافة تكمّل الطلب في معظم الردود (دون إلحاح ولا تكرار لما رفضه)." };
  const upsTxt = UPS[ai.upsell] ?? "";
  const custom = String(ai.instructions || "").trim().slice(0, 700);
  const customTxt = custom ? "\nتعليمات خاصة من صاحب المتجر (التزم بها ما لم تتعارض مع القواعد الصارمة أعلاه): " + custom : "";
  let mem = "";
  try {
    const past: string[] = []; const seenNames = new Set<string>();
    if (who && ai.memory !== false) {
      const { data: od } = await db.from("orders").select("items,created_at").eq("store_id", who.store).eq("customer_phone", who.wa).order("id", { ascending: false }).limit(5);
      for (const o of od || []) {
        const days = Math.max(0, Math.round((Date.now() - new Date(o.created_at || Date.now()).getTime()) / 86400000));
        const its = (Array.isArray(o.items) ? o.items : []).map((i: any) => { const n = String(i.name || i.title || ""); if (n) seenNames.add(n); return (i.quantity || i.qty || 1) + "×" + n; }).join("، ");
        past.push((days === 0 ? "اليوم" : "قبل " + days + " يوم") + ": " + its);
      }
    }
    const fresh = menu.items.filter((i) => i.ts && Date.now() - new Date(i.ts).getTime() < 21 * 86400000 && !seenNames.has(i.name)).slice(0, 5).map((i) => i.name + " (id " + i.id + ")");
    mem = past.length ? "ذاكرة العميل — طلباته السابقة (الأحدث أولاً):\n" + past.join("\n") : "ذاكرة العميل: عميل جديد ما طلب قبل.";
    if (fresh.length) mem += "\nأصناف جديدة أضافها المتجر مؤخراً: " + fresh.join("، ");
  } catch { /* */ }
  const catName = (id: number | null) => menu.cats.find((c) => c.id === id)?.name || "";
  const list = menu.items.slice(0, 150).map((i) => `${i.id}|${i.name}|${i.price} ر.س|${catName(i.cat)}${i.pop ? "|⭐ الأكثر مبيعاً" : ""}${i.desc ? "|" + i.desc : ""}${i.aliases ? "|يسمّونه: " + i.aliases : ""}`).join("\n");
  const cart = (sess?.cart || []).map((l: any) => `${l.qty}×${l.name}(id ${l.id})`).join("، ");
  const hist = (sess?.ctx?.hist || []).map((h: any) => `${h.r === "u" ? "العميل" : "أنت"}: ${h.t}`).join("\n");
  const branches = (menu.branches || []).map((b) => b.name + (b.city ? " - " + b.city : "")).join("، ");
  const prompt = `أنت "${botName}" على واتساب (متجر ${menu.store}): مندوب مبيعات ذكي، لبق، سريع البديهة، ${toneTxt}، ردودك قصيرة (جملتين إلى ٣) مع إيموجي واحد أو اثنين.
هدفك: تفهم احتياج العميل (جوعان؟ عائلة؟ ميزانية؟ يبغى شي خفيف؟) وتقدّم له الأصناف المناسبة بحماس وبثقة، تبدأ بالأكثر مبيعاً ⭐، تقترح إضافة تكمّل طلبه (مشروب/جانبي/حلا) بشكل طبيعي، وتساعده يكوّن طلبه ويكمله. جاوب على أي سؤال أو سالفة بلطافة ثم رجّعه بذكاء للطلب. إذا سأل عن أصناف غير موجودة قل بلطف ما عندنا ورشّح البديل.
قواعد صارمة: لا تخترع أصنافاً أو أسعاراً أو عروضاً أو أوقات غير الموجودة بالبيانات. استخدم أرقام id من القائمة فقط. الأسعار بالريال. لا تسأل عن الاسم أو الموقع أو الإيميل أو الدفع، النظام يسألهم تلقائياً بعد ما يقول العميل إنه يبغى يكمل. ناده باسمه الأول في كل رد متى ما عرفته (ولا تسأله عن اسمه أنت). استفد من ذاكرته: خمّن طلبه الجاي من عاداته مثل «آخر مرة طلبت كذا، تبيه نفسه؟» لكن فقط لما يناسب. التسويق بذوق وبدون إزعاج: اقتراح واحد قصير فقط في الرد، ولا تقترح في كل رسالة (تقريباً مرة كل رسالتين)، لا تكرر اقتراحاً تجاهله أو رفضه، وإذا كان مستعجل أو حدد طلبه بوضوح اكتفِ بتأكيده. الأصناف الجديدة اذكرها مرة وحدة وبشكل طبيعي لمن يناسبه ذوقه.${upsTxt}${customTxt}
بيانات ${menu.store}: التوصيل ${cfg?.delivery_fee ? cfg.delivery_fee + " ر.س" : "مجاني"}${cfg?.free_over > 0 ? "، مجاني فوق " + cfg.free_over + " ر.س" : ""}${cfg?.min_order > 0 ? "، الحد الأدنى للطلب " + cfg.min_order + " ر.س" : ""}. الدفع عند الاستلام.${cfg?.hours?.enabled ? ` الدوام ${cfg.hours.open}–${cfg.hours.close}.` : ""}${branches ? " الفروع: " + branches + "." : ""}
المنيو (id|الاسم|السعر|القسم|⭐|الوصف):
${list}
${ai.memory === false ? "" : mem}
${cart ? "سلة العميل الحالية: " + cart : "سلة العميل فاضية."}${sess?.name ? "\nاسم العميل: " + sess.name : ""}
${hist ? "آخر المحادثة:\n" + hist + "\n" : ""}${sess?.webToken ? "رابط المنيو بالصور جاهز ويُرسل للعميل تلقائياً عند next=menu. تصرّف ككاشير ومسوّق: لا تسرد المنيو نصاً أبداً، اعرض الرابط فوراً بدون لف ودوران، ثم اقترح الأكثر مبيعاً ⭐ بجملة وحدة وسهّل الطلب.\n" : ""}رسالة العميل الآن: """${text.slice(0, 600)}"""
أرجع JSON فقط بهذا الشكل: {"reply":"ردك للعميل","add":[{"id":رقم,"qty":رقم}],"set":[{"id":رقم,"qty":رقم}],"remove":[رقم],"name":"اسم العميل لو ذكره","email":"إيميله لو ذكره","next":"chat|menu|cart|checkout|human"}
- add: أصناف طلبها صراحة أو وافق عليها (qty افتراضي ١). set: لتغيير كمية صنف موجود بالسلة (qty=0 يحذفه). remove: ids للحذف.
- next=checkout: لما يقول خلاص/كمّل/أكّد/ابغى أطلب/هذا كل شي وسلته فيها أصناف (ردك حينها تأكيد قصير بدون أسئلة).
- next=menu: لما يبغى يشوف المنيو/القائمة/يتصفح. next=cart: يسأل عن سلته. next=human: يبغى موظف أو شكوى جدية. غير ذلك next=chat.`;
  const t = await gemini(prompt, 0.5);
  if (!t) return null;
  try {
    const p = JSON.parse(t);
    const ok = (id: any) => menu.items.some((i) => i.id === Number(id));
    const norm = (a: any) => (Array.isArray(a) ? a : []).map((x: any) => ({ id: Number(x.id), qty: Math.max(0, Math.min(30, Number(x.qty ?? 1) || 0)) })).filter((x: any) => ok(x.id));
    return { reply: p.reply ? String(p.reply) : "", add: norm(p.add).filter((x: any) => x.qty > 0), set: norm(p.set), remove: (Array.isArray(p.remove) ? p.remove : []).map(Number).filter(ok), name: p.name ? String(p.name) : undefined, email: p.email ? String(p.email) : undefined, next: String(p.next || "chat") };
  } catch { await logErr(null, "wa_ai", false, "parse " + t.slice(0, 300)); return null; }
}

async function adminOf(req: Request) {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data: u } = await db.auth.getUser(token);
  if (!u?.user) return null;
  const { data: p } = await db.from("profiles").select("store_id,role,is_active").eq("id", u.user.id).maybeSingle();
  if (!p?.is_active || p.role !== "admin" || !p.store_id) return null;
  return { store_id: p.store_id as number };
}

/** معاينة رد الشات الذكي بإعدادات التاجر قبل الحفظ */
async function aiPreview(req: Request) {
  const a = await adminOf(req); if (!a) return json({ error: "غير مصرح" }, 401);
  const b = await req.json().catch(() => ({}));
  const text = String(b.message || "").trim().slice(0, 500); if (!text) return json({ error: "اكتب رسالة" }, 400);
  const { menu, cfg } = await loadStore(a.store_id, true);
  const c: any = { ...cfg, ai: b.ai && typeof b.ai === "object" ? b.ai : (cfg as any).ai };
  const hist = Array.isArray(b.hist) ? b.hist.slice(-8).map((h: any) => ({ r: h.r === "u" ? "u" : "b", t: String(h.t || "").slice(0, 300) })) : [];
  const sess: any = { cart: [], ctx: { hist }, name: b.name ? String(b.name).slice(0, 40) : null };
  const r = await aiAgent(text, menu, c, sess, undefined);
  if (!r) return json({ error: "الذكاء الاصطناعي ما رد، جرّب بعد شوي" }, 502);
  const nm = (id: number) => menu.items.find((i) => i.id === id)?.name || "";
  return json({ reply: r.reply, add: (r.add || []).map((x) => ({ name: nm(x.id), qty: x.qty })), next: r.next });
}

/** قراءة صورة منيو واستخراج التصنيفات والأصناف (للمراجعة قبل الحفظ) */
// يقفل JSON مقطوع (لما المنيو كبير والرد ينقطع): نقص لآخر صنف مكتمل ونقفل الأقواس
function repairJson(t: string): any {
  try { return JSON.parse(t); } catch (_) { /* نكمل */ }
  let s = t.trim().replace(/^```json\s*|^```\s*|```$/g, "");
  try { return JSON.parse(s); } catch (_) { /* نكمل */ }
  for (let k = 0; k < 400; k++) {
    const i = s.lastIndexOf("},");
    if (i < 0) break;
    s = s.slice(0, i + 1);
    for (const tail of ["]}]}", "]}", "}]}"]) { try { return JSON.parse(s + tail); } catch (_) { /* جرّب التالي */ } }
    s = s.slice(0, i);
  }
  throw new Error("json");
}
async function menuScan(req: Request) {
  const a = await adminOf(req); if (!a) return json({ error: "غير مصرح" }, 401);
  const key = env("GEMINI_API_KEY"); if (!key) return json({ error: "الذكاء الاصطناعي غير مفعّل" }, 503);
  const b = await req.json().catch(() => ({}));
  const img = String(b.file || b.image || "");
  const mime = /^(image\/(jpeg|png|webp)|application\/pdf)$/.test(String(b.mime)) ? String(b.mime) : "image/jpeg";
  if (img.length < 500 || img.length > 14000000) return json({ error: "الملف غير صالح أو كبير (الحد 10 ميجا)" }, 400);
  const pr = Array.isArray(b.range) && mime === "application/pdf" ? [Math.max(1, Number(b.range[0]) | 0), Math.max(1, Number(b.range[1]) | 0)] : null;
  const scope = pr ? `اقرأ فقط الصفحات من ${pr[0]} إلى ${pr[1]} من الملف وتجاهل بقية الصفحات.` : (mime === "application/pdf" ? "اقرأ كل صفحات الملف." : "");
  const prompt = `هذا منيو (قائمة أصناف) لمتجر. ${scope} استخرج كل الأصناف بدون استثناء وبدون اختصار ولو كانت مئات، كما هي مكتوبة بدون ما تخترع شي.
أرجع JSON فقط بهذا الشكل: {"categories":[{"name":"اسم القسم","emoji":"إيموجي مناسب","items":[{"name":"اسم الصنف","price":رقم,"old_price":رقم أو null,"description":"الوصف أو المكونات إن وجدت وإلا فارغ","badge":"شارة قصيرة إن وجدت (عرض، جديد، الأكثر طلباً) وإلا فارغ"}]}]}
- الأسعار أرقام فقط بالريال (حوّل الأرقام العربية للإنجليزية).
- old_price: لو الصنف عليه سعر قبل الخصم (مشطوب) ضعه، وإلا null، والسعر الحالي في price.
- لو للصنف أحجام (صغير/وسط/كبير) اجعل كل حجم صنفاً مستقلاً واسمه يتضمن الحجم.
- لو ما فيه أقسام ضع الأصناف في قسم اسمه «المنيو».
- اسم الصنف ما يزيد عن 60 حرف والوصف ما يزيد عن 160. اكتب الوصف الموجود في الملف فقط.`;
  const tries: [string, number][] = [["gemini-3.5-flash", 110000], ["gemini-3.1-flash-lite", 40000]];
  for (const [m, to] of tries) {
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${key}`, { method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(to),
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }, { inline_data: { mime_type: mime, data: img } }] }], generationConfig: { temperature: 0.1, responseMimeType: "application/json", maxOutputTokens: 32768 } }) });
      if (!r.ok) { await logErr(a.store_id, "wa_scan", false, `${m} ${r.status} ${(await r.text()).slice(0, 200)}`); continue; }
      const j = await r.json(); const t = j?.candidates?.[0]?.content?.parts?.[0]?.text; if (!t) continue;
      const p = repairJson(t); const cut = j?.candidates?.[0]?.finishReason === "MAX_TOKENS";
      const num = (v: any) => { const n = Number(v); return Number.isFinite(n) && n >= 0 ? n : 0; };
      const categories = (Array.isArray(p.categories) ? p.categories : []).slice(0, 60).map((c: any) => ({
        name: String(c.name || "المنيو").trim().slice(0, 24) || "المنيو", emoji: String(c.emoji || "").trim().slice(0, 4),
        items: (Array.isArray(c.items) ? c.items : []).slice(0, 400).map((i: any) => ({ name: String(i.name || "").trim().slice(0, 60), price: num(i.price), old_price: num(i.old_price) > num(i.price) ? num(i.old_price) : null, description: String(i.description || "").trim().slice(0, 160), badge: String(i.badge || "").trim().slice(0, 16) })).filter((i: any) => i.name),
      })).filter((c: any) => c.items.length);
      if (categories.length) return json({ categories, truncated: cut });
    } catch (e) { await logErr(a.store_id, "wa_scan", false, `${m} ${String(e).slice(0, 200)}`); }
  }
  return json({ error: "ما قدرت أقرأ الملف، جرّب صورة أوضح أو أقل صفحات" }, 422);
}

async function aiTest(req: Request) {
  const auth = req.headers.get("authorization") || "";
  const uc = createClient(Deno.env.get("SUPABASE_URL")!, env("SUPABASE_ANON_KEY"), { global: { headers: { Authorization: auth } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: isOwner } = await uc.rpc("is_owner");
  if (!isOwner) return json({ error: "forbidden" }, 403);
  const key = env("GEMINI_API_KEY"); if (!key) return json({ error: "no key" });
  const lr = await fetch(`https://generativelanguage.googleapis.com/v1beta/models?pageSize=200&key=${key}`); const lj = await lr.json().catch(() => ({}));
  const all: string[] = (lj.models || []).filter((x: any) => (x.supportedGenerationMethods || []).includes("generateContent")).map((x: any) => String(x.name).replace("models/", ""));
  if (new URL(req.url).searchParams.get("list")) return json({ all });
  const models = (new URL(req.url).searchParams.get("m") || "gemini-flash-latest").split(",");
  const res = await Promise.all(models.map(async (m) => {
    const t0 = Date.now();
    try {
      const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${key}`, { method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(15000), body: JSON.stringify({ contents: [{ parts: [{ text: 'أرجع JSON {"ok":true} فقط' }] }], generationConfig: { responseMimeType: "application/json", thinkingConfig: { thinkingBudget: 0 } } }) });
      return { m, status: r.status, ms: Date.now() - t0, body: (await r.text()).slice(0, 120) };
    } catch (e) { return { m, ms: Date.now() - t0, err: String(e) }; }
  }));
  return json({ res });
}

// ---------- الجلسة ----------
const CANCEL_Q = /(?:الغ|إلغ|ألغ|الغي|كنسل|cancel).{0,12}(?:طلب|الطلب|طلبي)|(?:طلبي|الطلب).{0,10}(?:الغ|إلغ|كنسل)|ابغى الغي|ابي الغي|ابغا الغي/i; const ORDER_Q = /(?:وش|ايش|شو|وين|فين|متى|كم|حالة|وصل|وصول|تأخر|اتأخر).{0,14}(?:طلب|الطلب|طلبي|طلبنا)|(?:طلبي|طلبنا|الطلب).{0,14}(?:وين|فين|متى|وش صار|ايش صار|وصل|تأخر|اتأخر|وصلنا)|وين المندوب|تتبع/;
const toSess = (r: any): Sess => ({ state: r.state, cart: r.cart || [], ctx: r.ctx || {}, name: r.name, human: r.human, webToken: r.web_token,
  lastCart: r.last_cart, lastLat: r.last_lat, lastLon: r.last_lon, lastAddress: r.last_address });
async function saveSess(id: number, s: Sess, extra: Record<string, unknown> = {}) {
  await db.from("wa_sessions").update({ state: s.state, cart: s.cart, ctx: s.ctx, human: !!s.human, name: s.name ?? null, last_msg_at: new Date().toISOString(), ...extra }).eq("id", id);
}

// ---------- معالجة رسالة واردة ----------
const seenMsg = new Map<string, number>();
const badCat = new Map<number, number>();
/** يظهر للعميل «يكتب…» ويعلّم الرسالة مقروءة فوراً (يحسّن الإحساس بالسرعة) */
async function typing(ch: any, wamid: string) {
  const token = await channelToken(ch.id); if (!token) return;
  await fetch(`${GRAPH()}/${ch.phone_number_id}/messages`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(4000),
    body: JSON.stringify({ messaging_product: "whatsapp", status: "read", message_id: wamid, typing_indicator: { type: "text" } }) });
}
const chCache = new Map<string, { t: number; ch: any; on: boolean }>();
async function handleMessage(ch: any, m: any, contactName: string | null) {
  const from = String(m.from || "");
  if (!from) return;
  const type = m.type;
  let inp: In = { kind: "other" }, logBody = `[${type}]`; let mediaIn: any = null;
  if (type === "text") { inp = { kind: "text", text: String(m.text?.body || "") }; logBody = inp.text!; }
  else if (type === "interactive") {
    const b = m.interactive?.button_reply, l = m.interactive?.list_reply, nf = m.interactive?.nfm_reply;
    if (nf) {
      let rj: any = {}; try { rj = JSON.parse(nf.response_json || "{}"); } catch { /* */ }
      inp = { kind: "flow", flow: Object.fromEntries(Object.entries(rj).filter(([k]) => /^q_\d+$/.test(k)).map(([k, v]) => [k, String(v)])) }; logBody = "🧾 نموذج الطلب";
    } else if (b) { inp = { kind: "button", id: b.id }; logBody = "🔘 " + b.title; }
    else if (l) { inp = { kind: "list", id: l.id }; logBody = "📋 " + l.title; }
  } else if (type === "order") {
    const pi: any[] = m.order?.product_items || [];
    inp = { kind: "flow", flow: Object.fromEntries(pi.map((p) => ["q_" + String(p.product_retailer_id), String(p.quantity || 1)])) }; logBody = "🛒 سلة الكتالوج";
  } else if (type === "button") { inp = { kind: "button", id: m.button?.payload || "" }; logBody = m.button?.text || "[button]"; }
  else if (["image", "document", "audio", "video", "sticker"].includes(type)) {
    const md = m[type] || {}; mediaIn = { id: md.id, mime: md.mime_type, filename: md.filename, kind: type, caption: md.caption };
    logBody = (type === "image" ? "📷 صورة" : type === "document" ? "📎 ملف" : type === "audio" ? "🎤 رسالة صوتية" : type === "video" ? "🎬 فيديو" : "🙂 ملصق") + (md.caption ? ": " + md.caption : md.filename ? ": " + md.filename : "");
  }
  else if (type === "location") { inp = { kind: "location", lat: Number(m.location?.latitude), lon: Number(m.location?.longitude), addr: [m.location?.name, m.location?.address].filter(Boolean).join(" — ") || undefined }; logBody = "📍 موقع"; }

  // جلسة + بيانات المتجر بالتوازي (والمتجر من الكاش)
  const [sr, store] = await Promise.all([
    db.from("wa_sessions").select("*").eq("channel_id", ch.id).eq("wa_id", from).maybeSingle(),
    loadStore(ch.store_id),
  ]);
  let row = sr.data;
  if (!row) {
    const ins = await db.from("wa_sessions").insert({ store_id: ch.store_id, channel_id: ch.id, wa_id: from, name: contactName }).select("*").single();
    row = ins.data;
    if (!row) { const again = await db.from("wa_sessions").select("*").eq("channel_id", ch.id).eq("wa_id", from).maybeSingle(); row = again.data; }
  }
  if (!row) return;
  // منع التكرار (ميتا تعيد الإرسال أحياناً): ذاكرة سريعة + تسجيل خلفي
  if (m.id) { if (seenMsg.has(m.id)) return; seenMsg.set(m.id, Date.now()); if (seenMsg.size > 500) for (const [k, t] of seenMsg) { if (Date.now() - t > 600000) seenMsg.delete(k); } }
  if (m.id && !row.human) typing(ch, m.id).catch(() => { /* */ });
  const logIn = db.from("wa_messages").insert({ store_id: ch.store_id, session_id: row.id, dir: "in", kind: type, body: logBody.slice(0, 2000), wamid: m.id || null, payload: mediaIn ? { media: mediaIn } : null });

  const paused = row.human || (row.bot_paused_until && new Date(row.bot_paused_until).getTime() > Date.now()) || store.raw?.bot_off === true;
  const bump = { unread: (row.unread || 0) + 1 };
  if (paused) { await logIn; await db.from("wa_sessions").update({ last_in_at: new Date().toISOString(), last_msg_at: new Date().toISOString(), name: row.name || contactName, ...bump }).eq("id", row.id); return; }
  db.from("wa_sessions").update(bump).eq("id", row.id).then(() => {}, () => {});
  const { menu, cfg, flow, catalogId } = store;
  const sess = toSess(row);
  // سؤال العميل عن طلبه الحالي («وش صار على طلبي؟»): نرد بحالته الفعلية وتفاصيله ورابط التتبع بدل الرد العام
  if (row.last_order_id && ((inp.kind === "text" && CANCEL_Q.test(String(inp.text || ""))) || (inp.kind === "button" && /^x:(yes|no)/.test(String(inp.id || ""))))) { const { data: od } = await db.from("orders").select("id,invoice_number,status").eq("id", row.last_order_id).maybeSingle(); if (od) { await logIn; const free = ["pending", "new"].includes(od.status); const say = async (o: any[]) => { await db.from("wa_sessions").update({ last_in_at: new Date().toISOString(), last_msg_at: new Date().toISOString(), name: row.name || contactName, ...bump }).eq("id", row.id); await sendOut(ch, row.id, from, o); }; const NO = "🙏 عذراً، طلبك #" + od.invoice_number + " صار قيد التجهيز وما نقدر نلغيه الحين. لو فيه استفسار كلمنا."; if (inp.kind === "button" && inp.id === "x:no") { await say([{ t: "text", body: "تمام، طلبك مكمّل 👍" }]); return; } if (inp.kind === "button" && inp.id === "x:yes:" + od.id) { if (!free) { await say([{ t: "text", body: NO }]); return; } await db.from("wa_outbox").insert({ store_id: ch.store_id, session_id: row.id, order_id: od.id, status: "cancelled", sent_at: new Date().toISOString() }); const { data: up } = await db.from("orders").update({ status: "cancelled", cancelled_at: new Date().toISOString(), cancel_reason: "ألغاه العميل من واتساب" }).eq("id", od.id).in("status", ["pending", "new"]).select("id"); if (up && up.length) await say([{ t: "text", body: "❌ تم إلغاء طلبك #" + od.invoice_number + ". نتشرف بخدمتك دايماً 🌷" }]); else { await db.from("wa_outbox").delete().eq("order_id", od.id).eq("status", "cancelled"); await say([{ t: "text", body: NO }]); } return; } if (inp.kind === "text") { if (od.status === "cancelled") await say([{ t: "text", body: "طلبك #" + od.invoice_number + " ملغي من قبل." }]); else if (od.status === "delivered") await say([{ t: "text", body: "طلبك #" + od.invoice_number + " تم تسليمه، ما نقدر نلغيه." }]); else if (!free || (cfg as any).cancel_ok === false) await say([{ t: "text", body: NO }]); else await say([{ t: "buttons", body: "تبغى تلغي طلبك #" + od.invoice_number + "؟", buttons: [{ id: "x:yes:" + od.id, title: "❌ نعم، ألغِ" }, { id: "x:no", title: "↩ لا، كمّل" }] }]); return; } } }
  if (inp.kind === "text" && row.last_order_id && ORDER_Q.test(String(inp.text || ""))) {
    const { data: od } = await db.from("orders").select("invoice_number,status,items,total,track_token,created_at").eq("id", row.last_order_id).maybeSingle();
    const done = od && ["delivered", "cancelled"].includes(od.status);
    if (od && !(done && Date.now() - new Date(od.created_at).getTime() > 2 * 86400000)) {
      await logIn;
      const ST: Record<string, string> = { pending: "🧾 استلمنا طلبك وبانتظار تأكيد الفرع", new: "🧾 استلمنا طلبك وبانتظار تأكيد الفرع", preparing: "🍳 قيد التجهيز الحين", ready: "📦 جاهز وبانتظار المندوب", assigned: "🛵 عند المندوب وبيطلع لك قريباً", out_for_delivery: "🚚 في الطريق لك", delivered: "✅ تم توصيله، بالعافية عليك", cancelled: "✖️ تم إلغاء الطلب" };
      const its = (Array.isArray(od.items) ? od.items : []).map((i: any) => `• ${i.quantity || i.qty || 1} × ${i.name}`).join("\n");
      const body = `📋 طلبك #${od.invoice_number}\nالحالة: ${ST[od.status] || od.status}\n\n${its}\n\nالمجموع: ${Number(od.total)} ر.س${["pending", "new"].includes(od.status) ? "\n\nلإلغاء الطلب اكتب «ألغي طلبي» (قبل بدء التجهيز)." : ""}`;
      const tr = od.track_token ? `${SITE()}/track?t=${od.track_token}` : "";
      await db.from("wa_sessions").update({ last_in_at: new Date().toISOString(), last_msg_at: new Date().toISOString(), name: row.name || contactName, ...bump }).eq("id", row.id);
      await sendOut(ch, row.id, from, tr ? [{ t: "cta", body: body.slice(0, 1000), label: "تتبّع طلبي", url: tr }] : [{ t: "text", body }]);
      return;
    }
  }
  const res = await step(cfg, menu, sess, inp, {
    webUrl: (t) => `${SITE()}/m?t=${t}`, catalogId: (badCat.get(ch.store_id) || 0) > Date.now() - 600000 ? undefined : catalogId, flowId: flow?.id, flowDraft: flow ? !flow.published : undefined,
    checkLoc: async (lat, lon) => {
      const { data } = await db.rpc("wa_check_location", { p_store: ch.store_id, p_lat: lat, p_lon: lon });
      if (!data || data.nearest_id == null) return null;
      return { ok: data.branch_id != null, km: data.nearest_km != null ? Number(data.nearest_km) : null };
    },
    ai: aiParse,
    chat: aiChat,
    agent: (tx: string, mn: Menu, cf: any, ss: any) => aiAgent(tx, mn, cf, ss, { wa: from, store: ch.store_id }),
  });
  const sent = (res.out.length ? sendOut(ch, row.id, from, res.out) : Promise.resolve(true)).then(async (ok) => {
    if (!ok && res.out.some((o) => o.t === "catalog" || o.t === "flow")) { badCat.set(ch.store_id, Date.now()); await sendOut(ch, row.id, from, welcome(cfg, menu, res.sess, {}, true)); }
  });
  await Promise.all([saveSess(row.id, res.sess, { last_in_at: new Date().toISOString() }), sent, logIn]);

  if (res.action?.type === "create_order") {
    const a = res.action;
    const { data, error } = await db.rpc("wa_create_order", { p_session: row.id, p: {
      customer_name: res.sess.name || a.name || contactName, customer_email: a.email || res.sess.ctx?.email || null, address_text: a.address, lat: a.lat, lon: a.lon, subtotal: a.subtotal, shipping_fee: a.fee,
      items: a.lines.map((l) => ({ name: l.name, quantity: l.qty, price: l.price, total: l.qty * l.price })), cart: a.lines } });
    if (error || !data) { await logErr(ch.store_id, "wa_order", false, error?.message || "فشل إنشاء الطلب"); await sendOut(ch, row.id, from, [{ t: "text", body: "عذراً صار خلل في تسجيل الطلب 🙏 حاول مرة ثانية أو كلمنا." }]); return; }
    await sendOut(ch, row.id, from, orderDoneOut(cfg, data.invoice, a.subtotal + a.fee, data.track_token ? `${SITE()}/track?t=${data.track_token}` : undefined));
  } else if (res.action?.type === "handoff") {
    await db.from("wa_sessions").update({ human: true }).eq("id", row.id);
  }
}

async function handleWebhook(req: Request) {
  const raw = await req.text();
  if (!(await validSignature(raw, req.headers.get("x-hub-signature-256")))) return json({ error: "bad signature" }, 401);
  let body: any; try { body = JSON.parse(raw); } catch { return json({ ok: true }); }
  if (body?.object !== "whatsapp_business_account") return json({ ok: true });
  const work: Promise<void>[] = [];
  for (const e of body.entry || []) for (const c of e.changes || []) {
    const v = c.value || {}; const pnid = String(v.metadata?.phone_number_id || "");
    if (!pnid) continue;
    const names = new Map<string, string>((v.contacts || []).map((x: any) => [String(x.wa_id), String(x.profile?.name || "")]));
    for (const st of v.statuses || []) {
      work.push((async () => {
        try {
          const map: Record<string, string> = { sent: "sent", delivered: "delivered", read: "read", failed: "failed" };
          const ns = map[String(st.status)]; if (!ns || !st.id) return;
          const patch: any = { status: ns };
          if (ns === "failed") patch.payload = { failed: true, error: String(st.errors?.[0]?.title || st.errors?.[0]?.message || "").slice(0, 200) };
          await db.from("wa_messages").update(patch).eq("wamid", String(st.id)).eq("dir", "out");
        } catch (_) { /* */ }
      })());
    }
    for (const m of v.messages || []) {
      work.push((async () => {
        try {
          let hit = chCache.get(pnid);
          if (!hit || Date.now() - hit.t > 30000) {
            const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,status").eq("phone_number_id", pnid).maybeSingle();
            if (!ch || ch.status !== "active") { chCache.delete(pnid); return; }
            const { data: on } = await db.rpc("wa_enabled_for", { p_store: ch.store_id });
            hit = { t: Date.now(), ch, on: !!on }; chCache.set(pnid, hit);
          }
          if (!hit.on) return;
          const ch = hit.ch;
          await handleMessage(ch, m, names.get(String(m.from)) || null);
        } catch (err) { await logErr(null, "wa_webhook", false, String(err)); }
      })());
    }
  }
  const all = Promise.allSettled(work);
  // @ts-ignore EdgeRuntime موجود في Supabase
  if (typeof EdgeRuntime !== "undefined" && EdgeRuntime?.waitUntil) EdgeRuntime.waitUntil(all); else await all;
  return json({ ok: true });
}



// ---------- كتالوج واتساب (سلة أصناف أصلية داخل المحادثة) ----------
async function catalogFeed(u: URL) {
  const store_id = Number(u.searchParams.get("store"));
  if (!store_id) return new Response("store?", { status: 400 });
  const { menu } = await loadStore(store_id, true);
  const q = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""').replace(/\r?\n/g, " ")}"`;
  const cat = new Map(menu.cats.map((c) => [c.id, c.name]));
  const rows = [["id", "title", "description", "availability", "condition", "price", "link", "image_link", "brand", "product_type"].join(",")];
  for (const it of menu.items) {
    rows.push([it.id, q(it.name), q(it.desc || it.name), "in stock", "new", `${Number(it.price).toFixed(2)} SAR`, q(SITE()), q(it.img || ""), q(menu.store), q(it.cat != null ? cat.get(it.cat) || "" : "")].join(","));
  }
  return new Response("\ufeff" + rows.join("\n"), { headers: { ...CORS, "Content-Type": "text/csv; charset=utf-8" } });
}
async function catalogSync(req: Request) {
  const auth = req.headers.get("authorization") || "";
  const uc = createClient(Deno.env.get("SUPABASE_URL")!, env("SUPABASE_ANON_KEY"), { global: { headers: { Authorization: auth } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: isOwner } = await uc.rpc("is_owner");
  if (!isOwner) return json({ error: "forbidden" }, 403);
  const b = await req.json().catch(() => ({}));
  const store_id = Number(b.store_id);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,waba_id").eq("store_id", store_id).limit(1).maybeSingle();
  if (!ch) return json({ error: "لا يوجد رقم مربوط بهذا المتجر" }, 400);
  const token = await channelToken(ch.id);
  if (!token) return json({ error: "لا يوجد توكن" }, 400);
  const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };
  const out: Record<string, unknown> = {};
  const { data: cf } = await db.from("wa_config").select("config").eq("store_id", store_id).maybeSingle();
  const prev = (cf?.config as any)?.catalog || {};
  const catalog_id = String(b.catalog_id || prev.id || "");
  if (!catalog_id) return json({ error: "catalog_id مطلوب" }, 400);
  if (b.probe) {
    const r = await fetch(`${GRAPH()}/${catalog_id}?fields=name,product_count`, { headers: H }); out.probe = { status: r.status, body: await r.json().catch(() => ({})) };
    return json(out);
  }
  // 1) ربط الكتالوج برقم الواتساب وتفعيل السلة
  if (b.link !== false) {
    const r = await fetch(`${GRAPH()}/${ch.phone_number_id}/whatsapp_commerce_settings?catalog_id=${catalog_id}&is_cart_enabled=true&is_catalog_visible=true`, { method: "POST", headers: H });
    out.link = { status: r.status, body: await r.json().catch(() => ({})) };
  }
  // 2) رفع الأصناف
  if (b.items !== false) {
    const { menu } = await loadStore(store_id, true);
    const requests = menu.items.map((it) => ({ method: "UPDATE", data: { id: String(it.id), title: it.name, description: it.desc || it.name, availability: "in stock", condition: "new", price: `${Number(it.price).toFixed(2)} SAR`, link: SITE(), image_link: it.img || "", brand: menu.store } }));
    const r = await fetch(`${GRAPH()}/${catalog_id}/items_batch`, { method: "POST", headers: H, body: JSON.stringify({ item_type: "PRODUCT_ITEM", allow_upsert: true, requests }) });
    out.items = { status: r.status, body: await r.json().catch(() => ({})) };
  }
  if (b.ready !== undefined) {
    await db.from("wa_config").upsert({ store_id, config: { ...(cf?.config || {}), catalog: { id: catalog_id, ready: !!b.ready } }, updated_at: new Date().toISOString() });
    storeCache.delete(store_id);
    out.ready = !!b.ready;
  }
  return json(out);
}

// ---------- نموذج الطلب (WhatsApp Flow): يُبنى من المنيو وينشر لميتا ----------
function buildFlow(menu: Menu) {
  const groups: { title: string; items: Menu["items"] }[] = [];
  for (const c of menu.cats) {
    const its = menu.items.filter((i) => i.cat === c.id);
    for (let k = 0; k < its.length; k += 10) groups.push({ title: `${c.emoji ? c.emoji + " " : ""}${c.name}${its.length > 10 ? ` (${k / 10 + 1})` : ""}`.slice(0, 30), items: its.slice(k, k + 10) });
  }
  const unc = menu.items.filter((i) => i.cat == null);
  for (let k = 0; k < unc.length; k += 10) groups.push({ title: "أصناف أخرى", items: unc.slice(k, k + 10) });
  const gs = groups.slice(0, 26);
  const qty = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"].map((n) => ({ id: n, title: n }));
  const sid = (n: number) => "CAT_" + String.fromCharCode(65 + n);
  const prev: string[] = [];
  const screens = gs.map((g, n) => {
    const last = n === gs.length - 1;
    const cur = g.items.map((i) => "q_" + i.id);
    const payload: Record<string, string> = {};
    for (const f of prev) payload[f] = "${data." + f + "}";
    for (const f of cur) payload[f] = "${form." + f + "}";
    const data: Record<string, unknown> = {};
    for (const f of prev) data[f] = { type: "string", __example__: "0" };
    const children: unknown[] = [{ type: "TextBody", text: `اختر الكمية لكل صنف (0 = ما أبغاه) — ${n + 1}/${gs.length}` }];
    for (const i of g.items) {
      children.push({ type: "TextBody", text: `${i.pop ? "⭐ " : ""}${i.name} — ${i.price} ر.س${i.desc ? "\n" + i.desc : ""}`.slice(0, 300) });
      children.push({ type: "Dropdown", name: "q_" + i.id, label: "الكمية", required: false, "init-value": "0", "data-source": qty });
    }
    children.push({ type: "Footer", label: last ? "تأكيد الطلب" : "التالي", "on-click-action": last ? { name: "complete", payload } : { name: "navigate", next: { type: "screen", name: sid(n + 1) }, payload } });
    prev.push(...cur);
    return { id: sid(n), title: g.title, ...(last ? { terminal: true, success: true } : {}), ...(Object.keys(data).length ? { data } : {}), layout: { type: "SingleColumnLayout", children } };
  });
  return { version: "6.3", screens };
}
async function flowSync(req: Request) {
  const auth = req.headers.get("authorization") || "";
  const uc = createClient(Deno.env.get("SUPABASE_URL")!, env("SUPABASE_ANON_KEY"), { global: { headers: { Authorization: auth } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: isOwner } = await uc.rpc("is_owner");
  if (!isOwner) return json({ error: "forbidden" }, 403);
  const b = await req.json().catch(() => ({}));
  const store_id = Number(b.store_id);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,waba_id").eq("store_id", store_id).limit(1).maybeSingle();
  if (!ch) return json({ error: "لا يوجد رقم مربوط بهذا المتجر" }, 400);
  const waba = ch.waba_id || String(b.waba_id || "");
  const token = await channelToken(ch.id);
  if (!waba || !token) return json({ error: !waba ? "WABA ID غير محفوظ للقناة" : "لا يوجد توكن" }, 400);
  const { menu } = await loadStore(store_id, true);
  if (!menu.items.length) return json({ error: "المنيو فاضي" }, 400);
  const fj = buildFlow(menu);
  const r = await fetch(`${GRAPH()}/${waba}/flows`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
    body: JSON.stringify({ name: `msar-${store_id}-${Date.now().toString(36)}`, categories: ["OTHER"], flow_json: JSON.stringify(fj) }) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || !j.id) { await logErr(store_id, "wa_flow", false, `${r.status} ${JSON.stringify(j).slice(0, 700)}`); return json({ ok: false, status: r.status, error: j?.error || j }, 400); }
  const { data: cf } = await db.from("wa_config").select("config").eq("store_id", store_id).maybeSingle();
  const old = (cf?.config as any)?.flow;
  let published = false;
  if (b.publish && !(j.validation_errors || []).length) {
    const pr = await fetch(`${GRAPH()}/${j.id}/publish`, { method: "POST", headers: { Authorization: `Bearer ${token}` } });
    published = pr.ok; if (!pr.ok) await logErr(store_id, "wa_flow", false, "publish " + (await pr.text()).slice(0, 500));
  }
  await db.from("wa_config").upsert({ store_id, config: { ...(cf?.config || {}), flow: { id: String(j.id), sig: menuSig(menu), published } }, updated_at: new Date().toISOString() });
  storeCache.delete(store_id);
  if (old?.id && !old.published) fetch(`${GRAPH()}/${old.id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } }).catch(() => { /* */ });
  return json({ ok: true, flow_id: j.id, published, validation_errors: j.validation_errors || [], screens: fj.screens.length });
}

// ---------- صفحة المنيو الكامل ----------
async function sessionByToken(t: string) {
  if (!/^[a-f0-9]{32}$/.test(t)) return null;
  const { data } = await db.from("wa_sessions").select("*").eq("web_token", t).maybeSingle();
  if (!data) return null;
  const { data: on } = await db.rpc("wa_enabled_for", { p_store: data.store_id });
  return on ? data : null;
}
async function webMenu(url: URL) {
  const row = await sessionByToken(url.searchParams.get("t") || "");
  if (!row) return json({ error: "الرابط غير صالح أو منتهي" }, 404);
  const { menu, cfg } = await loadStore(row.store_id);
  return json({ store: menu.store, cats: menu.cats, items: menu.items.map((i) => ({ id: i.id, cat: i.cat, name: i.name, desc: i.desc, price: i.price, img: i.img, emoji: i.emoji, pop: !!i.pop })), wa: String((await db.from("wa_channels").select("display_phone").eq("id", row.channel_id).maybeSingle()).data?.display_phone || "").replace(/\D/g, ""), fee: cfg.delivery_fee, free_over: cfg.free_over, min_order: cfg.min_order });
}
async function webSubmit(req: Request) {
  const b = await req.json().catch(() => ({}));
  const row = await sessionByToken(String(b.t || ""));
  if (!row) return json({ error: "الرابط غير صالح أو منتهي" }, 404);
  const lines = (Array.isArray(b.lines) ? b.lines : []).map((l: any) => ({ id: Number(l.id), qty: Number(l.qty), no: (Array.isArray(l.no) ? l.no : []).map((x: any) => String(x).replace(/[\n\r()]/g, " ").trim().slice(0, 20)).filter(Boolean).slice(0, 12) })).filter((l: any) => l.id > 0 && l.qty > 0).slice(0, 60);
  if (!lines.length) return json({ error: "السلة فاضية" }, 400);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,status").eq("id", row.channel_id).maybeSingle();
  if (!ch || ch.status !== "active") return json({ error: "القناة غير متاحة" }, 400);
  const { menu, cfg } = await loadStore(row.store_id);
  const sess = toSess(row);
  const outs = webSubmitted(cfg, menu, sess, lines);
  if (!sess.cart.length) return json({ error: "الأصناف غير متاحة" }, 400);
  await saveSess(row.id, sess);
  await db.from("wa_messages").insert({ store_id: row.store_id, session_id: row.id, dir: "in", kind: "web_order", body: "🌐 طلب من المنيو الكامل: " + sess.cart.map((l) => `${l.qty}×${l.name}`).join("، ") });
  await sendOut(ch as any, row.id, row.wa_id, outs);
  return json({ ok: true });
}

// ---------- رد الموظف ----------
async function authAgent(req: Request): Promise<any> {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return { err: json({ error: "غير مصرح" }, 401) };
  const { data: u } = await db.auth.getUser(token);
  if (!u?.user) return { err: json({ error: "غير مصرح" }, 401) };
  const { data: p } = await db.from("profiles").select("store_id,role,is_active,full_name").eq("id", u.user.id).maybeSingle();
  if (!p?.is_active || !["admin", "cashier"].includes(p.role)) return { err: json({ error: "غير مصرح" }, 403) };
  return { p };
}
async function agentReply(req: Request) {
  const au = await authAgent(req); if (au.err) return au.err; const p = au.p;
  let text = "", sessionId = 0, file: File | null = null;
  if ((req.headers.get("content-type") || "").includes("multipart/form-data")) {
    const f = await req.formData(); text = String(f.get("text") || "").trim().slice(0, 1000); sessionId = Number(f.get("session_id")); const x = f.get("file"); if (x instanceof File && x.size) file = x;
  } else { const b = await req.json().catch(() => ({})); text = String(b.text || "").trim().slice(0, 1500); sessionId = Number(b.session_id); }
  if (!text && !file) return json({ error: "الرسالة فاضية" }, 400);
  const { data: s } = await db.from("wa_sessions").select("*").eq("id", sessionId).maybeSingle();
  if (!s || s.store_id !== p.store_id) return json({ error: "المحادثة غير موجودة" }, 404);
  const { data: on } = await db.rpc("wa_enabled_for", { p_store: s.store_id });
  if (!on) return json({ error: "الميزة غير مفعلة" }, 403);
  if (!s.last_in_at || Date.now() - new Date(s.last_in_at).getTime() > 24 * 3600 * 1000)
    return json({ error: "مرّت أكثر من 24 ساعة على آخر رسالة من العميل، ميتا تمنع الرد الحر. انتظر رسالة جديدة منه." }, 400);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id").eq("id", s.channel_id).maybeSingle();
  if (!ch) return json({ error: "القناة غير موجودة" }, 404);
  const out: Out[] = [];
  if (file) {
    if (file.size > 5 * 1024 * 1024) return json({ error: "الملف أكبر من 5 ميجا" }, 400);
    const isImg = /^image\/(jpeg|png)$/.test(file.type); const okDoc = /^(application\/pdf|application\/msword|application\/vnd\.|text\/plain)/.test(file.type);
    if (!isImg && !okDoc) return json({ error: "نوع الملف غير مدعوم (صور JPG/PNG أو PDF/Word/Excel)" }, 400);
    const token = await channelToken(ch.id); if (!token) return json({ error: "لا يوجد توكن للقناة" }, 400);
    const fd = new FormData(); fd.append("messaging_product", "whatsapp"); fd.append("type", file.type); fd.append("file", file, file.name);
    const up = await fetch(`${GRAPH()}/${ch.phone_number_id}/media`, { method: "POST", headers: { Authorization: `Bearer ${token}` }, body: fd, signal: AbortSignal.timeout(20000) });
    const uj: any = await up.json().catch(() => ({}));
    if (!up.ok || !uj.id) { await logErr(ch.store_id, "wa_send", false, `media ${up.status} ${JSON.stringify(uj?.error || uj).slice(0, 400)}`); return json({ error: "تعذر رفع الملف لميتا: " + (uj?.error?.message || up.status) }, 400); }
    out.push({ t: "media", kind: isImg ? "image" : "document", id: uj.id, mime: file.type, filename: file.name, caption: text } as any);
  } else out.push({ t: "text", body: text });
  const ok = await sendOut(ch as any, s.id, s.wa_id, out, "agent", p.full_name || "موظف");
  // ردي يوقف البوت تلقائياً حسب الإعداد (agent_pause بالدقائق: 0 = لا يوقف، -1 = لين أرجعه يدوياً)
  const { raw } = await loadStore(s.store_id);
  const mins = raw?.agent_pause === undefined ? 60 : Number(raw.agent_pause);
  const upd: any = { last_msg_at: new Date().toISOString(), unread: 0 };
  if (ok && mins === -1) upd.human = true; else if (ok && mins > 0) upd.bot_paused_until = new Date(Date.now() + mins * 60000).toISOString();
  await db.from("wa_sessions").update(upd).eq("id", s.id);
  return json({ ok, paused: ok ? (mins === -1 ? "manual" : mins > 0 ? upd.bot_paused_until : null) : null });
}

// عرض صورة/ملف وارد أو صادر (بروكسي لميتا بتوكن القناة — المتصفح ما يقدر يوصلها مباشرة)
async function mediaProxy(req: Request) {
  const au = await authAgent(req); if (au.err) return au.err; const p = au.p;
  const b = await req.json().catch(() => ({}));
  const mid = String(b.media_id || ""); const { data: msg } = await db.from("wa_messages").select("id,session_id,store_id,payload").eq("id", Number(b.message_id)).maybeSingle();
  if (!msg || msg.store_id !== p.store_id || (msg.payload as any)?.media?.id !== mid) return json({ error: "غير موجود" }, 404);
  const { data: s } = await db.from("wa_sessions").select("channel_id").eq("id", msg.session_id).maybeSingle();
  const token = s ? await channelToken(s.channel_id) : ""; if (!token) return json({ error: "لا يوجد توكن" }, 400);
  const mj: any = await (await fetch(`${GRAPH()}/${encodeURIComponent(mid)}`, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(10000) })).json().catch(() => ({}));
  if (!mj?.url) return json({ error: "انتهت صلاحية الملف عند ميتا (30 يوم)" }, 410);
  const r = await fetch(mj.url, { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(20000) });
  if (!r.ok) return json({ error: "تعذر تحميل الملف" }, 502);
  return new Response(r.body, { headers: { "Content-Type": mj.mime_type || r.headers.get("content-type") || "application/octet-stream", "Cache-Control": "private, max-age=3600", "Access-Control-Allow-Origin": "*" } });
}

// ---------- تحديثات الحالة ----------
async function flush() {
  const { data: rows } = await db.from("wa_outbox").select("*").is("sent_at", null).lt("tries", 5).order("id").limit(40);
  let sent = 0;
  for (const r of rows || []) {
    try {
      await db.from("wa_outbox").update({ tries: r.tries + 1 }).eq("id", r.id);
      const [{ data: o }, { data: s }] = await Promise.all([
        db.from("orders").select("invoice_number,status").eq("id", r.order_id).maybeSingle(),
        db.from("wa_sessions").select("*").eq("id", r.session_id).maybeSingle()]);
      if (!o || !s) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "no order/session" }).eq("id", r.id); continue; }
      if (!s.last_in_at || Date.now() - new Date(s.last_in_at).getTime() > 24 * 3600 * 1000) {
        await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "خارج نافذة 24 ساعة (يحتاج قالب معتمد)" }).eq("id", r.id); continue; }
      const { cfg } = await loadStore(s.store_id);
      const txt = statusText(cfg, r.status, o.invoice_number || String(r.order_id));
      const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id").eq("id", s.channel_id).maybeSingle();
      if (!txt || !ch) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "skip" }).eq("id", r.id); continue; }
      const ok = await sendOut(ch as any, s.id, s.wa_id, [{ t: "text", body: txt }], "status");
      if (ok) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: null }).eq("id", r.id); sent++; }
      else await db.from("wa_outbox").update({ error: "فشل الإرسال" }).eq("id", r.id);
    } catch (e) { await db.from("wa_outbox").update({ error: String(e).slice(0, 300) }).eq("id", r.id); }
  }
  return json({ ok: true, sent, pending: (rows || []).length });
}

/** ---------- Embedded Signup: ربط رقم التاجر بنفسه + القوالب ---------- */
const META_APP_ID = () => env("WA_APP_ID") || "1860542181636270";
async function gjson(r: Response) { return await r.json().catch(() => ({})); }

async function esConnect(req: Request) {
  const a = await adminOf(req); if (!a) return json({ error: "غير مصرح" }, 401);
  const secret = env("WA_APP_SECRET"); if (!secret) return json({ error: "إعداد ميتا ناقص في الخادم" }, 503);
  const b = await req.json().catch(() => ({}));
  const code = String(b.code || ""), waba = String(b.waba_id || ""), pnid = String(b.phone_number_id || "");
  if (!code || !/^\d{5,25}$/.test(waba) || !/^\d{5,25}$/.test(pnid)) return json({ error: "بيانات الربط غير مكتملة، أعد المحاولة" }, 400);
  const { data: ex } = await db.from("wa_channels").select("id,store_id").eq("phone_number_id", pnid).maybeSingle();
  if (ex && ex.store_id !== a.store_id) return json({ error: "هذا الرقم مربوط بمتجر آخر" }, 409);
  const tr = await fetch(`${GRAPH()}/oauth/access_token?client_id=${META_APP_ID()}&client_secret=${encodeURIComponent(secret)}&code=${encodeURIComponent(code)}`);
  const tj: any = await gjson(tr);
  if (!tr.ok || !tj.access_token) { await logErr(a.store_id, "wa_es", false, "token " + tr.status + " " + JSON.stringify(tj).slice(0, 200).replace(secret, "***")); return json({ error: "ميتا رفضت الرمز، أعد المحاولة من البداية" }, 502); }
  const token = String(tj.access_token);
  const H = { "Content-Type": "application/json", Authorization: `Bearer ${token}` };
  const sub = await fetch(`${GRAPH()}/${waba}/subscribed_apps`, { method: "POST", headers: H });
  if (!sub.ok) { await logErr(a.store_id, "wa_es", false, "subscribe " + sub.status + " " + JSON.stringify(await gjson(sub)).slice(0, 200)); return json({ error: "تعذر تفعيل استقبال الرسائل لهذا الحساب" }, 502); }
  const pin = String(Math.floor(100000 + Math.random() * 900000));
  const reg = await fetch(`${GRAPH()}/${pnid}/register`, { method: "POST", headers: H, body: JSON.stringify({ messaging_product: "whatsapp", pin }) });
  if (!reg.ok) await logErr(a.store_id, "wa_es", false, "register " + reg.status + " " + JSON.stringify(await gjson(reg)).slice(0, 200));
  const info: any = await gjson(await fetch(`${GRAPH()}/${pnid}?fields=display_phone_number,verified_name`, { headers: H }));
  const row = { store_id: a.store_id, phone_number_id: pnid, waba_id: waba, display_phone: info.display_phone_number || null, label: info.verified_name || null, status: "active" };
  const { data: ch, error } = await db.from("wa_channels").upsert(row, { onConflict: "phone_number_id" }).select("id").single();
  if (error || !ch) { await logErr(a.store_id, "wa_es", false, "db " + String(error?.message || "").slice(0, 200)); return json({ error: "تعذر حفظ الربط" }, 500); }
  await db.from("wa_secrets").upsert({ channel_id: ch.id, access_token: token, updated_at: new Date().toISOString() });
  tokenCache.delete(ch.id); chCache.clear();
  await logErr(a.store_id, "wa_es", true, "connected " + pnid);
  return json({ ok: true, display_phone: row.display_phone, label: row.label });
}

async function esDisconnect(req: Request) {
  const a = await adminOf(req); if (!a) return json({ error: "غير مصرح" }, 401);
  const b = await req.json().catch(() => ({}));
  const { data: ch } = await db.from("wa_channels").select("id,store_id,waba_id").eq("id", Number(b.channel_id)).maybeSingle();
  if (!ch || ch.store_id !== a.store_id) return json({ error: "غير موجود" }, 404);
  const { data: sec } = await db.from("wa_secrets").select("access_token").eq("channel_id", ch.id).maybeSingle();
  if (sec?.access_token && ch.waba_id) {
    try { await fetch(`${GRAPH()}/${ch.waba_id}/subscribed_apps`, { method: "DELETE", headers: { Authorization: `Bearer ${sec.access_token}` } }); } catch { /* */ }
  }
  await db.from("wa_secrets").delete().eq("channel_id", ch.id);
  await db.from("wa_channels").update({ status: "paused" }).eq("id", ch.id);
  tokenCache.delete(ch.id); chCache.clear();
  await logErr(a.store_id, "wa_es", true, "disconnected " + ch.id);
  return json({ ok: true });
}

async function tplCtx(req: Request) {
  const a = await adminOf(req); if (!a) return { err: json({ error: "غير مصرح" }, 401) };
  const { data: ch } = await db.from("wa_channels").select("id,waba_id,status").eq("store_id", a.store_id).eq("status", "active").limit(1).maybeSingle();
  if (!ch?.waba_id) return { err: json({ error: "اربط رقم واتساب أولاً" }, 400) };
  const token = await channelToken(ch.id); if (!token) return { err: json({ error: "لا يوجد توكن" }, 400) };
  return { a, ch, token, H: { "Content-Type": "application/json", Authorization: `Bearer ${token}` } };
}
async function tplList(req: Request) {
  const c: any = await tplCtx(req); if (c.err) return c.err;
  const r = await fetch(`${GRAPH()}/${c.ch.waba_id}/message_templates?fields=name,status,category,language,components,rejected_reason&limit=100`, { headers: c.H });
  const j: any = await gjson(r); if (!r.ok) return json({ error: j?.error?.message || "تعذر جلب القوالب" }, 502);
  return json({ templates: (j.data || []).map((t: any) => ({ name: t.name, status: t.status, category: t.category, language: t.language, rejected_reason: t.rejected_reason,
    body: (t.components || []).find((x: any) => x.type === "BODY")?.text || "" })) });
}
async function tplCreate(req: Request) {
  const c: any = await tplCtx(req); if (c.err) return c.err;
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || "").trim();
  const lang = ["ar", "en", "en_US"].includes(String(b.language)) ? String(b.language) : "ar";
  const category = b.category === "MARKETING" ? "MARKETING" : "UTILITY";
  const text = String(b.body || "").trim();
  if (!/^[a-z0-9_]{1,60}$/.test(name)) return json({ error: "اسم القالب: حروف إنجليزية صغيرة وأرقام و_ فقط" }, 400);
  if (text.length < 5 || text.length > 1000) return json({ error: "نص القالب من 5 إلى 1000 حرف" }, 400);
  const vars = [...text.matchAll(/\{\{(\d+)\}\}/g)].map((m) => Number(m[1]));
  const nv = vars.length ? Math.max(...vars) : 0;
  if (nv > 0 && new Set(vars).size !== nv) return json({ error: "رقّم المتغيرات بالترتيب {{1}} {{2}} …" }, 400);
  const examples = Array.isArray(b.examples) ? b.examples.map((x: any) => String(x).slice(0, 60)) : [];
  const body: any = { type: "BODY", text };
  if (nv > 0) { if (examples.length < nv || examples.slice(0, nv).some((x: string) => !x)) return json({ error: "اكتب مثالاً لكل متغير" }, 400); body.example = { body_text: [examples.slice(0, nv)] }; }
  const r = await fetch(`${GRAPH()}/${c.ch.waba_id}/message_templates`, { method: "POST", headers: c.H, body: JSON.stringify({ name, language: lang, category, components: [body] }) });
  const j: any = await gjson(r);
  if (!r.ok) return json({ error: j?.error?.error_user_msg || j?.error?.message || "ميتا رفضت القالب" }, 502);
  return json({ ok: true, id: j.id, status: j.status });
}
async function tplDelete(req: Request) {
  const c: any = await tplCtx(req); if (c.err) return c.err;
  const b = await req.json().catch(() => ({}));
  const name = String(b.name || "");
  if (!/^[a-z0-9_]{1,60}$/.test(name)) return json({ error: "اسم غير صالح" }, 400);
  const r = await fetch(`${GRAPH()}/${c.ch.waba_id}/message_templates?name=${name}`, { method: "DELETE", headers: c.H });
  const j: any = await gjson(r); if (!r.ok) return json({ error: j?.error?.message || "تعذر الحذف" }, 502);
  return json({ ok: true });
}

/** فحص صلاحية توكنات القنوات (للمالك فقط): لا يرجع أي توكن، فقط الحالة وتاريخ الانتهاء */
async function tokenInfo(req: Request) {
  const auth = req.headers.get("authorization") || "";
  const uc = createClient(Deno.env.get("SUPABASE_URL")!, env("SUPABASE_ANON_KEY"), { global: { headers: { Authorization: auth } }, auth: { persistSession: false, autoRefreshToken: false } });
  const { data: isOwner } = await uc.rpc("is_owner");
  if (!isOwner) return json({ error: "forbidden" }, 403);
  const app = `${META_APP_ID()}|${env("WA_APP_SECRET")}`;
  const { data: chs } = await db.from("wa_channels").select("id,store_id,phone_number_id,status");
  const out: any[] = [];
  for (const c of chs || []) {
    const t = await channelToken(c.id);
    if (!t) { out.push({ channel_id: c.id, status: c.status, has_token: false }); continue; }
    const j: any = await gjson(await fetch(`${GRAPH()}/debug_token?input_token=${encodeURIComponent(t)}&access_token=${encodeURIComponent(app)}`));
    const d = j?.data || {};
    out.push({ channel_id: c.id, store_id: c.store_id, status: c.status, has_token: true, is_valid: d.is_valid, type: d.type, expires_at: d.expires_at, data_access_expires_at: d.data_access_expires_at, scopes: d.scopes, error: j?.error?.message });
  }
  return json({ channels: out, global_token: !!env("WA_ACCESS_TOKEN") });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "";
  try {
    if (req.method === "GET" && url.searchParams.get("hub.mode") === "subscribe") {
      const ok = env("WA_VERIFY_TOKEN") && url.searchParams.get("hub.verify_token") === env("WA_VERIFY_TOKEN");
      return ok ? new Response(url.searchParams.get("hub.challenge") || "", { status: 200 }) : new Response("forbidden", { status: 403 });
    }
    if (action === "health") return json({ ok: true, secrets: { verify: !!env("WA_VERIFY_TOKEN"), app_secret: !!env("WA_APP_SECRET"), token: !!env("WA_ACCESS_TOKEN"), ai: !!env("GEMINI_API_KEY") } });
    if (action === "web_menu" && req.method === "GET") return await webMenu(url);
    if (action === "web_submit" && req.method === "POST") return await webSubmit(req);
    if (action === "reply" && req.method === "POST") return await agentReply(req);
    if (action === "media" && req.method === "POST") return await mediaProxy(req);
    if (action === "flow_sync" && req.method === "POST") return await flowSync(req);
    if (action === "ai_test" && req.method === "POST") return await aiTest(req);
    if (action === "ai_preview" && req.method === "POST") return await aiPreview(req);
    if (action === "menu_scan" && req.method === "POST") return await menuScan(req);
    if (action === "es_connect" && req.method === "POST") return await esConnect(req);
    if (action === "es_disconnect" && req.method === "POST") return await esDisconnect(req);
    if (action === "tpl_list" && req.method === "POST") return await tplList(req);
    if (action === "tpl_create" && req.method === "POST") return await tplCreate(req);
    if (action === "tpl_delete" && req.method === "POST") return await tplDelete(req);
    if (action === "token_info" && req.method === "POST") return await tokenInfo(req);
    if (action === "catalog_sync" && req.method === "POST") return await catalogSync(req);
    if (action === "catalog_feed" && req.method === "GET") return await catalogFeed(url);
    if (action === "flush") return (await cronOk(req)) ? await flush() : json({ error: "forbidden" }, 403);
    if (req.method === "POST" && !action) return await handleWebhook(req);
    return json({ error: "unknown" }, 404);
  } catch (e) { await logErr(null, "wa_fatal", false, String(e)); return json({ error: "server" }, 500); }
});
