// =====================================================================
//  مسار (MSAR) — إشعارات Push للمندوب عبر Firebase Cloud Messaging (Supabase Edge Function: push)
//  تُستدعى من قاعدة البيانات (trigger على orders) بمفتاح x-cron-key، وليست للمتصفح.
//  تحتاج السر FCM_SERVICE_ACCOUNT (محتوى ملف JSON من Firebase) — صاحب المشروع يضيفه بنفسه في Supabase Secrets.
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT"
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { "Content-Type": "application/json; charset=utf-8" } });

async function getSetting(k: string): Promise<string | null> {
  const { data } = await db.from("app_settings").select("value").eq("key", k).maybeSingle();
  return data ? (data.value as string) : null;
}

// ---- OAuth لخدمة FCM من حساب الخدمة (JWT RS256 بدون مكتبات)
const b64u = (b: ArrayBuffer | Uint8Array | string) => {
  const u = typeof b === "string" ? new TextEncoder().encode(b) : b instanceof Uint8Array ? b : new Uint8Array(b);
  let s = ""; u.forEach((c) => (s += String.fromCharCode(c)));
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
let cached: { token: string; exp: number } | null = null;
async function accessToken(sa: any): Promise<string> {
  if (cached && cached.exp > Date.now() + 60_000) return cached.token;
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: "RS256", typ: "JWT" }));
  const claim = b64u(JSON.stringify({ iss: sa.client_email, scope: "https://www.googleapis.com/auth/firebase.messaging", aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600 }));
  const pem = String(sa.private_key).replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "");
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey("pkcs8", der, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(`${head}.${claim}`));
  const r = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: `${head}.${claim}.${b64u(sig)}` }),
  });
  const j = await r.json();
  if (!j.access_token) throw new Error("fcm oauth: " + JSON.stringify(j).slice(0, 200));
  cached = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return cached.token;
}

async function sendOne(sa: any, at: string, token: string, title: string, body: string, data: Record<string, string>) {
  const r = await fetch(`https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`, {
    method: "POST", headers: { Authorization: `Bearer ${at}`, "Content-Type": "application/json" },
    body: JSON.stringify({ message: {
      token, data,
      // رسالة "notification" عشان النظام نفسه يعرضها بصوت القناة حتى لو التطبيق مقفول/مذبوح
      notification: { title, body },
      android: { priority: "HIGH", ttl: "300s", collapse_key: "msar_order_" + (data.order_id || ""),
        notification: { channel_id: "orders_v2", sound: "msar_driver", notification_priority: "PRIORITY_MAX", visibility: "PUBLIC", default_vibrate_timings: false, vibrate_timings: ["0.6s", "0.2s", "0.6s", "0.2s", "0.6s"], tag: "order_" + (data.order_id || "") } },
    } }),
  });
  if (r.ok) return { ok: true };
  const t = await r.text();
  return { ok: false, gone: /UNREGISTERED|NOT_FOUND|INVALID_ARGUMENT/.test(t) && r.status !== 401, err: t.slice(0, 200) };
}

Deno.serve(async (req) => {
  if (req.method !== "POST") return json({ ok: false, error: "method" }, 405);
  const key = await getSetting("cron_key");
  if (!key || req.headers.get("x-cron-key") !== key) return json({ ok: false, error: "unauthorized" }, 401);
  let b: any = {}; try { b = await req.json(); } catch (_) {}
  const raw = Deno.env.get("FCM_SERVICE_ACCOUNT");
  if (!raw) return json({ ok: false, error: "FCM_SERVICE_ACCOUNT not set" }, 200);
  let sa: any; try { sa = JSON.parse(raw); } catch (_) { return json({ ok: false, error: "FCM_SERVICE_ACCOUNT is not valid JSON" }, 200); }

  // اختبار من لوحة المالك/يدوي: { kind:"test", user_id }
  let title = "🛵 طلب جديد لك!", body = "افتح التطبيق لعرض الطلب", userId: string | null = b.driver_id || null; const data: Record<string, string> = { type: "new_order" };
  if (b.kind === "new_order" && b.order_id) {
    const { data: o } = await db.from("orders").select("id,status,driver_id,invoice_number,customer_name,district").eq("id", b.order_id).maybeSingle();
    if (!o || o.status !== "assigned" || !o.driver_id) return json({ ok: true, skipped: "order not assigned" });
    userId = o.driver_id;
    body = `#${o.invoice_number || o.id} — ${o.customer_name || ""} — ${o.district || ""}`.replace(/ — +$/g, "");
    data.order_id = String(o.id);
  } else if (b.kind === "test") { title = "🔔 تجربة"; body = "إشعارات مسار تعمل حتى لو التطبيق مقفول"; data.type = "test"; }
  else return json({ ok: false, error: "bad request" }, 400);
  if (!userId) return json({ ok: false, error: "no driver" }, 400);

  const { data: toks } = await db.from("push_tokens").select("token").eq("user_id", userId);
  if (!toks?.length) return json({ ok: true, sent: 0, note: "no tokens" });
  let at: string; try { at = await accessToken(sa); } catch (e) { return json({ ok: false, error: String((e as Error).message) }, 200); }
  let sent = 0; const errs: string[] = [];
  for (const t of toks) {
    const r = await sendOne(sa, at, t.token, title, body, data);
    if (r.ok) sent++; else { errs.push(r.err || ""); if (r.gone) await db.from("push_tokens").delete().eq("token", t.token); }
  }
  return json({ ok: true, sent, failed: toks.length - sent, errs: errs.slice(0, 2) });
});
