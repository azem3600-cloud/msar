// =====================================================================
//  مسار (MSAR) — الربط مع زد لكل المتاجر (Supabase Edge Function: zid)
//  install  : بداية تثبيت التطبيق من سوق زد (OAuth)
//  callback : استلام التوكن → إنشاء/تحديث المتجر → Webhooks → مزامنة → صفحة الإعداد
//  webhook  : الطلبات الجديدة وتحديثات الحالة لحظياً (?store=ID&key=...)
//  setup    : إنشاء حساب مدير المتجر لأول مرة (برمز الإعداد)
//  cron/push: مزامنة احتياطية + إرسال الحالات لزد + تجديد التوكنات
//  sync/import/webhooks/status : لمدير المتجر من لوحة التحكم
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT"
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false, autoRefreshToken: false } });

const ZID_API = "https://api.zid.sa/v1";
const ZID_OAUTH = "https://oauth.zid.sa";
// الرابط العام للدالة كما يراه زد (OAuth redirect_uri + Webhooks): عبر وسيط api.msarpro.com (deploy/api-proxy)
// بدل *.supabase.co اللي ترفضه مراجعة زد. غيّره بمتغير PUBLIC_FN_URL لو احتجت الرجوع للرابط المباشر.
const FN_URL = Deno.env.get("PUBLIC_FN_URL") || "https://api.msarpro.com/zid";
const EMAIL_DOMAIN = "msar.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });
const esc = (s: string) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
// Supabase يعرض HTML من الدوال كنص عادي، فنحوّل لصفحة رسائل على موقع مسار
let WEB_BASE = "";
const html = (msg: string, ok = true, redirect?: string) => {
  if (WEB_BASE) {
    const q = new URLSearchParams({ ok: ok ? "1" : "0", m: msg });
    if (redirect) q.set("next", redirect);
    return Response.redirect(`${WEB_BASE}msg?${q}`, 302);
  }
  return new Response(`${ok ? "✅" : "⚠️"} ${msg}${redirect ? `\n${redirect}` : ""}`, { status: ok ? 200 : 400, headers: { "Content-Type": "text/plain; charset=utf-8" } });
};

// ------------------------------------------------------------------ helpers
async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data } = await db.from("app_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? null) as T | null;
}
async function setSetting(key: string, value: unknown) {
  await db.from("app_settings").upsert({ key, value, updated_at: new Date().toISOString() });
}
async function log(store: number | null, kind: string, ok: boolean, message: string, payload?: unknown) {
  try { await db.from("zid_log").insert({ store_id: store, kind, ok, message: message?.slice(0, 1000), payload: payload ?? null }); } catch (_) { /* ignore */ }
}
const webUrl = async () => String((await getSetting<string>("web_url")) ?? "").replace(/\/?$/, "/");

type Tokens = { access_token: string; authorization: string; refresh_token: string; expires_at?: string; obtained_at?: string };
async function getTokens(store: number): Promise<Tokens | null> {
  const { data } = await db.from("store_secrets").select("zid_tokens").eq("store_id", store).maybeSingle();
  return (data?.zid_tokens ?? null) as Tokens | null;
}
async function saveSecrets(store: number, patch: Record<string, unknown>) {
  await db.from("store_secrets").upsert({ store_id: store, ...patch, updated_at: new Date().toISOString() });
}

async function zid(path: string, t: Tokens | null, init: RequestInit = {}): Promise<any> {
  if (!t?.access_token) throw new Error("المتجر غير مربوط بزد");
  const res = await fetch(`${ZID_API}${path}`, {
    ...init,
    headers: {
      "Authorization": `Bearer ${t.authorization}`,
      "X-Manager-Token": t.access_token,
      "Accept": "application/json",
      "Accept-Language": "ar",
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  const text = await res.text();
  let body: any; try { body = JSON.parse(text); } catch { body = text; }
  if (!res.ok) throw new Error(`Zid ${res.status} ${path}: ${typeof body === "string" ? body.slice(0, 300) : JSON.stringify(body).slice(0, 300)}`);
  return body;
}

async function tokenRequest(params: Record<string, string>): Promise<Tokens> {
  const clientId = await getSetting<string>("zid_client_id");
  const clientSecret = await getSetting<string>("zid_client_secret");
  if (!clientId || !clientSecret) throw new Error("مفاتيح تطبيق زد غير مُدخلة في لوحة صاحب المنصة");
  const form = new URLSearchParams({ client_id: String(clientId), client_secret: String(clientSecret), ...params });
  const res = await fetch(`${ZID_OAUTH}/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
    body: form,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.access_token) throw new Error(`فشل الحصول على التوكن من زد (${res.status}): ${JSON.stringify(body).slice(0, 300)}`);
  const now = Date.now();
  return {
    access_token: body.access_token,
    authorization: body.authorization,
    refresh_token: body.refresh_token,
    expires_at: new Date(now + (Number(body.expires_in) || 31536000) * 1000).toISOString(),
    obtained_at: new Date(now).toISOString(),
  };
}

async function refreshIfNeeded(store: number) {
  const t = await getTokens(store);
  if (!t?.refresh_token || !t.obtained_at) return;
  if ((Date.now() - Date.parse(t.obtained_at)) / 86400000 < 300) return;
  try {
    const nt = await tokenRequest({ grant_type: "refresh_token", refresh_token: t.refresh_token, redirect_uri: `${FN_URL}?action=callback` });
    await saveSecrets(store, { zid_tokens: { ...t, ...nt } });
    await log(store, "oauth", true, "تم تجديد توكن زد");
  } catch (e) {
    await log(store, "oauth", false, `فشل تجديد التوكن: ${(e as Error).message}`);
  }
}

// ------------------------------------------------------------------ OAuth state (موقّع، بدون تخزين)
async function hmacHex(key: string, msg: string) {
  const k = await crypto.subtle.importKey("raw", new TextEncoder().encode(key), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", k, new TextEncoder().encode(msg));
  return Array.from(new Uint8Array(sig)).map((b) => b.toString(16).padStart(2, "0")).join("");
}
async function stateSecret() { return String((await getSetting<string>("zid_client_secret")) ?? "") + "|msar-state"; }
async function makeState() {
  const p = `${Date.now().toString(36)}.${crypto.randomUUID().replace(/-/g, "").slice(0, 16)}`;
  return `${p}.${(await hmacHex(await stateSecret(), p)).slice(0, 32)}`;
}
async function checkState(st: string | null) {
  const parts = String(st ?? "").split(".");
  if (parts.length !== 3) return false;
  const p = `${parts[0]}.${parts[1]}`;
  if ((await hmacHex(await stateSecret(), p)).slice(0, 32) !== parts[2]) return false;
  const age = Date.now() - parseInt(parts[0], 36);
  return age >= 0 && age < 30 * 60 * 1000;
}

// ------------------------------------------------------------------ حذف التطبيق
async function markUninstalled(store: number, reason: string) {
  await db.from("stores").update({ status: "uninstalled", uninstalled_at: new Date().toISOString() }).eq("id", store);
  await saveSecrets(store, { zid_tokens: null, setup_token: null, setup_expires: null });
  await log(store, "uninstall", true, `تم إيقاف المتجر: ${reason}`);
}
const isSessionInvalid = (msg: string) => /ERROR_SESSION_INVALID|Zid 401/.test(msg);

// ------------------------------------------------------------------ الباقة من اشتراك زد (نتحقق من API زد، ما نثق بالحدث وحده)
function mapPlan(name: string): string | null {
  const n = String(name || "").toLowerCase();
  if (/pro|احتراف|unlimited|غير محدود|enterprise|مؤسس/.test(n)) return "pro";
  if (/grow|نمو|النمو/.test(n)) return "growth";
  if (/start|basic|أساس|اساس/.test(n)) return "starter";
  return null;
}
async function syncPlan(store: number) {
  const t = await getTokens(store);
  if (!t?.access_token) { await db.from("stores").update({ plan_checked_at: new Date().toISOString() }).eq("id", store); return null; }
  const r = await zid(`/market/app/subscription`, t);
  const sub = r?.subscription;
  const patch: Record<string, unknown> = { plan_checked_at: new Date().toISOString() };
  if (sub && !Array.isArray(sub)) {
    const st = String(sub.subscription_status ?? sub.status ?? "").toLowerCase();
    const plan = mapPlan(String(sub.plan_name ?? ""));
    patch.plan_status = st || null;
    patch.plan_ends_at = sub.end_date ? zidTime(sub.end_date) : null;
    if (plan) patch.plan = plan;
    const { data: cur } = await db.from("stores").select("status").eq("id", store).single();
    if (/expired|cancel|refund|suspend/.test(st) && cur?.status !== "uninstalled") patch.status = "suspended";
    else if (/active|trial|renew/.test(st) && cur?.status === "suspended") patch.status = "active";
    await log(store, "plan", true, `الاشتراك في زد: ${sub.plan_name ?? "?"} (${st || "?"}) → ${plan ?? "بدون تغيير"}`);
  }
  await db.from("stores").update(patch).eq("id", store);
  return patch;
}

// ------------------------------------------------------------------ normalize
const num = (v: unknown) => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
};
const round2 = (n: number | null) => (n === null ? null : Math.round(n * 100) / 100);
function normPhone(p?: string | null) {
  if (!p) return null;
  let s = String(p).replace(/[^\d+]/g, "");
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (/^05\d{8}$/.test(s)) s = "+966" + s.slice(1);
  if (/^5\d{8}$/.test(s)) s = "+966" + s;
  if (/^966\d{9}$/.test(s)) s = "+" + s;
  return s;
}
function zidTime(s?: string | null) {
  if (!s) return null;
  if (/[zZ]|[+\-]\d\d:?\d\d$/.test(s)) return new Date(s).toISOString();
  // زد يرجّع الوقت بتوقيت UTC بدون علامة المنطقة (تحقّقنا: طلب 501229523 = 10:43 UTC)
  const d = new Date(s.replace(" ", "T") + "Z");
  return isNaN(d.getTime()) ? null : d.toISOString();
}
function productImage(p: any): string | null {
  const im = p?.images?.[0] ?? p?.image;
  if (!im) return null;
  if (typeof im === "string") return im;
  return im?.image?.small ?? im?.image?.medium ?? im?.small ?? im?.thumbnail ?? im?.origin ?? im?.url ?? null;
}
function normalizeOrder(o: any) {
  const addr = o?.shipping?.address ?? o?.address ?? {};
  const pm = o?.payment?.method ?? o?.payment_method ?? {};
  const pmCode = String(pm?.code ?? "").toLowerCase();
  const pmName = String(pm?.name ?? "");
  const isCod = pmCode.includes("cod") || /الاستلام|cash/i.test(pmName);
  const items = (o?.products ?? []).map((p: any) => ({
    name: p?.name ?? p?.product?.name ?? "منتج",
    sku: p?.sku ?? null,
    quantity: num(p?.quantity) ?? 1,
    price: round2(num(p?.price)),
    total: round2(num(p?.total) ?? (num(p?.price) ?? 0) * (num(p?.quantity) ?? 1)),
    image: productImage(p),
    product_id: p?.id ?? p?.product_id ?? null,
    options: Array.isArray(p?.options) ? p.options.map((x: any) => `${x?.name ?? ""}: ${x?.value ?? ""}`).filter((s: string) => s.trim() !== ":") : [],
  }));
  const total = num(o?.order_total) ?? num(o?.transaction_amount) ?? items.reduce((a: number, b: any) => a + (b.total ?? 0), 0);
  const addressParts = [addr?.formatted_address, addr?.street, addr?.district, addr?.city?.name]
    .filter((x: any) => x && x !== "N/A" && String(x).length > 1);
  return {
    zid_order_id: o?.id,
    invoice_number: String(o?.invoice_number ?? o?.code ?? o?.id ?? ""),
    customer_name: o?.customer?.name ?? addr?.name ?? null,
    customer_phone: normPhone(o?.customer?.mobile ?? addr?.mobile ?? o?.customer?.phone),
    customer_email: o?.customer?.email ?? null,
    address_text: [...new Set(addressParts)].join("، ") || null,
    district: addr?.district ?? null,
    city: addr?.city?.name ?? (typeof addr?.city === "string" ? addr.city : null),
    short_address: addr?.short_address ?? null,
    lat: num(addr?.lat ?? addr?.latitude),
    lon: num(addr?.lng ?? addr?.lon ?? addr?.longitude),
    items,
    subtotal: round2(num(o?.products_sum_total) ?? items.reduce((a: number, x: any) => a + (x.total ?? 0), 0)),
    shipping_fee: round2(num(o?.shipping?.method?.cost ?? o?.shipping_cost)),
    total: round2(total),
    currency: o?.currency_code ?? "SAR",
    payment_method: pmName || null,
    payment_status: o?.payment_status ?? null,
    is_cod: isCod,
    shipping_method: o?.shipping?.method?.name ?? null,
    customer_note: o?.customer_note ?? o?.notes ?? o?.note ?? null,
    zid_status: String(o?.order_status?.code ?? o?.status ?? "new").toLowerCase(),
    order_created_at: zidTime(o?.created_at),
    raw: o,
  };
}

async function storeRow(store: number) {
  const { data } = await db.from("stores").select("*").eq("id", store).maybeSingle();
  return data;
}

async function upsertZidOrder(store: number, o: any, force = false) {
  const n = normalizeOrder(o);
  if (!n.zid_order_id) throw new Error("طلب بدون رقم");
  const s = await storeRow(store);
  const filter = s?.settings?.shipping_filter as string[] | undefined;
  if (!force && Array.isArray(filter) && filter.length && n.shipping_method && !filter.includes(n.shipping_method)) {
    const { data: ex } = await db.from("orders").select("id").eq("store_id", store).eq("zid_order_id", n.zid_order_id).maybeSingle();
    if (!ex) return { skipped: true, reason: "shipping_method" };
  }
  const { data, error } = await db.rpc("zid_upsert_order", { p_store: store, p: n, p_force: force });
  if (error) throw new Error(error.message);
  return data;
}

async function fetchOrder(t: Tokens, id: number | string) {
  const r = await zid(`/managers/store/orders/${id}/view`, t);
  return r?.order ?? r?.data ?? r;
}

async function syncRecent(store: number, pages = 1, perPage = 30) {
  const t = await getTokens(store);
  const st = await storeRow(store);
  const imp: string[] = st?.settings?.import_statuses ?? ["new", "preparing", "ready"];
  let added = 0, updated = 0, skipped = 0;
  for (let page = 1; page <= pages; page++) {
    const r = await zid(`/managers/store/orders?page=${page}&per_page=${perPage}&order_by=id&sort_by=desc`, t);
    const list: any[] = r?.orders ?? r?.data ?? [];
    if (!list.length) break;
    const ids = list.map((o) => o.id);
    const { data: existing } = await db.from("orders").select("zid_order_id, zid_status").eq("store_id", store).in("zid_order_id", ids);
    const ex = new Map((existing ?? []).map((e: any) => [Number(e.zid_order_id), e.zid_status]));
    for (const o of list) {
      const stt = String(o?.order_status?.code ?? o?.status ?? "").toLowerCase();
      try {
        if (ex.has(Number(o.id))) {
          if (ex.get(Number(o.id)) !== stt) { await upsertZidOrder(store, o); updated++; }
          continue;
        }
        if (!imp.includes(stt)) { skipped++; continue; }
        const needsDetail = !o?.products?.length || o?.shipping?.address?.lat === undefined;
        const full = needsDetail ? await fetchOrder(t!, o.id).catch(() => o) : o;
        const res: any = await upsertZidOrder(store, full);
        if (res?.skipped) skipped++; else added++;
      } catch (e) {
        await log(store, "sync", false, `طلب ${o?.id}: ${(e as Error).message}`);
      }
    }
    if (list.length < perPage) break;
  }
  return { added, updated, skipped };
}

// تنفيذ متوازي محدود العدد مع مهلة زمنية
async function pool<T>(items: T[], n: number, fn: (x: T) => Promise<void>, deadline = Infinity) {
  let i = 0;
  await Promise.all(Array.from({ length: Math.min(n, items.length) }, async () => {
    while (i < items.length) {
      if (Date.now() > deadline) return;
      const x = items[i++];
      try { await fn(x); } catch (_) { /* كل عنصر يسجل خطأه بنفسه */ }
    }
  }));
}

async function pushOutbox(deadline = Date.now() + 25000) {
  const { data: rows } = await db.from("zid_outbox").select("*").eq("done", false).eq("platform", "zid").lt("attempts", 5).order("id").limit(200);
  if (!rows?.length) return { pushed: 0 };
  let pushed = 0;
  const latest = new Map<string, any>();
  for (const r of rows) latest.set(`${r.store_id}:${r.zid_order_id}`, r);
  const superseded = rows.filter((r) => latest.get(`${r.store_id}:${r.zid_order_id}`)?.id !== r.id).map((r) => r.id);
  if (superseded.length) await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "تجاوزه تحديث أحدث" }).in("id", superseded);
  // نجمع حسب المتجر: كل متجر بالترتيب، والمتاجر بالتوازي
  const byStore = new Map<number, any[]>();
  for (const r of latest.values()) { if (!byStore.has(r.store_id)) byStore.set(r.store_id, []); byStore.get(r.store_id)!.push(r); }
  await pool([...byStore.entries()], 6, async ([storeId, list]) => {
    const t = await getTokens(storeId);
    const s = await storeRow(storeId);
    for (const r of list) {
      if (Date.now() > deadline) return;
      if (!t?.access_token || s?.settings?.push_status !== true) {
        await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "التحديث في زد موقوف لهذا المتجر" }).eq("id", r.id);
        continue;
      }
      // حجز السطر عشان ما ينرسل مرتين لو اشتغل push و cron بنفس الوقت
      const { data: claimed } = await db.from("zid_outbox").update({ attempts: r.attempts + 1 }).eq("id", r.id).eq("attempts", r.attempts).eq("done", false).select("id");
      if (!claimed?.length) continue;
      const body: Record<string, unknown> = { order_status: r.zid_status };
      if (r.zid_status === "ready" && s?.settings?.location_id) body.inventory_address_id = s.settings.location_id;
      try {
        await zid(`/managers/store/orders/${r.zid_order_id}/change-order-status`, t, { method: "POST", body: JSON.stringify(body) });
        await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: null }).eq("id", r.id);
        await db.from("orders").update({ zid_status: r.zid_status }).eq("id", r.order_id);
        pushed++;
      } catch (e) {
        const msg = (e as Error).message;
        await db.from("zid_outbox").update({ last_error: msg.slice(0, 500) }).eq("id", r.id);
        if (r.attempts + 1 >= 5) await db.from("order_events").insert({ order_id: r.order_id, type: "zid_push_error", note: `تعذر تحديث الحالة في زد: ${msg.slice(0, 200)}` });
        await log(r.store_id, "push", false, msg, { order: r.zid_order_id, status: r.zid_status });
        if (isSessionInvalid(msg)) { await markUninstalled(storeId, "انتهت صلاحية الربط (التطبيق محذوف من زد)"); return; }
      }
    }
  }, deadline);
  return { pushed };
}

// يبدأ التسجيل والمزامنة الأولية — يُستدعى فقط بعد اكتمال الإعداد (وجود مدير فعّال)
async function startSync(store: number) {
  try { await registerWebhooks(store); } catch (e) { await log(store, "webhook", false, (e as Error).message); }
  try { const r = await syncRecent(store, 1, 30); await log(store, "sync", true, `مزامنة أولية: ${JSON.stringify(r)}`); } catch (e) { await log(store, "sync", false, (e as Error).message); }
}

async function registerWebhooks(store: number) {
  const s = await storeRow(store);
  const t = await getTokens(store);
  const target = `${FN_URL}/wh/${store}/${s.webhook_key}`;
  const results: string[] = [];
  let existing: any[] = [];
  try { const r = await zid(`/managers/webhooks`, t); existing = r?.data ?? r?.webhooks ?? []; } catch (_) { /* ignore */ }
  for (const event of ["order.create", "order.status.update", "order.payment_status.update"]) {
    if (existing.some((w: any) => w?.event === event && String(w?.target_url ?? "") === target)) { results.push(`${event}: موجود`); continue; }
    const variants: Record<string, unknown>[] = [
      { event, target_url: target },
      { event, target_url: target, conditions: {} },
      { event, target_url: target, original_id: store, conditions: {} },
    ];
    const errs: string[] = [];
    let done = false;
    for (const body of variants) {
      try {
        await zid(`/managers/webhooks`, t, { method: "POST", body: JSON.stringify(body) });
        results.push(`${event}: تم`);
        done = true;
        break;
      } catch (e) {
        errs.push((e as Error).message.slice(0, 400));
      }
    }
    if (!done) results.push(`${event}: فشل — ${errs.join(" || ")}`);
  }
  const ok = results.every((r) => /: (تم|موجود)$/.test(r));
  await log(store, "webhooks", ok, `تسجيل Webhooks: ${results.join(" | ")}`.slice(0, 1000));
  return results;
}

async function caller(req: Request) {
  const auth = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!auth) return null;
  const { data } = await db.auth.getUser(auth);
  if (!data?.user) return null;
  const { data: p } = await db.from("profiles").select("id, role, store_id, is_active").eq("id", data.user.id).maybeSingle();
  return p?.is_active ? p : null;
}
async function requireStoreAdmin(req: Request): Promise<number | null> {
  const p = await caller(req);
  return p?.role === "admin" && p.store_id ? p.store_id : null;
}
async function checkCronKey(req: Request) {
  const key = await getSetting<string>("cron_key");
  return !!key && req.headers.get("x-cron-key") === key;
}

function slugCode(s: string) {
  return String(s ?? "").toLowerCase().replace(/^https?:\/\//, "").replace(/\.(zid\.store|com|sa|net|store)(\/.*)?$/, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 20);
}
async function uniqueCode(base: string, fallback: string) {
  let c = slugCode(base);
  if (c.length < 2) c = fallback;
  for (let i = 0; i < 50; i++) {
    const cand = i ? `${c}-${i + 1}` : c;
    const { data } = await db.from("stores").select("id").eq("code", cand).maybeSingle();
    if (!data) return cand;
  }
  return `${fallback}-${Date.now() % 100000}`;
}
const randomToken = () => Array.from(crypto.getRandomValues(new Uint8Array(24))).map((b) => b.toString(16).padStart(2, "0")).join("");

// ------------------------------------------------------------------ handler
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const url = new URL(req.url);
  const whPath = url.pathname.match(/\/wh\/(\d+)\/([a-f0-9]+)\/?$/);
  const action = whPath ? "webhook" : (url.searchParams.get("action") ?? "");
  const web = await webUrl();
  WEB_BASE = web && web !== "/" ? web : "";

  try {
    switch (action) {
      case "install": {
        const clientId = await getSetting<string>("zid_client_id");
        if (!clientId) return html("التطبيق غير جاهز بعد — تواصل مع فريق مسار", false);
        const q = new URLSearchParams({ client_id: String(clientId), redirect_uri: `${FN_URL}?action=callback`, response_type: "code", state: await makeState() });
        return Response.redirect(`${ZID_OAUTH}/oauth/authorize?${q}`, 302);
      }

      case "callback": {
        const code = url.searchParams.get("code");
        if (!code) return html("لم يصل رمز التفويض من زد", false);
        if (!(await checkState(url.searchParams.get("state")))) {
          await log(null, "oauth", false, "callback برمز state غير صالح أو منتهي — تم تجاهله");
          return html("انتهت صلاحية طلب الربط — افتح مسار من لوحة زد وفعّله من جديد", false);
        }
        const t = await tokenRequest({ grant_type: "authorization_code", code, redirect_uri: `${FN_URL}?action=callback` });
        let info: any = null;
        try { const prof = await zid(`/managers/account/profile`, t); info = prof?.user?.store ?? prof?.store ?? null; info = info ? { ...info, _user: prof?.user } : null; } catch (_) { /* ignore */ }
        if (!info?.id) return html("تعذر قراءة بيانات المتجر من زد", false);
        const zidId = Number(info.id);
        let { data: s } = await db.from("stores").select("*").eq("zid_store_id", zidId).maybeSingle();
        // نداء مكرر خلال دقيقتين لنفس المتجر؟ لا نعيد التسجيل والمزامنة
        const duplicate = !!s && s.status !== "uninstalled" && !!s.installed_at && Date.now() - Date.parse(s.installed_at) < 120000;
        if (!s) {
          const codeStr = await uniqueCode(info.url ?? info.username ?? info.title ?? "", `s${zidId}`);
          const ins = await db.from("stores").insert({
            code: codeStr, name: info.title ?? info.name ?? "متجر", zid_store_id: zidId, zid_store_uuid: info.uuid ?? null,
            store_url: info.url ?? null, logo_url: info.logo ?? null, owner_email: info._user?.email ?? info.email ?? null,
            owner_phone: info._user?.mobile ?? info.phone ?? null, installed_at: new Date().toISOString(),
            settings: { radius_km: 5, push_status: false, import_statuses: ["new", "preparing", "ready"] },
          }).select("*").single();
          if (ins.error) throw new Error(ins.error.message);
          s = ins.data;
        } else {
          await db.from("stores").update({ status: s.status === "uninstalled" ? "trial" : s.status, uninstalled_at: null, installed_at: new Date().toISOString(), store_url: info.url ?? s.store_url, logo_url: info.logo ?? s.logo_url }).eq("id", s.id);
        }
        await saveSecrets(s.id, { zid_tokens: t });
        try { await syncPlan(s.id); } catch (e) { await log(s.id, "plan", false, (e as Error).message); }
        if (!duplicate) await log(s.id, "oauth", true, `تم ربط المتجر ${s.name}`);
        const { count } = await db.from("store_members").select("id", { count: "exact", head: true }).eq("store_id", s.id).eq("role", "admin").eq("is_active", true);
        // سياسة زد: ما نبدأ المزامنة/تسجيل الـ Webhooks قبل اكتمال الإعداد — متجر جديد بدون مدير ينتظر صفحة الإعداد
        if ((count ?? 0) > 0 && !duplicate) await startSync(s.id);
        if ((count ?? 0) === 0) {
          // نعيد استخدام رابط الإعداد الساري بدل ما نبطله (زد أحياناً ينادي الـ callback أكثر من مرة)
          const { data: sec } = await db.from("store_secrets").select("setup_token, setup_expires").eq("store_id", s.id).maybeSingle();
          let tok = sec?.setup_token && sec.setup_expires && Date.parse(sec.setup_expires) > Date.now() ? sec.setup_token : null;
          if (!tok) {
            tok = randomToken();
            await saveSecrets(s.id, { setup_token: tok, setup_expires: new Date(Date.now() + 7 * 86400000).toISOString() });
          }
          return Response.redirect(`${web}setup?t=${tok}`, 302);
        }
        return html(`تم ربط متجر ${s.name} مع مسار 🎉`, true, `${web}?store=${s.code}`);
      }

      case "setup_info": {
        const tok = url.searchParams.get("t") ?? "";
        const { data: sec } = await db.from("store_secrets").select("store_id, setup_expires").eq("setup_token", tok).maybeSingle();
        if (!tok || !sec || Date.parse(sec.setup_expires) < Date.now()) return json({ ok: false, error: "رابط الإعداد غير صالح أو منتهي" }, 400);
        const s = await storeRow(sec.store_id);
        return json({ ok: true, store: { name: s.name, code: s.code, store_url: s.store_url, platform: s.platform ?? "zid" } });
      }
      case "setup": {
        // إنشاء/ربط مدير المتجر بالإيميل (حساب واحد للشخص حتى لو عنده أكثر من متجر)
        const b = await req.json().catch(() => ({}));
        const { data: sec } = await db.from("store_secrets").select("store_id, setup_expires").eq("setup_token", String(b.t ?? "")).maybeSingle();
        if (!b.t || !sec || Date.parse(sec.setup_expires) < Date.now()) return json({ ok: false, error: "رابط الإعداد غير صالح أو منتهي" }, 400);
        const s = await storeRow(sec.store_id);
        const fullName = String(b.full_name ?? "").trim();
        if (fullName.length < 2) return json({ ok: false, error: "اكتب اسمك" }, 400);
        const authHeader = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
        let userId: string | null = null, email = "";
        if (authHeader && authHeader.split(".").length === 3) {
          const { data } = await db.auth.getUser(authHeader);
          if (data?.user && !String(data.user.email ?? "").endsWith(`.${EMAIL_DOMAIN}`)) { userId = data.user.id; email = data.user.email!; }
        }
        if (!userId) {
          email = String(b.email ?? "").trim().toLowerCase();
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return json({ ok: false, error: "اكتب إيميل صحيح" }, 400);
          if (b.mode === "google") {
            // نجهّز الحساب بدون كلمة مرور عشان الدخول بقوقل يرتبط فيه (التسجيل العام يبقى مقفل)
            const { data: existing } = await db.rpc("user_id_by_email", { p_email: email });
            if (!existing) {
              const { error } = await db.auth.admin.createUser({ email, email_confirm: true, user_metadata: { full_name: fullName } });
              if (error) return json({ ok: false, error: error.message }, 400);
            }
            return json({ ok: true, prepared: true, email });
          }
          const { data: existing } = await db.rpc("user_id_by_email", { p_email: email });
          if (existing) return json({ ok: false, need_login: true, error: "عندك حساب في مسار بهذا الإيميل — سجّل دخول عشان نربط المتجر بحسابك" }, 400);
          if (!b.password || String(b.password).length < 8) return json({ ok: false, error: "كلمة المرور لازم تكون 8 أحرف أو أكثر" }, 400);
          const { data, error } = await db.auth.admin.createUser({
            email, password: String(b.password), email_confirm: true,
            user_metadata: { full_name: fullName, phone: b.phone ?? null },
          });
          if (error) return json({ ok: false, error: error.message }, 400);
          userId = data.user!.id;
        }
        await db.from("store_members").upsert({ store_id: s.id, user_id: userId, role: "admin", branch_id: null, username: null,
          full_name: fullName, phone: b.phone ?? null, is_active: true }, { onConflict: "store_id,user_id" });
        await db.from("profiles").upsert({ id: userId, store_id: s.id, username: email, role: "admin", full_name: fullName,
          phone: b.phone ?? null, branch_id: null, is_active: true, is_online: false }, { onConflict: "id" });
        await saveSecrets(s.id, { setup_token: null, setup_expires: null });
        if (b.store_name && String(b.store_name).trim().length > 1) await db.from("stores").update({ name: String(b.store_name).trim(), owner_email: email }).eq("id", s.id);
        await log(s.id, "setup", true, `تم ربط مدير المتجر ${email}`);
        await startSync(s.id);   // الإعداد اكتمل — الحين نسجّل الـ Webhooks ونسوي المزامنة الأولية
        return json({ ok: true, code: s.code, email });
      }

      case "webhook": {
        const store = Number(whPath?.[1] ?? url.searchParams.get("store"));
        const key = whPath?.[2] ?? url.searchParams.get("key");
        const s = store ? await storeRow(store) : null;
        if (!s || key !== s.webhook_key) return json({ error: "unauthorized" }, 401);
        if (!["trial", "active"].includes(s.status)) return json({ ok: true, ignored: "store " + s.status });
        const body = await req.json().catch(() => ({}));
        const o = body?.order ?? body?.data ?? body;
        const id = o?.id ?? o?.order_id;
        if (!id) return json({ ok: true, ping: true }); // طلب تحقق من زد
        let full = o;
        try { full = await fetchOrder((await getTokens(store))!, id); } catch (_) { /* نستخدم الـ payload */ }
        const r = await upsertZidOrder(store, full);
        await log(store, "webhook", true, `طلب ${id} (${full?.order_status?.code ?? ""})`, { result: r });
        return json({ ok: true, result: r });
      }

      case "app_event": {
        const b = await req.json().catch(() => ({}));
        const ev = String(b?.event_name ?? b?.event ?? b?.action ?? "");
        const zidStore = Number(b?.store_id ?? b?.envelope?.store_id ?? 0);
        let s: any = null;
        if (b?.store_uuid) s = (await db.from("stores").select("*").eq("zid_store_uuid", String(b.store_uuid)).maybeSingle()).data;
        if (!s && zidStore) s = (await db.from("stores").select("*").eq("zid_store_id", zidStore).maybeSingle()).data;
        await log(s?.id ?? null, "app_event", true, `${ev} (store ${zidStore || b?.store_uuid || "?"})`, b);
        if (s && /subscription/.test(ev)) {
          try { await syncPlan(s.id); } catch (e) { await log(s.id, "plan", false, (e as Error).message); }
        }
        if (s && ev === "app.market.application.uninstall") {
          // لا نثق بالحدث وحده: نتأكد من زد إن التوكن انسحب فعلاً
          const t = await getTokens(s.id);
          let revoked = !t?.access_token;
          if (!revoked) { try { await zid(`/managers/account/profile`, t); } catch (e) { revoked = isSessionInvalid((e as Error).message); } }
          if (revoked) await markUninstalled(s.id, "حذف التطبيق من زد");
          else await log(s.id, "app_event", false, "وصل حدث حذف لكن التوكن ما زال صالحاً — سيتم التحقق في المزامنة القادمة");
        }
        return json({ ok: true });
      }

      case "cron": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        const deadline = Date.now() + 45000;
        await setSetting("cron_last_run", new Date().toISOString());
        const push = await pushOutbox(Date.now() + 15000);
        // الـ Webhooks هي الأساس؛ المزامنة الدورية احتياط: كل متجر كل 15 دقيقة، دفعات محدودة كل دقيقة
        const cutoff = new Date(Date.now() - 15 * 60000).toISOString();
        const { data: due, error: dueErr } = await db.from("stores").select("id, code")
          .in("status", ["trial", "active"]).eq("platform", "zid").or(`last_synced_at.is.null,last_synced_at.lt."${cutoff}"`)
          .order("last_synced_at", { ascending: true, nullsFirst: true }).limit(60);
        if (dueErr) { await log(null, "cron", false, dueErr.message); return json({ ok: false, push, error: dueErr.message }); }
        const ids = (due ?? []).map((d: any) => d.id);
        const { data: secs } = ids.length ? await db.from("store_secrets").select("store_id").in("store_id", ids).not("zid_tokens", "is", null) : { data: [] as any[] };
        const has = new Set((secs ?? []).map((x: any) => x.store_id));
        // لا مزامنة دورية لمتجر ما أكمل الإعداد (ما عنده مدير فعّال)
        const { data: adm } = ids.length ? await db.from("store_members").select("store_id").in("store_id", ids).eq("role", "admin").eq("is_active", true) : { data: [] as any[] };
        const ready = new Set((adm ?? []).map((x: any) => x.store_id));
        const work = (due ?? []).filter((d: any) => has.has(d.id) && ready.has(d.id));
        if (work.length) await db.from("stores").update({ last_synced_at: new Date().toISOString() }).in("id", work.map((w: any) => w.id));
        let synced = 0;
        await pool(work, 8, async (s: any) => {
          try {
            const r = await syncRecent(s.id, 1, 20);
            synced++;
            if (r.added || r.updated) await log(s.id, "sync", true, `مزامنة دورية: ${JSON.stringify(r)}`);
          } catch (e) {
            const m = (e as Error).message;
            if (isSessionInvalid(m)) await markUninstalled(s.id, "انتهت صلاحية الربط (التطبيق محذوف من زد)");
            else await log(s.id, "sync", false, m);
          }
          await refreshIfNeeded(s.id);
        }, deadline);
        // تحقق دوري من الاشتراك (مرة كل 12 ساعة لكل متجر، دفعات صغيرة)
        const pcut = new Date(Date.now() - 12 * 3600000).toISOString();
        const { data: pdue } = await db.from("stores").select("id").eq("platform", "zid").in("status", ["trial", "active", "suspended"])
          .or(`plan_checked_at.is.null,plan_checked_at.lt."${pcut}"`).limit(15);
        await pool(pdue ?? [], 5, async (d: any) => {
          try { await syncPlan(d.id); } catch (e) { const m = (e as Error).message; await db.from("stores").update({ plan_checked_at: new Date().toISOString() }).eq("id", d.id); if (!isSessionInvalid(m)) await log(d.id, "plan", false, m); }
        }, deadline);
        return json({ ok: true, push, due: work.length, synced });
      }
      case "health": {
        const last = await getSetting<string>("cron_last_run");
        const age = last ? Math.round((Date.now() - Date.parse(String(last))) / 1000) : null;
        const { count: stuck } = await db.from("zid_outbox").select("id", { count: "exact", head: true })
          .eq("done", false).lt("created_at", new Date(Date.now() - 10 * 60000).toISOString());
        const ok = age !== null && age < 300 && (stuck ?? 0) < 50;
        return json({ ok, cron_age_s: age, outbox_stuck: stuck ?? 0 }, ok ? 200 : 503);
      }
      case "push": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        return json({ ok: true, ...(await pushOutbox()) });
      }

      case "resolve_map": {
        // فك روابط قوقل ماب القصيرة (maps.app.goo.gl) واستخراج الإحداثيات — للمستخدمين المسجلين فقط
        if (!(await caller(req))) return json({ error: "غير مصرح" }, 401);
        const b = await req.json().catch(() => ({}));
        let cur: URL;
        try { cur = new URL(String(b.url ?? "").trim()); } catch { return json({ error: "رابط غير صالح" }, 400); }
        const okHost = (h: string) => /^(maps\.app\.goo\.gl|goo\.gl|consent\.google\.[a-z.]+|(www\.)?google\.[a-z.]+|maps\.google\.[a-z.]+)$/i.test(h);
        const extract = (s: string) => {
          let t = s; try { t = decodeURIComponent(s); } catch { /* */ }
          const pats = [/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/, /@(-?\d+\.\d+),(-?\d+\.\d+)/, /[?&](?:q|ll|query|destination|center)=\+?(-?\d+\.\d+),\s*\+?(-?\d+\.\d+)/,
            /\[null,null,(-?\d+\.\d+),(-?\d+\.\d+)\]/, /center=(-?\d+\.\d+)(?:%2C|,)(-?\d+\.\d+)/];
          for (const p of pats) {
            const m = t.match(p);
            if (m) { const lat = parseFloat(m[1]), lon = parseFloat(m[2]); if (Math.abs(lat) <= 90 && Math.abs(lon) <= 180) return { lat, lon }; }
          }
          return null;
        };
        let dbg = "";
        for (let i = 0; i < 8; i++) {
          if (!okHost(cur.hostname)) return json({ error: "الرابط ليس من قوقل ماب (" + cur.hostname + ")" }, 400);
          const c = extract(cur.href);
          if (c) return json({ ok: true, ...c });
          if (/^consent\./i.test(cur.hostname)) {
            const cont = cur.searchParams.get("continue");
            if (cont) { try { cur = new URL(cont); continue; } catch { /* */ } }
          }
          const r = await fetch(cur.href, { redirect: "manual", headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36", "Accept-Language": "ar,en;q=0.8", "Cookie": "CONSENT=YES+1; SOCS=CAI" } });
          dbg += cur.hostname + ":" + r.status + " ";
          const loc = r.headers.get("location");
          if (loc) { cur = new URL(loc, cur); continue; }
          const html = await r.text();
          const c2 = extract(html);
          if (c2) return json({ ok: true, ...c2 });
          break;
        }
        return json({ error: "ما قدرت أستخرج الإحداثيات من الرابط", debug: dbg.trim() }, 422);
      }
      case "sync": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const r = await syncRecent(store, Math.min(Number(url.searchParams.get("pages") ?? 2), 5), 50);
        await log(store, "sync", true, `مزامنة يدوية: ${JSON.stringify(r)}`);
        return json({ ok: true, ...r });
      }
      case "import": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const id = url.searchParams.get("id");
        if (!id) return json({ error: "رقم الطلب مطلوب" }, 400);
        const r = await upsertZidOrder(store, await fetchOrder((await getTokens(store))!, id), true);
        return json({ ok: true, result: r });
      }
      case "webhooks": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        return json({ ok: true, results: await registerWebhooks(store) });
      }
      case "status": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const t = await getTokens(store);
        if (!t?.access_token) return json({ connected: false });
        try {
          const r = await zid(`/managers/store/orders?page=1&per_page=1`, t);
          return json({ connected: true, ok: true, total_orders: r?.total_order_count ?? null, expires_at: t.expires_at });
        } catch (e) {
          return json({ connected: true, ok: false, error: (e as Error).message });
        }
      }
      default:
        return json({ ok: true, service: "msar-zid" });
    }
  } catch (e) {
    const msg = (e as Error).message;
    await log(null, action || "error", false, msg);
    if (action === "callback" || action === "install") return html(msg, false);
    return json({ ok: false, error: msg }, 500);
  }
});
