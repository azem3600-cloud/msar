// =====================================================================
//  مسار (MSAR) — الربط مع زد لكل المتاجر (Supabase Edge Function: zid)
//  install  : بداية تثبيت التطبيق من سوق زد (OAuth)
//  callback : استلام التوكن → إنشاء/تحديث المتجر → Webhooks → مزامنة → صفحة الإعداد
//  webhook  : الطلبات الجديدة وتحديثات الحالة لحظياً (?store=ID&key=...)
//  setup    : إنشاء حساب مدير المتجر لأول مرة (برمز الإعداد)
//  cron/push: مزامنة احتياطية + إرسال الحالات لزد + تجديد التوكنات
//  sync/import/webhooks/status : لمدير المتجر من لوحة التحكم
//  ملاحظة: انشر هذه الدالة مع إيقاف "Verify JWT"
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";

const SB_URL = Deno.env.get("SUPABASE_URL")!;
const SB_SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const db = createClient(SB_URL, SB_SERVICE, { auth: { persistSession: false, autoRefreshToken: false } });

const ZID_API = "https://api.zid.sa/v1";
const ZID_OAUTH = "https://oauth.zid.sa";
const FN_URL = `${SB_URL}/functions/v1/zid`;
const EMAIL_DOMAIN = "msar.app";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
};
const json = (b: unknown, status = 200) =>
  new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });
const esc = (s: string) => String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
const html = (msg: string, ok = true, redirect?: string) =>
  new Response(
    `<!doctype html><html dir="rtl" lang="ar"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>مسار</title><body style="font-family:system-ui,Tahoma;background:#f3f5f4;display:grid;place-items:center;min-height:100vh;margin:0">
<div style="background:#fff;padding:32px;border-radius:16px;max-width:460px;text-align:center;box-shadow:0 4px 24px #0001">
<div style="font-size:46px">${ok ? "✅" : "⚠️"}</div><h2 style="font-size:20px">${esc(msg)}</h2>
${redirect ? `<p><a href="${esc(redirect)}" style="color:#0f766e;font-weight:700">متابعة</a></p><script>setTimeout(()=>location.href=${JSON.stringify(redirect)},1800)</script>` : ""}
</div></body></html>`,
    { status: ok ? 200 : 400, headers: { "Content-Type": "text/html; charset=utf-8" } },
  );

// ------------------------------------------------------------------ helpers
async function getSetting<T = any>(key: string): Promise<T | null> {
  const { data } = await db.from("app_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value ?? null) as T | null;
}
async function setSetting(key: string, value: unknown) {
  await db.from("app_settings").upsert({ key, value, updated_at: new Date().toISOString() });
}
async function log(store: number | null, kind: string, ok: boolean, message: string, payload?: unknown) {
  try { await db.from("zid_log").insert({ store_id: store, kind, ok, message: message?.slice(0, 1000), payload: payload ?? null }); } catch (_) { /* ignore */ }
}
const webUrl = async () => String((await getSetting<string>("web_url")) ?? "").replace(/\/?$/, "/");

type Tokens = { access_token: string; authorization: string; refresh_token: string; expires_at?: string; obtained_at?: string };
async function getTokens(store: number): Promise<Tokens | null> {
  const { data } = await db.from("store_secrets").select("zid_tokens").eq("store_id", store).maybeSingle();
  return (data?.zid_tokens ?? null) as Tokens | null;
}
async function saveSecrets(store: number, patch: Record<string, unknown>) {
  await db.from("store_secrets").upsert({ store_id: store, ...patch, updated_at: new Date().toISOString() });
}

async function zid(path: string, t: Tokens | null, init: RequestInit = {}): Promise<any> {
  if (!t?.access_token) throw new Error("المتجر غير مربوط بزد");
  const res = await fetch(`${ZID_API}${path}`, {
    ...init,
    headers: {
      "Authorization": `Bearer ${t.authorization}`,
      "X-Manager-Token": t.access_token,
      "Accept": "application/json",
      "Accept-Language": "ar",
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  const text = await res.text();
  let body: any; try { body = JSON.parse(text); } catch { body = text; }
  if (!res.ok) throw new Error(`Zid ${res.status} ${path}: ${typeof body === "string" ? body.slice(0, 300) : JSON.stringify(body).slice(0, 300)}`);
  return body;
}

async function tokenRequest(params: Record<string, string>): Promise<Tokens> {
  const clientId = await getSetting<string>("zid_client_id");
  const clientSecret = await getSetting<string>("zid_client_secret");
  if (!clientId || !clientSecret) throw new Error("مفاتيح تطبيق زد غير مُدخلة في لوحة صاحب المنصة");
  const form = new URLSearchParams({ client_id: String(clientId), client_secret: String(clientSecret), ...params });
  const res = await fetch(`${ZID_OAUTH}/oauth/token`, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json" },
    body: form,
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok || !body.access_token) throw new Error(`فشل الحصول على التوكن من زد (${res.status}): ${JSON.stringify(body).slice(0, 300)}`);
  const now = Date.now();
  return {
    access_token: body.access_token,
    authorization: body.authorization,
    refresh_token: body.refresh_token,
    expires_at: new Date(now + (Number(body.expires_in) || 31536000) * 1000).toISOString(),
    obtained_at: new Date(now).toISOString(),
  };
}

async function refreshIfNeeded(store: number) {
  const t = await getTokens(store);
  if (!t?.refresh_token || !t.obtained_at) return;
  if ((Date.now() - Date.parse(t.obtained_at)) / 86400000 < 300) return;
  try {
    const nt = await tokenRequest({ grant_type: "refresh_token", refresh_token: t.refresh_token, redirect_uri: `${FN_URL}?action=callback` });
    await saveSecrets(store, { zid_tokens: { ...t, ...nt } });
    await log(store, "oauth", true, "تم تجديد توكن زد");
  } catch (e) {
    await log(store, "oauth", false, `فشل تجديد التوكن: ${(e as Error).message}`);
  }
}

// ------------------------------------------------------------------ normalize
const num = (v: unknown) => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/[^\d.\-]/g, ""));
  return Number.isFinite(n) ? n : null;
};
const round2 = (n: number | null) => (n === null ? null : Math.round(n * 100) / 100);
function normPhone(p?: string | null) {
  if (!p) return null;
  let s = String(p).replace(/[^\d+]/g, "");
  if (s.startsWith("00")) s = "+" + s.slice(2);
  if (/^05\d{8}$/.test(s)) s = "+966" + s.slice(1);
  if (/^5\d{8}$/.test(s)) s = "+966" + s;
  if (/^966\d{9}$/.test(s)) s = "+" + s;
  return s;
}
function zidTime(s?: string | null) {
  if (!s) return null;
  if (/[zZ]|[+\-]\d\d:?\d\d$/.test(s)) return new Date(s).toISOString();
  const d = new Date(s.replace(" ", "T") + "+03:00");
  return isNaN(d.getTime()) ? null : d.toISOString();
}
function productImage(p: any): string | null {
  const im = p?.images?.[0] ?? p?.image;
  if (!im) return null;
  if (typeof im === "string") return im;
  return im?.image?.small ?? im?.image?.medium ?? im?.small ?? im?.thumbnail ?? im?.origin ?? im?.url ?? null;
}
function normalizeOrder(o: any) {
  const addr = o?.shipping?.address ?? o?.address ?? {};
  const pm = o?.payment?.method ?? o?.payment_method ?? {};
  const pmCode = String(pm?.code ?? "").toLowerCase();
  const pmName = String(pm?.name ?? "");
  const isCod = pmCode.includes("cod") || /الاستلام|cash/i.test(pmName);
  const items = (o?.products ?? []).map((p: any) => ({
    name: p?.name ?? p?.product?.name ?? "منتج",
    sku: p?.sku ?? null,
    quantity: num(p?.quantity) ?? 1,
    price: round2(num(p?.price)),
    total: round2(num(p?.total) ?? (num(p?.price) ?? 0) * (num(p?.quantity) ?? 1)),
    image: productImage(p),
    product_id: p?.id ?? p?.product_id ?? null,
    options: Array.isArray(p?.options) ? p.options.map((x: any) => `${x?.name ?? ""}: ${x?.value ?? ""}`).filter((s: string) => s.trim() !== ":") : [],
  }));
  const total = num(o?.order_total) ?? num(o?.transaction_amount) ?? items.reduce((a: number, b: any) => a + (b.total ?? 0), 0);
  const addressParts = [addr?.formatted_address, addr?.street, addr?.district, addr?.city?.name]
    .filter((x: any) => x && x !== "N/A" && String(x).length > 1);
  return {
    zid_order_id: o?.id,
    invoice_number: String(o?.invoice_number ?? o?.code ?? o?.id ?? ""),
    customer_name: o?.customer?.name ?? addr?.name ?? null,
    customer_phone: normPhone(o?.customer?.mobile ?? addr?.mobile ?? o?.customer?.phone),
    customer_email: o?.customer?.email ?? null,
    address_text: [...new Set(addressParts)].join("، ") || null,
    district: addr?.district ?? null,
    city: addr?.city?.name ?? (typeof addr?.city === "string" ? addr.city : null),
    short_address: addr?.short_address ?? null,
    lat: num(addr?.lat ?? addr?.latitude),
    lon: num(addr?.lng ?? addr?.lon ?? addr?.longitude),
    items,
    subtotal: round2(num(o?.products_sum_total)),
    shipping_fee: round2(num(o?.shipping?.method?.cost ?? o?.shipping_cost)),
    total: round2(total),
    currency: o?.currency_code ?? "SAR",
    payment_method: pmName || null,
    payment_status: o?.payment_status ?? null,
    is_cod: isCod,
    shipping_method: o?.shipping?.method?.name ?? null,
    customer_note: o?.customer_note ?? o?.notes ?? o?.note ?? null,
    zid_status: String(o?.order_status?.code ?? o?.status ?? "new").toLowerCase(),
    order_created_at: zidTime(o?.created_at),
    raw: o,
  };
}

async function storeRow(store: number) {
  const { data } = await db.from("stores").select("*").eq("id", store).maybeSingle();
  return data;
}

async function upsertZidOrder(store: number, o: any, force = false) {
  const n = normalizeOrder(o);
  if (!n.zid_order_id) throw new Error("طلب بدون رقم");
  const s = await storeRow(store);
  const filter = s?.settings?.shipping_filter as string[] | undefined;
  if (!force && Array.isArray(filter) && filter.length && n.shipping_method && !filter.includes(n.shipping_method)) {
    const { data: ex } = await db.from("orders").select("id").eq("store_id", store).eq("zid_order_id", n.zid_order_id).maybeSingle();
    if (!ex) return { skipped: true, reason: "shipping_method" };
  }
  const { data, error } = await db.rpc("zid_upsert_order", { p_store: store, p: n, p_force: force });
  if (error) throw new Error(error.message);
  return data;
}

async function fetchOrder(t: Tokens, id: number | string) {
  const r = await zid(`/managers/store/orders/${id}/view`, t);
  return r?.order ?? r?.data ?? r;
}

async function syncRecent(store: number, pages = 1, perPage = 30) {
  const t = await getTokens(store);
  let added = 0, updated = 0, skipped = 0;
  for (let page = 1; page <= pages; page++) {
    const r = await zid(`/managers/store/orders?page=${page}&per_page=${perPage}&order_by=id&sort_by=desc`, t);
    const list: any[] = r?.orders ?? r?.data ?? [];
    if (!list.length) break;
    const ids = list.map((o) => o.id);
    const { data: existing } = await db.from("orders").select("zid_order_id, zid_status").eq("store_id", store).in("zid_order_id", ids);
    const ex = new Map((existing ?? []).map((e: any) => [Number(e.zid_order_id), e.zid_status]));
    for (const o of list) {
      const st = String(o?.order_status?.code ?? o?.status ?? "").toLowerCase();
      try {
        if (ex.has(Number(o.id))) {
          if (ex.get(Number(o.id)) !== st) { await upsertZidOrder(store, o); updated++; }
          continue;
        }
        const s = await storeRow(store);
        const imp: string[] = s?.settings?.import_statuses ?? ["new", "preparing", "ready"];
        if (!imp.includes(st)) { skipped++; continue; }
        const needsDetail = !o?.products?.length || o?.shipping?.address?.lat === undefined;
        const full = needsDetail ? await fetchOrder(t!, o.id).catch(() => o) : o;
        const res: any = await upsertZidOrder(store, full);
        if (res?.skipped) skipped++; else added++;
      } catch (e) {
        await log(store, "sync", false, `طلب ${o?.id}: ${(e as Error).message}`);
      }
    }
    if (list.length < perPage) break;
  }
  return { added, updated, skipped };
}

async function pushOutbox() {
  const { data: rows } = await db.from("zid_outbox").select("*").eq("done", false).lt("attempts", 5).order("id").limit(50);
  if (!rows?.length) return { pushed: 0 };
  let pushed = 0;
  const latest = new Map<string, any>();
  for (const r of rows) latest.set(`${r.store_id}:${r.zid_order_id}`, r);
  for (const r of rows) {
    if (latest.get(`${r.store_id}:${r.zid_order_id}`)?.id !== r.id) {
      await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "تجاوزه تحديث أحدث" }).eq("id", r.id);
    }
  }
  const tokCache = new Map<number, Tokens | null>();
  for (const r of latest.values()) {
    if (!tokCache.has(r.store_id)) tokCache.set(r.store_id, await getTokens(r.store_id));
    const t = tokCache.get(r.store_id);
    const s = await storeRow(r.store_id);
    if (!t?.access_token || s?.settings?.push_status !== true) {
      await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), last_error: "التحديث في زد موقوف لهذا المتجر" }).eq("id", r.id);
      continue;
    }
    const body: Record<string, unknown> = { order_status: r.zid_status };
    if (r.zid_status === "ready" && s?.settings?.location_id) body.inventory_address_id = s.settings.location_id;
    try {
      await zid(`/managers/store/orders/${r.zid_order_id}/change-order-status`, t, { method: "POST", body: JSON.stringify(body) });
      await db.from("zid_outbox").update({ done: true, processed_at: new Date().toISOString(), attempts: r.attempts + 1, last_error: null }).eq("id", r.id);
      await db.from("orders").update({ zid_status: r.zid_status }).eq("id", r.order_id);
      pushed++;
    } catch (e) {
      const msg = (e as Error).message;
      await db.from("zid_outbox").update({ attempts: r.attempts + 1, last_error: msg.slice(0, 500) }).eq("id", r.id);
      if (r.attempts + 1 >= 5) await db.from("order_events").insert({ order_id: r.order_id, type: "zid_push_error", note: `تعذر تحديث الحالة في زد: ${msg.slice(0, 200)}` });
      await log(r.store_id, "push", false, msg, { order: r.zid_order_id, status: r.zid_status });
    }
  }
  return { pushed };
}

async function registerWebhooks(store: number) {
  const s = await storeRow(store);
  const t = await getTokens(store);
  const target = `${FN_URL}?action=webhook&store=${store}&key=${s.webhook_key}`;
  const results: string[] = [];
  let existing: any[] = [];
  try { const r = await zid(`/managers/webhooks`, t); existing = r?.data ?? r?.webhooks ?? []; } catch (_) { /* ignore */ }
  for (const event of ["order.create", "order.status.update", "order.payment_status.update"]) {
    if (existing.some((w: any) => w?.event === event && String(w?.target_url ?? "") === target)) { results.push(`${event}: موجود`); continue; }
    try {
      await zid(`/managers/webhooks`, t, { method: "POST", body: JSON.stringify({ event, target_url: target, conditions: {} }) });
      results.push(`${event}: تم`);
    } catch (e) {
      results.push(`${event}: ${(e as Error).message.slice(0, 120)}`);
    }
  }
  await log(store, "oauth", true, `تسجيل Webhooks: ${results.join(" | ")}`);
  return results;
}

async function caller(req: Request) {
  const auth = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!auth) return null;
  const { data } = await db.auth.getUser(auth);
  if (!data?.user) return null;
  const { data: p } = await db.from("profiles").select("id, role, store_id, is_active").eq("id", data.user.id).maybeSingle();
  return p?.is_active ? p : null;
}
async function requireStoreAdmin(req: Request): Promise<number | null> {
  const p = await caller(req);
  return p?.role === "admin" && p.store_id ? p.store_id : null;
}
async function checkCronKey(req: Request) {
  const key = await getSetting<string>("cron_key");
  return !!key && req.headers.get("x-cron-key") === key;
}

function slugCode(s: string) {
  return String(s ?? "").toLowerCase().replace(/^https?:\/\//, "").replace(/\.(zid\.store|com|sa|net|store)(\/.*)?$/, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 20);
}
async function uniqueCode(base: string, fallback: string) {
  let c = slugCode(base);
  if (c.length < 2) c = fallback;
  for (let i = 0; i < 50; i++) {
    const cand = i ? `${c}-${i + 1}` : c;
    const { data } = await db.from("stores").select("id").eq("code", cand).maybeSingle();
    if (!data) return cand;
  }
  return `${fallback}-${Date.now() % 100000}`;
}
const randomToken = () => Array.from(crypto.getRandomValues(new Uint8Array(24))).map((b) => b.toString(16).padStart(2, "0")).join("");

// ------------------------------------------------------------------ handler
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "";
  const web = await webUrl();

  try {
    switch (action) {
      case "install": {
        const clientId = await getSetting<string>("zid_client_id");
        if (!clientId) return html("التطبيق غير جاهز بعد — تواصل مع فريق مسار", false);
        const q = new URLSearchParams({ client_id: String(clientId), redirect_uri: `${FN_URL}?action=callback`, response_type: "code" });
        return Response.redirect(`${ZID_OAUTH}/oauth/authorize?${q}`, 302);
      }

      case "callback": {
        const code = url.searchParams.get("code");
        if (!code) return html("لم يصل رمز التفويض من زد", false);
        const t = await tokenRequest({ grant_type: "authorization_code", code, redirect_uri: `${FN_URL}?action=callback` });
        let info: any = null;
        try { const prof = await zid(`/managers/account/profile`, t); info = prof?.user?.store ?? prof?.store ?? null; info = info ? { ...info, _user: prof?.user } : null; } catch (_) { /* ignore */ }
        if (!info?.id) return html("تعذر قراءة بيانات المتجر من زد", false);
        const zidId = Number(info.id);
        let { data: s } = await db.from("stores").select("*").eq("zid_store_id", zidId).maybeSingle();
        if (!s) {
          const codeStr = await uniqueCode(info.url ?? info.username ?? info.title ?? "", `s${zidId}`);
          const ins = await db.from("stores").insert({
            code: codeStr, name: info.title ?? info.name ?? "متجر", zid_store_id: zidId, zid_store_uuid: info.uuid ?? null,
            store_url: info.url ?? null, logo_url: info.logo ?? null, owner_email: info._user?.email ?? info.email ?? null,
            owner_phone: info._user?.mobile ?? info.phone ?? null, installed_at: new Date().toISOString(),
            settings: { radius_km: 5, push_status: false, import_statuses: ["new", "preparing", "ready"] },
          }).select("*").single();
          if (ins.error) throw new Error(ins.error.message);
          s = ins.data;
        } else {
          await db.from("stores").update({ status: s.status === "uninstalled" ? "trial" : s.status, installed_at: new Date().toISOString(), store_url: info.url ?? s.store_url, logo_url: info.logo ?? s.logo_url }).eq("id", s.id);
        }
        await saveSecrets(s.id, { zid_tokens: t });
        await log(s.id, "oauth", true, `تم ربط المتجر ${s.name}`);
        await registerWebhooks(s.id);
        try { const r = await syncRecent(s.id, 1, 30); await log(s.id, "sync", true, `مزامنة أولية: ${JSON.stringify(r)}`); } catch (e) { await log(s.id, "sync", false, (e as Error).message); }
        const { count } = await db.from("profiles").select("id", { count: "exact", head: true }).eq("store_id", s.id).eq("role", "admin");
        if ((count ?? 0) === 0) {
          const tok = randomToken();
          await saveSecrets(s.id, { setup_token: tok, setup_expires: new Date(Date.now() + 7 * 86400000).toISOString() });
          return Response.redirect(`${web}setup.html?t=${tok}`, 302);
        }
        return html(`تم ربط متجر ${s.name} مع مسار 🎉`, true, `${web}?store=${s.code}`);
      }

      case "setup_info": {
        const tok = url.searchParams.get("t") ?? "";
        const { data: sec } = await db.from("store_secrets").select("store_id, setup_expires").eq("setup_token", tok).maybeSingle();
        if (!tok || !sec || Date.parse(sec.setup_expires) < Date.now()) return json({ ok: false, error: "رابط الإعداد غير صالح أو منتهي" }, 400);
        const s = await storeRow(sec.store_id);
        return json({ ok: true, store: { name: s.name, code: s.code, store_url: s.store_url } });
      }
      case "setup": {
        const b = await req.json().catch(() => ({}));
        const { data: sec } = await db.from("store_secrets").select("store_id, setup_expires").eq("setup_token", String(b.t ?? "")).maybeSingle();
        if (!b.t || !sec || Date.parse(sec.setup_expires) < Date.now()) return json({ ok: false, error: "رابط الإعداد غير صالح أو منتهي" }, 400);
        const s = await storeRow(sec.store_id);
        const username = String(b.username ?? "").trim().toLowerCase();
        if (!/^[a-z0-9._-]{3,32}$/.test(username)) return json({ ok: false, error: "اسم المستخدم لازم يكون إنجليزي (حروف/أرقام) من 3 إلى 32 حرف" }, 400);
        if (!b.password || String(b.password).length < 8) return json({ ok: false, error: "كلمة المرور لازم تكون 8 أحرف أو أكثر" }, 400);
        const { data, error } = await db.auth.admin.createUser({
          email: `${username}@${s.code}.${EMAIL_DOMAIN}`, password: String(b.password), email_confirm: true,
          app_metadata: { role: "admin", store_id: String(s.id) },
          user_metadata: { username, full_name: String(b.full_name ?? username).trim(), phone: b.phone ?? null },
        });
        if (error) return json({ ok: false, error: /already/i.test(error.message) ? "اسم المستخدم مستخدم من قبل" : error.message }, 400);
        await db.from("profiles").upsert({ id: data.user!.id, store_id: s.id, username, role: "admin", full_name: String(b.full_name ?? username).trim(), phone: b.phone ?? null }, { onConflict: "id" });
        await saveSecrets(s.id, { setup_token: null, setup_expires: null });
        if (b.store_name && String(b.store_name).trim().length > 1) await db.from("stores").update({ name: String(b.store_name).trim() }).eq("id", s.id);
        await log(s.id, "setup", true, `تم إنشاء حساب المدير ${username}`);
        return json({ ok: true, code: s.code, email: `${username}@${s.code}.${EMAIL_DOMAIN}` });
      }

      case "webhook": {
        const store = Number(url.searchParams.get("store"));
        const s = store ? await storeRow(store) : null;
        if (!s || url.searchParams.get("key") !== s.webhook_key) return json({ error: "unauthorized" }, 401);
        if (!["trial", "active"].includes(s.status)) return json({ ok: true, ignored: "store " + s.status });
        const body = await req.json().catch(() => ({}));
        const o = body?.order ?? body?.data ?? body;
        const id = o?.id ?? o?.order_id;
        if (!id) { await log(store, "webhook", false, "payload بدون رقم طلب", body); return json({ ok: true }); }
        let full = o;
        try { full = await fetchOrder((await getTokens(store))!, id); } catch (_) { /* نستخدم الـ payload */ }
        const r = await upsertZidOrder(store, full);
        await log(store, "webhook", true, `طلب ${id} (${full?.order_status?.code ?? ""})`, { result: r });
        return json({ ok: true, result: r });
      }

      case "cron": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        const push = await pushOutbox();
        const { data: secs } = await db.from("store_secrets").select("store_id, zid_tokens").not("zid_tokens", "is", null);
        const minute = new Date().getMinutes();
        const res: Record<string, unknown> = {};
        for (const sec of secs ?? []) {
          const s = await storeRow(sec.store_id);
          if (!s || !["trial", "active"].includes(s.status)) continue;
          if (minute % 5 === s.id % 5) {
            try { const r = await syncRecent(s.id, 1, 20); res[s.code] = r; if (r.added || r.updated) await log(s.id, "sync", true, `مزامنة دورية: ${JSON.stringify(r)}`); }
            catch (e) { await log(s.id, "sync", false, (e as Error).message); }
          }
          if (minute === 7) await refreshIfNeeded(s.id);
        }
        return json({ ok: true, push, sync: res });
      }
      case "push": {
        if (!(await checkCronKey(req))) return json({ error: "unauthorized" }, 401);
        return json({ ok: true, ...(await pushOutbox()) });
      }

      case "sync": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const r = await syncRecent(store, Math.min(Number(url.searchParams.get("pages") ?? 2), 5), 50);
        await log(store, "sync", true, `مزامنة يدوية: ${JSON.stringify(r)}`);
        return json({ ok: true, ...r });
      }
      case "import": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const id = url.searchParams.get("id");
        if (!id) return json({ error: "رقم الطلب مطلوب" }, 400);
        const r = await upsertZidOrder(store, await fetchOrder((await getTokens(store))!, id), true);
        return json({ ok: true, result: r });
      }
      case "webhooks": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        return json({ ok: true, results: await registerWebhooks(store) });
      }
      case "status": {
        const store = await requireStoreAdmin(req);
        if (!store) return json({ error: "غير مصرح" }, 401);
        const t = await getTokens(store);
        if (!t?.access_token) return json({ connected: false });
        try {
          const r = await zid(`/managers/store/orders?page=1&per_page=1`, t);
          return json({ connected: true, ok: true, total_orders: r?.total_order_count ?? null, expires_at: t.expires_at });
        } catch (e) {
          return json({ connected: true, ok: false, error: (e as Error).message });
        }
      }
      default:
        return json({ ok: true, service: "msar-zid" });
    }
  } catch (e) {
    const msg = (e as Error).message;
    await log(null, action || "error", false, msg);
    if (action === "callback" || action === "install") return html(msg, false);
    return json({ ok: false, error: msg }, 500);
  }
});
