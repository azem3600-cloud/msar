-- 015: هوية المتجر لصفحة تتبع الطلب (شعار + ألوان + رسالة). آمنة للتشغيل أكثر من مرة.
create table if not exists public.store_brand (
  store_id int primary key references public.stores(id) on delete cascade,
  logo_data text,
  color_primary text,
  color_accent text,
  display_name text,
  tagline text,
  hero_style text not null default 'solid',
  show_powered boolean not null default true,
  updated_at timestamptz not null default now(),
  constraint sb_colors check ((color_primary is null or color_primary ~ '^#[0-9a-fA-F]{6}$') and (color_accent is null or color_accent ~ '^#[0-9a-fA-F]{6}$')),
  constraint sb_logo check (logo_data is null or (length(logo_data) < 300000 and logo_data ~ '^data:image/(png|jpeg|webp);base64,')),
  constraint sb_hero check (hero_style in ('solid', 'gradient')),
  constraint sb_text check (length(coalesce(display_name, '')) <= 60 and length(coalesce(tagline, '')) <= 140)
);
alter table public.store_brand enable row level security;
drop policy if exists sb_sel on public.store_brand;
create policy sb_sel on public.store_brand for select to authenticated using (store_id = public.my_store() or public.is_owner());
drop policy if exists sb_ins on public.store_brand;
create policy sb_ins on public.store_brand for insert to authenticated with check ((public.is_admin() and store_id = public.my_store()) or public.is_owner());
drop policy if exists sb_upd on public.store_brand;
create policy sb_upd on public.store_brand for update to authenticated using ((public.is_admin() and store_id = public.my_store()) or public.is_owner())
  with check ((public.is_admin() and store_id = public.my_store()) or public.is_owner());
grant select, insert, update on public.store_brand to authenticated;

create or replace function public.store_brand_json(p_store int) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select jsonb_build_object('logo', logo_data, 'primary', color_primary, 'accent', color_accent, 'name', display_name,
                                             'tagline', tagline, 'hero', hero_style, 'powered', show_powered)
                   from public.store_brand where store_id = p_store), '{}'::jsonb)
$$;

-- يضيف الهوية إلى رد track_order (دون إعادة كتابة الدالة كلها)
do $$
declare d text;
begin
  d := pg_get_functiondef('public.track_order(text)'::regprocedure);
  if position('store_brand_json' in d) = 0 then
    d := replace(d, '''store'', s.name, ''logo'', s.logo_url,', '''brand'', public.store_brand_json(o.store_id), ''store'', s.name, ''logo'', s.logo_url,');
    if position('store_brand_json' in d) = 0 then raise exception 'track_order patch failed'; end if;
    execute d;
  end if;
end $$;
