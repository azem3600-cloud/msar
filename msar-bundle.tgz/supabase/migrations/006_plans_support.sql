-- =====================================================================
-- مسار — ترقية 006: الباقات وحدودها + الدعم الفني (تذاكر ومرفقات)
--   الباقات:  starter = الأساسية (فرعين، 5 موظفين، بدون تتبع مباشر)
--             growth  = النمو (5 فروع، 20 موظف، تتبع مباشر)
--             pro     = الاحترافية (بلا حدود)
--   المتجر بدون باقة يعامل كـ "الأساسية". صاحب المنصة يقدر يغيّر الحدود من app_settings.plans
-- آمنة لإعادة التشغيل
-- =====================================================================

alter table public.stores add column if not exists plan_status text;
alter table public.stores add column if not exists plan_ends_at timestamptz;
alter table public.stores add column if not exists plan_checked_at timestamptz;
update public.stores set plan = null where plan is not null and plan not in ('starter','growth','pro');
alter table public.stores drop constraint if exists stores_plan_chk;
alter table public.stores add constraint stores_plan_chk check (plan is null or plan in ('starter','growth','pro'));

-- حدود الباقات (null = بلا حدود)
create or replace function public.plan_defs() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce((select value from public.app_settings where key = 'plans'),
    '{"starter":{"name_ar":"الأساسية","name_en":"Starter","branches":2,"staff":5,"live":false},
      "growth":{"name_ar":"النمو","name_en":"Growth","branches":5,"staff":20,"live":true},
      "pro":{"name_ar":"الاحترافية","name_en":"Pro","branches":null,"staff":null,"live":true}}'::jsonb)
$$;

create or replace function public.store_plan(p_store int) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('code', coalesce(s.plan, 'starter')) || (public.plan_defs() -> coalesce(s.plan, 'starter'))
         || jsonb_build_object('plan_status', s.plan_status, 'plan_ends_at', s.plan_ends_at)
  from public.stores s where s.id = p_store
$$;

-- عدد الموظفين = كل الأعضاء النشطين ما عدا المدير الأول (صاحب المتجر)
create or replace function public.store_staff_count(p_store int) returns int
language sql stable security definer set search_path = public as $$
  select greatest(0, (select count(*) from public.store_members m where m.store_id = p_store and m.is_active)::int - 1)
$$;

-- الباقة والاستخدام للمتجر الحالي (للوحة التاجر)
create or replace function public.my_plan() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when public.my_store() is null then null else
    public.store_plan(public.my_store()) || jsonb_build_object(
      'used_branches', (select count(*) from public.branches b where b.store_id = public.my_store()),
      'used_staff', public.store_staff_count(public.my_store()),
      'pending_invites', (select count(*) from public.invites i where i.store_id = public.my_store() and i.accepted_at is null and i.expires_at > now()))
  end
$$;
grant execute on function public.my_plan() to authenticated;
revoke all on function public.store_plan(int), public.store_staff_count(int), public.plan_defs() from public, anon, authenticated;
grant execute on function public.store_plan(int), public.store_staff_count(int), public.plan_defs() to service_role;

-- فرض الحدود في قاعدة البيانات (ما يعتمد على الواجهة)
create or replace function public.enforce_branch_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim int; used int; p jsonb;
begin
  p := public.store_plan(new.store_id);
  lim := nullif(p->>'branches', '')::int;
  if lim is null then return new; end if;
  select count(*) into used from public.branches where store_id = new.store_id;
  if used >= lim then
    raise exception 'باقة % تسمح بـ % فروع كحد أقصى — رقِّ باقتك من متجر تطبيقات زد لإضافة فروع أكثر', p->>'name_ar', lim;
  end if;
  return new;
end $$;
drop trigger if exists branches_limit_trg on public.branches;
create trigger branches_limit_trg before insert on public.branches for each row execute function public.enforce_branch_limit();

create or replace function public.enforce_staff_limit() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim int; used int; p jsonb; sid int;
begin
  sid := new.store_id;
  if tg_table_name = 'store_members' then
    if not new.is_active then return new; end if;
    if tg_op = 'UPDATE' and old.is_active then return new; end if;
    -- upsert لعضو موجود ونشط أصلاً (مثل إعادة الإعداد) ما يُحسب مرة ثانية
    if tg_op = 'INSERT' and exists (select 1 from public.store_members m where m.store_id = sid and m.user_id = new.user_id and m.is_active) then return new; end if;
    -- أول مدير للمتجر (صاحبه) ما يُحسب
    if not exists (select 1 from public.store_members m where m.store_id = sid and m.is_active and m.id is distinct from new.id) then return new; end if;
  end if;
  p := public.store_plan(sid);
  lim := nullif(p->>'staff', '')::int;
  if lim is null then return new; end if;
  used := public.store_staff_count(sid);
  if tg_table_name = 'invites' then
    used := used + (select count(*) from public.invites i where i.store_id = sid and i.accepted_at is null and i.expires_at > now());
  elsif exists (select 1 from public.invites i where i.store_id = sid and i.accepted_at is null and lower(i.email) = lower(coalesce((select email from auth.users u where u.id = new.user_id), ''))) then
    return new; -- قبول دعوة محسوبة مسبقاً
  end if;
  if used >= lim then
    raise exception 'باقة % تسمح بـ % موظفين كحد أقصى — رقِّ باقتك من متجر تطبيقات زد لإضافة موظفين أكثر', p->>'name_ar', lim;
  end if;
  return new;
end $$;
drop trigger if exists store_members_limit_trg on public.store_members;
create trigger store_members_limit_trg before insert or update of is_active on public.store_members for each row execute function public.enforce_staff_limit();
drop trigger if exists invites_limit_trg on public.invites;
create trigger invites_limit_trg before insert on public.invites for each row execute function public.enforce_staff_limit();

-- صاحب المنصة: تحديث الباقة يدوياً مع التحقق
create or replace function public.owner_update_store(p_id int, p jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  if p ? 'status' and p->>'status' not in ('trial','active','suspended','uninstalled') then raise exception 'حالة غير صحيحة'; end if;
  if p ? 'code' and p->>'code' !~ '^[a-z0-9-]{2,30}$' then raise exception 'رمز المتجر: حروف إنجليزية صغيرة وأرقام فقط'; end if;
  if p ? 'plan' and coalesce(p->>'plan','') not in ('', 'starter','growth','pro') then raise exception 'باقة غير صحيحة'; end if;
  update public.stores set
    status = coalesce(p->>'status', status),
    plan = case when p ? 'plan' then nullif(p->>'plan','') else plan end,
    name = coalesce(nullif(p->>'name',''), name),
    code = coalesce(nullif(p->>'code',''), code),
    trial_ends_at = case when p ? 'trial_ends_at' then (p->>'trial_ends_at')::timestamptz else trial_ends_at end,
    settings = case when p ? 'push_status' then jsonb_set(settings, '{push_status}', to_jsonb((p->>'push_status')::boolean)) else settings end
  where id = p_id;
end $$;

-- =====================================================================
-- الدعم الفني
-- =====================================================================
create table if not exists public.support_tickets (
  id            bigserial primary key,
  store_id      int references public.stores(id) on delete set null,
  user_id       uuid not null,
  user_name     text,
  user_email    text,
  user_role     text,
  store_name    text,
  subject       text not null check (length(subject) between 2 and 200),
  status        text not null default 'open' check (status in ('open','answered','closed')),
  source        text not null default 'widget',
  page          text,
  staff_unread  boolean not null default true,
  user_unread   boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists support_tickets_user_idx on public.support_tickets(user_id, updated_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets(status, updated_at desc);

create table if not exists public.support_messages (
  id          bigserial primary key,
  ticket_id   bigint not null references public.support_tickets(id) on delete cascade,
  sender      text not null check (sender in ('user','staff','ai')),
  author      uuid,
  body        text not null check (length(body) <= 8000),
  attachments jsonb not null default '[]'::jsonb,
  created_at  timestamptz not null default now()
);
create index if not exists support_messages_ticket_idx on public.support_messages(ticket_id, id);

create table if not exists public.support_ai_usage (
  user_id uuid not null,
  day     date not null default current_date,
  n       int not null default 0,
  primary key (user_id, day)
);

alter table public.support_tickets enable row level security;
alter table public.support_messages enable row level security;
alter table public.support_ai_usage enable row level security;
revoke all on public.support_tickets, public.support_messages, public.support_ai_usage from anon, authenticated;
grant select on public.support_tickets, public.support_messages to authenticated;
drop policy if exists support_tickets_read on public.support_tickets;
create policy support_tickets_read on public.support_tickets for select to authenticated using (user_id = auth.uid() or public.is_owner());
drop policy if exists support_messages_read on public.support_messages;
create policy support_messages_read on public.support_messages for select to authenticated
  using (exists (select 1 from public.support_tickets t where t.id = ticket_id and (t.user_id = auth.uid() or public.is_owner())));

-- مرفقات مقبولة: [{path, name, type}] داخل مجلد المستخدم في مخزن support
drop function if exists public.support_clean_att(jsonb);
create or replace function public.support_clean_att(p jsonb, p_uid uuid) returns jsonb
language sql immutable as $$
  select coalesce(jsonb_agg(jsonb_build_object('path', a->>'path', 'name', left(coalesce(a->>'name','file'), 120), 'type', left(coalesce(a->>'type',''), 60))), '[]'::jsonb)
  from (select a from jsonb_array_elements(case when jsonb_typeof(p) = 'array' then p else '[]'::jsonb end) a limit 6) x
  where coalesce(a->>'path','') ~ '^[0-9a-f-]{36}/[A-Za-z0-9._-]{1,140}$' and split_part(a->>'path', '/', 1) = p_uid::text
$$;

create or replace function public.support_ticket_create(p_subject text, p_body text, p_attachments jsonb default '[]', p_transcript jsonb default '[]', p_page text default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare tid bigint; me record; st record; m jsonb; recent int;
begin
  if auth.uid() is null then raise exception 'سجّل الدخول أولاً'; end if;
  select count(*) into recent from public.support_tickets where user_id = auth.uid() and created_at > now() - interval '1 hour';
  if recent >= 8 then raise exception 'أرسلت تذاكر كثيرة خلال ساعة — حاول بعد قليل أو كمّل في تذكرتك الحالية'; end if;
  if length(trim(coalesce(p_body,''))) < 3 then raise exception 'اكتب وصف المشكلة'; end if;
  select p.full_name, p.role, p.store_id, u.email into me from public.profiles p left join auth.users u on u.id = p.id where p.id = auth.uid();
  select s.name into st from public.stores s where s.id = me.store_id;
  insert into public.support_tickets(store_id, user_id, user_name, user_email, user_role, store_name, subject, page, source)
  values (me.store_id, auth.uid(), me.full_name, me.email, me.role, st.name, left(trim(coalesce(nullif(p_subject,''), left(p_body, 80))), 200), left(p_page, 200),
          case when jsonb_array_length(coalesce(p_transcript,'[]'::jsonb)) > 0 then 'ai' else 'widget' end)
  returning id into tid;
  -- محادثة المساعد قبل التحويل (للسياق)
  for m in select * from jsonb_array_elements(coalesce(p_transcript, '[]'::jsonb)) limit 30 loop
    if m->>'role' in ('user','ai') and length(coalesce(m->>'text','')) > 0 then
      insert into public.support_messages(ticket_id, sender, author, body, attachments)
      values (tid, m->>'role', case when m->>'role' = 'user' then auth.uid() end, left(m->>'text', 8000), public.support_clean_att(m->'attachments', auth.uid()));
    end if;
  end loop;
  insert into public.support_messages(ticket_id, sender, author, body, attachments)
  values (tid, 'user', auth.uid(), left(p_body, 8000), public.support_clean_att(p_attachments, auth.uid()));
  return tid;
end $$;

create or replace function public.support_ticket_reply(p_ticket bigint, p_body text, p_attachments jsonb default '[]')
returns void language plpgsql security definer set search_path = public as $$
declare t public.support_tickets; staff boolean := public.is_owner();
begin
  select * into t from public.support_tickets where id = p_ticket;
  if t.id is null or (t.user_id <> auth.uid() and not staff) then raise exception 'التذكرة غير موجودة'; end if;
  if length(trim(coalesce(p_body,''))) < 1 and jsonb_array_length(public.support_clean_att(p_attachments, auth.uid())) = 0 then raise exception 'اكتب ردك'; end if;
  insert into public.support_messages(ticket_id, sender, author, body, attachments)
  values (p_ticket, case when staff and t.user_id <> auth.uid() then 'staff' else 'user' end, auth.uid(), left(coalesce(p_body,''), 8000), public.support_clean_att(p_attachments, auth.uid()));
  if staff and t.user_id <> auth.uid() then
    update public.support_tickets set status = 'answered', user_unread = true, staff_unread = false, updated_at = now() where id = p_ticket;
  else
    update public.support_tickets set status = 'open', staff_unread = true, updated_at = now() where id = p_ticket;
  end if;
end $$;

create or replace function public.support_ticket_status(p_ticket bigint, p_status text)
returns void language plpgsql security definer set search_path = public as $$
declare t public.support_tickets;
begin
  select * into t from public.support_tickets where id = p_ticket;
  if t.id is null or (t.user_id <> auth.uid() and not public.is_owner()) then raise exception 'التذكرة غير موجودة'; end if;
  if p_status not in ('open','answered','closed') then raise exception 'حالة غير صحيحة'; end if;
  update public.support_tickets set status = p_status, updated_at = now() where id = p_ticket;
end $$;

-- قراءة التذكرة تصفّر علامة "غير مقروء" للطرف القارئ
create or replace function public.support_ticket_seen(p_ticket bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if public.is_owner() then update public.support_tickets set staff_unread = false where id = p_ticket and user_id <> auth.uid(); end if;
  update public.support_tickets set user_unread = false where id = p_ticket and user_id = auth.uid();
end $$;

create or replace function public.support_unread() returns int
language sql stable security definer set search_path = public as $$
  select case when public.is_owner() then (select count(*) from public.support_tickets where staff_unread and status <> 'closed')::int
              else (select count(*) from public.support_tickets where user_id = auth.uid() and user_unread)::int end
$$;

-- حد استخدام المساعد الذكي (يستدعيه السيرفر فقط)
create or replace function public.support_ai_hit(p_user uuid, p_limit int default 60) returns boolean
language plpgsql security definer set search_path = public as $$
declare n int;
begin
  insert into public.support_ai_usage(user_id, day, n) values (p_user, current_date, 1)
  on conflict (user_id, day) do update set n = public.support_ai_usage.n + 1 returning public.support_ai_usage.n into n;
  return n <= p_limit;
end $$;
revoke all on function public.support_ai_hit(uuid, int) from public, anon, authenticated;
grant execute on function public.support_ai_hit(uuid, int) to service_role;

grant execute on function public.support_ticket_create(text, text, jsonb, jsonb, text), public.support_ticket_reply(bigint, text, jsonb),
  public.support_ticket_status(bigint, text), public.support_ticket_seen(bigint), public.support_unread() to authenticated;

-- مخزن مرفقات الدعم (خاص): كل مستخدم يرفع في مجلده، وصاحب المنصة يقرأ الكل
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('support', 'support', false, 6291456, array['image/png','image/jpeg','image/webp','image/gif','application/pdf'])
on conflict (id) do update set public = false, file_size_limit = 6291456,
  allowed_mime_types = array['image/png','image/jpeg','image/webp','image/gif','application/pdf'];
drop policy if exists support_files_ins on storage.objects;
create policy support_files_ins on storage.objects for insert to authenticated
  with check (bucket_id = 'support' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists support_files_read on storage.objects;
create policy support_files_read on storage.objects for select to authenticated
  using (bucket_id = 'support' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_owner()));

select 'msar migration 006 ok' as result;
