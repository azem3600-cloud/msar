-- 017_security.sql — تشديد أمني بعد المراجعة (18 نوفمبر 2026). آمن للتشغيل أكثر من مرة.

-- 1) صلاحيات جداول ما لها داعي للمتصفح: TRUNCATE ما يخضع لحماية الصفوف (RLS)، فنسحبه مع TRIGGER و REFERENCES
do $$ declare r record; begin
  for r in select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
           where n.nspname = 'public' and c.relkind = 'r' loop
    execute format('revoke truncate, trigger, references on public.%I from anon, authenticated', r.relname);
  end loop;
end $$;
revoke all on public.store_brand from anon;   -- الزائر ما يحتاج الجدول (الهوية توصله عبر track_order)

-- 2) جدول المتاجر: أعضاء المتجر (حتى الكاشير والمندوب) كانوا يقدرون يقرؤون كل الأعمدة،
--    ومنها مفتاح الـ webhook وملاحظات المدير الخاصة عن التاجر. نسمح بالأعمدة الآمنة فقط.
revoke select on public.stores from authenticated;
grant select (id, code, name, zid_store_id, store_url, logo_url, status, plan, trial_ends_at, settings,
              installed_at, created_at, last_synced_at, plan_status, plan_ends_at, platform)
  on public.stores to authenticated;

-- 3) دوال داخلية ما يناديها المتصفح أبداً: كانت تكشف فروع ومناديب وهوية أي متجر برقمه
do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname in ('nearest_branch', 'pick_driver', 'store_brand_json') loop
    execute format('revoke execute on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end $$;

-- 4) دوال المدير والدعم والحساب: للمسجّلين فقط (كل دالة تتحقق من الصلاحية داخلياً، وهذا قفل إضافي على الزائر)
do $$ declare f record; begin
  for f in select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
           where n.nspname = 'public' and p.proname in (
             'owner_health', 'owner_lead_status', 'owner_leads', 'owner_org_tree', 'owner_overview2', 'owner_store_detail',
             'owner_store_note', 'owner_wa_channel_delete', 'owner_wa_channel_save', 'owner_wa_overview', 'owner_wa_set_all',
             'owner_wa_set_store', 'store_staff', 'support_ticket_create', 'support_ticket_reply', 'support_ticket_seen',
             'support_ticket_status', 'support_unread', 'switch_store', 'my_memberships', 'my_plan', 'my_wa_enabled',
             'driver_register_push', 'driver_unregister_push', 'plan_price') loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated, service_role', f.sig);
  end loop;
end $$;
