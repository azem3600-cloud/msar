-- =====================================================================
--  021 — منشئ صفحة المنيو (blocks) + رقم واتساب خاص بالمنيو
--  Idempotent — شغّله من Supabase (SQL Editor). يتطلب 019 و020 قبله.
--   • msite.blocks: تخطيط الصفحة (بانرات/سلايدر، شريط أقسام، منتجات، نص)
--   • msite.wa: رقم واتساب الطلب (اختياري، يتقدم على رقم القناة)
-- =====================================================================

-- الهوية: + blocks (تخطيط الصفحة: بانرات، شريط أقسام، منتجات، نص)
create or replace function public._wa_theme(p_store int, p_ms jsonb) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'name', coalesce(nullif(p_ms ->> 'name', ''), (select name from public.stores where id = p_store)),
    'tagline', coalesce(p_ms ->> 'tagline', ''),
    'template', coalesce(nullif(p_ms ->> 'template', ''), 'rest'),
    'color', coalesce(nullif(p_ms ->> 'color', ''), '#144F74'),
    'logo', p_ms ->> 'logo', 'cover', p_ms ->> 'cover',
    'layout', coalesce(p_ms -> 'layout', '{}'::jsonb),
    'offer', coalesce(p_ms -> 'offer', '{}'::jsonb),
    'blocks', coalesce(p_ms -> 'blocks', '[]'::jsonb))
$$;
revoke execute on function public._wa_theme(int, jsonb) from public, anon, authenticated;

-- الصفحة العامة: الأصناف + old_price + badge
create or replace function public.wa_menu_public(p_slug text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r record; ms jsonb; cfg jsonb; wa text; open_now boolean;
begin
  if p_slug is null or p_slug !~ '^[a-z0-9][a-z0-9-]{1,38}$' then return jsonb_build_object('status', 'notfound'); end if;
  select c.store_id, c.config into r from public.wa_config c where c.config -> 'msite' ->> 'slug' = p_slug limit 1;
  if not found then return jsonb_build_object('status', 'notfound'); end if;
  if not public.wa_enabled_for(r.store_id) then return jsonb_build_object('status', 'notfound'); end if;
  ms := r.config -> 'msite'; cfg := r.config;
  if coalesce((ms ->> 'enabled')::boolean, false) = false or coalesce(ms ->> 'vis', 'all') = 'closed' then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  if coalesce(ms ->> 'vis', 'all') = 'wa' then
    return jsonb_build_object('status', 'private', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  open_now := public._wa_in_hours(cfg);
  if ms ->> 'vis' = 'hours' and not open_now then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms), 'hours', cfg -> 'hours');
  end if;
  -- رقم الطلب: الرقم اللي كتبه التاجر في المنيو، وإلا رقم قناة الواتساب المربوطة
  wa := nullif(regexp_replace(coalesce(ms ->> 'wa', ''), '\D', '', 'g'), '');
  if wa is null then select display_phone into wa from public.wa_channels where store_id = r.store_id and status = 'active' order by id limit 1; end if;
  return jsonb_build_object(
    'status', 'ok',
    'theme', public._wa_theme(r.store_id, ms),
    'wa', regexp_replace(coalesce(wa, ''), '\D', '', 'g'),
    'open', open_now,
    'fee', coalesce((cfg ->> 'delivery_fee')::numeric, 0),
    'free_over', coalesce((cfg ->> 'free_over')::numeric, 0),
    'min_order', coalesce((cfg ->> 'min_order')::numeric, 0),
    'cats', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'name', name, 'emoji', emoji) order by sort, id)
                       from public.wa_categories where store_id = r.store_id and is_active), '[]'::jsonb),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'cat', i.category_id, 'name', i.name, 'desc', i.description,
                       'price', i.price, 'old', i.old_price, 'badge', i.badge, 'img', i.image_url, 'emoji', i.emoji, 'pop', i.is_popular) order by i.sort, i.id)
                       from public.wa_items i left join public.wa_categories c on c.id = i.category_id
                       where i.store_id = r.store_id and i.is_active and (i.category_id is null or c.is_active)), '[]'::jsonb)
  );
end $$;
revoke execute on function public.wa_menu_public(text) from public;
grant execute on function public.wa_menu_public(text) to anon, authenticated;

select 'msar migration 021 ok' as result;
