-- =====================================================================
-- مسار — ترقية 005: محتوى الموقع التعريفي (يتحكم فيه صاحب المنصة)
--   * site_content: صفوف JSON (site = إعدادات الصفحة الرئيسية، page:terms / page:privacy / page:guide)
--   * القراءة عامة (الزوار)، والكتابة لصاحب المنصة فقط عبر owner_site_save
--   * مخزن صور عام "site" لرفع الشعار وصور الموقع من اللوحة
-- آمنة لإعادة التشغيل
-- =====================================================================

create table if not exists public.site_content (
  key        text primary key check (key ~ '^[a-z0-9:_-]{2,40}$'),
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.site_content enable row level security;
drop policy if exists site_content_read on public.site_content;
create policy site_content_read on public.site_content for select using (true);
revoke insert, update, delete on public.site_content from anon, authenticated;
grant select on public.site_content to anon, authenticated;

create or replace function public.owner_site_save(p_key text, p_data jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  if p_key !~ '^[a-z0-9:_-]{2,40}$' then raise exception 'مفتاح غير صالح'; end if;
  if pg_column_size(p_data) > 400000 then raise exception 'المحتوى كبير جداً'; end if;
  insert into public.site_content(key, data, updated_at) values (p_key, coalesce(p_data, '{}'::jsonb), now())
  on conflict (key) do update set data = excluded.data, updated_at = now();
end $$;
revoke all on function public.owner_site_save(text, jsonb) from public, anon;
grant execute on function public.owner_site_save(text, jsonb) to authenticated;

-- طلبات "تواصل معنا / اطلب عرض" من الصفحة الرئيسية (الزوار يرسلون، صاحب المنصة يقرأ)
create table if not exists public.site_leads (
  id         bigserial primary key,
  name       text not null check (length(name) between 2 and 120),
  phone      text check (phone is null or length(phone) <= 30),
  email      text check (email is null or length(email) <= 160),
  store_url  text check (store_url is null or length(store_url) <= 300),
  branches   int,
  message    text check (message is null or length(message) <= 2000),
  lang       text,
  status     text not null default 'new' check (status in ('new','contacted','closed')),
  created_at timestamptz not null default now()
);
alter table public.site_leads enable row level security;
revoke all on public.site_leads from anon, authenticated;

create or replace function public.site_lead_submit(p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare recent int;
begin
  -- حماية بسيطة من الإغراق: حد أقصى 30 طلب في الدقيقة على مستوى الموقع
  select count(*) into recent from public.site_leads where created_at > now() - interval '1 minute';
  if recent > 30 then raise exception 'حاول بعد قليل'; end if;
  insert into public.site_leads(name, phone, email, store_url, branches, message, lang)
  values (left(trim(p->>'name'), 120), nullif(left(trim(p->>'phone'), 30), ''), nullif(left(trim(p->>'email'), 160), ''),
          nullif(left(trim(p->>'store_url'), 300), ''), nullif(p->>'branches', '')::int, nullif(left(trim(p->>'message'), 2000), ''), left(p->>'lang', 5));
end $$;
grant execute on function public.site_lead_submit(jsonb) to anon, authenticated;

create or replace function public.owner_leads(p_limit int default 200) returns setof public.site_leads
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  return query select * from public.site_leads order by id desc limit least(p_limit, 1000);
end $$;

create or replace function public.owner_lead_status(p_id bigint, p_status text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  update public.site_leads set status = p_status where id = p_id;
end $$;

-- مخزن الصور العام للموقع
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('site', 'site', true, 5242880, array['image/png','image/jpeg','image/webp','image/svg+xml','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 5242880,
  allowed_mime_types = array['image/png','image/jpeg','image/webp','image/svg+xml','image/gif'];

drop policy if exists site_files_read on storage.objects;
create policy site_files_read on storage.objects for select using (bucket_id = 'site');
drop policy if exists site_files_owner_ins on storage.objects;
create policy site_files_owner_ins on storage.objects for insert to authenticated with check (bucket_id = 'site' and public.is_owner());
drop policy if exists site_files_owner_upd on storage.objects;
create policy site_files_owner_upd on storage.objects for update to authenticated using (bucket_id = 'site' and public.is_owner());
drop policy if exists site_files_owner_del on storage.objects;
create policy site_files_owner_del on storage.objects for delete to authenticated using (bucket_id = 'site' and public.is_owner());

select 'msar migration 005 ok' as result;
