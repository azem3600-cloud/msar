-- =====================================================================
--  020 — المنيو الإلكتروني الاحترافي: عروض + صور أصناف + شكل المنتجات
--  Idempotent — شغّله من Supabase (SQL Editor). يتطلب 019 قبله.
--   • wa_items: old_price (السعر قبل الخصم) و badge (شارة: عرض/جديد…)
--   • مخزن صور عام اسمه menu (مجلد لكل متجر)
--   • wa_menu_public يرجّع old_price/badge، والهوية ترجّع layout/offer
-- =====================================================================

alter table public.wa_items add column if not exists old_price numeric(10,2) check (old_price is null or old_price >= 0);
alter table public.wa_items add column if not exists badge text;

-- مخزن صور المنيو (قراءة عامة، والكتابة لأعضاء المتجر داخل مجلد متجرهم فقط)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('menu', 'menu', true, 3145728, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = 3145728, allowed_mime_types = array['image/jpeg','image/png','image/webp'];

drop policy if exists menu_files_read on storage.objects;
create policy menu_files_read on storage.objects for select using (bucket_id = 'menu');
drop policy if exists menu_files_ins on storage.objects;
create policy menu_files_ins on storage.objects for insert to authenticated
  with check (bucket_id = 'menu' and public.my_store() is not null and (storage.foldername(name))[1] = public.my_store()::text);
drop policy if exists menu_files_upd on storage.objects;
create policy menu_files_upd on storage.objects for update to authenticated
  using (bucket_id = 'menu' and public.my_store() is not null and (storage.foldername(name))[1] = public.my_store()::text);
drop policy if exists menu_files_del on storage.objects;
create policy menu_files_del on storage.objects for delete to authenticated
  using (bucket_id = 'menu' and public.my_store() is not null and (storage.foldername(name))[1] = public.my_store()::text);

-- الهوية: + شكل المنتجات (layout) + بانر العرض (offer)
create or replace function public._wa_theme(p_store int, p_ms jsonb) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'name', coalesce(nullif(p_ms ->> 'name', ''), (select name from public.stores where id = p_store)),
    'tagline', coalesce(p_ms ->> 'tagline', ''),
    'template', coalesce(nullif(p_ms ->> 'template', ''), 'rest'),
    'color', coalesce(nullif(p_ms ->> 'color', ''), '#144F74'),
    'logo', p_ms ->> 'logo', 'cover', p_ms ->> 'cover',
    'layout', coalesce(p_ms -> 'layout', '{}'::jsonb),
    'offer', coalesce(p_ms -> 'offer', '{}'::jsonb))
$$;
revoke execute on function public._wa_theme(int, jsonb) from public, anon, authenticated;

-- الصفحة العامة: الأصناف + old_price + badge
create or replace function public.wa_menu_public(p_slug text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r record; ms jsonb; cfg jsonb; wa text; open_now boolean;
begin
  if p_slug is null or p_slug !~ '^[a-z0-9][a-z0-9-]{1,38}$' then return jsonb_build_object('status', 'notfound'); end if;
  select c.store_id, c.config into r from public.wa_config c where c.config -> 'msite' ->> 'slug' = p_slug limit 1;
  if not found then return jsonb_build_object('status', 'notfound'); end if;
  if not public.wa_enabled_for(r.store_id) then return jsonb_build_object('status', 'notfound'); end if;
  ms := r.config -> 'msite'; cfg := r.config;
  if coalesce((ms ->> 'enabled')::boolean, false) = false or coalesce(ms ->> 'vis', 'all') = 'closed' then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  if coalesce(ms ->> 'vis', 'all') = 'wa' then
    return jsonb_build_object('status', 'private', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  open_now := public._wa_in_hours(cfg);
  if ms ->> 'vis' = 'hours' and not open_now then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms), 'hours', cfg -> 'hours');
  end if;
  select display_phone into wa from public.wa_channels where store_id = r.store_id and status = 'active' order by id limit 1;
  return jsonb_build_object(
    'status', 'ok',
    'theme', public._wa_theme(r.store_id, ms),
    'wa', regexp_replace(coalesce(wa, ''), '\D', '', 'g'),
    'open', open_now,
    'fee', coalesce((cfg ->> 'delivery_fee')::numeric, 0),
    'free_over', coalesce((cfg ->> 'free_over')::numeric, 0),
    'min_order', coalesce((cfg ->> 'min_order')::numeric, 0),
    'cats', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'name', name, 'emoji', emoji) order by sort, id)
                       from public.wa_categories where store_id = r.store_id and is_active), '[]'::jsonb),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'cat', i.category_id, 'name', i.name, 'desc', i.description,
                       'price', i.price, 'old', i.old_price, 'badge', i.badge, 'img', i.image_url, 'emoji', i.emoji, 'pop', i.is_popular) order by i.sort, i.id)
                       from public.wa_items i left join public.wa_categories c on c.id = i.category_id
                       where i.store_id = r.store_id and i.is_active and (i.category_id is null or c.is_active)), '[]'::jsonb)
  );
end $$;
revoke execute on function public.wa_menu_public(text) from public;
grant execute on function public.wa_menu_public(text) to anon, authenticated;

select 'msar migration 020 ok' as result;
