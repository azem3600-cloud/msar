-- 023 — إشعار واتساب للعميل لما يُسند الطلب للمندوب (assigned). Idempotent.
create or replace function public.wa_orders_notify() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.source = 'whatsapp' and new.status in ('preparing','assigned','out_for_delivery','delivered','cancelled')
     and (new.raw ->> 'wa_session') is not null then
    insert into public.wa_outbox(store_id, session_id, order_id, status)
    values (new.store_id, (new.raw ->> 'wa_session')::bigint, new.id, new.status)
    on conflict (order_id, status) do nothing;
    perform public.call_wa_function('flush');
  end if;
  return null;
end $$;
select 'msar migration 023 ok' as result;
