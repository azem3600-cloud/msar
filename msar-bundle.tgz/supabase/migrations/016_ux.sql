-- 016_ux.sql — تحسينات تجربة المستخدم (نوفمبر 2026)
-- كله إضافي: ما يغيّر أي دالة أو جدول موجود. آمن للتشغيل أكثر من مرة.
--   1) مفاتيح تشغيل/إيقاف المزايا (يتحكم فيها المدير من لوحته)
--   2) تقييم العميل بعد التسليم
--   3) رمز إثبات التسليم
--   4) بيانات إضافية لصفحة التتبع (الرمز، جوال المندوب، التقييم)

-- ------------------------------------------------------------------ 1) المزايا
create or replace function public.app_features() returns jsonb
language sql stable security definer set search_path = public as $$
  select '{"wizard":true,"test_order":true,"undo":true,"skeleton":true,"dark":true,"english":true,
           "pod":false,"route_sort":true,"rating":true,"eta":true,"call_driver":true}'::jsonb
         || coalesce((select value from public.app_settings where key = 'features'), '{}'::jsonb)
$$;
grant execute on function public.app_features() to anon, authenticated;

create or replace function public.owner_set_feature(p_key text, p_on boolean) returns jsonb
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  if p_key not in ('wizard','test_order','undo','skeleton','dark','english','pod','route_sort','rating','eta','call_driver') then
    raise exception 'ميزة غير معروفة';
  end if;
  insert into public.app_settings(key, value, updated_at)
  values ('features', jsonb_build_object(p_key, coalesce(p_on, false)), now())
  on conflict (key) do update
    set value = coalesce(public.app_settings.value, '{}'::jsonb) || jsonb_build_object(p_key, coalesce(p_on, false)),
        updated_at = now();
  return public.app_features();
end $$;
revoke all on function public.owner_set_feature(text, boolean) from public, anon;
grant execute on function public.owner_set_feature(text, boolean) to authenticated;

-- ------------------------------------------------------------------ 2) التقييم
alter table public.orders add column if not exists rating smallint;
alter table public.orders add column if not exists rating_note text;
alter table public.orders add column if not exists rated_at timestamptz;
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'orders_rating_chk') then
    alter table public.orders add constraint orders_rating_chk check (rating is null or rating between 1 and 5);
  end if;
end $$;

-- ------------------------------------------------------------------ 3) رمز إثبات التسليم
-- في جدول مستقل بدون أي صلاحية قراءة مباشرة، عشان المندوب ما يقدر يشوف الرمز من بيانات الطلب.
create table if not exists public.order_pod (
  order_id       bigint primary key references public.orders(id) on delete cascade,
  code           text not null,
  verified_at    timestamptz,
  skipped_reason text,
  tries          int not null default 0,
  created_at     timestamptz not null default now()
);
alter table public.order_pod enable row level security;
revoke all on public.order_pod from anon, authenticated;

create or replace function public.pod_code_for(p_order bigint) returns text
language plpgsql security definer set search_path = public as $$
declare v text;
begin
  insert into public.order_pod(order_id, code)
  values (p_order, lpad((floor(random() * 10000))::int::text, 4, '0'))
  on conflict (order_id) do nothing;
  select code into v from public.order_pod where order_id = p_order;
  return v;
end $$;
revoke all on function public.pod_code_for(bigint) from public, anon, authenticated;

-- هل هذا الطلب يحتاج رمز؟ (الميزة شغالة + باقة المتجر فيها رابط التتبع، لأن العميل يشوف الرمز من الرابط)
create or replace function public.driver_pod_check(p_order bigint) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders; need boolean;
begin
  select * into o from public.orders where id = p_order;
  if not found or o.driver_id is distinct from auth.uid() then raise exception 'غير مصرح'; end if;
  need := coalesce((public.app_features() ->> 'pod')::boolean, false)
      and coalesce((public.store_plan(o.store_id) ->> 'live')::boolean, false);
  if need then perform public.pod_code_for(p_order); end if;
  return jsonb_build_object('required', need);
end $$;
revoke all on function public.driver_pod_check(bigint) from public, anon;
grant execute on function public.driver_pod_check(bigint) to authenticated;

create or replace function public.driver_pod_verify(p_order bigint, p_code text) returns boolean
language plpgsql security definer set search_path = public as $$
declare o public.orders; r public.order_pod; ok boolean;
begin
  select * into o from public.orders where id = p_order;
  if not found or o.driver_id is distinct from auth.uid() then raise exception 'غير مصرح'; end if;
  select * into r from public.order_pod where order_id = p_order for update;
  if not found then return false; end if;
  if r.tries >= 10 and r.verified_at is null then raise exception 'محاولات كثيرة — اطلب من الفرع تأكيد التسليم'; end if;
  ok := r.code = regexp_replace(translate(coalesce(p_code, ''), '٠١٢٣٤٥٦٧٨٩', '0123456789'), '\D', '', 'g');
  if ok then
    update public.order_pod set verified_at = now() where order_id = p_order;
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (p_order, auth.uid(), public.my_name(), 'note', '✅ تسليم مؤكد برمز العميل');
  else
    update public.order_pod set tries = tries + 1 where order_id = p_order;
  end if;
  return ok;
end $$;
revoke all on function public.driver_pod_verify(bigint, text) from public, anon;
grant execute on function public.driver_pod_verify(bigint, text) to authenticated;

create or replace function public.driver_pod_skip(p_order bigint, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  select * into o from public.orders where id = p_order;
  if not found or o.driver_id is distinct from auth.uid() then raise exception 'غير مصرح'; end if;
  if coalesce(length(trim(p_reason)), 0) < 3 then raise exception 'اكتب السبب'; end if;
  perform public.pod_code_for(p_order);
  update public.order_pod set skipped_reason = left(trim(p_reason), 200) where order_id = p_order;
  insert into public.order_events(order_id, actor_id, actor_name, type, note)
  values (p_order, auth.uid(), public.my_name(), 'note', '⚠️ تسليم بدون رمز العميل: ' || left(trim(p_reason), 200));
end $$;
revoke all on function public.driver_pod_skip(bigint, text) from public, anon;
grant execute on function public.driver_pod_skip(bigint, text) to authenticated;

-- ------------------------------------------------------------------ 4) صفحة التتبع
-- نفس شروط track_order (رابط صحيح، متجر فعّال، باقة فيها التتبع، الرابط ما انتهى).
create or replace function public.track_extra(p_token text) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders; s public.stores; d public.profiles; f jsonb := public.app_features(); v_code text; v_phone text;
begin
  if p_token is null or p_token !~ '^[a-f0-9]{24,40}$' then return jsonb_build_object('ok', false); end if;
  select * into o from public.orders where track_token = p_token;
  if not found then return jsonb_build_object('ok', false); end if;
  select * into s from public.stores where id = o.store_id;
  if s.status not in ('trial', 'active') then return jsonb_build_object('ok', false); end if;
  if not coalesce((public.store_plan(o.store_id) ->> 'live')::boolean, false) then return jsonb_build_object('ok', false); end if;
  if o.order_created_at < now() - interval '7 days'
     or (o.delivered_at is not null and o.delivered_at < now() - interval '1 day')
     or (o.cancelled_at is not null and o.cancelled_at < now() - interval '1 day') then
    return jsonb_build_object('ok', false);
  end if;
  if coalesce((f ->> 'pod')::boolean, false) and o.status in ('assigned', 'out_for_delivery') then
    v_code := public.pod_code_for(o.id);
  end if;
  if coalesce((f ->> 'call_driver')::boolean, false) and o.status = 'out_for_delivery' then
    select * into d from public.profiles where id = o.driver_id;
    v_phone := nullif(trim(coalesce(d.phone, '')), '');
  end if;
  return jsonb_build_object('ok', true,
    'eta', coalesce((f ->> 'eta')::boolean, false),
    'pod_code', v_code,
    'driver_phone', v_phone,
    'can_rate', coalesce((f ->> 'rating')::boolean, false) and o.status = 'delivered' and o.rating is null,
    'rating', case when coalesce((f ->> 'rating')::boolean, false) then o.rating end);
end $$;
grant execute on function public.track_extra(text) to anon, authenticated;

create or replace function public.track_rate(p_token text, p_stars int, p_note text default null) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o public.orders;
begin
  if not coalesce((public.app_features() ->> 'rating')::boolean, false) then return jsonb_build_object('ok', false); end if;
  if p_token is null or p_token !~ '^[a-f0-9]{24,40}$' or p_stars is null or p_stars < 1 or p_stars > 5 then
    return jsonb_build_object('ok', false);
  end if;
  select * into o from public.orders where track_token = p_token for update;
  if not found or o.status <> 'delivered' or o.rating is not null
     or o.delivered_at < now() - interval '1 day' then
    return jsonb_build_object('ok', false);
  end if;
  update public.orders set rating = p_stars, rating_note = nullif(left(trim(coalesce(p_note, '')), 300), ''), rated_at = now()
  where id = o.id;
  return jsonb_build_object('ok', true);
end $$;
grant execute on function public.track_rate(text, int, text) to anon, authenticated;
