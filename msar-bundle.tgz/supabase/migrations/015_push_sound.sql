-- مسار: اختيار صوت إشعار المندوب (قناة أندرويد لكل صوت) — شغّله من Supabase → SQL Editor
alter table public.push_tokens add column if not exists sound text;

create or replace function public.driver_set_push_channel(p_token text, p_sound text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'غير مصرح'; end if;
  if p_sound is null or p_sound not in ('soft','drop','bell','chime','clear','silent') then raise exception 'صوت غير معروف'; end if;
  update public.push_tokens set sound = p_sound where token = p_token and user_id = auth.uid();
end $$;
grant execute on function public.driver_set_push_channel(text, text) to authenticated;
