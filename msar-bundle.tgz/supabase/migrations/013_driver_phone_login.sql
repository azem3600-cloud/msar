-- =====================================================================
-- مسار — ترقية 013: دخول المندوب برقم الجوال + كلمة المرور فقط
--   driver_ids_by_phone(p_last9): يرجّع معرّفات المناديب الفعّالين اللي جوالهم ينتهي بهذي الأرقام التسعة
--   تُستدعى من دالة admin (action = phone_login) فقط بمفتاح الخدمة — ما تنفتح لأي مستخدم.
--   آمنة لإعادة التشغيل.
-- =====================================================================
create or replace function public.driver_ids_by_phone(p_last9 text) returns uuid[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(id), '{}') from public.profiles
  where role = 'driver' and is_active and phone is not null
    and right(regexp_replace(phone, '\D', '', 'g'), 9) = p_last9
    and length(p_last9) = 9
$$;
revoke execute on function public.driver_ids_by_phone(text) from public, anon, authenticated;

create index if not exists profiles_driver_phone_idx on public.profiles (right(regexp_replace(coalesce(phone, ''), '\D', '', 'g'), 9)) where role = 'driver';

select 'msar migration 013 ok';
