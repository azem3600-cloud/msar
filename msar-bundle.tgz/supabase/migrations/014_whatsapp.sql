-- =====================================================================
--  014 — طلبات الواتساب (WhatsApp Cloud API)
--  مستقل تماماً عن زد/سلة: جداول ودوال جديدة فقط، ولا يغيّر سلوك أي شي موجود.
--  مخفي افتراضياً: يظهر للمتجر فقط لو فعّله المالك (stores.settings.wa_enabled)
--  أو فعّله للكل (app_settings.wa_all). Idempotent — تقدر تعيد تشغيله.
-- =====================================================================

-- ---------- 0) مصدر الطلب يقبل واتساب ----------
do $$ declare c text; begin
  for c in select conname from pg_constraint where conrelid = 'public.orders'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%source%' loop
    execute format('alter table public.orders drop constraint %I', c);
  end loop;
  alter table public.orders add constraint orders_source_check check (source in ('zid','salla','manual','whatsapp'));
end $$;

-- ---------- 1) علم التفعيل ----------
create or replace function public.wa_enabled_for(p_store int) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce((select (value #>> '{}') = 'true' from public.app_settings where key = 'wa_all'), false)
      or coalesce((select settings ->> 'wa_enabled' = 'true' from public.stores where id = p_store), false)
$$;
create or replace function public.my_wa_enabled() returns boolean
language sql stable security definer set search_path = public as $$
  select case when public.my_store() is null then false else public.wa_enabled_for(public.my_store()) end
$$;
grant execute on function public.my_wa_enabled() to authenticated;
revoke execute on function public.wa_enabled_for(int) from public, anon;
grant execute on function public.wa_enabled_for(int) to authenticated, service_role;

-- ---------- 2) الجداول ----------
create table if not exists public.wa_channels (
  id              serial primary key,
  store_id        int not null references public.stores(id) on delete cascade,
  phone_number_id text not null unique,
  waba_id         text,
  display_phone   text,
  label           text,
  status          text not null default 'active' check (status in ('active','paused')),
  created_at      timestamptz not null default now()
);
create index if not exists wa_channels_store_idx on public.wa_channels(store_id);

-- توكن الوصول: للسيرفر فقط (لا policies، ولا صلاحيات للمستخدمين)
create table if not exists public.wa_secrets (
  channel_id   int primary key references public.wa_channels(id) on delete cascade,
  access_token text not null,
  updated_at   timestamptz not null default now()
);

create table if not exists public.wa_categories (
  id        serial primary key,
  store_id  int not null references public.stores(id) on delete cascade,
  name      text not null,
  emoji     text,
  sort      int not null default 0,
  is_active boolean not null default true
);
create index if not exists wa_categories_store_idx on public.wa_categories(store_id, sort);

create table if not exists public.wa_items (
  id          serial primary key,
  store_id    int not null references public.stores(id) on delete cascade,
  category_id int references public.wa_categories(id) on delete set null,
  name        text not null,
  description text,
  price       numeric(10,2) not null default 0 check (price >= 0),
  image_url   text,
  emoji       text,
  is_active   boolean not null default true,    -- متوفر
  is_popular  boolean not null default false,   -- يظهر في الأكثر طلباً
  sort        int not null default 0,
  aliases     text,                              -- أسماء بديلة للكتابة الحرة (افصل بفاصلة)
  created_at  timestamptz not null default now()
);
create index if not exists wa_items_store_idx on public.wa_items(store_id, category_id, sort);

create table if not exists public.wa_config (
  store_id   int primary key references public.stores(id) on delete cascade,
  config     jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.wa_sessions (
  id            bigserial primary key,
  store_id      int not null references public.stores(id) on delete cascade,
  channel_id    int not null references public.wa_channels(id) on delete cascade,
  wa_id         text not null,                    -- رقم العميل
  name          text,
  state         text not null default 'idle',
  cart          jsonb not null default '[]'::jsonb,
  ctx           jsonb not null default '{}'::jsonb,
  web_token     text not null default encode(gen_random_bytes(16), 'hex'),
  human         boolean not null default false,   -- تدخل موظف
  last_in_at    timestamptz,
  last_msg_at   timestamptz not null default now(),
  last_order_id bigint,
  last_cart     jsonb,
  last_lat      double precision,
  last_lon      double precision,
  last_address  text,
  orders_count  int not null default 0,
  created_at    timestamptz not null default now(),
  unique (channel_id, wa_id)
);
create index if not exists wa_sessions_store_idx on public.wa_sessions(store_id, last_msg_at desc);
create unique index if not exists wa_sessions_token_uq on public.wa_sessions(web_token);

create table if not exists public.wa_messages (
  id         bigserial primary key,
  store_id   int not null references public.stores(id) on delete cascade,
  session_id bigint not null references public.wa_sessions(id) on delete cascade,
  dir        text not null check (dir in ('in','out')),
  kind       text,
  body       text,
  payload    jsonb,
  wamid      text,
  created_at timestamptz not null default now()
);
create index if not exists wa_messages_sess_idx on public.wa_messages(session_id, created_at);
create unique index if not exists wa_messages_in_uq on public.wa_messages(wamid) where dir = 'in' and wamid is not null;

-- رسائل تحديث حالة الطلب للعميل (يرسلها السيرفر)
create table if not exists public.wa_outbox (
  id         bigserial primary key,
  store_id   int not null,
  session_id bigint,
  order_id   bigint not null,
  status     text not null,
  created_at timestamptz not null default now(),
  sent_at    timestamptz,
  tries      int not null default 0,
  error      text,
  unique (order_id, status)
);
create index if not exists wa_outbox_pending_idx on public.wa_outbox(id) where sent_at is null;

-- ---------- 3) الأمان (RLS) ----------
alter table public.wa_channels   enable row level security;
alter table public.wa_secrets    enable row level security;
alter table public.wa_categories enable row level security;
alter table public.wa_items      enable row level security;
alter table public.wa_config     enable row level security;
alter table public.wa_sessions   enable row level security;
alter table public.wa_messages   enable row level security;
alter table public.wa_outbox     enable row level security;
revoke all on public.wa_secrets, public.wa_outbox from anon, authenticated;
revoke all on public.wa_channels, public.wa_categories, public.wa_items, public.wa_config, public.wa_sessions, public.wa_messages from anon;

do $$ declare t text; begin
  foreach t in array array['wa_channels','wa_categories','wa_items','wa_config','wa_sessions','wa_messages'] loop
    execute format('drop policy if exists %I on public.%I', t || '_sel', t);
    execute format($p$create policy %I on public.%I for select to authenticated
      using (public.is_owner() or (store_id = public.my_store() and public.my_role() in ('admin','cashier') and public.wa_enabled_for(store_id)))$p$, t || '_sel', t);
  end loop;
  foreach t in array array['wa_categories','wa_items','wa_config'] loop
    execute format('drop policy if exists %I on public.%I', t || '_mod', t);
    execute format($p$create policy %I on public.%I for all to authenticated
      using (public.is_owner() or (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id)))
      with check (public.is_owner() or (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id)))$p$, t || '_mod', t);
  end loop;
  -- الجلسات: المدير يقدر يحدّث (تدخل الموظف) فقط
  execute 'drop policy if exists wa_sessions_upd on public.wa_sessions';
  execute $p$create policy wa_sessions_upd on public.wa_sessions for update to authenticated
    using (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id))
    with check (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id))$p$;
end $$;
revoke insert, delete on public.wa_channels, public.wa_sessions, public.wa_messages from authenticated;
revoke update on public.wa_channels, public.wa_messages from authenticated;
revoke update on public.wa_sessions from authenticated;
grant update (human) on public.wa_sessions to authenticated;

-- ---------- 4) دوال المالك ----------
create or replace function public.owner_wa_overview() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  return jsonb_build_object(
    'all', coalesce((select (value #>> '{}') = 'true' from public.app_settings where key = 'wa_all'), false),
    'stores', coalesce((select jsonb_agg(jsonb_build_object(
        'id', s.id, 'name', s.name, 'code', s.code, 'status', s.status,
        'enabled', coalesce(s.settings ->> 'wa_enabled' = 'true', false),
        'items', (select count(*) from public.wa_items i where i.store_id = s.id),
        'sessions', (select count(*) from public.wa_sessions x where x.store_id = s.id),
        'orders', (select count(*) from public.orders o where o.store_id = s.id and o.source = 'whatsapp'),
        'channels', coalesce((select jsonb_agg(jsonb_build_object('id', c.id, 'phone_number_id', c.phone_number_id,
            'waba_id', c.waba_id, 'display_phone', c.display_phone, 'status', c.status,
            'has_token', exists(select 1 from public.wa_secrets w where w.channel_id = c.id)) order by c.id)
          from public.wa_channels c where c.store_id = s.id), '[]'::jsonb)
      ) order by s.id) from public.stores s), '[]'::jsonb));
end $$;
grant execute on function public.owner_wa_overview() to authenticated;

create or replace function public.owner_wa_set_store(p_store int, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  update public.stores set settings = coalesce(settings, '{}'::jsonb) || jsonb_build_object('wa_enabled', p_on) where id = p_store;
  if not found then raise exception 'المتجر غير موجود'; end if;
end $$;
grant execute on function public.owner_wa_set_store(int, boolean) to authenticated;

create or replace function public.owner_wa_set_all(p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  insert into public.app_settings(key, value) values ('wa_all', to_jsonb(p_on))
  on conflict (key) do update set value = excluded.value;
end $$;
grant execute on function public.owner_wa_set_all(boolean) to authenticated;

-- ربط رقم: يحفظ بيانات القناة، والتوكن (اختياري) في جدول سري
create or replace function public.owner_wa_channel_save(p_store int, p_phone_number_id text, p_waba_id text,
                                                         p_display text, p_token text default null) returns int
language plpgsql security definer set search_path = public as $$
declare v_id int;
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  if coalesce(trim(p_phone_number_id), '') !~ '^[0-9]{5,25}$' then raise exception 'Phone Number ID لازم يكون أرقام فقط'; end if;
  if not exists (select 1 from public.stores where id = p_store) then raise exception 'المتجر غير موجود'; end if;
  insert into public.wa_channels(store_id, phone_number_id, waba_id, display_phone)
  values (p_store, trim(p_phone_number_id), nullif(trim(p_waba_id), ''), nullif(trim(p_display), ''))
  on conflict (phone_number_id) do update
    set store_id = excluded.store_id, waba_id = excluded.waba_id, display_phone = excluded.display_phone, status = 'active'
  returning id into v_id;
  if nullif(trim(p_token), '') is not null then
    insert into public.wa_secrets(channel_id, access_token) values (v_id, trim(p_token))
    on conflict (channel_id) do update set access_token = excluded.access_token, updated_at = now();
  end if;
  return v_id;
end $$;
grant execute on function public.owner_wa_channel_save(int, text, text, text, text) to authenticated;

create or replace function public.owner_wa_channel_delete(p_channel int) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  delete from public.wa_channels where id = p_channel;
end $$;
grant execute on function public.owner_wa_channel_delete(int) to authenticated;

-- ---------- 5) إنشاء الطلب من الشات (للسيرفر فقط) ----------
create or replace function public.wa_create_order(p_session bigint, p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s public.wa_sessions; o public.orders; v_sub numeric := coalesce(nullif(p->>'subtotal','')::numeric, 0);
        v_fee numeric := coalesce(nullif(p->>'shipping_fee','')::numeric, 0);
begin
  select * into s from public.wa_sessions where id = p_session for update;
  if not found then raise exception 'الجلسة غير موجودة'; end if;
  insert into public.orders(store_id, source, customer_name, customer_phone, address_text, lat, lon, items,
                            subtotal, shipping_fee, total, is_cod, cod_method, payment_method, payment_status,
                            customer_note, invoice_number, raw)
  values (s.store_id, 'whatsapp', coalesce(nullif(p->>'customer_name',''), s.name, 'عميل واتساب'), s.wa_id,
          nullif(p->>'address_text',''), nullif(p->>'lat','')::double precision, nullif(p->>'lon','')::double precision,
          coalesce(p->'items', '[]'::jsonb), v_sub, v_fee, v_sub + v_fee, true, null, 'الدفع عند الاستلام', 'pending',
          nullif(p->>'note',''), 'W-' || to_char(now() at time zone 'Asia/Riyadh', 'YYMMDD') || '-' || lpad((s.orders_count + 1)::text, 2, '0') || right(s.wa_id, 3),
          jsonb_build_object('wa_session', s.id, 'wa_id', s.wa_id))
  returning * into o;
  update public.wa_sessions set last_order_id = o.id, last_cart = coalesce(p->'cart', last_cart),
         last_lat = coalesce(nullif(p->>'lat','')::double precision, last_lat),
         last_lon = coalesce(nullif(p->>'lon','')::double precision, last_lon),
         last_address = coalesce(nullif(p->>'address_text',''), last_address),
         orders_count = orders_count + 1, cart = '[]'::jsonb, state = 'idle', ctx = '{}'::jsonb
   where id = s.id;
  return jsonb_build_object('id', o.id, 'invoice', o.invoice_number, 'track_token', o.track_token,
                            'branch_id', o.branch_id, 'routing', o.routing_method);
end $$;
revoke all on function public.wa_create_order(bigint, jsonb) from public, anon, authenticated;
grant execute on function public.wa_create_order(bigint, jsonb) to service_role;

-- هل الموقع ضمن نطاق التوصيل؟ (للسيرفر)
create or replace function public.wa_check_location(p_store int, p_lat double precision, p_lon double precision) returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(public.nearest_branch(p_store, p_lat, p_lon), '{}'::jsonb)
$$;
revoke all on function public.wa_check_location(int, double precision, double precision) from public, anon, authenticated;
grant execute on function public.wa_check_location(int, double precision, double precision) to service_role;

-- ---------- 6) تحديثات الحالة للعميل ----------
create or replace function public.call_wa_function(p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare v_url text; v_key text;
begin
  select value #>> '{}' into v_url from public.app_settings where key = 'functions_url';
  select value #>> '{}' into v_key from public.app_settings where key = 'cron_key';
  if v_url is null or v_key is null then return; end if;
  perform net.http_post(
    url := v_url || '/whatsapp?action=' || p_action,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-key', v_key),
    body := '{}'::jsonb, timeout_milliseconds := 25000);
end $$;
revoke execute on function public.call_wa_function(text) from public, anon, authenticated;

create or replace function public.wa_orders_notify() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.source = 'whatsapp' and new.status in ('preparing','out_for_delivery','delivered','cancelled')
     and (new.raw ->> 'wa_session') is not null then
    insert into public.wa_outbox(store_id, session_id, order_id, status)
    values (new.store_id, (new.raw ->> 'wa_session')::bigint, new.id, new.status)
    on conflict (order_id, status) do nothing;
    perform public.call_wa_function('flush');
  end if;
  return null;
end $$;
drop trigger if exists wa_orders_notify_trg on public.orders;
create trigger wa_orders_notify_trg after update of status on public.orders
  for each row when (new.status is distinct from old.status and new.source = 'whatsapp')
  execute function public.wa_orders_notify();

create or replace function public.wa_housekeeping() returns void
language sql security definer set search_path = public as $$
  delete from public.wa_messages where created_at < now() - interval '30 days';
  delete from public.wa_outbox where created_at < now() - interval '30 days';
$$;
revoke execute on function public.wa_housekeeping() from public, anon, authenticated;

do $$ begin perform cron.unschedule('msar-wa-cron'); exception when others then null; end $$;
do $$ begin perform cron.unschedule('msar-wa-housekeeping'); exception when others then null; end $$;
select cron.schedule('msar-wa-cron', '* * * * *', $$
  select public.call_wa_function('flush') where exists (select 1 from public.wa_outbox where sent_at is null and tries < 5)
$$);
select cron.schedule('msar-wa-housekeeping', '30 0 * * *', $$ select public.wa_housekeeping() $$);

select 'msar migration 014 ok';
