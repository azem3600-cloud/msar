-- =====================================================================
--  022 — تخصيص الطلب في المنيو (شطة/مخلل/مايونيز…): msite.mods
--  Idempotent — شغّله من Supabase (SQL Editor). يتطلب 021 قبله.
-- =====================================================================
create or replace function public._wa_theme(p_store int, p_ms jsonb) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'name', coalesce(nullif(p_ms ->> 'name', ''), (select name from public.stores where id = p_store)),
    'tagline', coalesce(p_ms ->> 'tagline', ''),
    'template', coalesce(nullif(p_ms ->> 'template', ''), 'rest'),
    'color', coalesce(nullif(p_ms ->> 'color', ''), '#144F74'),
    'logo', p_ms ->> 'logo', 'cover', p_ms ->> 'cover',
    'layout', coalesce(p_ms -> 'layout', '{}'::jsonb),
    'offer', coalesce(p_ms -> 'offer', '{}'::jsonb),
    'blocks', coalesce(p_ms -> 'blocks', '[]'::jsonb),
    'mods', coalesce(p_ms -> 'mods', '{}'::jsonb))
$$;
revoke execute on function public._wa_theme(int, jsonb) from public, anon, authenticated;
select 'msar migration 022 ok' as result;
