-- =====================================================================
--  مسار — 008: سجل محادثات المساعد الذكي (يطّلع عليه صاحب المنصة فقط)
-- =====================================================================
create table if not exists public.support_ai_log (
  id bigserial primary key,
  created_at timestamptz not null default now(),
  conv text not null,
  store_id int references public.stores(id) on delete set null,
  store_name text,
  user_id uuid,
  user_name text,
  user_role text,
  page text,
  question text not null,
  answer text,
  mode text,
  escalated boolean not null default false,
  off_topic boolean not null default false,
  had_image boolean not null default false
);
create index if not exists support_ai_log_conv_idx on public.support_ai_log (conv, id);
create index if not exists support_ai_log_created_idx on public.support_ai_log (created_at desc);
create index if not exists support_ai_log_store_idx on public.support_ai_log (store_id, created_at desc);

alter table public.support_ai_log enable row level security;
drop policy if exists support_ai_log_owner_read on public.support_ai_log;
create policy support_ai_log_owner_read on public.support_ai_log for select to authenticated using (public.is_owner());
revoke all on public.support_ai_log from anon;
grant select on public.support_ai_log to authenticated;

-- قائمة المحادثات مجمّعة (لصاحب المنصة)
create or replace function public.owner_ai_convs(p_search text default null, p_filter text default 'all', p_limit int default 150)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare v jsonb; q text := nullif(trim(coalesce(p_search, '')), '');
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  with c as (
    select conv,
      min(created_at) as started_at, max(created_at) as last_at, count(*) as n,
      (array_agg(question order by id))[1] as first_q,
      (array_agg(store_name order by id desc))[1] as store_name,
      (array_agg(store_id order by id desc))[1] as store_id,
      (array_agg(user_name order by id desc))[1] as user_name,
      (array_agg(user_role order by id desc))[1] as user_role,
      bool_or(escalated) as escalated, bool_or(off_topic) as off_topic, bool_or(had_image) as had_image,
      string_agg(question, ' ') as all_q
    from support_ai_log
    where created_at > now() - interval '180 days'
    group by conv
  )
  select coalesce(jsonb_agg(to_jsonb(x) - 'all_q' order by x.last_at desc), '[]'::jsonb) into v
  from (select * from c
        where (q is null or coalesce(store_name, '') ilike '%' || q || '%' or coalesce(user_name, '') ilike '%' || q || '%' or all_q ilike '%' || q || '%')
          and (p_filter = 'all' or (p_filter = 'escalated' and escalated) or (p_filter = 'off' and off_topic))
        order by last_at desc limit greatest(1, least(coalesce(p_limit, 150), 500))) x;
  return v;
end $$;
revoke execute on function public.owner_ai_convs(text, text, int) from public, anon;
grant execute on function public.owner_ai_convs(text, text, int) to authenticated;

-- تنظيف السجلات الأقدم من 180 يوم (يُستدعى من الدالة أحياناً)
create or replace function public.support_ai_log_cleanup() returns void language sql security definer set search_path = public as $$
  delete from support_ai_log where created_at < now() - interval '180 days';
$$;
revoke all on function public.support_ai_log_cleanup() from public, anon, authenticated;
grant execute on function public.support_ai_log_cleanup() to service_role;

select 'msar migration 008 ok' as result;
