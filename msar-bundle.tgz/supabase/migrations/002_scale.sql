-- =====================================================================
--  مسار — ترقية 002: التوسّع والتنظيف والمراقبة (آمنة لإعادة التشغيل)
--  تُشغَّل مرة وحدة بعد schema.sql و cron.sql
-- =====================================================================

-- 1) أعمدة جديدة للمتاجر
alter table public.stores add column if not exists last_synced_at timestamptz;
alter table public.stores add column if not exists uninstalled_at timestamptz;

-- 2) فهارس للتوسّع
create index if not exists stores_sync_due_idx        on public.stores(status, last_synced_at nulls first);
create index if not exists stores_zid_uuid_idx        on public.stores(zid_store_uuid);
create index if not exists driver_locations_at_idx    on public.driver_locations(at);
create index if not exists zid_log_at_only_idx        on public.zid_log(at);
create index if not exists zid_log_errors_idx         on public.zid_log(at) where not ok;
create index if not exists zid_outbox_processed_idx   on public.zid_outbox(done, processed_at);

-- 3) التنظيف اليومي: + حذف بيانات المتاجر اللي حذفت التطبيق من 90 يوم (حسب سياسة الخصوصية)
create or replace function public.housekeeping() returns void
language plpgsql security definer set search_path = public as $$
declare r record;
begin
  delete from public.driver_locations where at < now() - interval '90 days';
  delete from public.zid_log where at < now() - interval '30 days';
  delete from public.zid_outbox where done and processed_at < now() - interval '30 days';
  update public.profiles set is_online = false
   where role = 'driver' and is_online and coalesce(last_seen_at, now() - interval '1 day') < now() - interval '30 minutes';
  update public.stores set status = 'suspended' where status = 'trial' and trial_ends_at < now() - interval '3 days' and plan is null;

  for r in select id, code from public.stores
            where status = 'uninstalled' and coalesce(uninstalled_at, now()) < now() - interval '90 days'
  loop
    delete from public.driver_locations where store_id = r.id;
    delete from auth.users where email like '%@' || r.code || '.msar.app';
    delete from public.stores where id = r.id;   -- يحذف الفروع والطلبات والسجل بالتتابع
  end loop;
end $$;
revoke execute on function public.housekeeping() from public, anon, authenticated;

-- 4) صحة النظام لصاحب المنصة
create or replace function public.owner_health() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  return jsonb_build_object(
    'cron_last_run', (select value #>> '{}' from public.app_settings where key = 'cron_last_run'),
    'outbox_pending', (select count(*) from public.zid_outbox where not done),
    'outbox_stuck', (select count(*) from public.zid_outbox where not done and created_at < now() - interval '10 minutes'),
    'errors_1h', (select count(*) from public.zid_log where not ok and at > now() - interval '1 hour'),
    'errors_24h', (select count(*) from public.zid_log where not ok and at > now() - interval '1 day'),
    'stores_never_synced', (select count(*) from public.stores where status in ('trial','active') and last_synced_at is null),
    'stores_sync_late', (select count(*) from public.stores where status in ('trial','active') and last_synced_at < now() - interval '2 hours'),
    'db_size_mb', (select round(pg_database_size(current_database()) / 1048576.0)),
    'driver_locations_rows', (select greatest(reltuples, 0)::bigint from pg_class where oid = 'public.driver_locations'::regclass));
end $$;
grant execute on function public.owner_health() to authenticated;

select 'msar migration 002 ok' as result;
