-- =====================================================================
-- مسار — ترقية 012: إشعارات Push للمندوب (تعمل حتى لو التطبيق مقفول)
--   push_tokens: توكنات أجهزة المناديب (FCM) — للسيرفر فقط، بدون سياسات RLS
--   driver_register_push / driver_unregister_push: يسجّلها التطبيق بعد تسجيل الدخول
--   trigger على orders: عند إسناد طلب لمندوب (status = assigned) ننادي دالة push
--   آمنة لإعادة التشغيل. لا تؤثر على أي طلب لو فشل الإرسال (الـ trigger يبلع الأخطاء).
-- =====================================================================
create extension if not exists pg_net;

create table if not exists public.push_tokens (
  token       text primary key,
  user_id     uuid not null,
  store_id    bigint,
  platform    text not null default 'android',
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists push_tokens_user_idx on public.push_tokens(user_id);
alter table public.push_tokens enable row level security;
revoke all on public.push_tokens from anon, authenticated;

-- المندوب يسجّل جهازه (يحذف نفس التوكن لو كان لمستخدم آخر: نفس الجوال تغيّر عليه الحساب)
create or replace function public.driver_register_push(p_token text, p_platform text default 'android')
returns void language plpgsql security definer set search_path = public as $$
declare p public.profiles;
begin
  if auth.uid() is null then raise exception 'غير مصرح'; end if;
  if p_token is null or length(p_token) < 20 or length(p_token) > 4096 then raise exception 'توكن غير صالح'; end if;
  select * into p from public.profiles where id = auth.uid() and is_active;
  if not found then raise exception 'غير مصرح'; end if;
  insert into public.push_tokens(token, user_id, store_id, platform, updated_at)
  values (p_token, auth.uid(), p.store_id, coalesce(p_platform, 'android'), now())
  on conflict (token) do update
    set user_id = excluded.user_id, store_id = excluded.store_id, platform = excluded.platform, updated_at = now();
end $$;

create or replace function public.driver_unregister_push(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  delete from public.push_tokens where token = p_token and user_id = auth.uid();
end $$;

grant execute on function public.driver_register_push(text, text) to authenticated;
grant execute on function public.driver_unregister_push(text) to authenticated;

-- نداء عام لأي دالة Edge بمفتاح الـ cron (نفس آلية call_zid_function)
create or replace function public.call_edge_function(p_path text, p_body jsonb default '{}'::jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare v_url text; v_key text;
begin
  select value #>> '{}' into v_url from public.app_settings where key = 'functions_url';
  select value #>> '{}' into v_key from public.app_settings where key = 'cron_key';
  if v_url is null or v_key is null then return; end if;
  perform net.http_post(
    url := v_url || '/' || p_path,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-key', v_key),
    body := p_body,
    timeout_milliseconds := 20000);
end $$;
revoke execute on function public.call_edge_function(text, jsonb) from public, anon, authenticated;

-- عند إسناد طلب لمندوب ننبّه جواله
create or replace function public.orders_notify_driver() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'assigned' and new.driver_id is not null
     and (tg_op = 'INSERT' or old.driver_id is distinct from new.driver_id or old.status is distinct from new.status)
     and exists (select 1 from public.push_tokens t where t.user_id = new.driver_id) then
    perform public.call_edge_function('push', jsonb_build_object('kind', 'new_order', 'order_id', new.id, 'driver_id', new.driver_id));
  end if;
  return null;
exception when others then
  return null; -- الإشعار ما يوقف تحديث الطلب أبداً
end $$;

drop trigger if exists orders_notify_driver_trg on public.orders;
create trigger orders_notify_driver_trg after insert or update of driver_id, status on public.orders
  for each row execute function public.orders_notify_driver();

-- حذف توكنات قديمة (أكثر من 90 يوم بدون تحديث) مع الصيانة اليومية
do $$ begin perform cron.unschedule('msar-push-tokens-clean'); exception when others then null; end $$;
select cron.schedule('msar-push-tokens-clean', '30 0 * * *', $$ delete from public.push_tokens where updated_at < now() - interval '90 days' $$);

select 'msar migration 012 ok';
