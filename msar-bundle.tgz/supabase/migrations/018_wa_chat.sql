-- مسار: تطوير محادثات الواتساب (إيقاف البوت لكل شخص، غير مقروء، صور/ملفات، ردود سريعة، حالة التسليم)
alter table public.wa_sessions add column if not exists bot_paused_until timestamptz;
alter table public.wa_sessions add column if not exists unread int not null default 0;
alter table public.wa_sessions add column if not exists note text;
alter table public.wa_messages add column if not exists sender_name text;
alter table public.wa_messages add column if not exists status text;
create index if not exists wa_messages_wamid_idx on public.wa_messages(wamid) where wamid is not null;

grant update (human, bot_paused_until, unread, note) on public.wa_sessions to authenticated;

create table if not exists public.wa_quick (
  id       serial primary key,
  store_id int not null references public.stores(id) on delete cascade,
  title    text not null,
  body     text not null,
  sort     int not null default 0
);
create index if not exists wa_quick_store_idx on public.wa_quick(store_id, sort);
alter table public.wa_quick enable row level security;
revoke all on public.wa_quick from anon;
drop policy if exists wa_quick_sel on public.wa_quick;
create policy wa_quick_sel on public.wa_quick for select to authenticated
  using (public.is_owner() or (store_id = public.my_store() and public.my_role() in ('admin','cashier') and public.wa_enabled_for(store_id)));
drop policy if exists wa_quick_mod on public.wa_quick;
create policy wa_quick_mod on public.wa_quick for all to authenticated
  using (public.is_owner() or (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id)))
  with check (public.is_owner() or (store_id = public.my_store() and public.is_admin() and public.wa_enabled_for(store_id)));
grant select, insert, update, delete on public.wa_quick to authenticated;
grant usage, select on sequence public.wa_quick_id_seq to authenticated;
