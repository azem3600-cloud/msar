-- =====================================================================
-- مسار — ترقية 007: لوحة صاحب المنصة (إدارة العملاء)
--   * ملاحظات ووسوم ومتابعة لكل متجر
--   * مؤشرات الاشتراكات: الدخل الشهري المتكرر (MRR)، التجارب، الإلغاءات
--   * تفاصيل متجر: الفريق، آخر دخول، الطلبات اليومية، السجل، التذاكر
-- آمنة لإعادة التشغيل
-- =====================================================================
alter table public.stores add column if not exists owner_note text;
alter table public.stores add column if not exists owner_tags text[] not null default '{}';
alter table public.stores add column if not exists owner_followup date;

-- أسعار الباقات الشهرية (قابلة للتغيير من app_settings.plan_prices)
create or replace function public.plan_price(p_plan text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(
    ((select value from public.app_settings where key = 'plan_prices') ->> coalesce(p_plan, 'starter'))::numeric,
    case coalesce(p_plan, 'starter') when 'starter' then 99 when 'growth' then 149 when 'pro' then 399 else 0 end)
$$;

-- هل المتجر مشترك مدفوع حالياً؟
create or replace function public.store_is_paying(s public.stores) returns boolean
language sql stable as $$
  select s.status = 'active' and s.plan is not null
     and coalesce(lower(s.plan_status), 'active') not in ('trial','expired','cancelled','canceled','suspended','refunded')
$$;

create or replace function public.owner_overview2() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  select jsonb_build_object(
    'stores', coalesce((select jsonb_agg(x order by (x->>'id')::int desc) from (
      select jsonb_build_object(
        'id', s.id, 'code', s.code, 'name', s.name, 'status', s.status, 'plan', s.plan,
        'plan_status', s.plan_status, 'plan_ends_at', s.plan_ends_at, 'plan_checked_at', s.plan_checked_at,
        'price', public.plan_price(s.plan), 'paying', public.store_is_paying(s),
        'store_url', s.store_url, 'zid_store_id', s.zid_store_id, 'trial_ends_at', s.trial_ends_at,
        'installed_at', s.installed_at, 'uninstalled_at', s.uninstalled_at, 'created_at', s.created_at, 'logo_url', s.logo_url, 'owner_email', s.owner_email, 'owner_phone', s.owner_phone,
        'owner_note', s.owner_note, 'owner_tags', to_jsonb(s.owner_tags), 'owner_followup', s.owner_followup,
        'zid_connected', coalesce((select zid_tokens ? 'access_token' from public.store_secrets where store_id = s.id), false),
        'push_status', coalesce(s.settings->'push_status', 'false'::jsonb),
        'last_synced_at', s.last_synced_at,
        'branches', (select count(*) from public.branches b where b.store_id = s.id),
        'drivers',  (select count(*) from public.store_members m where m.store_id = s.id and m.role = 'driver' and m.is_active),
        'staff',    (select count(*) from public.store_members m where m.store_id = s.id and m.is_active),
        'has_admin', exists(select 1 from public.store_members m where m.store_id = s.id and m.role = 'admin'),
        'admin_name', (select m.full_name from public.store_members m where m.store_id = s.id and m.role = 'admin' order by m.created_at limit 1),
        'admin_email', (select u.email from public.store_members m join auth.users u on u.id = m.user_id
                         where m.store_id = s.id and m.role = 'admin' and u.email not like '%.msar.app' order by m.created_at limit 1),
        'last_login_at', (select max(u.last_sign_in_at) from public.store_members m join auth.users u on u.id = m.user_id where m.store_id = s.id),
        'orders_today', (select count(*) from public.orders o where o.store_id = s.id and o.order_created_at > now() - interval '1 day'),
        'orders_7d',    (select count(*) from public.orders o where o.store_id = s.id and o.order_created_at > now() - interval '7 days'),
        'orders_30d',   (select count(*) from public.orders o where o.store_id = s.id and o.order_created_at > now() - interval '30 days'),
        'delivered_30d',(select count(*) from public.orders o where o.store_id = s.id and o.status = 'delivered' and o.order_created_at > now() - interval '30 days'),
        'gmv_30d',      (select coalesce(sum(o.total), 0) from public.orders o where o.store_id = s.id and o.status <> 'cancelled' and o.order_created_at > now() - interval '30 days'),
        'last_order_at', (select max(order_created_at) from public.orders o where o.store_id = s.id),
        'errors_24h', (select count(*) from public.zid_log l where l.store_id = s.id and not l.ok and l.at > now() - interval '1 day'),
        'open_tickets', (select count(*) from public.support_tickets t where t.store_id = s.id and t.status <> 'closed')) x
      from public.stores s) t), '[]'::jsonb),
    'totals', jsonb_build_object(
      'stores', (select count(*) from public.stores where status <> 'uninstalled'),
      'active', (select count(*) from public.stores where status = 'active'),
      'trial',  (select count(*) from public.stores where status = 'trial' or lower(coalesce(plan_status,'')) = 'trial'),
      'suspended', (select count(*) from public.stores where status = 'suspended'),
      'uninstalled', (select count(*) from public.stores where status = 'uninstalled'),
      'paying', (select count(*) from public.stores s where public.store_is_paying(s)),
      'mrr',    (select coalesce(sum(public.plan_price(s.plan)), 0) from public.stores s where public.store_is_paying(s)),
      'by_plan', (select coalesce(jsonb_object_agg(p, n), '{}'::jsonb) from (select coalesce(plan, 'none') p, count(*) n from public.stores where status in ('active','trial') group by 1) q),
      'trials_ending_7d', (select count(*) from public.stores where status = 'trial' and trial_ends_at between now() and now() + interval '7 days'),
      'new_30d', (select count(*) from public.stores where coalesce(installed_at, created_at) > now() - interval '30 days'),
      'churn_30d', (select count(*) from public.stores where status = 'uninstalled' and coalesce(uninstalled_at, created_at) > now() - interval '30 days'),
      'orders_today', (select count(*) from public.orders where order_created_at > now() - interval '1 day'),
      'orders_30d', (select count(*) from public.orders where order_created_at > now() - interval '30 days'),
      'gmv_30d', (select coalesce(sum(total), 0) from public.orders where status <> 'cancelled' and order_created_at > now() - interval '30 days'),
      'drivers', (select count(*) from public.store_members where role = 'driver' and is_active),
      'open_tickets', (select count(*) from public.support_tickets where status <> 'closed'),
      'new_leads', (select count(*) from public.site_leads where coalesce(status, 'new') = 'new')),
    'orders_daily', (select coalesce(jsonb_agg(jsonb_build_object('d', d::date, 'n', n) order by d), '[]'::jsonb) from (
        select g d, (select count(*) from public.orders o where o.order_created_at >= (g at time zone 'Asia/Riyadh') and o.order_created_at < ((g + interval '1 day') at time zone 'Asia/Riyadh')) n
        from generate_series(date_trunc('day', now() at time zone 'Asia/Riyadh') - interval '29 days', date_trunc('day', now() at time zone 'Asia/Riyadh'), interval '1 day') g) z),
    'zid_client_id', (select value #>> '{}' from public.app_settings where key = 'zid_client_id'),
    'zid_client_secret_set', exists(select 1 from public.app_settings where key = 'zid_client_secret' and coalesce(value #>> '{}','') <> ''),
    'web_url', (select value #>> '{}' from public.app_settings where key = 'web_url'))
  into r;
  return r;
end $$;

-- تفاصيل متجر واحد
create or replace function public.owner_store_detail(p_id int) returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  return jsonb_build_object(
    'team', coalesce((select jsonb_agg(jsonb_build_object(
        'name', m.full_name, 'role', m.role, 'active', m.is_active, 'phone', m.phone, 'username', m.username,
        'email', case when u.email like '%.msar.app' then null else u.email end,
        'last_login_at', u.last_sign_in_at, 'created_at', m.created_at,
        'branch', (select b.name from public.branches b where b.id = m.branch_id)) order by m.role, m.created_at)
      from public.store_members m left join auth.users u on u.id = m.user_id where m.store_id = p_id), '[]'::jsonb),
    'branches', coalesce((select jsonb_agg(jsonb_build_object('name', b.name, 'city', b.city, 'active', b.is_active) order by b.id)
      from public.branches b where b.store_id = p_id), '[]'::jsonb),
    'orders_daily', (select coalesce(jsonb_agg(jsonb_build_object('d', g::date, 'n',
        (select count(*) from public.orders o where o.store_id = p_id and o.order_created_at >= (g at time zone 'Asia/Riyadh') and o.order_created_at < ((g + interval '1 day') at time zone 'Asia/Riyadh'))) order by g), '[]'::jsonb)
      from generate_series(date_trunc('day', now() at time zone 'Asia/Riyadh') - interval '29 days', date_trunc('day', now() at time zone 'Asia/Riyadh'), interval '1 day') g),
    'status_30d', (select coalesce(jsonb_object_agg(status, n), '{}'::jsonb) from (select status, count(*) n from public.orders
      where store_id = p_id and order_created_at > now() - interval '30 days' group by status) q),
    'logs', coalesce((select jsonb_agg(row_to_json(l)) from (select at, kind, ok, message from public.zid_log
      where store_id = p_id order by at desc limit 25) l), '[]'::jsonb),
    'tickets', coalesce((select jsonb_agg(row_to_json(t)) from (select id, subject, status, updated_at, user_name from public.support_tickets
      where store_id = p_id order by updated_at desc limit 15) t), '[]'::jsonb));
end $$;

-- ملاحظات صاحب المنصة على المتجر
create or replace function public.owner_store_note(p_id int, p_note text, p_tags text[], p_followup date) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  update public.stores set
    owner_note = nullif(left(coalesce(p_note, ''), 4000), ''),
    owner_tags = coalesce((select array_agg(distinct left(trim(t), 30)) from unnest(coalesce(p_tags, '{}')) t where trim(t) <> ''), '{}'),
    owner_followup = p_followup
  where id = p_id;
end $$;

revoke execute on function public.owner_overview2() from anon;
revoke execute on function public.owner_store_detail(int) from anon;
revoke execute on function public.owner_store_note(int, text, text[], date) from anon;
revoke execute on function public.plan_price(text) from anon;


-- =====================================================================
-- رابط تتبع للعميل (باقتي النمو والاحترافية): صفحة عامة msarpro.com/track?t=…
-- =====================================================================
alter table public.orders add column if not exists track_token text;
update public.orders set track_token = replace(gen_random_uuid()::text, '-', '') where track_token is null;
alter table public.orders alter column track_token set default replace(gen_random_uuid()::text, '-', '');
create unique index if not exists orders_track_token_uq on public.orders(track_token);

create or replace function public.track_order(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare o public.orders; s public.stores; b public.branches; d public.profiles; live boolean; fresh boolean;
begin
  if p_token is null or p_token !~ '^[a-f0-9]{24,40}$' then return jsonb_build_object('ok', false, 'error', 'invalid'); end if;
  select * into o from public.orders where track_token = p_token;
  if not found then return jsonb_build_object('ok', false, 'error', 'not_found'); end if;
  select * into s from public.stores where id = o.store_id;
  if s.status not in ('trial', 'active') then return jsonb_build_object('ok', false, 'error', 'inactive'); end if;
  live := coalesce((public.store_plan(o.store_id) ->> 'live')::boolean, false);
  if not live then return jsonb_build_object('ok', false, 'error', 'plan', 'store', s.name); end if;
  if o.order_created_at < now() - interval '7 days'
     or (o.delivered_at is not null and o.delivered_at < now() - interval '1 day')
     or (o.cancelled_at is not null and o.cancelled_at < now() - interval '1 day') then
    return jsonb_build_object('ok', false, 'error', 'expired', 'store', s.name);
  end if;
  select * into b from public.branches where id = o.branch_id;
  select * into d from public.profiles where id = o.driver_id;
  fresh := d.id is not null and o.status = 'out_for_delivery' and d.last_location_at > now() - interval '10 minutes';
  return jsonb_build_object('ok', true,
    'store', s.name, 'logo', s.logo_url, 'store_url', s.store_url,
    'number', coalesce(o.invoice_number, o.zid_order_id::text, o.id::text),
    'status', o.status, 'items_count', o.items_count, 'total', o.total, 'is_cod', o.is_cod, 'cod_amount', o.cod_amount,
    'times', jsonb_build_object('received', o.received_at, 'preparing', o.preparing_at, 'ready', o.ready_at, 'assigned', o.assigned_at,
                                'picked_up', o.picked_up_at, 'delivered', o.delivered_at, 'cancelled', o.cancelled_at),
    'branch', b.name, 'branch_phone', b.phone,
    'driver', case when d.id is not null and o.status in ('assigned', 'out_for_delivery', 'delivered') then jsonb_build_object(
        'name', split_part(coalesce(d.full_name, ''), ' ', 1),
        'lat', case when fresh then d.last_lat end, 'lon', case when fresh then d.last_lon end,
        'at', case when fresh then d.last_location_at end) end,
    'dest', case when o.status = 'out_for_delivery' then jsonb_build_object('lat', coalesce(o.delivery_lat, o.lat), 'lon', coalesce(o.delivery_lon, o.lon)) end,
    'distance_km', case when fresh and coalesce(o.delivery_lat, o.lat) is not null
        then round(public.haversine_km(d.last_lat, d.last_lon, coalesce(o.delivery_lat, o.lat), coalesce(o.delivery_lon, o.lon))::numeric, 1) end,
    'now', now());
end $$;
grant execute on function public.track_order(text) to anon, authenticated;

select 'msar migration 007 ok' as result;
