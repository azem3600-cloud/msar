-- مسار — ترقية 003: تصحيح أوقات الطلبات (زد يرجّع الوقت UTC بدون علامة المنطقة) — آمنة لإعادة التشغيل
update public.orders
   set order_created_at = (replace(raw->>'created_at', ' ', 'T') || 'Z')::timestamptz
 where raw->>'created_at' ~ '^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$'
   and order_created_at is distinct from (replace(raw->>'created_at', ' ', 'T') || 'Z')::timestamptz;
select 'msar migration 003 ok' as result, count(*) as orders from public.orders;
