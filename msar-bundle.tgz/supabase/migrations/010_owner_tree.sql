-- =====================================================================
--  مسار — ترقية 010: شجرة العملاء لصاحب المنصة
--  دالة واحدة ترجع كل المتاجر ← الفروع (مع الكاشيرين) ← المناديب في استدعاء واحد.
--  مصممة للسرعة: مرور واحد على الطلبات (grouping sets) وتجميع الأعضاء مرة وحدة،
--  ومفاتيح JSON مختصرة عشان حجم الرد يبقى صغير مع مئات المتاجر.
--  آمنة لإعادة التشغيل. تُشغَّل بعد 009.
--
--  شكل الرد: { generated_at, stores: [ { id, name, code, logo_url, status, plan, platform, installed_at,
--     oo (طلبات مفتوحة), o30 (طلبات 30 يوم), admins:[عضو], branches:[ { id, name, city, active, oo, o30, cashiers:[عضو], drivers:[عضو] } ],
--     un: { cashiers:[عضو], drivers:[عضو] } (بدون فرع) } ] }
--  العضو: { i (id), n (الاسم), p (جوال), e (إيميل), v (مركبة), a (نشط), ll (آخر دخول),
--           on (متصل — للمندوب), ls (آخر ظهور — للمندوب), bz (طلبات بيده الآن), d30 (وصّلها خلال 30 يوم) }
-- =====================================================================

create or replace function public.owner_org_tree() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare res jsonb;
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;

  with o as (                                  -- مرور واحد على الطلبات الحيّة/الحديثة
    select store_id, branch_id, driver_id,
           count(*) filter (where status not in ('delivered','cancelled')) as oo,
           count(*) filter (where order_created_at > now() - interval '30 days') as o30,
           count(*) filter (where status in ('assigned','out_for_delivery')) as bz,
           count(*) filter (where status = 'delivered' and order_created_at > now() - interval '30 days') as d30
      from public.orders
     where status not in ('delivered','cancelled') or order_created_at > now() - interval '30 days'
     group by grouping sets ((store_id), (branch_id), (driver_id))
  ), m as (                                    -- كل الأعضاء مرة وحدة
    select sm.store_id, sm.user_id, sm.role, sm.branch_id, sm.full_name, sm.is_active, sm.created_at,
           case when p.store_id = sm.store_id then coalesce(p.is_online, false) else false end as is_online,
           jsonb_strip_nulls(jsonb_build_object(
             'i', sm.user_id, 'n', sm.full_name, 'p', sm.phone, 'v', sm.vehicle, 'a', sm.is_active,
             'e', case when u.email like '%.msar.app' then null else u.email end,
             'll', date_trunc('second', u.last_sign_in_at),
             'on', case when sm.role = 'driver' then (case when p.store_id = sm.store_id then coalesce(p.is_online, false) else false end) end,
             'ls', case when sm.role = 'driver' and p.store_id = sm.store_id then date_trunc('second', p.last_seen_at) end,
             'bz', case when sm.role = 'driver' then coalesce(od.bz, 0) end,
             'd30', case when sm.role = 'driver' then coalesce(od.d30, 0) end)) as j
      from public.store_members sm
      left join auth.users u on u.id = sm.user_id
      left join public.profiles p on p.id = sm.user_id
      left join o od on od.driver_id = sm.user_id and od.store_id is null and od.branch_id is null
  ), agg as (                                  -- الأعضاء مجمّعين حسب (المتجر، الفرع، الدور)
    select store_id, case when role = 'admin' then null else branch_id end as branch_id, role,
           jsonb_agg(j order by is_active desc, is_online desc, full_name) as arr
      from m group by 1, 2, 3
  ), br as (                                   -- الفروع مع كاشيريها ومناديبها
    select b.store_id, jsonb_agg(jsonb_build_object(
             'id', b.id, 'name', b.name, 'city', b.city, 'active', b.is_active,
             'oo', coalesce(ob.oo, 0), 'o30', coalesce(ob.o30, 0),
             'cashiers', coalesce(ac.arr, '[]'::jsonb), 'drivers', coalesce(ad.arr, '[]'::jsonb))
             order by b.is_active desc, b.id) as arr
      from public.branches b
      left join o ob on ob.branch_id = b.id and ob.store_id is null and ob.driver_id is null
      left join agg ac on ac.store_id = b.store_id and ac.branch_id = b.id and ac.role = 'cashier'
      left join agg ad on ad.store_id = b.store_id and ad.branch_id = b.id and ad.role = 'driver'
     group by b.store_id
  )
  select coalesce(jsonb_agg(jsonb_build_object(
      'id', s.id, 'name', s.name, 'code', s.code, 'logo_url', s.logo_url, 'status', s.status, 'plan', s.plan,
      'platform', coalesce(s.platform, 'zid'), 'installed_at', coalesce(s.installed_at, s.created_at),
      'oo', coalesce(os.oo, 0), 'o30', coalesce(os.o30, 0),
      'admins',   coalesce(aa.arr, '[]'::jsonb),
      'branches', coalesce(br.arr, '[]'::jsonb),
      'un', jsonb_build_object('cashiers', coalesce(uc.arr, '[]'::jsonb), 'drivers', coalesce(ud.arr, '[]'::jsonb))
    ) order by (s.status = 'uninstalled'), s.name), '[]'::jsonb)
    into res
    from public.stores s
    left join o   os on os.store_id = s.id and os.branch_id is null and os.driver_id is null
    left join agg aa on aa.store_id = s.id and aa.branch_id is null and aa.role = 'admin'
    left join agg uc on uc.store_id = s.id and uc.branch_id is null and uc.role = 'cashier'
    left join agg ud on ud.store_id = s.id and ud.branch_id is null and ud.role = 'driver'
    left join br      on br.store_id = s.id;

  return jsonb_build_object('generated_at', now(), 'stores', res);
end $$;

revoke execute on function public.owner_org_tree() from anon;
grant  execute on function public.owner_org_tree() to authenticated;

select 'msar migration 010 ok' as result;
