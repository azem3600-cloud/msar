-- =====================================================================
--  مسار — 009: دعم منصة سلة (Salla) بجانب زد
--  - stores.platform + salla_merchant_id ، store_secrets.salla_tokens
--  - مصدر الطلب 'salla' ، صف الإرسال zid_outbox صار لكل منصة (عمود platform)
--  - دوال: رابط إعداد من صاحب المنصة، وربط حساب التاجر بإيميل متجر سلة
-- =====================================================================
alter table public.stores add column if not exists platform text not null default 'zid';
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'stores_platform_chk') then
    alter table public.stores add constraint stores_platform_chk check (platform in ('zid','salla'));
  end if;
end $$;
alter table public.stores add column if not exists salla_merchant_id bigint;
create unique index if not exists stores_salla_merchant_uidx on public.stores(salla_merchant_id) where salla_merchant_id is not null;
alter table public.store_secrets add column if not exists salla_tokens jsonb;

-- مصدر الطلب يقبل سلة
do $$ declare c text; begin
  for c in select conname from pg_constraint where conrelid = 'public.orders'::regclass and contype = 'c' and pg_get_constraintdef(oid) ilike '%source%' loop
    execute format('alter table public.orders drop constraint %I', c);
  end loop;
  alter table public.orders add constraint orders_source_check check (source in ('zid','salla','manual'));
end $$;

alter table public.zid_outbox add column if not exists platform text not null default 'zid';
create index if not exists zid_outbox_platform_idx on public.zid_outbox(platform, done, id);

create or replace function public.orders_after_write() returns trigger
language plpgsql security definer set search_path = public as $$
declare z text;
begin
  if tg_op = 'INSERT' then
    insert into public.order_events(order_id, actor_id, actor_name, type, to_status, note)
    values (new.id, auth.uid(), public.my_name(), 'created', new.status,
            case new.routing_method
              when 'nearest' then 'تم التوجيه تلقائياً لأقرب فرع (' || coalesce(new.distance_km::text, '?') || ' كم)'
              when 'out_of_range' then 'العميل خارج نطاق التوجيه التلقائي (أقرب فرع ' || coalesce(new.distance_km::text, '?') || ' كم) — بانتظار توجيه الإدارة'
              when 'none' then 'لا توجد إحداثيات للعميل — بانتظار توجيه الإدارة'
              else 'تم تحديد الفرع يدوياً' end);
    return new;
  end if;

  if new.status is distinct from old.status then
    insert into public.order_events(order_id, actor_id, actor_name, type, from_status, to_status)
    values (new.id, auth.uid(), public.my_name(), 'status', old.status, new.status);
    if new.source in ('zid','salla') and new.zid_order_id is not null
       and coalesce(current_setting('msar.from_zid', true), '') <> '1' then
      z := case new.status
             when 'preparing' then 'preparing' when 'ready' then 'ready'
             when 'out_for_delivery' then 'indelivery' when 'delivered' then 'delivered'
             when 'cancelled' then 'cancelled' else null end;
      if z is not null and coalesce(public.store_setting(new.store_id, 'push_status')::text, 'false') = 'true' then
        insert into public.zid_outbox(store_id, order_id, zid_order_id, zid_status, platform)
        values (new.store_id, new.id, new.zid_order_id, z, new.source);
      end if;
    end if;
  end if;

  if new.branch_id is distinct from old.branch_id then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (new.id, auth.uid(), public.my_name(), 'reroute',
            case when old.branch_id is null then 'تم التوجيه إلى ' else 'تحويل من ' || coalesce((select name from public.branches where id = old.branch_id), '—') || ' إلى ' end
            || coalesce((select name from public.branches where id = new.branch_id), '—'));
  end if;

  if new.driver_id is distinct from old.driver_id and new.driver_id is not null then
    insert into public.order_events(order_id, actor_id, actor_name, type, note)
    values (new.id, auth.uid(), public.my_name(), 'dispatch',
            'أُسند للمندوب: ' || coalesce((select full_name from public.profiles where id = new.driver_id), '?'));
  end if;
  return new;
end $$;

create or replace function public.zid_upsert_order(p_store int, p jsonb, p_force boolean default false)
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_status text; v_zs text := lower(coalesce(p->>'zid_status',''));
        v_import jsonb; v_new boolean := false;
begin
  perform set_config('msar.from_zid', '1', true);
  select id, status into v_id, v_status from public.orders
   where store_id = p_store and zid_order_id = (p->>'zid_order_id')::bigint;
  if v_id is null then
    v_import := coalesce(public.store_setting(p_store, 'import_statuses'), '["new","preparing","ready"]'::jsonb);
    if not p_force and not (v_import ? v_zs) then
      return jsonb_build_object('skipped', true, 'reason', 'status ' || v_zs);
    end if;
    insert into public.orders(store_id, source, zid_order_id, invoice_number, customer_name, customer_phone, customer_email,
        address_text, district, city, short_address, lat, lon, items, subtotal, shipping_fee, total, currency,
        payment_method, payment_status, is_cod, shipping_method, customer_note, zid_status, order_created_at, raw)
    values (p_store, case when p->>'source' = 'salla' then 'salla' else 'zid' end, (p->>'zid_order_id')::bigint, p->>'invoice_number', p->>'customer_name', p->>'customer_phone',
        p->>'customer_email', p->>'address_text', p->>'district', p->>'city', p->>'short_address',
        nullif(p->>'lat','')::double precision, nullif(p->>'lon','')::double precision,
        coalesce(p->'items','[]'::jsonb), nullif(p->>'subtotal','')::numeric, nullif(p->>'shipping_fee','')::numeric,
        coalesce(nullif(p->>'total','')::numeric, 0), coalesce(p->>'currency','SAR'),
        p->>'payment_method', p->>'payment_status', coalesce((p->>'is_cod')::boolean, false),
        p->>'shipping_method', p->>'customer_note', v_zs,
        coalesce(nullif(p->>'order_created_at','')::timestamptz, now()), p->'raw')
    returning id into v_id;
    v_new := true;
    if v_zs in ('preparing','ready') then update public.orders set status = v_zs where id = v_id; end if;
  else
    update public.orders set
      zid_status = v_zs,
      payment_status = coalesce(p->>'payment_status', payment_status),
      status = case
        when v_zs = 'cancelled' and status not in ('delivered','cancelled') then 'cancelled'
        when v_zs = 'delivered' and status not in ('delivered','cancelled') then 'delivered'
        else status end,
      cancel_reason = case when v_zs = 'cancelled' and status <> 'cancelled' then case when p->>'source' = 'salla' then 'أُلغي من سلة' else 'أُلغي من زد' end else cancel_reason end,
      raw = coalesce(p->'raw', raw)
    where id = v_id;
  end if;
  return jsonb_build_object('id', v_id, 'new', v_new);
end $$;

create or replace function public.admin_get_settings() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s public.stores; t jsonb; st jsonb;
begin
  if not public.is_admin() then raise exception 'غير مصرح'; end if;
  select * into s from public.stores where id = public.my_store();
  select zid_tokens, salla_tokens into t, st from public.store_secrets where store_id = s.id;
  return s.settings || jsonb_build_object(
    'store_id', s.id, 'store_code', s.code, 'store_name', s.name, 'store_url', s.store_url, 'status', s.status,
    'trial_ends_at', s.trial_ends_at, 'zid_store_id', s.zid_store_id,
    'zid_connected', coalesce(t ? 'access_token', false),
    'zid_connected_at', t->>'obtained_at',
    'zid_last_sync', (select max(at) from public.zid_log where store_id = s.id and kind in ('sync','webhook') and ok),
    'zid_outbox_pending', (select count(*) from public.zid_outbox where store_id = s.id and not done and attempts < 5),
    'zid_outbox_failed', (select count(*) from public.zid_outbox where store_id = s.id and not done and attempts >= 5),
    'zid_outbox_sent_today', (select count(*) from public.zid_outbox where store_id = s.id and done and processed_at > now() - interval '1 day'),
    'radius_km', public.route_radius(s.id),
    'push_status', coalesce(s.settings->'push_status', 'false'::jsonb),
    'platform', s.platform, 'salla_merchant_id', s.salla_merchant_id,
    'salla_connected', coalesce(st ? 'access_token', false), 'salla_connected_at', st->>'obtained_at');
end $$;

create or replace function public.my_store_info() returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('id', s.id, 'code', s.code, 'name', s.name, 'store_url', s.store_url, 'logo_url', s.logo_url,
                            'status', s.status, 'trial_ends_at', s.trial_ends_at, 'radius_km', public.route_radius(s.id),
                            'has_branches', exists(select 1 from public.branches b where b.store_id = s.id), 'platform', s.platform)
  from public.stores s where s.id = public.my_store()
$$;


-- رابط إعداد حساب المدير (يولّده صاحب المنصة لمتجر ما له مدير بعد)
create or replace function public.owner_setup_link(p_store int) returns text
language plpgsql security definer set search_path = public as $$
declare tok text;
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  select setup_token into tok from public.store_secrets where store_id = p_store and setup_expires > now() + interval '1 day';
  if tok is null then
    tok := encode(gen_random_bytes(24), 'hex');
    insert into public.store_secrets(store_id, setup_token, setup_expires, updated_at) values (p_store, tok, now() + interval '7 days', now())
    on conflict (store_id) do update set setup_token = excluded.setup_token, setup_expires = excluded.setup_expires, updated_at = now();
  end if;
  return tok;
end $$;
revoke execute on function public.owner_setup_link(int) from public, anon;
grant execute on function public.owner_setup_link(int) to authenticated;

-- إعدادات صاحب المنصة: نسمح بمفاتيح سلة
create or replace function public.owner_set_setting(p_key text, p_value jsonb) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  if p_key not in ('zid_client_id','zid_client_secret','web_url','salla_client_id','salla_client_secret','salla_webhook_secret','salla_app_id') then raise exception 'إعداد غير معروف'; end if;
  insert into public.app_settings(key, value, updated_at) values (p_key, p_value, now())
  on conflict (key) do update set value = excluded.value, updated_at = now();
end $$;

-- بيانات سلة لصاحب المنصة (المفاتيح محجوبة) + متاجر سلة وحالة إعداد المدير
create or replace function public.owner_salla_info() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_owner() then raise exception 'غير مصرح'; end if;
  return jsonb_build_object(
    'client_id', (select value #>> '{}' from public.app_settings where key = 'salla_client_id'),
    'app_id', (select value #>> '{}' from public.app_settings where key = 'salla_app_id'),
    'client_secret_set', exists(select 1 from public.app_settings where key = 'salla_client_secret' and coalesce(value #>> '{}','') <> ''),
    'webhook_secret_set', exists(select 1 from public.app_settings where key = 'salla_webhook_secret' and coalesce(value #>> '{}','') <> ''),
    'last_event', (select max(at) from public.zid_log where kind like 'salla%'),
    'stores', coalesce((select jsonb_agg(jsonb_build_object('id', s.id, 'name', s.name, 'code', s.code, 'status', s.status, 'owner_email', s.owner_email,
        'owner_phone', s.owner_phone, 'merchant', s.salla_merchant_id, 'installed_at', s.installed_at,
        'has_admin', exists(select 1 from public.store_members m where m.store_id = s.id and m.role = 'admin' and m.is_active)) order by s.id desc)
      from public.stores s where s.platform = 'salla'), '[]'::jsonb));
end $$;
revoke execute on function public.owner_salla_info() from public, anon;
grant execute on function public.owner_salla_info() to authenticated;

-- ---------------------------------------------------------------------
-- المهام المجدولة لسلة + إشعار فوري حسب المنصة
-- ---------------------------------------------------------------------
create or replace function public.call_salla_function(p_action text) returns void
language plpgsql security definer set search_path = public as $$
declare v_url text; v_key text;
begin
  select value #>> '{}' into v_url from public.app_settings where key = 'functions_url';
  select value #>> '{}' into v_key from public.app_settings where key = 'cron_key';
  if v_url is null then return; end if;
  perform net.http_post(
    url := v_url || '/salla?action=' || p_action,
    headers := jsonb_build_object('Content-Type', 'application/json', 'x-cron-key', v_key),
    body := '{}'::jsonb,
    timeout_milliseconds := 25000);
end $$;
revoke execute on function public.call_salla_function(text) from public, anon, authenticated;

do $$ begin
  if exists (select 1 from pg_proc where proname = 'call_zid_function') then
    execute $f$
      create or replace function public.zid_outbox_notify() returns trigger
      language plpgsql security definer set search_path = public as $b$
      begin
        if exists (select 1 from new_rows where platform = 'zid') then perform public.call_zid_function('push'); end if;
        if exists (select 1 from new_rows where platform = 'salla') then perform public.call_salla_function('push'); end if;
        return null;
      end $b$;
    $f$;
    drop trigger if exists zid_outbox_notify_trg on public.zid_outbox;
    create trigger zid_outbox_notify_trg after insert on public.zid_outbox
      referencing new table as new_rows for each statement execute function public.zid_outbox_notify();
  end if;
end $$;

do $$ begin
  if exists (select 1 from pg_extension where extname = 'pg_cron') then
    begin perform cron.unschedule('msar-salla-cron'); exception when others then null; end;
    perform cron.schedule('msar-salla-cron', '* * * * *', $c$
      select public.call_salla_function('cron')
      where exists (select 1 from public.store_secrets where salla_tokens ? 'access_token')
    $c$);
  end if;
end $$;

select 'msar migration 009 ok' as result;
