-- =====================================================================
-- مسار — ترقية 011: رصيد الطلبات الشهري للباقات + أسعار جديدة
--   الأساسية 500 طلب/شهر = 129 ر.س | النمو 2,000 = 199 | الاحترافية بلا حدود (استخدام عادل) = 449
--   الحد "مرن": ما نوقف استقبال الطلبات عند تجاوزه، فقط نعرض الاستخدام وننبّه التاجر للترقية.
--   الشهر يُحسب بتوقيت الرياض. آمنة لإعادة التشغيل.
-- =====================================================================

-- حدود الباقات (null = بلا حدود). نحافظ على أي تعديل يدوي في app_settings.plans ونضيف حقل orders إن لم يوجد
create or replace function public.plan_defs() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select jsonb_object_agg(k,
        case when v ? 'orders' then v else v || jsonb_build_object('orders',
          case k when 'starter' then 500 when 'growth' then 2000 else null end) end)
     from public.app_settings a, jsonb_each(a.value) e(k, v) where a.key = 'plans'),
    '{"starter":{"name_ar":"الأساسية","name_en":"Starter","branches":2,"staff":5,"orders":500,"live":false},
      "growth":{"name_ar":"النمو","name_en":"Growth","branches":5,"staff":20,"orders":2000,"live":true},
      "pro":{"name_ar":"الاحترافية","name_en":"Pro","branches":null,"staff":null,"orders":null,"live":true}}'::jsonb)
$$;

-- الأسعار الشهرية (قبل الضريبة)
create or replace function public.plan_price(p_plan text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(
    ((select value from public.app_settings where key = 'plan_prices') ->> coalesce(p_plan, 'starter'))::numeric,
    case coalesce(p_plan, 'starter') when 'starter' then 129 when 'growth' then 199 when 'pro' then 449 else 0 end)
$$;

-- إن كان صاحب المنصة حافظ أسعار قديمة في app_settings.plan_prices نحدّثها للجديدة
update public.app_settings set value = '{"starter":129,"growth":199,"pro":449}'::jsonb
 where key = 'plan_prices' and value = '{"starter":99,"growth":149,"pro":399}'::jsonb;

-- عدد طلبات المتجر هذا الشهر (توقيت الرياض)
create or replace function public.store_orders_month(p_store int) returns int
language sql stable security definer set search_path = public as $$
  select count(*)::int from public.orders o
  where o.store_id = p_store
    and o.order_created_at >= (date_trunc('month', now() at time zone 'Asia/Riyadh') at time zone 'Asia/Riyadh')
$$;
revoke all on function public.store_orders_month(int) from public, anon, authenticated;
grant execute on function public.store_orders_month(int) to service_role;

-- الباقة والاستخدام للمتجر الحالي (للوحة التاجر) + الطلبات
create or replace function public.my_plan() returns jsonb
language sql stable security definer set search_path = public as $$
  select case when public.my_store() is null then null else
    public.store_plan(public.my_store()) || jsonb_build_object(
      'used_branches', (select count(*) from public.branches b where b.store_id = public.my_store()),
      'used_staff', public.store_staff_count(public.my_store()),
      'used_orders', public.store_orders_month(public.my_store()),
      'pending_invites', (select count(*) from public.invites i where i.store_id = public.my_store() and i.accepted_at is null and i.expires_at > now()))
  end
$$;
grant execute on function public.my_plan() to authenticated;

select 'msar migration 011 ok' as result;
