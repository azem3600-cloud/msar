-- =====================================================================
--  019 — المنيو الإلكتروني (صفحة عامة برابط لكل متجر، قوالب، ظهور، باركود)
--  لا جداول جديدة: الإعدادات في wa_config.config.msite، والأصناف هي نفس wa_items/wa_categories.
--  Idempotent — تقدر تعيد تشغيله. شغّله من لوحة Supabase (SQL Editor).
--
--  شكل wa_config.config.msite:
--   { enabled, slug, vis('all'|'wa'|'hours'|'closed'), template('rest'|'buf'|'cons'|'sweet'|'gen'),
--     color, name, tagline, logo(data URL صغير), cover(data URL صغير), qr:{...} }
-- =====================================================================

-- slug فريد بين المتاجر
create unique index if not exists wa_config_msite_slug_uq
  on public.wa_config ((config -> 'msite' ->> 'slug'))
  where (config -> 'msite' ->> 'slug') is not null and (config -> 'msite' ->> 'slug') <> '';

-- هل الوقت الحالي (الرياض) داخل الدوام؟
create or replace function public._wa_in_hours(p_cfg jsonb) returns boolean
language plpgsql stable as $$
declare o text; c text; nowm int; om int; cm int;
begin
  if coalesce((p_cfg #>> '{hours,enabled}')::boolean, false) = false then return true; end if;
  o := coalesce(p_cfg #>> '{hours,open}', '00:00'); c := coalesce(p_cfg #>> '{hours,close}', '24:00');
  nowm := extract(hour from (now() at time zone 'Asia/Riyadh'))::int * 60 + extract(minute from (now() at time zone 'Asia/Riyadh'))::int;
  om := split_part(o, ':', 1)::int * 60 + split_part(o, ':', 2)::int;
  cm := split_part(c, ':', 1)::int * 60 + split_part(c, ':', 2)::int;
  if om = cm then return true; end if;
  if om < cm then return nowm >= om and nowm < cm; end if;
  return nowm >= om or nowm < cm;   -- يعبر منتصف الليل
exception when others then return true;
end $$;

-- الصفحة العامة: تُرجع المنيو فقط لو شغّال وظهوره عام. غير ذلك ترجع حالة بدون بيانات.
create or replace function public.wa_menu_public(p_slug text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare r record; ms jsonb; cfg jsonb; st text; wa text; open_now boolean;
begin
  if p_slug is null or p_slug !~ '^[a-z0-9][a-z0-9-]{1,38}$' then return jsonb_build_object('status', 'notfound'); end if;
  select c.store_id, c.config into r from public.wa_config c where c.config -> 'msite' ->> 'slug' = p_slug limit 1;
  if not found then return jsonb_build_object('status', 'notfound'); end if;
  if not public.wa_enabled_for(r.store_id) then return jsonb_build_object('status', 'notfound'); end if;
  ms := r.config -> 'msite'; cfg := r.config;
  if coalesce((ms ->> 'enabled')::boolean, false) = false or coalesce(ms ->> 'vis', 'all') = 'closed' then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  if coalesce(ms ->> 'vis', 'all') = 'wa' then
    return jsonb_build_object('status', 'private', 'theme', public._wa_theme(r.store_id, ms));
  end if;
  open_now := public._wa_in_hours(cfg);
  if ms ->> 'vis' = 'hours' and not open_now then
    return jsonb_build_object('status', 'closed', 'theme', public._wa_theme(r.store_id, ms), 'hours', cfg -> 'hours');
  end if;
  select display_phone into wa from public.wa_channels where store_id = r.store_id and status = 'active' order by id limit 1;
  return jsonb_build_object(
    'status', 'ok',
    'theme', public._wa_theme(r.store_id, ms),
    'wa', regexp_replace(coalesce(wa, ''), '\D', '', 'g'),
    'open', open_now,
    'fee', coalesce((cfg ->> 'delivery_fee')::numeric, 0),
    'free_over', coalesce((cfg ->> 'free_over')::numeric, 0),
    'min_order', coalesce((cfg ->> 'min_order')::numeric, 0),
    'cats', coalesce((select jsonb_agg(jsonb_build_object('id', id, 'name', name, 'emoji', emoji) order by sort, id)
                       from public.wa_categories where store_id = r.store_id and is_active), '[]'::jsonb),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', i.id, 'cat', i.category_id, 'name', i.name, 'desc', i.description,
                       'price', i.price, 'img', i.image_url, 'emoji', i.emoji, 'pop', i.is_popular) order by i.sort, i.id)
                       from public.wa_items i left join public.wa_categories c on c.id = i.category_id
                       where i.store_id = r.store_id and i.is_active and (i.category_id is null or c.is_active)), '[]'::jsonb)
  );
end $$;

-- الهوية (اسم، قالب، ألوان، شعار، غلاف) — مشتركة بين الصفحة العامة والرابط الخاص
create or replace function public._wa_theme(p_store int, p_ms jsonb) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'name', coalesce(nullif(p_ms ->> 'name', ''), (select name from public.stores where id = p_store)),
    'tagline', coalesce(p_ms ->> 'tagline', ''),
    'template', coalesce(nullif(p_ms ->> 'template', ''), 'rest'),
    'color', coalesce(nullif(p_ms ->> 'color', ''), '#144F74'),
    'logo', p_ms ->> 'logo', 'cover', p_ms ->> 'cover')
$$;
revoke execute on function public._wa_theme(int, jsonb) from public, anon, authenticated;

-- الرابط الخاص (من واتساب): نفس الهوية بدون كشف شي، يعتمد على توكن الجلسة
create or replace function public.wa_menu_theme_by_token(p_token text) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare s record; ms jsonb;
begin
  if p_token is null or p_token !~ '^[a-f0-9]{32}$' then return null; end if;
  select store_id into s from public.wa_sessions where web_token = p_token;
  if not found or not public.wa_enabled_for(s.store_id) then return null; end if;
  select config -> 'msite' into ms from public.wa_config where store_id = s.store_id;
  return public._wa_theme(s.store_id, coalesce(ms, '{}'::jsonb));
end $$;

revoke execute on function public.wa_menu_public(text), public.wa_menu_theme_by_token(text) from public;
grant execute on function public.wa_menu_public(text), public.wa_menu_theme_by_token(text) to anon, authenticated;
revoke execute on function public._wa_in_hours(jsonb) from public, anon, authenticated;
