-- =====================================================================
--  مسار — ترقية 004: هوية موحّدة (حساب واحد للشخص + عضوية في أكثر من متجر + الدعوات)
--  آمنة لإعادة التشغيل. تُشغَّل بعد 002 و 003.
--
--  الفكرة:
--   * store_members = مصدر الحقيقة: (المستخدم، المتجر، الدور، الفرع)
--   * profiles = "المتجر النشط حالياً" للمستخدم (كل صلاحيات RLS الحالية تعتمد عليه)
--   * switch_store() تنقل المستخدم بين متاجره بنسخ العضوية إلى profiles
-- =====================================================================

-- 1) العضويات
create table if not exists public.store_members (
  id          bigserial primary key,
  store_id    int not null references public.stores(id) on delete cascade,
  user_id     uuid not null,
  role        text not null check (role in ('admin','cashier','driver')),
  branch_id   int references public.branches(id) on delete set null,
  username    text,                       -- للدخول القديم (رمز المتجر + اسم المستخدم)
  full_name   text not null,
  phone       text,
  vehicle     text,
  is_active   boolean not null default true,
  created_at  timestamptz not null default now(),
  unique (store_id, user_id)
);
create unique index if not exists store_members_username_uq on public.store_members(store_id, lower(username)) where username is not null;
create index if not exists store_members_user_idx on public.store_members(user_id);

-- نقل الحسابات الحالية
insert into public.store_members(store_id, user_id, role, branch_id, username, full_name, phone, vehicle, is_active)
select p.store_id, p.id, p.role, p.branch_id, p.username, p.full_name, p.phone, p.vehicle, p.is_active
  from public.profiles p
 where p.store_id is not null and p.role in ('admin','cashier','driver')
on conflict (store_id, user_id) do nothing;

-- 2) الدعوات
create table if not exists public.invites (
  token       text primary key default encode(gen_random_bytes(24), 'hex'),
  store_id    int not null references public.stores(id) on delete cascade,
  email       text not null,
  role        text not null check (role in ('admin','cashier','driver')),
  branch_id   int references public.branches(id) on delete set null,
  full_name   text not null,
  phone       text,
  vehicle     text,
  invited_by  uuid,
  created_at  timestamptz not null default now(),
  expires_at  timestamptz not null default now() + interval '7 days',
  accepted_at timestamptz
);
create index if not exists invites_store_idx on public.invites(store_id, accepted_at);

-- 3) الصلاحيات
alter table public.store_members enable row level security;
alter table public.invites       enable row level security;
drop policy if exists store_members_read on public.store_members;
create policy store_members_read on public.store_members for select to authenticated using (
  user_id = auth.uid() or public.is_owner()
  or (public.is_admin() and store_id = public.my_store()));
drop policy if exists invites_read on public.invites;
create policy invites_read on public.invites for select to authenticated using (
  public.is_admin() and store_id = public.my_store() and accepted_at is null);
revoke insert, update, delete on public.store_members, public.invites from anon, authenticated;
revoke all on public.store_members, public.invites from anon;
grant select on public.store_members, public.invites to authenticated;

-- 4) إنشاء الحساب: نضيف العضوية تلقائياً
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
declare m jsonb := coalesce(new.raw_user_meta_data, '{}'::jsonb);
        a jsonb := coalesce(new.raw_app_meta_data, '{}'::jsonb);
        v_store int := nullif(a->>'store_id','')::int;
        v_user  text := coalesce(m->>'username', split_part(new.email, '@', 1));
begin
  if coalesce(a->>'role', '') not in ('owner','admin','cashier','driver') then return new; end if;
  insert into public.profiles (id, store_id, username, full_name, phone, role, branch_id, vehicle)
  values (new.id, v_store, v_user,
          coalesce(m->>'full_name', split_part(new.email, '@', 1)),
          m->>'phone', a->>'role', nullif(a->>'branch_id', '')::int, m->>'vehicle')
  on conflict (id) do nothing;
  if v_store is not null and a->>'role' <> 'owner' then
    insert into public.store_members(store_id, user_id, role, branch_id, username, full_name, phone, vehicle)
    values (v_store, new.id, a->>'role', nullif(a->>'branch_id', '')::int,
            case when new.email like '%.' || 'msar.app' then v_user end,
            coalesce(m->>'full_name', split_part(new.email, '@', 1)), m->>'phone', m->>'vehicle')
    on conflict (store_id, user_id) do nothing;
  end if;
  return new;
end $$;

-- 5) عضوياتي + التنقل بين المتاجر
create or replace function public.my_memberships() returns jsonb
language sql stable security definer set search_path = public as $$
  select coalesce(jsonb_agg(jsonb_build_object(
           'store_id', s.id, 'store_name', s.name, 'store_code', s.code, 'store_status', s.status,
           'role', m.role, 'branch_id', m.branch_id, 'branch_name', b.name, 'is_active', m.is_active,
           'current', (p.store_id = s.id)) order by s.name), '[]'::jsonb)
    from public.store_members m
    join public.stores s on s.id = m.store_id
    left join public.branches b on b.id = m.branch_id
    left join public.profiles p on p.id = m.user_id
   where m.user_id = auth.uid() and m.is_active and s.status in ('trial','active')
$$;

create or replace function public.switch_store(p_store int) returns jsonb
language plpgsql security definer set search_path = public as $$
declare m public.store_members; v_email text; v_username text;
begin
  if auth.uid() is null then raise exception 'سجّل الدخول أولاً'; end if;
  if exists (select 1 from public.profiles where id = auth.uid() and role = 'owner') then
    raise exception 'حساب صاحب المنصة لا يُنقل بين المتاجر';
  end if;
  select mm.* into m from public.store_members mm join public.stores s on s.id = mm.store_id
   where mm.user_id = auth.uid() and mm.store_id = p_store and mm.is_active and s.status in ('trial','active');
  if not found then raise exception 'ما عندك صلاحية على هذا المتجر'; end if;
  select email into v_email from auth.users where id = auth.uid();
  -- اسم مستخدم فريد داخل المتجر: القديم إن وُجد، وإلا الإيميل نفسه
  v_username := coalesce(m.username, v_email, auth.uid()::text);
  insert into public.profiles (id, store_id, username, full_name, phone, role, branch_id, vehicle, is_active)
  values (auth.uid(), m.store_id, v_username, m.full_name, m.phone, m.role, m.branch_id, m.vehicle, true)
  on conflict (id) do update set store_id = excluded.store_id, username = excluded.username,
    full_name = excluded.full_name, phone = excluded.phone, role = excluded.role,
    branch_id = excluded.branch_id, vehicle = excluded.vehicle, is_active = true,
    is_online = false;
  return jsonb_build_object('ok', true, 'store_id', m.store_id, 'role', m.role);
end $$;

-- 6) قائمة موظفي المتجر (للمدير: الكل، للكاشير: فرعه)
create or replace function public.store_staff() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_role text := public.my_role(); v_store int := public.my_store(); v_branch int := public.my_branch();
begin
  if v_role not in ('admin','cashier') then raise exception 'غير مصرح'; end if;
  return coalesce((select jsonb_agg(x order by x->>'role', x->>'full_name') from (
    select jsonb_build_object(
      'id', m.user_id, 'role', m.role, 'branch_id', m.branch_id, 'full_name', m.full_name,
      'username', coalesce(m.username, u.email), 'email', case when u.email like '%.msar.app' then null else u.email end,
      'phone', m.phone, 'vehicle', m.vehicle, 'is_active', m.is_active,
      'here', (p.store_id = m.store_id),
      'is_online', case when p.store_id = m.store_id then p.is_online else false end,
      'last_seen_at', case when p.store_id = m.store_id then p.last_seen_at end,
      'last_battery', case when p.store_id = m.store_id then p.last_battery end) x
    from public.store_members m
    left join public.profiles p on p.id = m.user_id
    left join auth.users u on u.id = m.user_id
   where m.store_id = v_store
     and (v_role = 'admin' or m.user_id = auth.uid() or (m.branch_id = v_branch and m.role = 'driver'))) t), '[]'::jsonb);
end $$;

-- 7) تعديل موظف: العضوية + الملف النشط إن كان في نفس المتجر
create or replace function public.admin_update_profile(p_id uuid, p jsonb) returns public.profiles
language plpgsql security definer set search_path = public as $$
declare r public.profiles; m public.store_members;
begin
  if not public.is_admin() then raise exception 'غير مصرح'; end if;
  if p ? 'role' and p->>'role' not in ('admin','cashier','driver') then raise exception 'الدور غير صحيح'; end if;
  if nullif(p->>'branch_id','') is not null and not exists (select 1 from public.branches where id = (p->>'branch_id')::int and store_id = public.my_store()) then
    raise exception 'الفرع غير صحيح';
  end if;
  update public.store_members set
    full_name = coalesce(p->>'full_name', full_name),
    phone     = coalesce(p->>'phone', phone),
    role      = coalesce(p->>'role', role),
    branch_id = case when p ? 'branch_id' then nullif(p->>'branch_id','')::int else branch_id end,
    is_active = coalesce((p->>'is_active')::boolean, is_active),
    vehicle   = coalesce(p->>'vehicle', vehicle)
  where user_id = p_id and store_id = public.my_store() returning * into m;
  if m.id is null then raise exception 'المستخدم غير موجود'; end if;
  update public.profiles set full_name = m.full_name, phone = m.phone, role = m.role,
         branch_id = m.branch_id, is_active = m.is_active, vehicle = m.vehicle
   where id = p_id and store_id = m.store_id returning * into r;
  return r;   -- فاضي إذا الموظف نشط حالياً في متجر ثاني (ما نكشف بيانات المتجر الثاني)
end $$;

grant execute on function public.my_memberships(), public.switch_store(int), public.store_staff() to authenticated;

-- 8) البحث عن مستخدم بالإيميل (للسيرفر فقط)
create or replace function public.user_id_by_email(p_email text) returns uuid
language sql stable security definer set search_path = public as $$
  select id from auth.users where lower(email) = lower(trim(p_email)) limit 1
$$;
revoke execute on function public.user_id_by_email(text) from public, anon, authenticated;
do $$ begin
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    grant execute on function public.user_id_by_email(text) to service_role;
  end if;
end $$;

select 'msar migration 004 ok' as result,
       (select count(*) from public.store_members) as members;
