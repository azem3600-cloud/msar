// مسار — وسيط api.msarpro.com (Deno Deploy)
// يحوّل https://api.msarpro.com/<function>?... إلى دوال Supabase Edge بنفس الطريقة والرؤوس والجسم.
// الهدف: روابط OAuth/Webhooks في لوحة شركاء زد تكون على نطاقنا بدل *.supabase.co.
const UPSTREAM = "https://ydfsevhzjztnyfdbmzdb.supabase.co/functions/v1";
const ALLOWED = new Set(["zid", "admin", "support", "salla"]);

Deno.serve(async (req) => {
  const url = new URL(req.url);
  const parts = url.pathname.split("/").filter(Boolean);
  const fn = parts[0] ?? "";
  if (!fn) return new Response("msar api ok", { headers: { "content-type": "text/plain; charset=utf-8" } });
  if (!ALLOWED.has(fn)) return new Response("not found", { status: 404 });

  const target = `${UPSTREAM}/${parts.join("/")}${url.search}`;
  const headers = new Headers(req.headers);
  headers.delete("host");
  headers.set("x-forwarded-host", url.host);
  headers.set("x-forwarded-proto", "https");
  const init: RequestInit = { method: req.method, headers, redirect: "manual" };
  if (req.method !== "GET" && req.method !== "HEAD") init.body = req.body;

  const res = await fetch(target, init);
  const out = new Headers(res.headers);
  // لا نمرر ترميزات النقل الخاصة بالمصدر
  out.delete("content-encoding");
  out.delete("content-length");
  out.delete("transfer-encoding");
  return new Response(res.body, { status: res.status, statusText: res.statusText, headers: out });
});
