# تفعيل إشعارات المندوب وهو مقفول التطبيق (Firebase Push)

**ليش نحتاجها؟** تنبيه المندوب الحالي "محلي": التطبيق نفسه يولّده لما يكون شغّال. لو المندوب قفل التطبيق (سحبه من التطبيقات الأخيرة) ما يوصله صوت.
الحل: السيرفر يرسل إشعار Push عبر Firebase (FCM) أول ما يُسنَد الطلب، والنظام يعرضه بصوت قناة «orders_v2» (`msar_driver`) حتى لو التطبيق مقفول.

**الكود جاهز ومنشور مع الحزمة، وما يتفعّل إلا بعد الخطوات التالية (بدونها كل شي يشتغل مثل قبل).**

## الخطوات (صاحب المشروع بنفسه — Firebase حسابه)

1. https://console.firebase.google.com ← Add project ← الاسم «msar» (Google Analytics: اختياري/أوقفه).
2. داخل المشروع: Add app ← Android ← **Package name: `sa.msar.driver`** ← Register. نزّل **`google-services.json`**.
   - هذا الملف مو سري (ينحط داخل كل APK). أرسله لي أو ارفعه في المستودع في المسار `android/google-services.json`.
3. Project settings ← **Service accounts** ← Generate new private key ← ينزل ملف JSON. **هذا سري — لا ترسله لأي أحد ولا ينرفع للمستودع.**
4. Supabase ← Edge Functions ← Secrets ← Add new secret: الاسم `FCM_SERVICE_ACCOUNT` والقيمة = محتوى ملف الـ JSON كامل (الصق بنفسك).
5. Supabase ← SQL Editor ← الصق `supabase/migrations/012_driver_push.sql` وشغّله (آمن لإعادة التشغيل).
6. Supabase ← Edge Functions ← **Deploy a new function** باسم `push` ← الصق `supabase/functions/push/index.ts` ← أوقف **Verify JWT** ← Deploy.
7. ارفع الحزمة (`msar-bundle.tgz`) على GitHub مع `android/google-services.json` ← ينبني APK جديد (نفس مفتاح التوقيع).
8. المندوب يثبّت الـ APK الجديد، يسجّل دخول، ويوافق على الإشعارات. في القائمة (⋮) يطلع له سطر «✅ إشعارات الخلفية مفعّلة».

## الاختبار
- مندوب مسجّل دخول على الجوال ← اسحب التطبيق من التطبيقات الأخيرة (قفله تماماً) ← من لوحة الكاشير أسند له طلب ← لازم يوصل إشعار بصوت الطلبات واهتزاز حتى والشاشة مقفلة.
- لو ما وصل: القائمة (⋮) تعرض الحالة (مرفوضة/خطأ). تأكد أن إعدادات البطارية للتطبيق «بدون قيود» (بعض الجوالات: شاومي/هواوي/سامسونج توقف التطبيقات المقفولة).
- سجل الأخطاء: Supabase ← Edge Functions ← push ← Logs. الرد `{ok:true,sent:N}`.

## كيف يشتغل
`orders` (AFTER INSERT/UPDATE of driver_id,status) ← trigger `orders_notify_driver` ← `call_edge_function('push')` (مفتاح cron) ← دالة `push` تجيب توكنات المندوب من `push_tokens` ← FCM HTTP v1 برسالة `notification` + `android.notification.channel_id=orders_v2` + `sound=msar_driver`.
التوكنات تُسجَّل من التطبيق عبر `driver_register_push` وتنحذف عند تسجيل الخروج أو لما FCM يرجع UNREGISTERED. الـ trigger يبلع أي خطأ (ما يوقف تحديث الطلب).

## حدود معروفة
- الإشعار صوته يشتغل مرة واحدة (مو متكرر مثل نافذة التنبيه داخل التطبيق). المندوب يضغطه يفتح التطبيق.
- مندوب الويب (PWA بالمتصفح) خارج هذا النطاق: الإشعارات الخلفية للـ APK فقط.
- لو المندوب أوقف الإشعارات من إعدادات أندرويد، أو شغّل «عدم الإزعاج»، النظام يتحكم بالصوت.
