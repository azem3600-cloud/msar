# مسار (MSAR)
منصة توجيه طلبات متاجر زد لأقرب فرع + شاشة الكاشير + تطبيق المندوب.

- `web/` لوحة التاجر (index.html)، لوحة صاحب المنصة (owner.html)، إعداد المتجر (setup.html)، تطبيق المندوب (driver.html)
- `supabase/` قاعدة البيانات (schema.sql ثم cron.sql) والدوال (zid, admin) — بدون Verify JWT
- `android/` تطبيق المندوب (Capacitor) — يُبنى تلقائياً عبر GitHub Actions
