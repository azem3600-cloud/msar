# مسار (MSAR)

منصة لتجار **زد**: توجيه الطلبات تلقائياً لأقرب فرع، شاشة كاشير لكل فرع، وتطبيق مندوب أندرويد مع التتبّع المباشر.

- 📒 **الدليل الشامل (الحالة الحالية، الروابط، طريقة النشر):** [`docs/HANDBOOK.md`](docs/HANDBOOK.md)
- 📘 **دليل المشروع للمطورين ومساعدي الذكاء الاصطناعي:** [`AGENTS.md`](AGENTS.md)
- 🗺️ **خطة النجاح والمراحل:** [`docs/PLAN.md`](docs/PLAN.md)
- 🌐 الموقع: https://azem3600-cloud.github.io/msar/
- ✅ الفحص قبل أي تعديل: `bash ci/check.sh`

## المجلدات
- `web/` لوحة التاجر والكاشير (`index.html`)، صاحب المنصة (`owner.html`)، إعداد المتجر (`setup.html`)، المندوب (`driver.html`)، الخصوصية والدعم.
- `supabase/` قاعدة البيانات (`schema.sql` ثم `cron.sql` ثم `migrations/` بالترتيب) والدوال (`zid`, `admin`) — بدون Verify JWT.
- `android/` تطبيق المندوب (Capacitor) — يُبنى ويُوقّع تلقائياً عبر GitHub Actions من الأسرار.
- `ci/` سكربت البناء والفحص.
