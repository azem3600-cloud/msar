// إعدادات مسار (المفتاح العام anon آمن للنشر — الحماية عبر RLS)
window.AZM_CONFIG = {
  SUPABASE_URL: "https://ydfsevhzjztnyfdbmzdb.supabase.co",
  SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InlkZnNldmh6anp0bnlmZGJtemRiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTMwMTk3NTIsImV4cCI6MjEwODU5NTc1Mn0.-OdFn72eztWZdMWP3Q9eZ4eSkp9vmlb85HjFo6Y3o5s",
  EMAIL_DOMAIN: "msar.app",
  BRAND: "مسار",
  STORE_NAME: "",
  STORE_URL: "",
  APK_URL: "msar-driver.apk",
};
