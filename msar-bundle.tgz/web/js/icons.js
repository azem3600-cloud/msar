/* مسار — أيقونات خطية بدل الإيموجي. تعمل تلقائياً على أي نص يُرسم في الصفحة. */
(function () {
  const P = {
    store: '<path d="M4 9l1-5h14l1 5M4 9v11h16V9M4 9c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    bike: '<circle cx="6" cy="16" r="3.2"/><circle cx="18" cy="16" r="3.2"/><path d="M6 16l3-7h4l3 7M9 9H7M13 9l-1-3h-2"/>',
    truck: '<path d="M3 6h11v10H3zM14 9h4l3 3v4h-7"/><circle cx="7" cy="17.5" r="1.8"/><circle cx="17" cy="17.5" r="1.8"/>',
    card: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 10h18M7 15h3"/>',
    cash: '<rect x="3" y="7" width="18" height="10" rx="2"/><circle cx="12" cy="12" r="2.4"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    list: '<path d="M8 6h12M8 12h12M8 18h12M4 6h.01M4 12h.01M4 18h.01"/>',
    map: '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2-6-2zM9 4v14M15 6v14"/>',
    pin: '<path d="M12 21s-6.5-5.6-6.5-11a6.5 6.5 0 0 1 13 0c0 5.4-6.5 11-6.5 11z"/><circle cx="12" cy="10" r="2.2"/>',
    link: '<path d="M10 14a4 4 0 0 0 5.7 0l3-3a4 4 0 0 0-5.7-5.7l-1 1M14 10a4 4 0 0 0-5.7 0l-3 3a4 4 0 0 0 5.7 5.7l1-1"/>',
    user: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.6-6 8-6s8 2 8 6"/>',
    users: '<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-5.5 6.5-5.5s6.5 1.9 6.5 5.5M16 4.8a3.5 3.5 0 0 1 0 6.4M18 14.8c2 .6 3.5 2.2 3.5 5.2"/>',
    cart: '<path d="M3 4h2l2.4 11h10.2L20 8H6.2"/><circle cx="9" cy="19" r="1.4"/><circle cx="17" cy="19" r="1.4"/>',
    bag: '<path d="M5 8h14l-1 12H6zM9 8V6a3 3 0 0 1 6 0v2"/>',
    box: '<path d="M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10"/>',
    alert: '<path d="M12 4l9 16H3zM12 10v4.5M12 17.5h.01"/>',
    bell: '<path d="M6 17V11a6 6 0 0 1 12 0v6l1.5 2h-15zM10 21h4"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>',
    chart: '<path d="M4 20V10M10 20V4M16 20v-8M22 20H2"/>',
    target: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/>',
    search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4-4"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="m3 7 9 6 9-6"/>',
    clip: '<path d="M20 11l-8 8a5 5 0 0 1-7-7l8.5-8.5a3.5 3.5 0 0 1 5 5L10 16a2 2 0 0 1-3-3l7-7"/>',
    chat: '<path d="M4 5h16v11H9l-5 4z"/>',
    ticket: '<path d="M3 8a2 2 0 0 0 0 4v0a2 2 0 0 0 0 4v2h18v-2a2 2 0 0 1 0-4v0a2 2 0 0 1 0-4V6H3z"/>',
    clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
    bot: '<rect x="4" y="8" width="16" height="11" rx="2"/><path d="M12 8V4M9 13h.01M15 13h.01M9 16.5h6"/>',
    refresh: '<path d="M20 11a8 8 0 0 0-14-4L4 9M4 4v5h5M4 13a8 8 0 0 0 14 4l2-2M20 20v-5h-5"/>',
    battery: '<rect x="3" y="8" width="16" height="9" rx="2"/><path d="M21 11v3M6 11v3"/>',
    exit: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
    bulb: '<path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/>',
    signal: '<path d="M4 20v-4M9 20v-8M14 20V8M19 20V4"/>',
    lock: '<rect x="5" y="11" width="14" height="9" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    doc: '<path d="M6 3h8l4 4v14H6zM14 3v4h4M9 12h6M9 16h6"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.7.4-1 1-1 1.7M12 17h.01"/>',
    send: '<path d="M4 12l16-8-6 16-3-7z"/>',
    crown: '<path d="M4 18l-1-10 5 4 4-7 4 7 5-4-1 10z"/>',
    image: '<rect x="3" y="5" width="18" height="14" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M4 18l5-5 4 3 3-3 4 4"/>',
    brain: '<path d="M9 4a3 3 0 0 0-3 3 3 3 0 0 0-2 5 3 3 0 0 0 2 5 3 3 0 0 0 6 1V4a3 3 0 0 0-3 0zM15 4a3 3 0 0 1 3 3 3 3 0 0 1 2 5 3 3 0 0 1-2 5 3 3 0 0 1-6 1"/>',
    help2: '<circle cx="12" cy="12" r="9"/><path d="M12 8v5M12 16h.01"/>',
    lifebuoy: '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="3.5"/><path d="M5.6 5.6l3.9 3.9M14.5 14.5l3.9 3.9M18.4 5.6l-3.9 3.9M9.5 14.5l-3.9 3.9"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/>',
    download: '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    trash: '<path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13M10 11v6M14 11v6"/>',
    save: '<path d="M5 4h11l3 3v13H5zM8 4v5h7V4M8 20v-6h8v6"/>',
    print: '<path d="M7 9V4h10v5M7 17H4v-7h16v7h-3M7 14h10v6H7z"/>',
    menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
    undo: '<path d="M9 7L4 12l5 5M4 12h11a5 5 0 0 1 0 10h-3"/>',
    home: '<path d="M4 11l8-7 8 7M6 10v10h12V10"/>',
    bolt: '<path d="M13 3L5 14h6l-1 7 8-11h-6z"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    swap: '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
  };
  // رمز → اسم الأيقونة. null = حذف الرمز (زخرفي بلا معنى).
  const MAP = {
    "🏪": "store", "🏬": "store", "✅": "check", "✔️": "check", "✔": "check", "✓": "check", "☑️": "check",
    "❌": "x", "✖️": "x", "✖": "x", "✕": "x", "🚫": "x", "🛵": "bike", "🏍️": "bike", "🚚": "truck", "💳": "card", "💵": "cash",
    "➕": "plus", "📋": "list", "🗂️": "list", "🧾": "list", "🗺️": "map", "📍": "pin", "🔗": "link", "👤": "user", "👥": "users",
    "🛒": "cart", "🛍️": "bag", "🧺": "bag", "📦": "box", "⚠️": "alert", "⚠": "alert", "🔔": "bell", "🔑": "key", "🌐": "globe",
    "📊": "chart", "🎯": "target", "⚙️": "gear", "🔎": "search", "🔍": "search", "📞": "phone", "👁️": "eye", "👁": "eye",
    "⬆️": "up", "📨": "mail", "📧": "mail", "✉️": "mail", "📎": "clip", "💬": "chat", "🎫": "ticket", "⏳": "clock", "⏱️": "clock", "🕒": "clock",
    "🤖": "bot", "🔄": "refresh", "🔋": "battery", "🚪": "exit", "💡": "bulb", "📶": "signal", "🔒": "lock", "⏸️": "pause",
    "📄": "doc", "❓": "help", "❔": "help", "➤": "send", "👑": "crown", "🖼️": "image", "🧠": "brain", "🛟": "lifebuoy", "ℹ️": "help2",
    "↩️": "undo", "⬇️": "download", "💾": "save", "🧭": "compass", "📜": "doc", "📝": "edit", "✏️": "edit", "☰": "menu", "🖨️": "print",
    "🔀": "swap", "🔁": "refresh", "🕓": "clock", "⏰": "clock", "📅": "calendar", "🔐": "lock", "🔌": "bolt", "⚡": "bolt", "🗑️": "trash",
    "🏠": "home", "🚗": "bike", "📡": "signal", "📌": "pin", "📥": "download", "🖥️": null, "💻": null, "📱": null, "📏": null, "🔕": "bell",
    "🔴": "dot-r", "🟠": "dot-w", "🟡": "dot-w", "🏆": null, "🩺": null, "⏭️": null, "😌": null, "😴": null, "👏": null, "📭": null,
    "🌳": null, "🏷️": null, "🎨": null, "📣": null, "🏁": null, "🪜": null, "⚖️": null, "📘": "doc",
    "🟢": "dot-g", "🔵": "dot-b", "⚪": "dot",
    "🆕": null, "👋": null, "👍": null, "🌟": null, "✨": null, "🚀": null, "🧩": null, "🌿": null, "🎉": null, "🔥": null, "⭐": null,
  };
  const keys = Object.keys(MAP).sort((a, b) => b.length - a.length).map((k) => k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
  const RE = new RegExp("(?:" + keys.join("|") + ")\\uFE0F?", "g");
  const SKIP = new Set(["SCRIPT", "STYLE", "TEXTAREA", "OPTION", "TITLE", "INPUT", "SVG", "CODE", "PRE"]);

  function inject() {
    if (document.getElementById("ic-sprite") || !document.body) return;
    const d = document.createElement("div");
    d.id = "ic-sprite"; d.setAttribute("aria-hidden", "true"); d.style.cssText = "position:absolute;width:0;height:0;overflow:hidden";
    d.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="0" height="0"><defs>' +
      Object.keys(P).map((k) => `<symbol id="ic-${k}" viewBox="0 0 24 24">${P[k]}</symbol>`).join("") + "</defs></svg>";
    document.body.prepend(d);
  }
  const svgFor = (n) => `<svg class="ic" aria-hidden="true"><use href="#ic-${n}"/></svg>`;
  const htmlFor = (sym) => {
    const base = sym.replace(/️$/, "");
    const n = (sym in MAP) ? MAP[sym] : MAP[base];
    if (n === null) return "";
    if (n === "dot") return '<i class="dotc"></i>';
    if (n === "dot-g") return '<i class="dotc g"></i>';
    if (n === "dot-r") return '<i class="dotc r"></i>';
    if (n === "dot-w") return '<i class="dotc w"></i>';
    if (n === "dot-b") return '<i class="dotc b"></i>';
    return svgFor(n);
  };

  function processText(node) {
    const t = node.nodeValue;
    if (!t || !RE.test(t)) { RE.lastIndex = 0; return; }
    RE.lastIndex = 0;
    const p = node.parentNode;
    if (!p || SKIP.has((p.nodeName || "").toUpperCase()) || p.isContentEditable) return;
    const frag = document.createDocumentFragment();
    let last = 0, m;
    while ((m = RE.exec(t))) {
      if (m.index > last) frag.appendChild(document.createTextNode(t.slice(last, m.index)));
      const h = htmlFor(m[0]);
      if (h) { const s = document.createElement("span"); s.innerHTML = h; s.style.display = "contents"; frag.appendChild(s); }
      else { // حذف الرمز مع المسافة التي بعده
        const rest = t.slice(m.index + m[0].length); if (rest.startsWith(" ")) RE.lastIndex += 1;
      }
      last = RE.lastIndex;
    }
    if (last < t.length) frag.appendChild(document.createTextNode(t.slice(last)));
    p.replaceChild(frag, node);
  }
  function scan(root) {
    if (!root) return;
    if (root.nodeType === 3) return processText(root);
    if (root.nodeType !== 1 || SKIP.has(root.nodeName.toUpperCase())) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode: (n) => (SKIP.has((n.parentNode?.nodeName || "").toUpperCase()) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT),
    });
    const list = []; while (w.nextNode()) list.push(w.currentNode);
    list.forEach(processText);
    // خصائص نصية: نحذف الإيموجي المعروفة من العناوين والـ placeholder
    root.querySelectorAll?.("[title],[placeholder],[aria-label]").forEach((el) => {
      ["title", "placeholder", "aria-label"].forEach((a) => { const v = el.getAttribute(a); if (v && RE.test(v)) { el.setAttribute(a, v.replace(RE, "").replace(/\s{2,}/g, " ").trim()); } RE.lastIndex = 0; });
    });
    // خيارات القوائم: نص فقط
    root.querySelectorAll?.("option").forEach((o) => { if (RE.test(o.textContent)) o.textContent = o.textContent.replace(RE, "").replace(/\s{2,}/g, " ").trim(); RE.lastIndex = 0; });
  }

  let queued = false; const pend = new Set();
  function flush() { queued = false; const a = [...pend]; pend.clear(); a.forEach((n) => { if (n.isConnected) scan(n); }); }
  function start() {
    inject(); scan(document.body);
    new MutationObserver((ms) => {
      for (const m of ms) {
        if (m.type === "childList") m.addedNodes.forEach((n) => { if (n.id !== "ic-sprite") pend.add(n); });
        else if (m.type === "characterData") pend.add(m.target);
      }
      if (pend.size && !queued) { queued = true; requestAnimationFrame(flush); }
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  }
  window.AZM_ICONS = { scan, svgFor };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
