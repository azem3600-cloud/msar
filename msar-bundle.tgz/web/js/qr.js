/* مولّد QR صغير بدون مكتبات (نمط البايت، نسخ 1–15، مستويات تصحيح L/M/Q/H).
   window.MSARQR.matrix(text, ecc) → مصفوفة [صف][عمود] من 0/1. */
(function () {
  "use strict";
  var ECC_PER_BLOCK = {
    L: [0, 7, 10, 15, 20, 26, 18, 20, 24, 30, 18, 20, 24, 26, 30, 22],
    M: [0, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24],
    Q: [0, 13, 22, 18, 26, 18, 24, 18, 22, 20, 24, 28, 26, 24, 20, 30],
    H: [0, 17, 28, 22, 16, 22, 28, 26, 26, 24, 28, 24, 28, 22, 24, 24],
  };
  var BLOCKS = {
    L: [0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 4, 4, 4, 4, 4, 6],
    M: [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10],
    Q: [0, 1, 1, 2, 2, 4, 4, 6, 6, 8, 8, 8, 10, 12, 16, 12],
    H: [0, 1, 1, 2, 4, 4, 4, 5, 6, 8, 8, 11, 11, 16, 16, 18],
  };
  var FMT = { L: 1, M: 0, Q: 3, H: 2 };

  function rawModules(v) {
    var r = (16 * v + 128) * v + 64;
    if (v >= 2) { var n = Math.floor(v / 7) + 2; r -= (25 * n - 10) * n - 55; if (v >= 7) r -= 36; }
    return r;
  }
  function dataCodewords(v, e) { return Math.floor(rawModules(v) / 8) - ECC_PER_BLOCK[e][v] * BLOCKS[e][v]; }

  // GF(256)
  var EXP = new Array(512), LOG = new Array(256);
  (function () { var x = 1; for (var i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 256) x ^= 0x11d; } for (var j = 255; j < 512; j++) EXP[j] = EXP[j - 255]; })();
  function gmul(a, b) { return a && b ? EXP[LOG[a] + LOG[b]] : 0; }
  function rsGen(d) { var g = [1]; for (var i = 0; i < d; i++) { var n = new Array(g.length + 1).fill(0); for (var j = 0; j < g.length; j++) { n[j] ^= g[j]; n[j + 1] ^= gmul(g[j], EXP[i]); } g = n; } return g; }
  function rsRem(data, gen) { var d = gen.length - 1, res = new Array(d).fill(0); data.forEach(function (b) { var f = b ^ res.shift(); res.push(0); for (var i = 0; i < d; i++) res[i] ^= gmul(gen[i + 1], f); }); return res; }

  function utf8(s) { return Array.from(unescape(encodeURIComponent(s))).map(function (c) { return c.charCodeAt(0); }); }

  function build(text, e) {
    var bytes = utf8(text), v, cap;
    for (v = 1; v <= 15; v++) { cap = dataCodewords(v, e); var cc = v < 10 ? 8 : 16; if (4 + cc + bytes.length * 8 <= cap * 8) break; }
    if (v > 15) throw new Error("النص طويل");
    var bits = [];
    function put(val, len) { for (var i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); }
    put(4, 4); put(bytes.length, v < 10 ? 8 : 16); bytes.forEach(function (b) { put(b, 8); });
    var cap8 = cap * 8; put(0, Math.min(4, cap8 - bits.length)); while (bits.length % 8) bits.push(0);
    for (var pad = 0xec; bits.length < cap8; pad ^= 0xec ^ 0x11) put(pad, 8);
    var data = []; for (var i = 0; i < bits.length; i += 8) { var b = 0; for (var k = 0; k < 8; k++) b = (b << 1) | bits[i + k]; data.push(b); }
    // تقسيم لكتل + تصحيح الأخطاء
    var nb = BLOCKS[e][v], ecl = ECC_PER_BLOCK[e][v], raw = Math.floor(rawModules(v) / 8), shortLen = Math.floor(raw / nb), nShort = nb - (raw % nb);
    var gen = rsGen(ecl), blocks = [], pos = 0;
    for (var bi = 0; bi < nb; bi++) { var dl = shortLen - ecl + (bi < nShort ? 0 : 1); var dat = data.slice(pos, pos + dl); pos += dl; blocks.push({ d: dat, e: rsRem(dat, gen) }); }
    var out = [], maxD = shortLen - ecl + 1;
    for (var x = 0; x < maxD; x++) blocks.forEach(function (bl) { if (x < bl.d.length) out.push(bl.d[x]); });
    for (var y = 0; y < ecl; y++) blocks.forEach(function (bl) { out.push(bl.e[y]); });
    return { v: v, cw: out };
  }

  function matrixFor(v, cw, e, mask) {
    var n = 17 + 4 * v, M = [], F = [];
    for (var i = 0; i < n; i++) { M.push(new Array(n).fill(0)); F.push(new Array(n).fill(false)); }
    function set(r, c, val) { if (r >= 0 && r < n && c >= 0 && c < n) { M[r][c] = val ? 1 : 0; F[r][c] = true; } }
    // التوقيت
    for (var t = 0; t < n; t++) { set(6, t, t % 2 === 0); set(t, 6, t % 2 === 0); }
    // العلامات الثلاث
    function finder(r, c) { for (var dy = -1; dy <= 7; dy++) for (var dx = -1; dx <= 7; dx++) { var d = Math.max(Math.abs(dy - 3), Math.abs(dx - 3)); set(r + dy, c + dx, d !== 2 && d !== 4 && dy >= 0 && dy <= 6 && dx >= 0 && dx <= 6); } }
    finder(0, 0); finder(0, n - 7); finder(n - 7, 0);
    // المحاذاة
    if (v > 1) {
      var na = Math.floor(v / 7) + 2, step = v === 32 ? 26 : Math.ceil((v * 4 + 4) / (na * 2 - 2)) * 2, al = [6];
      for (var p = n - 7; al.length < na; p -= step) al.splice(1, 0, p);
      al.forEach(function (ar, ai) { al.forEach(function (ac, aj) {
        if ((ai === 0 && aj === 0) || (ai === 0 && aj === na - 1) || (ai === na - 1 && aj === 0)) return;
        for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) set(ar + dy, ac + dx, Math.max(Math.abs(dy), Math.abs(dx)) !== 1);
      }); });
    }
    // حجز مناطق الصيغة والإصدار
    function formatBits(mk) { var d = (FMT[e] << 3) | mk, r = d; for (var i = 0; i < 10; i++) r = (r << 1) ^ ((r >>> 9) * 0x537); return ((d << 10) | r) ^ 0x5412; }
    function drawFormat(mk) {
      var b = formatBits(mk), g = function (i) { return ((b >>> i) & 1) === 1; };
      for (var i = 0; i <= 5; i++) set(i, 8, g(i)); set(7, 8, g(6)); set(8, 8, g(7)); set(8, 7, g(8)); for (var j = 9; j < 15; j++) set(8, 14 - j, g(j));
      for (var k = 0; k < 8; k++) set(8, n - 1 - k, g(k)); for (var m = 8; m < 15; m++) set(n - 15 + m, 8, g(m)); set(n - 8, 8, true);
    }
    drawFormat(0);
    if (v >= 7) { var r = v; for (var q = 0; q < 12; q++) r = (r << 1) ^ ((r >>> 11) * 0x1f25); var vb = (v << 12) | r;
      for (var z = 0; z < 18; z++) { var bit = ((vb >>> z) & 1) === 1, a = n - 11 + (z % 3), bb = Math.floor(z / 3); set(a, bb, bit); set(bb, a, bit); } }
    // البيانات (متعرّج)
    var bi = 0, total = cw.length * 8, data = [];
    for (var right = n - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (var vert = 0; vert < n; vert++) for (var j2 = 0; j2 < 2; j2++) {
        var x = right - j2, up = ((right + 1) & 2) === 0, y = up ? n - 1 - vert : vert;
        if (!F[y][x] && bi < total) { M[y][x] = (cw[bi >>> 3] >>> (7 - (bi & 7))) & 1; bi++; data.push([y, x]); }
      }
    }
    return { M: M, F: F, data: data, drawFormat: drawFormat, n: n };
  }
  var MASKS = [
    function (y, x) { return (x + y) % 2 === 0; }, function (y) { return y % 2 === 0; }, function (y, x) { return x % 3 === 0; }, function (y, x) { return (x + y) % 3 === 0; },
    function (y, x) { return (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; }, function (y, x) { return ((x * y) % 2) + ((x * y) % 3) === 0; },
    function (y, x) { return (((x * y) % 2) + ((x * y) % 3)) % 2 === 0; }, function (y, x) { return (((x + y) % 2) + ((x * y) % 3)) % 2 === 0; },
  ];
  function penalty(M, n) {
    var p = 0, y, x, run, dark = 0;
    for (y = 0; y < n; y++) { run = 1; for (x = 1; x < n; x++) { if (M[y][x] === M[y][x - 1]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
    for (x = 0; x < n; x++) { run = 1; for (y = 1; y < n; y++) { if (M[y][x] === M[y - 1][x]) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1; } }
    for (y = 0; y < n - 1; y++) for (x = 0; x < n - 1; x++) { var c = M[y][x]; if (c === M[y][x + 1] && c === M[y + 1][x] && c === M[y + 1][x + 1]) p += 3; }
    var PA = [1, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0], PB = [0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1];
    function hit(get) { for (var a = 0; a < n; a++) for (var b = 0; b <= n - 11; b++) { var ma = true, mb = true; for (var k = 0; k < 11; k++) { var v = get(a, b + k); if (v !== PA[k]) ma = false; if (v !== PB[k]) mb = false; if (!ma && !mb) break; } if (ma) p += 40; if (mb) p += 40; } }
    hit(function (a, b) { return M[a][b]; }); hit(function (a, b) { return M[b][a]; });
    // أي نمط 1011101 (شبيه بعلامة الزاوية) في أي مكان يربك بعض القارئات
    function core(get) { for (var a = 0; a < n; a++) for (var b = 0; b <= n - 7; b++) { if (get(a, b) && !get(a, b + 1) && get(a, b + 2) && get(a, b + 3) && get(a, b + 4) && !get(a, b + 5) && get(a, b + 6)) p += 25; } }
    core(function (a, b) { return M[a][b]; }); core(function (a, b) { return M[b][a]; });
    for (y = 0; y < n; y++) for (x = 0; x < n; x++) dark += M[y][x];
    p += Math.floor(Math.abs(dark * 20 - n * n * 10) / (n * n)) * 10;
    return p;
  }
  function matrix(text, ecc, force) {
    ecc = ecc || "M";
    var b = build(String(text), ecc), best = null, bestP = 1e9;
    for (var mk = 0; mk < 8; mk++) { if (force !== undefined && mk !== force) continue;
      var o = matrixFor(b.v, b.cw, ecc, mk);
      o.data.forEach(function (d) { if (MASKS[mk](d[0], d[1])) o.M[d[0]][d[1]] ^= 1; });
      o.drawFormat(mk);
      var pn = penalty(o.M, o.n); if (pn < bestP) { bestP = pn; best = o.M; }
    }
    return best;
  }
  window.MSARQR = { matrix: matrix };
})();
