/* مسار — مُصيِّر صفحة المنيو الإلكتروني (مشترك بين صفحة العميل m.html ومعاينة لوحة التاجر).
   MSARMENU.html(D, TH) → نص HTML لمحتوى الصفحة. MSARMENU.rootClass(TH) → كلاسات العنصر الجذر (.mr). */
(function () {
  "use strict";
  var TPL = { rest: "🍽️", buf: "🥙", cons: "🛒", sweet: "🧁", gen: "🛍️" };
  var DEFSTYLE = { rest: "cards", buf: "compact", cons: "grid2", sweet: "sweet", gen: "grid2" };
  var STYLES = /^(cards|list|compact|grid2|grid3|sweet)$/;
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]; }); };
  var safeImg = function (u) { return /^(https:\/\/|data:image\/(jpeg|png|webp);base64,)/.test(u || "") ? u : ""; };
  var money = function (n) { return (Math.round(n * 100) / 100) + " ر.س"; };
  var colorOk = function (c, d) { return /^#[0-9a-fA-F]{6}$/.test(c || "") ? c : d; };
  var RATIO = { "1:1": "ratio-11", "4:3": "ratio-43", "16:9": "ratio-169" };

  function rootClass(TH) {
    TH = TH || {}; var L = TH.layout || {}, t = TPL[TH.template] ? TH.template : "rest";
    return "mr t-" + t + " r-" + (/^(sm|md|lg)$/.test(L.round) ? L.round : "md") + " " + (RATIO[L.ratio] || "ratio-43") + (L.fit === "contain" ? " fit-contain" : "") + (L.img === false ? " noimg" : "") + (L.desc === false ? " nodesc" : "");
  }
  function styleOf(TH, blockStyle) {
    var L = (TH && TH.layout) || {}, t = TPL[TH && TH.template] ? TH.template : "rest";
    var s = STYLES.test(blockStyle) ? blockStyle : (STYLES.test(L.style) ? L.style : "");
    if (L.style === "grid3" || L.style === "list") s = STYLES.test(blockStyle) ? blockStyle : L.style;
    return s || DEFSTYLE[t];
  }
  function priceHtml(i) {
    var pct = i.old > i.price ? Math.round((1 - i.price / i.old) * 100) : 0;
    return (i.old > i.price ? "<s>" + money(i.old) + "</s> " : "") + money(i.price) + (pct ? ' <em class="pct">-' + pct + "%</em>" : "");
  }
  function qHtml(qty, id) { return qty ? '<button class="m" data-m="' + id + '" aria-label="إنقاص">−</button><span>' + qty + '</span><button data-p="' + id + '" aria-label="زيادة">+</button>' : '<button data-p="' + id + '" aria-label="إضافة">+</button>'; }
  var thumb = function (u) { return /-m\.jpg$/.test(u) ? u.replace(/-m\.jpg$/, "-t.jpg") : u; };
  function itemHtml(i, TH, cart, idx) {
    var im = safeImg(i.img), tm = thumb(im), emo = i.emoji || TPL[TH.template] || "🍽️";
    return '<article class="it rv" data-o="' + i.id + '"><div class="ph">' + (im ? '<img ' + (idx < 4 ? "" : 'loading="lazy" ') + 'decoding="async" alt="" ' + (tm !== im ? 'data-f="' + esc(im) + '" ' : "") + 'src="' + esc(tm) + '">' : "<span>" + esc(emo) + "</span>") + (i.badge ? '<span class="bdg">' + esc(i.badge) + "</span>" : (i.pop ? '<span class="bdg pop">⭐</span>' : "")) + "</div>" +
      '<div class="tx"><h5 class="n">' + esc(i.name) + "</h5>" + (i.desc ? '<p class="d">' + esc(i.desc) + "</p>" : "") + '<div class="pr">' + priceHtml(i) + "</div></div>" +
      '<div class="q" data-q="' + i.id + '">' + qHtml(cart && cart[i.id], i.id) + "</div></article>";
  }
  function grid(list, TH, cart, st) {
    return '<div class="items s-' + st + '">' + list.map(function (i, k) { return itemHtml(i, TH, cart, k); }).join("") + "</div>";
  }
  function sec(id, title, list, TH, cart, st) { return '<section class="sec" id="sec-' + id + '">' + (title ? "<h2>" + esc(title) + "</h2>" : "") + grid(list, TH, cart, st) + "</section>"; }

  function blockHtml(b, D, TH, cart) {
    if (!b || b.hidden) return "";
    if (b.type === "banner") {
      var sl = (b.slides || []).filter(function (s) { return safeImg(s.img); }).slice(0, 8); if (!sl.length) return "";
      var ar = { wide: "16/6", std: "16/9", square: "1/1" }[b.ratio] || "16/7";
      return '<div class="bn" data-bn="' + esc(b.id) + '" style="--bar:' + ar + '"><div class="track">' + sl.map(function (s, k) {
        var go = s.cat ? ' data-go="' + esc(s.cat) + '"' : "";
        return '<a class="sl"' + go + '><img ' + (k ? 'loading="lazy" ' : 'fetchpriority="high" ') + 'decoding="async" alt="' + esc(s.title || "") + '" src="' + esc(safeImg(s.img)) + '">' + ((s.title || s.sub) ? '<div class="cap">' + (s.title ? "<b>" + esc(s.title) + "</b>" : "") + (s.sub ? "<span>" + esc(s.sub) + "</span>" : "") + "</div>" : "") + "</a>";
      }).join("") + "</div>" + (sl.length > 1 ? '<div class="dots">' + sl.map(function (_, k) { return '<i class="' + (k ? "" : "on") + '"></i>'; }).join("") + "</div>" : "") + "</div>";
    }
    if (b.type === "cats") {
      var cs = D.cats.filter(function (c) { return D.items.some(function (i) { return i.cat === c.id; }); }); if (cs.length < 1) return "";
      var circ = b.style === "circles";
      return '<nav class="cats' + (circ ? " circles" : "") + '" data-cats="1">' + cs.map(function (c, k) {
        return '<button data-cat="' + c.id + '" class="' + (k ? "" : "on") + '">' + (circ ? '<span class="em">' + esc(c.emoji || "🍽️") + "</span><span>" + esc(c.name) + "</span>" : esc((c.emoji ? c.emoji + " " : "") + c.name)) + "</button>";
      }).join("") + "</nav>";
    }
    if (b.type === "text") {
      if (!b.title && !b.text) return "";
      return '<div class="tb">' + (b.title ? "<h3>" + esc(b.title) + "</h3>" : "") + (b.text ? "<p>" + esc(b.text) + "</p>" : "") + "</div>";
    }
    if (b.type === "products") {
      var st = styleOf(TH, b.style), src = String(b.source || "all"), out = "";
      if (src === "all") {
        var seen = {}; D.cats.forEach(function (c) { var l = D.items.filter(function (i) { return i.cat === c.id; }); if (l.length) out += sec(c.id, (c.emoji ? c.emoji + " " : "") + c.name, l, TH, cart, st); seen[c.id] = 1; });
        var rest = D.items.filter(function (i) { return !seen[i.cat]; }); if (rest.length) out += sec(0, D.cats.length ? "أخرى" : "", rest, TH, cart, st);
        return out;
      }
      var list, title = b.title || "";
      if (src === "offers") { list = D.items.filter(function (i) { return i.old > i.price; }); title = title || "🔥 العروض"; }
      else if (src === "popular") { list = D.items.filter(function (i) { return i.pop; }); title = title || "⭐ الأكثر طلباً"; }
      else if (src.indexOf("cat:") === 0) { var cid = +src.slice(4), c2 = D.cats.filter(function (c) { return c.id === cid; })[0]; list = D.items.filter(function (i) { return i.cat === cid; }); title = title || (c2 ? (c2.emoji ? c2.emoji + " " : "") + c2.name : ""); }
      else list = [];
      return list.length ? '<section class="sec">' + (title ? "<h2>" + esc(title) + "</h2>" : "") + grid(list.slice(0, 60), TH, cart, st) + "</section>" : "";
    }
    return "";
  }
  var DEFBLOCKS = [{ id: "d1", type: "cats", style: "chips" }, { id: "d2", type: "products", source: "all" }];
  function head(TH, info) {
    var cov = safeImg(TH.cover), lg = safeImg(TH.logo), emo = TPL[TH.template] || "🍽️";
    return '<div class="cover">' + (cov ? '<img decoding="async" fetchpriority="high" alt="" src="' + esc(cov) + '">' : '<span class="cv-emo">' + esc(emo) + "</span>") + '</div><div class="info"><div class="logo">' + (lg ? '<img decoding="async" alt="" src="' + esc(lg) + '">' : "<span>" + esc(emo) + "</span>") + "</div><div><h1>" + esc(TH.name || "المنيو") + "</h1><p>" + esc(TH.tagline || info || "") + "</p></div></div>";
  }
  function offerBar(TH) { var o = TH.offer || {}; return o.on && o.text ? '<div class="offer" style="background:' + colorOk(o.color, "#dc2626") + '">' + esc(o.text) + "</div>" : ""; }
  function html(D, TH, o) {
    o = o || {}; TH = TH || {}; var cart = o.cart || {}, blocks = Array.isArray(TH.blocks) && TH.blocks.length ? TH.blocks : DEFBLOCKS;
    var h = head(TH, o.info) + offerBar(TH) + (o.status ? '<span class="st">' + esc(o.status) + "</span>" : "");
    h += blocks.map(function (b) { return blockHtml(b, D, TH, cart); }).join("");
    var notes = []; if (D.fee) notes.push("رسوم التوصيل " + money(D.fee) + (D.free_over ? " (مجاني فوق " + money(D.free_over) + ")" : "")); if (D.min_order) notes.push("الحد الأدنى " + money(D.min_order));
    if (notes.length) h += '<div class="note">' + esc(notes.join(" · ")) + "</div>";
    return h;
  }
  window.MSARMENU = { html: html, rootClass: rootClass, qHtml: qHtml, priceHtml: priceHtml, money: money, esc: esc, safeImg: safeImg, TPL: TPL, colorOk: colorOk };
})();
