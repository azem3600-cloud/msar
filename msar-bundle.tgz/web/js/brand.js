/* مسار — صفحة «هوية المتجر»: تخصيص صفحة تتبع الطلب (شعار + ألوان + رسالة) */
(function () {
  const A = window.AZM, { sb, $, $$, esc, toast } = A;
  const DEF = { logo_data: null, color_primary: "#144F74", color_accent: "#159FC6", display_name: "", tagline: "", hero_style: "solid", show_powered: true };
  let SID = null, row = { ...DEF }, storeName = "";

  const hex2 = (n) => Math.max(0, Math.min(255, Math.round(n))).toString(16).padStart(2, "0");
  const toHex = (r, g, b) => "#" + hex2(r) + hex2(g) + hex2(b);
  const lum = (r, g, b) => { const f = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b); };
  const parse = (h) => [1, 3, 5].map((i) => parseInt(h.slice(i, i + 2), 16));
  // يغمّق اللون لو كان فاتحاً بحيث يظهر النص الأبيض فوقه بوضوح
  const readable = (h) => { let [r, g, b] = parse(h); let k = 0; while (lum(r, g, b) > 0.28 && k++ < 30) { r *= 0.92; g *= 0.92; b *= 0.92; } return toHex(r, g, b); };

  /** استخراج لونين رئيسيين من الشعار (يتجاهل الأبيض والرمادي والشفاف) */
  function palette(img) {
    const c = document.createElement("canvas"); const S = 64; c.width = c.height = S; const x = c.getContext("2d"); x.drawImage(img, 0, 0, S, S);
    const d = x.getImageData(0, 0, S, S).data; const bk = new Map();
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2], a = d[i + 3]; if (a < 200) continue;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b), sat = mx ? (mx - mn) / mx : 0;
      if (mx > 235 && sat < 0.15) continue; if (sat < 0.22 && mx > 40) continue; if (mx < 25) continue;
      const k = (r >> 5) + "," + (g >> 5) + "," + (b >> 5); const e = bk.get(k) || { n: 0, r: 0, g: 0, b: 0 }; e.n++; e.r += r; e.g += g; e.b += b; bk.set(k, e);
    }
    const arr = [...bk.values()].sort((p, q) => q.n - p.n).map((e) => [e.r / e.n, e.g / e.n, e.b / e.n]);
    if (!arr.length) return null;
    const dist = (p, q) => Math.hypot(p[0] - q[0], p[1] - q[1], p[2] - q[2]);
    const p1 = arr[0]; const p2 = arr.find((p) => dist(p, p1) > 90) || [Math.min(255, p1[0] * 1.25 + 20), Math.min(255, p1[1] * 1.25 + 20), Math.min(255, p1[2] * 1.25 + 20)];
    return { primary: readable(toHex(...p1)), accent: toHex(...p2) };
  }
  const logoFromFile = (file) => new Promise((res, rej) => {
    const img = new Image(), u = URL.createObjectURL(file);
    img.onload = () => {
      const k = Math.min(1, 256 / Math.max(img.width, img.height)); const c = document.createElement("canvas"); c.width = Math.max(1, Math.round(img.width * k)); c.height = Math.max(1, Math.round(img.height * k));
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
      const data = c.toDataURL("image/png"); const im2 = new Image(); im2.onload = () => res({ data, pal: palette(im2) }); im2.src = data;
    };
    img.onerror = () => rej(new Error("الصورة غير مقروءة")); img.src = u;
  });

  const preview = (v) => {
    const grad = v.hero_style === "gradient"; const name = v.display_name || storeName || "اسم المتجر";
    return `<div style="max-width:300px;margin:0 auto;border:1px solid #d9e4e9;border-radius:14px;overflow:hidden;background:#f2f7fa;font-size:13px">
      <div style="background:${grad ? `linear-gradient(135deg,${v.color_primary},${v.color_accent})` : v.color_primary};color:#fff;padding:14px 12px 34px;display:flex;gap:10px;align-items:center">
        <div style="width:42px;height:42px;border-radius:10px;background:#fff;display:grid;place-items:center;overflow:hidden;color:${v.color_primary};font-weight:800;flex:none">${v.logo_data ? `<img src="${v.logo_data}" style="width:100%;height:100%;object-fit:contain">` : esc(name.charAt(0))}</div>
        <div><b style="font-size:15px">${esc(name)}</b><div style="opacity:.85">طلب رقم 1042</div></div></div>
      <div style="margin:-22px 10px 0;background:#fff;border:1px solid #d9e4e9;border-radius:8px;padding:12px;text-align:center"><div style="font-size:28px">🚚</div><b>طلبك في الطريق لك</b></div>
      <div style="margin:8px 10px;background:#fff;border:1px solid #d9e4e9;border-radius:8px;padding:10px">
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:6px"><span style="width:18px;height:18px;border-radius:50%;background:#73AE46;display:inline-block"></span> تم استلام الطلب</div>
        <div style="display:flex;gap:8px;align-items:center;font-weight:700"><span style="width:18px;height:18px;border-radius:50%;border:2px solid ${v.color_accent};background:#fff;display:inline-block"></span> في الطريق</div></div>
      ${v.tagline ? `<div style="margin:8px 10px;background:#fff;border:1px solid #d9e4e9;border-radius:8px;padding:10px;text-align:center;font-weight:600">${esc(v.tagline)}</div>` : ""}
      <div style="text-align:center;padding:6px 0 12px;color:#64748b;font-size:12px">الصفحة تتحدّث تلقائياً${v.show_powered ? " · مقدّم من مسار" : ""}</div></div>`;
  }

  async function render(view, ctx) {
    SID = ctx.storeId; view.innerHTML = `<div class="empty">جاري التحميل…</div>`;
    const [b, s] = await Promise.all([sb.from("store_brand").select("*").eq("store_id", SID).maybeSingle(), sb.from("stores").select("name,logo_url").eq("id", SID).maybeSingle()]);
    if (b.error) { view.innerHTML = `<div class="card"><div class="empty">⚠️ ${esc(A.errMsg(b.error))}<br><span class="small">تأكد أن ترقية 015 مشغّلة في قاعدة البيانات.</span></div></div>`; return; }
    storeName = s.data?.name || ""; row = { ...DEF, ...(b.data || {}) };
    if (!row.logo_data && s.data?.logo_url && /^https:/.test(s.data.logo_url)) row._storeLogo = s.data.logo_url;
    view.innerHTML = `<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px;align-items:start">
      <div class="card"><div class="card-head"><h3>🎨 هوية صفحة التتبع</h3></div>
        <div class="small muted" style="margin-bottom:10px">هذي الصفحة اللي يفتحها عميلك من رابط التتبع. ارفع شعارك وتتلوّن الصفحة تلقائياً بألوانه، وتقدر تعدّل كل شي.</div>
        <label class="field"><span>شعار المتجر (PNG أو JPG)</span><input type="file" id="br-f" accept="image/*"></label>
        <div class="row" style="gap:10px;margin:6px 0"><button class="btn btn-sm" id="br-auto" ${row.logo_data ? "" : "disabled"}>✨ استخراج الألوان من الشعار</button><button class="btn btn-sm" id="br-rmlogo" ${row.logo_data ? "" : "disabled"}>حذف الشعار</button></div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
          <label class="field"><span>اللون الرئيسي</span><input type="color" id="br-p" value="${row.color_primary || DEF.color_primary}" style="width:100%;height:40px"></label>
          <label class="field"><span>لون التمييز</span><input type="color" id="br-a" value="${row.color_accent || DEF.color_accent}" style="width:100%;height:40px"></label></div>
        <label class="field"><span>اسم المتجر الظاهر (اتركه فاضي لاسم متجرك)</span><input id="br-n" maxlength="60" value="${esc(row.display_name || "")}" placeholder="${esc(storeName)}"></label>
        <label class="field"><span>رسالة للعميل تظهر في الصفحة (اختياري)</span><input id="br-t" maxlength="140" value="${esc(row.tagline || "")}" placeholder="شكراً لثقتك فينا 🌷"></label>
        <label class="field"><span>شكل الرأس</span><select id="br-h"><option value="solid" ${row.hero_style === "solid" ? "selected" : ""}>لون واحد</option><option value="gradient" ${row.hero_style === "gradient" ? "selected" : ""}>تدرّج بين اللونين</option></select></label>
        <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="br-pw" ${row.show_powered !== false ? "checked" : ""}> إظهار «مقدّم من مسار» أسفل الصفحة</label>
        <div class="row" style="margin-top:8px"><button class="btn btn-primary" id="br-save">💾 حفظ</button><button class="btn btn-sm" id="br-reset">استعادة الافتراضي</button></div></div>
      <div class="card"><div class="card-head"><h3>معاينة مباشرة</h3></div><div id="br-pv"></div></div></div>`;
    const read = () => ({ ...row, color_primary: $("#br-p", view).value, color_accent: $("#br-a", view).value, display_name: $("#br-n", view).value.trim(), tagline: $("#br-t", view).value.trim(), hero_style: $("#br-h", view).value, show_powered: $("#br-pw", view).checked });
    const paint = () => { $("#br-pv", view).innerHTML = preview(read()); };
    ["#br-p", "#br-a", "#br-n", "#br-t", "#br-h", "#br-pw"].forEach((q) => { $(q, view).oninput = paint; $(q, view).onchange = paint; });
    $("#br-f", view).onchange = async (e) => {
      const f = e.target.files?.[0]; if (!f) return;
      try { const r = await logoFromFile(f); row.logo_data = r.data; if (r.pal) { $("#br-p", view).value = r.pal.primary; $("#br-a", view).value = r.pal.accent; toast("تم استخراج الألوان من الشعار ✨"); } else toast("ما قدرت أستخرج ألوان واضحة، اختر الألوان يدوياً"); $("#br-auto", view).disabled = false; $("#br-rmlogo", view).disabled = false; paint(); }
      catch (er) { toast(er.message || "تعذّر رفع الشعار", "error"); }
    };
    $("#br-auto", view).onclick = () => { if (!row.logo_data) return; const im = new Image(); im.onload = () => { const p = palette(im); if (p) { $("#br-p", view).value = p.primary; $("#br-a", view).value = p.accent; paint(); toast("تم ✨"); } else toast("ما قدرت أستخرج ألوان واضحة", "error"); }; im.src = row.logo_data; };
    $("#br-rmlogo", view).onclick = () => { row.logo_data = null; $("#br-auto", view).disabled = true; $("#br-rmlogo", view).disabled = true; paint(); };
    $("#br-reset", view).onclick = () => { row = { ...DEF }; render(view, ctx); };
    $("#br-save", view).onclick = async () => {
      const v = read();
      const rec = { store_id: SID, logo_data: v.logo_data, color_primary: v.color_primary, color_accent: v.color_accent, display_name: v.display_name || null, tagline: v.tagline || null, hero_style: v.hero_style, show_powered: v.show_powered, updated_at: new Date().toISOString() };
      const { error } = await sb.from("store_brand").upsert(rec);
      if (error) return toast(A.errMsg(error), "error");
      row = { ...rec }; toast("تم الحفظ — صفحة التتبع تتلوّن بهويتك من الحين ✅");
    };
    paint();
  }
  window.MSAR_BRAND = { render };
})();
