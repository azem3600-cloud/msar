/* مسار — لغة تطبيق المندوب (عربي / English). الاختيار يُحفظ في الجهاز ويُطبَّق على كل نصوص التطبيق تلقائياً. */
(function () {
  const KEY = "msar-lang";
  let lang = "ar";
  try { lang = localStorage.getItem(KEY) === "en" ? "en" : "ar"; } catch (_) {}
  const EN = lang === "en";
  const api = { lang, isEn: EN, set(l) { try { localStorage.setItem(KEY, l); } catch (_) {} location.reload(); }, T: (s) => s };
  window.MSAR_LANG = api;
  window.MSAR_T = (s) => api.T(s);
  if (!EN) return;

  document.documentElement.lang = "en"; document.documentElement.dir = "ltr";
  document.documentElement.classList.add("lang-en");

  const D = {
    "جاري التحميل…": "Loading…", "تطبيق المندوب": "Driver app", "مسار": "Msar",
    "الإيميل أو اسم المستخدم": "Email or username", "رمز المتجر": "Store code", "(لاسم المستخدم فقط)": "(username login only)",
    "رقم الجوال": "Mobile number", "كلمة المرور": "Password", "دخول": "Sign in", "نسيت كلمة المرور؟": "Forgot password?",
    "الدخول برقم الجوال": "Sign in with mobile number", "دخول بالإيميل أو اسم المستخدم": "Sign in with email or username",
    "أو": "or", "الدخول بقوقل": "Sign in with Google",
    "حسابك غير مرتبط بأي متجر فعّال": "Your account is not linked to any active store",
    "هذا التطبيق خاص بالمناديب — استخدم لوحة التحكم من المتصفح": "This app is for drivers only — use the dashboard from a browser",
    "اختر المتجر": "Choose store", "حسابك مرتبط بأكثر من متجر:": "Your account is linked to more than one store:",
    "غير متصل": "Offline", "متصل — تستقبل الطلبات وموقعك مشارك": "Online — receiving orders, location shared",
    "الطلبات الحالية": "Current orders", "مكتملة اليوم": "Completed today",
    "تطبيق أندرويد": "Android app", "نسخة الويب": "Web version",
    "القائمة": "Menu", "تحديث الطلبات": "Refresh orders", "حسابي وكلمة المرور": "My account & password",
    "تجربة صوت التنبيه": "Test alert sound", "إعدادات البطارية (مهم لعدم إيقاف التطبيق)": "Battery settings (important so the app isn't stopped)",
    "تسجيل خروج": "Sign out", "إغلاق": "Close", "إلغاء": "Cancel", "تأكيد": "Confirm", "نعم": "Yes", "حفظ": "Save", "تم": "Done",
    "تجربة": "Test", "التنبيهات تعمل بشكل سليم": "Alerts are working properly",
    "✅ إشعارات الخلفية مفعّلة (توصلك والتطبيق مقفول)": "✅ Background notifications on (you get them even when the app is closed)",
    "⚠️ الإشعارات مرفوضة — فعّلها من إعدادات الجوال": "⚠️ Notifications denied — enable them in phone settings",
    "⚠️ تعذر تفعيل إشعارات الخلفية": "⚠️ Couldn't enable background notifications",
    "ℹ️ إشعارات الخلفية غير متوفرة في هذه النسخة": "ℹ️ Background notifications aren't available in this version",
    "💡 لضمان وصول التنبيهات: خلّ وضع \"متصل\" شغال، وفعّل الإشعارات، واستثنِ التطبيق من توفير البطارية.": "💡 To make sure alerts reach you: keep \"Online\" on, enable notifications, and exclude the app from battery saving.",
    "تأكيد ": "Confirm ", "عندك طلب في الطريق. متأكد تبي تقفل التتبع؟": "You have an order on the way. Sure you want to stop tracking?",
    "صلاحية الموقع مرفوضة — اضغط هنا لفتح الإعدادات": "Location permission denied — tap here to open settings",
    "تعذر تشغيل تتبع الموقع": "Couldn't start location tracking", "الجهاز لا يدعم تحديد الموقع": "This device doesn't support location",
    "اسمح للتطبيق بالوصول للموقع من إعدادات المتصفح": "Allow location access from the browser settings",
    "جاري تحديد الموقع…": "Getting your location…",
    "مسار — أنت متصل": "Msar — you're online", "يتم مشاركة موقعك مع الفرع أثناء العمل": "Your location is shared with the branch while you work",
    "طلب جديد لك!": "New order for you!", "طلب جديد!": "New order!", "عرض الطلب": "View order",
    "لا يوجد طلبات حالياً": "No orders right now", "أنت غير متصل": "You're offline",
    "أول ما يرسل لك الفرع طلب بيوصلك تنبيه مع صوت.": "As soon as the branch sends you an order you'll get an alert with sound.",
    "فعّل زر الاتصال فوق عشان تستقبل الطلبات.": "Turn on the switch above to receive orders.",
    "عميل": "Customer", "الملاحة": "Navigate", "اتصال": "Call", "واتساب": "WhatsApp",
    "حصّل من العميل:": "Collect from customer:", "كيف بيدفع العميل؟": "How will the customer pay?",
    "مدفوع مسبقاً — لا تحصّل شيء": "Prepaid — collect nothing", "مدفوع مسبقاً": "Prepaid",
    "استلمت الطلب — بدء التوصيل": "Picked up — start delivery", "تم التسليم للعميل": "Delivered to customer",
    "أرسل \"في الطريق\"": "Send \"on the way\"", "إرجاع للفرع": "Return to branch", "اتصال بالفرع": "Call the branch",
    "بالتوفيق 🛵 — تم إبلاغ النظام أنك في الطريق": "Good luck 🛵 — the system knows you're on the way",
    "الملاحة ": "Navigate ", "تفتح الخريطة للوصول للعميل؟": "Open the map to reach the customer?", "افتح الخريطة": "Open map",
    "تأكيد التسليم": "Confirm delivery", "تأكيد تسليم الطلب للعميل؟": "Confirm the order was delivered to the customer?",
    "نعم، تم التسليم": "Yes, delivered", "ممتاز 👏 تم تسليم الطلب": "Great 👏 order delivered",
    "إرجاع الطلب للفرع": "Return order to branch", "السبب": "Reason", "مثال: العميل لا يرد / العنوان غير صحيح": "e.g. customer not answering / wrong address",
    "إرجاع": "Return", "تم إرجاع الطلب للفرع": "Order returned to the branch",
    "كيف دفع العميل؟": "How did the customer pay?", "نقداً": "Cash", "استلمت المبلغ كاش": "I received the cash",
    "شبكة / بطاقة": "Card / network", "دفع بجهاز الشبكة": "Paid by card machine",
    "اختر طريقة الدفع: نقداً أو شبكة": "Choose a payment method: cash or card",
    "طلبات مسلّمة اليوم": "Orders delivered today", "نقدي معك للتسليم": "Cash on you to hand over", "شبكة (ما يحتاج تسلّمه)": "Card (nothing to hand over)",
    "لا يوجد طلبات مكتملة اليوم": "No completed orders today",
    "جديد": "New", "قيد التجهيز": "Preparing", "جاهز للإرسال": "Ready to send", "عند المندوب": "With driver", "في الطريق": "On the way",
    "تم التسليم": "Delivered", "ملغي": "Cancelled", "مدير": "Manager", "كاشير": "Cashier", "مندوب": "Driver",
    "الآن": "Just now", "المبلغ": "Amount", "طريقة التحصيل": "Collection method",
    "شبكة عند الاستلام": "Card on delivery", "نقداً عند الاستلام": "Cash on delivery", "عند الاستلام": "On delivery",
    "تم: الدفع بالشبكة": "Done: paid by card", "تم: الدفع نقداً": "Done: paid in cash",
    "لا توجد منتجات": "No items", "المتجر": "Store", "عرض المنتج في المتجر": "View product in store",
    "حسابي": "My account", "الإيميل": "Email", "مربوط بقوقل": "Linked to Google", "ما عندك إيميل مربوط": "No email linked",
    "كلمة مرور جديدة (8 أحرف أو أكثر)": "New password (8+ characters)", "تغيير كلمة المرور": "Change password", "ربط": "Link",
    "تم تغيير كلمة المرور": "Password changed", "كلمة المرور لازم تكون 8 أحرف أو أكثر": "Password must be at least 8 characters",
    "متاجري": "My stores", "الحالي": "Current",
    "اسم المستخدم أو كلمة المرور غير صحيحة": "Wrong username or password", "تعذر الاتصال بالإنترنت": "Couldn't connect to the internet",
    "انتهت الجلسة، سجل الدخول من جديد": "Session expired, please sign in again", "هذا الحقل مطلوب": "This field is required",
    "استعادة كلمة المرور": "Reset password", "أرسل الرابط": "Send link", "اكتب إيميل صحيح": "Enter a valid email",
    "اكتب الإيميل المربوط بحسابك ويوصلك رابط تختار فيه كلمة مرور جديدة.": "Enter the email linked to your account and we'll send you a link to choose a new password.",
    "ما عندك إيميل مربوط (دخول برمز المتجر واسم المستخدم)؟ اطلب من مدير المتجر يغيّر لك كلمة المرور.": "No email linked (signing in with store code and username)? Ask the store manager to change your password.",
    "إذا الإيميل مسجّل عندنا بيوصلك رابط خلال دقائق": "If the email is registered you'll get a link within minutes",
    "تم النسخ": "Copied", "سجّل الدخول أولاً": "Please sign in first",
    "رقم الجوال أو كلمة المرور غير صحيحة": "Wrong mobile number or password",
    "المحاولات كثيرة، جرّب بعد قليل": "Too many attempts, try again shortly",
    "الإسم": "Name", "ر.س": "SAR",     "عرض المنتجات": "View items", "مدة التوصيل": "Delivery time", "دقيقة": "min", "نقدي": "Cash", "شبكة": "Card",
    "حصّل من العميل": "Collect from customer", "الأربعاء": "Wed",
  };
  const PAT = [
    [/^قبل (\d+) د$/, "$1 min ago"], [/^قبل (\d+) س\s*(?:(\d+) د)?$/, (m, h, mi) => `${h} h${mi ? " " + mi + " min" : ""} ago`], [/^قبل (\d+) يوم$/, "$1 d ago"],
    [/^إرجاع من المندوب: (.*)$/, "Returned by driver: $1"], [/^تم ربط (.+) — من الحين ادخل بالإيميل$/, "$1 linked — sign in with the email from now on"],
    [/^خطأ (\d+)$/, "Error $1"], [/^([\d.,]+) كم منك$/, "$1 km away"], [/^([\d.,]+) منتج$/, "$1 items"],
    [/^(\d{1,2}:\d{2})\s*م$/, "$1 PM"], [/^(\d{1,2}:\d{2})\s*ص$/, "$1 AM"], [/^مدة التوصيل ([\d.,]+)\s*د(?:قيقة)?$/, "Delivery time $1 min"],
  ];
  const NATIVE_DIG = { "٠": "0", "١": "1", "٢": "2", "٣": "3", "٤": "4", "٥": "5", "٦": "6", "٧": "7", "٨": "8", "٩": "9", "٫": ".", "٬": "," };
  const KEYS = Object.keys(D).filter((k) => k.length >= 2).sort((a, b) => b.length - a.length);
  const RX = {}; KEYS.forEach((k) => { RX[k] = new RegExp("(?<![\\p{L}\\p{N}])" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "(?![\\p{L}\\p{N}])", "gu"); });
  const AR = /[؀-ۿ]/;
  const norm = (s) => s.replace(/[٠-٩٫٬]/g, (c) => NATIVE_DIG[c]);

  function tr(str) {
    if (!str || !(AR.test(str) || /[٠-٩]/.test(str))) return str;
    const m = str.match(/^(\s*[^\p{L}\p{N}]*)([\s\S]*?)([^\p{L}\p{N}]*\s*)$/u);
    const pre = m ? m[1] : "", core = m ? m[2] : str, post = m ? m[3] : "";
    const whole = str.trim();
    if (D[whole]) return str.replace(whole, D[whole]);
    let c = norm(core.trim());
    if (D[c]) return pre + D[c] + post;
    for (const [re, rep] of PAT) if (re.test(c)) return pre + c.replace(re, rep) + post;
    // استبدال العبارات المعروفة داخل النص المركّب
    let out = norm(str);
    for (const k of KEYS) if (out.includes(k)) out = out.replace(RX[k], D[k]);
    return out;
  }
  api.T = tr;

  const ATTRS = ["placeholder", "title", "aria-label", "alt"];
  function node(n) {
    if (n.nodeType === 3) { const p = n.parentNode && n.parentNode.nodeName; if (p === "SCRIPT" || p === "STYLE" || p === "TEXTAREA") return; const t = tr(n.data); if (t !== n.data) n.data = t; return; }
    if (n.nodeType !== 1) return;
    if (n.nodeName === "SCRIPT" || n.nodeName === "STYLE") return;
    for (const a of ATTRS) if (n.hasAttribute(a)) { const v = n.getAttribute(a), t = tr(v); if (t !== v) n.setAttribute(a, t); }
    if (n.nodeName === "INPUT" && n.type === "submit") { const t = tr(n.value); if (t !== n.value) n.value = t; }
    n.childNodes.forEach(node);
  }
  function start() {
    document.title = tr(document.title);
    node(document.body);
    new MutationObserver((ms) => {
      for (const m of ms) {
        if (m.type === "childList") m.addedNodes.forEach(node);
        else if (m.type === "characterData") node(m.target);
        else if (m.type === "attributes") node(m.target);
      }
    }).observe(document.body, { childList: true, subtree: true, characterData: true, attributes: true, attributeFilter: ATTRS });
  }
  if (document.body) start(); else document.addEventListener("DOMContentLoaded", start);
})();
