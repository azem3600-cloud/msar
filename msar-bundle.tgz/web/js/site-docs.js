/* مسار — المحتوى الافتراضي لصفحات الوثائق (يُعدَّل من لوحة صاحب المنصة ← الموقع ← الصفحات). الصيغة: ماركداون مبسّط */
(function (root) {
  const DOCS = {
    // ================================================================== سياسة الخصوصية
    privacy: {
      title_ar: "سياسة الخصوصية", title_en: "Privacy Policy", updated: "2026-11-14",
      ar: `توضّح هذه السياسة كيف تجمع منصة **مسار** ("المنصة" أو "نحن") البيانات وتستخدمها وتحميها عند تثبيتها على متجر في منصة زد، وعند استخدام لوحة التحكم وشاشات الفروع وتطبيق المندوب والموقع الإلكتروني msarpro.com.

## 1. البيانات التي نجمعها
- **بيانات المتجر:** اسم المتجر ورابطه وشعاره ومعرّفه في زد، وبريد وجوال صاحب المتجر كما توفّرها زد عند التثبيت.
- **بيانات الطلبات:** رقم الطلب وحالته والمنتجات والمبالغ وطريقة الدفع والشحن، واسم العميل وجواله وعنوانه وموقعه الجغرافي، وذلك لتوجيه الطلب لأقرب فرع وتوصيله.
- **بيانات المستخدمين:** أسماء وإيميلات وأرقام جوالات مدراء المتجر والكاشير والمناديب. كلمات المرور تُحفظ مشفّرة ولا نطّلع عليها.
- **موقع المندوب:** يُرسل تطبيق المندوب موقعه أثناء العمل فقط لعرضه على الخريطة وتتبع التوصيل.
- **رموز الربط مع زد:** رموز الوصول التي تمنحها زد عند التثبيت، وتُحفظ في الخادم فقط ولا تظهر في المتصفح.
- **نموذج التواصل:** الاسم والجوال والإيميل والرسالة التي ترسلها لنا من الموقع.
- **بيانات واتساب (للتجار الذين يفعّلون خدمة الطلبات عبر واتساب):** رقم جوال العميل واسمه الظاهر في واتساب، ومحتوى الرسائل المتبادلة مع رقم المتجر (نصوص، أزرار، موقع جغرافي مشارَك)، وحالة التسليم والقراءة، وسجل الطلبات السابقة لنفس العميل لدى نفس المتجر.
- **رموز ربط واتساب:** معرّف حساب واتساب للأعمال ومعرّف رقم الهاتف ورمز الوصول الذي يمنحه التاجر عند ربط رقمه، ويُحفظ في الخادم فقط.

## 2. كيف نستخدم البيانات
- استقبال طلبات المتجر من زد وتوجيهها للفرع الأقرب للعميل.
- عرض الطلبات على شاشات الفروع وتطبيق المندوب، وتتبّع التوصيل.
- تحديث حالة الطلب في زد عند تفعيل التاجر لهذا الخيار.
- إعداد التقارير لصاحب المتجر، والدعم الفني ومعالجة الأخطاء.
- الرد على طلبات التواصل والعروض.

لا نبيع البيانات ولا نستخدمها للإعلانات، ولا نشاركها مع أي طرف ثالث إلا مزوّدي الخدمة اللازمين لتشغيل المنصة (الاستضافة وقاعدة البيانات والخرائط)، أو إذا طلبت جهة نظامية ذلك.

## 3. عزل بيانات المتاجر
بيانات كل متجر معزولة عن غيره على مستوى قاعدة البيانات، ولا يرى مستخدمو أي متجر إلا بيانات متجرهم، ويرى الكاشير والمندوب ما يخص فرعهم وطلباتهم فقط.

## 4. مدة الاحتفاظ بالبيانات
- مواقع المناديب: 90 يوماً ثم تُحذف تلقائياً.
- سجلات الربط والأخطاء: 30 يوماً.
- عند حذف التطبيق من زد: نوقف الربط فوراً ونحذف رموز الوصول، ثم نحذف كل بيانات المتجر (الطلبات والفروع والمستخدمين) تلقائياً بعد 90 يوماً، إلا إذا أعاد التاجر تثبيت التطبيق خلالها.

## 5. خدمة الطلبات عبر واتساب (Meta)
عند تفعيل التاجر لهذه الخدمة يستقبل رقم واتساب الخاص بالمتجر رسائل عملائه، وتُعالَج عبر واجهة WhatsApp Business Cloud API المقدَّمة من شركة Meta Platforms. وبناءً عليه:
- نستخدم رقم العميل ومحتوى رسائله فقط لإتمام الطلب: عرض القائمة، وتسجيل الطلب وتأكيده، وإرسال تحديثات حالته، والرد على استفساراته، وعرضه على شاشة الكاشير للمتجر.
- قد تُستخدم خدمة ذكاء اصطناعي لفهم رسالة العميل وصياغة الرد، وتُرسَل لها نصوص المحادثة اللازمة فقط (مزوّد الذكاء الاصطناعي: Google Gemini)، ولا نستخدمها لتدريب نماذج خاصة بنا ولا لأي غرض إعلاني.
- تمرّ الرسائل عبر خوادم Meta وتخضع كذلك لـ [سياسة خصوصية واتساب للأعمال](https://www.whatsapp.com/legal/business-policy) و[شروط Meta](https://www.facebook.com/legal/terms) بالقدر الذي ينطبق عليها.
- التاجر هو المتحكّم في بيانات عملائه، ونحن معالِج لها نيابةً عنه. والتاجر مسؤول عن الحصول على موافقة عملائه المطلوبة نظاماً قبل مراسلتهم، وعن عدم إرسال رسائل ترويجية لمن لم يوافق، وعن إشعارهم بأن الطلب يتم عبر واتساب.
- لا نبيع أرقام العملاء ولا نشاركها مع المتاجر الأخرى، وبيانات كل متجر معزولة عن غيره.
- مدة الاحتفاظ: تُحذف نصوص الرسائل تلقائياً بعد 30 يوماً من تاريخ كل رسالة، ويبقى اسم العميل المعلن وحالة جلسته الأخيرة وبيانات الطلب نفسها (رقم الجوال والاسم والعنوان والمنتجات) لدى التاجر لأغراضه المحاسبية والنظامية حتى يحذفها أو يطلب حذفها.
- عند طلب التاجر فصل رقمه أو إلغاء اشتراكه نحذف رمز الوصول ونوقف استقبال الرسائل.

## 6. حقوقك
يحق لصاحب المتجر طلب نسخة من بياناته أو تصحيحها أو حذفها في أي وقت عبر التواصل معنا. ويحق للعميل النهائي (بما فيهم من راسل متجراً عبر واتساب) التواصل مع المتجر الذي راسله، أو معنا مباشرة، لطلب الاطلاع على بياناته أو حذفها، وفق التعليمات في [صفحة حذف البيانات](data-deletion). نلتزم بنظام حماية البيانات الشخصية في المملكة العربية السعودية.

## 7. الأمان
تُنقل البيانات عبر اتصال مشفّر (HTTPS)، وتُحفظ في قاعدة بيانات محمية بصلاحيات على مستوى الصفوف، وتُحفظ الأسرار ورموز الوصول في الخادم فقط.

## 8. ملفات تعريف الارتباط
نستخدم التخزين المحلي في المتصفح فقط لحفظ جلسة الدخول وتفضيلاتك (مثل اللغة)، ولا نستخدم ملفات تتبع إعلانية.

## 9. التعديلات
قد نحدّث هذه السياسة من وقت لآخر، ونوضّح تاريخ آخر تحديث أعلى الصفحة.

## 10. التواصل وحذف البيانات
لأي استفسار عن الخصوصية أو لطلب حذف البيانات: [info@msarpro.com](mailto:info@msarpro.com) — أو من [صفحة الدعم](support). خطوات الحذف التفصيلية في [صفحة حذف البيانات](data-deletion).\n\n**الجهة المشغّلة:** شركة تمكين المتحدة التجارية (شركة شخص واحد) — السجل التجاري (الرقم الوطني الموحد) 7017440962 — الرقم الضريبي 311868414300003 — الجوهرة، الجبيل 35518، المملكة العربية السعودية — +966545547123.`,
      en: `This policy explains how **Msar** ("the platform", "we") collects, uses and protects data when it is installed on a Zid store, and when you use the dashboard, branch screens, the driver app and the msarpro.com website.

## 1. Data we collect
- **Store data:** store name, URL, logo and Zid ID, plus the owner's email and mobile as provided by Zid at installation.
- **Order data:** order number, status, items, amounts, payment and shipping method, and the customer's name, mobile, address and location — used to route the order to the nearest branch and deliver it.
- **User data:** names, emails and mobile numbers of store admins, cashiers and drivers. Passwords are stored hashed and are never visible to us.
- **Driver location:** the driver app sends location only while on duty, to show it on the map and track deliveries.
- **Zid connection tokens:** access tokens granted by Zid at installation, stored server-side only and never exposed in the browser.
- **Contact form:** the name, mobile, email and message you send us from the website.
- **WhatsApp data (for merchants who enable ordering via WhatsApp):** the customer's phone number and WhatsApp profile name, the content of messages exchanged with the store's number (text, buttons, shared location), delivery/read status, and the customer's previous orders at that same store.
- **WhatsApp connection credentials:** the WhatsApp Business Account ID, phone number ID and access token the merchant grants when linking their number, stored server-side only.

## 2. How we use data
- Receive store orders from Zid and route each to the branch nearest the customer.
- Show orders on branch screens and the driver app, and track deliveries.
- Update the order status in Zid when the merchant enables this option.
- Produce reports for the store owner, provide support and fix errors.
- Reply to contact and demo requests.

We do not sell data or use it for advertising, and we do not share it with third parties except service providers required to run the platform (hosting, database, maps), or when legally required.

## 3. Store isolation
Each store's data is isolated at the database level. Users only see their own store's data; cashiers and drivers see only their branch and their orders.

## 4. Retention
- Driver locations: 90 days, then deleted automatically.
- Integration and error logs: 30 days.
- When the app is uninstalled from Zid we stop the connection immediately and delete access tokens, then delete all store data (orders, branches, users) automatically after 90 days unless the merchant reinstalls within that period.

## 5. Ordering via WhatsApp (Meta)
When a merchant enables this service, the store's WhatsApp number receives its customers' messages, which are processed through the WhatsApp Business Cloud API provided by Meta Platforms. Accordingly:
- We use the customer's number and message content only to complete the order: show the menu, record and confirm the order, send status updates, answer questions, and display it on the store's cashier screen.
- An AI service may be used to understand the customer's message and draft the reply; only the conversation text needed is sent (provider: Google Gemini), and we do not use it to train our own models or for advertising.
- Messages pass through Meta's servers and are also subject to the [WhatsApp Business Policy](https://www.whatsapp.com/legal/business-policy) and [Meta Terms](https://www.facebook.com/legal/terms) to the extent they apply.
- The merchant is the controller of their customers' data and we process it on the merchant's behalf. The merchant is responsible for obtaining the customer consent required by law before messaging them, for not sending promotional messages to those who have not agreed, and for informing customers that ordering happens over WhatsApp.
- We do not sell customer numbers or share them with other stores; each store's data is isolated.
- Retention: message text is deleted automatically 30 days after each message. The customer's stated name, last session state and the order record itself (phone, name, address, items) stay with the merchant for accounting and legal purposes until they delete it or ask us to.
- When a merchant asks to disconnect their number or cancels, we delete the access token and stop receiving messages.

## 6. Your rights
Store owners may request a copy, correction or deletion of their data at any time by contacting us. End customers (including anyone who messaged a store over WhatsApp) may contact that store, or us directly, to access or delete their data, following the steps on the [data deletion page](data-deletion). We comply with the Saudi Personal Data Protection Law.

## 7. Security
Data travels over encrypted connections (HTTPS) and is stored in a database protected by row-level permissions; secrets and access tokens are stored server-side only.

## 8. Cookies
We use browser local storage only to keep your login session and preferences (such as language). We do not use advertising trackers.

## 9. Changes
We may update this policy from time to time; the last-updated date is shown at the top of the page.

## 10. Contact & data deletion
For privacy questions or deletion requests: [info@msarpro.com](mailto:info@msarpro.com) — or via the [support page](support). Detailed steps are on the [data deletion page](data-deletion).\n\n**Operated by:** United Empowerment Trading Company, a one-person company (شركة تمكين المتحدة التجارية) — Commercial Registration (Unified National No.) 7017440962 — VAT No. 311868414300003 — Al-Jawharah, Jubail 35518, Saudi Arabia — +966545547123.`,
    },

    // ================================================================== شروط الاستخدام
    terms: {
      title_ar: "شروط الاستخدام", title_en: "Terms of Use", updated: "2026-11-14",
      ar: `مرحباً بك في **مسار**. باستخدامك للمنصة أو تثبيتها على متجرك فأنت توافق على هذه الشروط، فاقرأها بعناية.

## 1. التعريفات
- **المنصة:** خدمة مسار لتوجيه الطلبات وإدارة الفروع والمناديب، بما فيها الموقع msarpro.com ولوحة التحكم وتطبيق المندوب.
- **التاجر:** صاحب المتجر الإلكتروني الذي يثبّت مسار أو يشترك فيه.
- **المستخدمون:** التاجر ومن يضيفهم من مدراء وكاشير ومناديب.
- **العميل النهائي:** الشخص الذي يطلب من متجر التاجر.

## 2. الخدمة
تقدّم مسار أدوات لاستقبال طلبات المتجر من المنصات المتكاملة (مثل زد)، وتوجيهها للفروع، وعرضها على شاشات الفروع، وإسنادها للمناديب وتتبعها، وتحديث حالتها في منصة المتجر عند التفعيل. قد نطوّر الخدمة ونضيف أو نعدّل مميزاتها من وقت لآخر.

## 3. الحساب والمسؤولية عنه
- يلتزم التاجر بتقديم بيانات صحيحة، وبحماية بيانات الدخول الخاصة به وبفريقه.
- التاجر مسؤول عن كل ما يتم من خلال حسابه وحسابات فريقه، وعن الصلاحيات التي يمنحها لهم.
- يجب إبلاغنا فوراً عند الاشتباه في أي استخدام غير مصرح به.

## 4. الاستخدام المقبول
يُمنع استخدام المنصة في:
- أي نشاط مخالف للأنظمة في المملكة العربية السعودية.
- محاولة الوصول لبيانات متاجر أخرى أو تعطيل الخدمة أو اختبار اختراقها دون إذن مكتوب.
- نسخ المنصة أو إعادة بيعها أو الهندسة العكسية لها.
- إرسال محتوى ضار أو بيانات وهمية بكميات كبيرة.

## 5. البيانات والخصوصية
يبقى التاجر مالكاً لبيانات متجره وعملائه، ويمنحنا الحق في معالجتها بالقدر اللازم لتقديم الخدمة فقط وفق [سياسة الخصوصية](privacy). التاجر مسؤول عن إبلاغ عملائه بطريقة معالجة بياناتهم حسب الأنظمة.

## 6. الاشتراكات والدفع
- تُعرض الباقات وأسعارها في صفحة الأسعار، وقد تبدأ بفترة تجريبية مجانية.
- تُجدَّد الاشتراكات تلقائياً حسب دورة الفوترة ما لم يتم إلغاؤها قبل موعد التجديد.
- الأسعار لا تشمل ضريبة القيمة المضافة ما لم يُذكر خلاف ذلك.
- يحق لنا تعديل الأسعار مع إشعار مسبق، ولا يسري التعديل على الفترة المدفوعة مسبقاً.
- عند تأخر السداد قد نعلّق الخدمة بعد إشعار التاجر.

## 7. توفر الخدمة
نبذل جهدنا لتكون الخدمة متاحة باستمرار، لكن قد تحدث انقطاعات للصيانة أو بسبب أطراف خارجية (مثل منصة المتجر أو مزودي الاستضافة أو الخرائط). لا نضمن خلو الخدمة من الأخطاء بشكل كامل.

## 8. خدمة واتساب
- تعمل الخدمة عبر WhatsApp Business Cloud API من Meta، وتخضع كذلك لشروط واتساب للأعمال وسياسة Meta للمراسلة. وقد تتغير هذه الشروط أو يتأثر توفّر الخدمة بقرارات Meta دون أن نتحمل مسؤولية ذلك.
- رقم واتساب والحساب والرسوم التي تفرضها Meta على الرسائل (ما عدا ما تعلنه Meta مجانياً) تكون على التاجر ومن وسيلة دفعه لدى Meta.
- التاجر مسؤول عن مراسلة عملائه بموافقتهم، وعن محتوى القوالب والرسائل والرد على استفساراتهم، وعن الالتزام بسياسات واتساب ضد الرسائل المزعجة. ويحق لنا إيقاف الربط عند مخالفتها.
- الردود الآلية بالذكاء الاصطناعي تعتمد على قائمة التاجر وإعداداته، ولا تُنشأ الطلبات إلا بتأكيد العميل، ويراجع التاجر الطلبات على شاشة الكاشير قبل التنفيذ.

## 9. حدود المسؤولية
- مسار أداة لتنظيم العمليات، ويبقى التاجر مسؤولاً عن منتجاته وتسليمها وعلاقته مع عملائه ومناديبه.
- دقة التوجيه تعتمد على صحة موقع العميل في الطلب ومواقع الفروع المدخلة.
- لا نتحمل المسؤولية عن أي خسائر غير مباشرة أو فوات أرباح، وتقتصر مسؤوليتنا الإجمالية — في حدود ما يسمح به النظام — على قيمة ما دفعه التاجر خلال الأشهر الثلاثة السابقة للمطالبة.

## 10. الإيقاف والإنهاء
- يحق للتاجر إلغاء الاشتراك أو حذف التطبيق من منصة المتجر في أي وقت.
- يحق لنا إيقاف أو إنهاء الحساب عند مخالفة هذه الشروط.
- بعد الإنهاء تُعالج البيانات وتُحذف حسب سياسة الخصوصية.

## 11. الملكية الفكرية
جميع حقوق المنصة وتصميمها وشعارها وأكوادها محفوظة لمسار، ولا يمنح استخدامك لها أي حق ملكية فيها.

## 12. تعديل الشروط
قد نعدّل هذه الشروط، ونوضّح تاريخ آخر تحديث أعلى الصفحة. استمرارك في استخدام المنصة بعد التعديل يعني موافقتك عليه.

## 13. النظام الواجب التطبيق
تخضع هذه الشروط لأنظمة المملكة العربية السعودية، وتختص الجهات القضائية المختصة فيها بالنظر في أي نزاع.

## 14. التواصل
لأي استفسار: [info@msarpro.com](mailto:info@msarpro.com).\n\n**الجهة المشغّلة:** شركة تمكين المتحدة التجارية (شركة شخص واحد) — السجل التجاري (الرقم الوطني الموحد) 7017440962 — الرقم الضريبي 311868414300003 — الجوهرة، الجبيل 35518، المملكة العربية السعودية — +966545547123.`,
      en: `Welcome to **Msar**. By using the platform or installing it on your store you agree to these terms, so please read them carefully.

## 1. Definitions
- **Platform:** the Msar service for order routing and branch/driver management, including msarpro.com, the dashboard and the driver app.
- **Merchant:** the e-commerce store owner who installs or subscribes to Msar.
- **Users:** the merchant and the admins, cashiers and drivers they add.
- **End customer:** the person ordering from the merchant's store.

## 2. The service
Msar provides tools to receive store orders from integrated platforms (such as Zid), route them to branches, display them on branch screens, assign and track drivers, and update the status back in the store platform when enabled. We may develop the service and add or change features over time.

## 3. Accounts
- The merchant must provide accurate information and protect their own and their team's credentials.
- The merchant is responsible for all activity under their account and their team's accounts, and for the permissions they grant.
- Notify us immediately of any suspected unauthorized use.

## 4. Acceptable use
You may not use the platform to:
- Carry out any activity that violates the laws of the Kingdom of Saudi Arabia.
- Access other stores' data, disrupt the service, or perform penetration testing without written permission.
- Copy, resell or reverse-engineer the platform.
- Send harmful content or large volumes of fake data.

## 5. Data & privacy
The merchant remains the owner of their store and customer data and grants us the right to process it only as needed to provide the service, according to the [Privacy Policy](privacy?lang=en). The merchant is responsible for informing their customers about data processing as required by law.

## 6. Subscriptions & payment
- Plans and prices are shown on the pricing page and may start with a free trial.
- Subscriptions renew automatically each billing cycle unless cancelled before renewal.
- Prices exclude VAT unless stated otherwise.
- We may change prices with prior notice; changes do not apply to periods already paid.
- We may suspend the service after notice if payment is overdue.

## 7. Availability
We work to keep the service available at all times, but interruptions may occur for maintenance or due to third parties (such as the store platform, hosting or map providers). We do not guarantee the service will be completely error-free.

## 8. WhatsApp service
- The service runs on Meta's WhatsApp Business Cloud API and is also subject to the WhatsApp Business Terms and Meta's messaging policies. Changes to those terms or to Meta's decisions may affect availability, and we are not liable for them.
- The WhatsApp number, account and any Meta messaging fees (other than what Meta offers free) are the merchant's responsibility, billed by Meta to the merchant's payment method.
- The merchant is responsible for messaging customers only with their consent, for the content of templates and messages, for answering customers, and for complying with WhatsApp's anti-spam policies. We may suspend the connection if they are breached.
- Automated AI replies rely on the merchant's menu and settings; orders are only created once the customer confirms, and the merchant reviews orders on the cashier screen before fulfilment.

## 9. Limitation of liability
- Msar is an operations tool; the merchant remains responsible for their products, deliveries, and relationships with customers and drivers.
- Routing accuracy depends on the correctness of the customer's location in the order and the branch locations entered.
- We are not liable for indirect losses or lost profits, and our total liability — to the extent permitted by law — is limited to the fees paid by the merchant in the three months preceding the claim.

## 10. Suspension & termination
- The merchant may cancel or uninstall the app from the store platform at any time.
- We may suspend or terminate an account that breaches these terms.
- After termination, data is processed and deleted according to the Privacy Policy.

## 11. Intellectual property
All rights to the platform, its design, logo and code belong to Msar; using it grants you no ownership rights.

## 12. Changes to these terms
We may update these terms; the last-updated date is shown at the top. Continued use after a change means you accept it.

## 13. Governing law
These terms are governed by the laws of the Kingdom of Saudi Arabia, and its competent courts have jurisdiction over any dispute.

## 14. Contact
Questions: [info@msarpro.com](mailto:info@msarpro.com).\n\n**Operated by:** United Empowerment Trading Company, a one-person company (شركة تمكين المتحدة التجارية) — Commercial Registration (Unified National No.) 7017440962 — VAT No. 311868414300003 — Al-Jawharah, Jubail 35518, Saudi Arabia — +966545547123.`,
    },

    // ================================================================== حذف البيانات
    "data-deletion": {
      title_ar: "تعليمات حذف البيانات", title_en: "Data Deletion Instructions", updated: "2026-11-14",
      ar: `توضّح هذه الصفحة كيف تطلب حذف بياناتك من منصة **مسار** (msarpro.com)، سواء كنت صاحب متجر أو عميلاً راسل متجراً عبر واتساب.

## 1. أنت صاحب متجر
- **من زد:** احذف تطبيق مسار من متجرك في زد، فيتوقف الربط فوراً ونحذف رموز الوصول، وتُحذف كل بيانات المتجر (الطلبات والفروع والمستخدمين والمحادثات) تلقائياً بعد 90 يوماً، إلا إذا أعدت تثبيت التطبيق خلالها.
- **حذف فوري:** راسلنا على [info@msarpro.com](mailto:info@msarpro.com) من البريد المسجل في حسابك، واكتب «طلب حذف بيانات» مع رمز متجرك، وسنحذف بيانات المتجر خلال 30 يوماً من التحقق من هويتك كحد أقصى، ونؤكد لك بالإيميل.
- **ربط واتساب فقط:** راسلنا على البريد أعلاه لفصل الرقم، فيُحذف رمز الوصول ويتوقف استقبال الرسائل. ويمكنك أيضاً إزالة صلاحيات مسار في أي وقت من إعدادات حسابك في Meta Business.

## 2. أنت عميل راسلت متجراً عبر واتساب
بياناتك (رقم جوالك واسمك في واتساب ورسائلك وطلباتك) محفوظة لدى المتجر الذي راسلته، ونحن نعالجها نيابةً عنه. لحذفها:
1. أرسل طلب الحذف مباشرة إلى المتجر، أو
2. راسلنا على [info@msarpro.com](mailto:info@msarpro.com) واذكر **رقم جوالك بصيغة دولية** (مثل ‎+9665xxxxxxxx) **واسم المتجر** إن عرفته. سنتحقق منك بالرد على رقمك نفسه عند الحاجة، ثم نحذف رسائلك وبياناتك من منصتنا خلال 30 يوماً.

## 3. ما الذي يُحذف وما الذي قد يبقى
- يُحذف: الرسائل والمحادثات، ورقم الجوال والاسم، والعناوين والمواقع، والملاحظات المرتبطة بك.
- قد يبقى: سجل مالي مجرَّد من بياناتك الشخصية، أو ما نلزم بحفظه بحسب الأنظمة (مثل الفواتير والأنظمة الضريبية) لمدة النظام فقط.
- نسخ الرسائل لدى Meta/واتساب خارج سيطرتنا، ولحذفها راجع سياسات واتساب.

## 4. التواصل
البريد: [info@msarpro.com](mailto:info@msarpro.com) — الجوال: +966545547123 — شركة تمكين المتحدة التجارية (شركة شخص واحد)، السجل التجاري 7017440962، الرقم الضريبي 311868414300003، الجوهرة، الجبيل 35518، السعودية. راجع أيضاً [سياسة الخصوصية](privacy).`,
      en: `This page explains how to request deletion of your data from **Msar** (msarpro.com), whether you are a store owner or a customer who messaged a store over WhatsApp.

## 1. You are a store owner
- **From Zid:** uninstall Msar from your Zid store. The connection stops immediately, access tokens are deleted, and all store data (orders, branches, users, conversations) is deleted automatically after 90 days unless you reinstall within that period.
- **Immediate deletion:** email [info@msarpro.com](mailto:info@msarpro.com) from the address registered on your account with the subject "Data deletion request" and your store code. We delete the store data within 30 days of verifying your identity and confirm by email.
- **WhatsApp connection only:** email us to disconnect the number; the access token is deleted and message intake stops. You can also remove Msar's permissions at any time in your Meta Business settings.

## 2. You are a customer who messaged a store over WhatsApp
Your data (phone number, WhatsApp name, messages, orders) is held by the store you messaged, and we process it on its behalf. To delete it:
1. Send the deletion request directly to the store, or
2. Email [info@msarpro.com](mailto:info@msarpro.com) with **your phone number in international format** (e.g. +9665xxxxxxxx) and the **store name** if known. We may verify you by replying to that same number, then delete your messages and data from our platform within 30 days.

## 3. What is deleted and what may remain
- Deleted: messages and conversations, phone number and name, addresses and locations, and notes linked to you.
- May remain: financial records stripped of your personal data, or records we are legally required to keep (such as invoices under tax rules) for the legal period only.
- Copies held by Meta/WhatsApp are outside our control; see WhatsApp's policies to delete them.

## 4. Contact
Email: [info@msarpro.com](mailto:info@msarpro.com) — Phone: +966545547123 — United Empowerment Trading Company (one-person company), CR 7017440962, VAT No. 311868414300003, Al-Jawharah, Jubail 35518, Saudi Arabia. See also the [Privacy Policy](privacy).`,
    },

    // ================================================================== دليل الاستخدام
    guide: {
      title_ar: "دليل استخدام مسار", title_en: "Msar User Guide", updated: "2026-11-14",
      ar: `هذا الدليل يشرح لك مسار خطوة بخطوة: من التثبيت إلى أول طلب يوصل للعميل. تقدر ترجع له في أي وقت.

> نصيحة: إذا كنت تبدأ لأول مرة، اتبع الأقسام من 1 إلى 5 بالترتيب — تاخذ أقل من 15 دقيقة.

## 1. التثبيت من زد
1. من لوحة متجرك في زد افتح **متجر التطبيقات** وابحث عن **مسار**.
2. اضغط **تثبيت** ووافق على الصلاحيات المطلوبة (قراءة الطلبات وتحديث حالتها).
3. بعد التثبيت تفتح لك صفحة **إعداد متجرك** في مسار تلقائياً.
4. اكتب اسمك وإيميلك وكلمة مرور، أو اضغط **المتابعة بحساب قوقل**.
5. تدخل مباشرة على لوحة التحكم، وتبدأ طلبات متجرك الجديدة توصل لحظياً.

> مسار يستورد أيضاً الطلبات المفتوحة الأخيرة من زد عند الربط، عشان ما يفوتك شي.

## 2. إضافة الفروع
1. من القائمة الجانبية افتح **الفروع** واضغط **فرع جديد**.
2. اكتب اسم الفرع والمدينة وجوال الفرع.
3. الصق **رابط موقع الفرع من خرائط قوقل** أو اكتب الإحداثيات (مثال: 24.7136, 46.6753).
4. حدد **نطاق التوصيل الخاص** بالكيلو، أو اتركه فاضي ليستخدم النطاق العام.
5. احفظ — يظهر الفرع على الخريطة مع دائرة نطاقه.

تقدر توقف استقبال الطلبات لأي فرع مؤقتاً من زر التعديل، والطلبات تروح للفرع الأقرب التالي.

## 3. نطاق التوصيل والتوجيه التلقائي
- من **نطاق التوصيل** حدد المسافة القصوى (مثلاً 5 كم).
- كل طلب جديد: مسار يحسب المسافة بين موقع العميل وكل فرع، ويوجّه الطلب **للأقرب داخل النطاق**.
- الطلبات اللي **برا كل النطاقات** تظهر لك في الطلبات الحالية بعلامة "يحتاج توجيه" وتقدر تختار الفرع يدوياً.
- الخريطة في نفس الصفحة توضّح طلبات آخر 30 يوم داخل وخارج النطاق، عشان تختار الرقم المناسب.
- بعد تغيير النطاق تقدر تضغط **وجّه الطلبات المعلّقة** لإعادة توجيهها.

## 4. دعوة فريقك
افتح **الموظفين والمناديب**، وعندك طريقتين:
- **دعوة بالإيميل (المفضّلة):** اكتب الاسم والإيميل والدور (مدير / كاشير / مندوب) والفرع، ثم أرسل رابط الدعوة بالواتساب أو انسخه. الشخص يفتح الرابط ويختار كلمة مروره أو يدخل بقوقل.
- **حساب باسم مستخدم:** للي ما عندهم إيميل؛ تختار له اسم مستخدم وكلمة مرور، ويدخل برمز المتجر + اسم المستخدم.

الأدوار:
- **المدير:** يشوف كل الفروع والإعدادات والتقارير والفريق.
- **الكاشير:** يشوف طلبات فرعه فقط ويجهّزها ويرسلها للمناديب.
- **المندوب:** يشوف الطلبات المسندة له فقط في تطبيق المندوب.

## 5. دورة حياة الطلب
1. **جديد:** الطلب وصل من زد وتوجّه لفرع — تنبيه صوتي على شاشة الفرع.
2. **قيد التجهيز:** الكاشير بدأ يجهّز الطلب.
3. **جاهز:** الطلب جاهز للاستلام.
4. **أُسند لمندوب:** الكاشير أو المدير اختار مندوب من مناديب الفرع.
5. **في الطريق:** المندوب استلم الطلب وانطلق.
6. **تم التوصيل:** المندوب سلّم الطلب وسجّل طريقة الدفع إن كان دفع عند الاستلام.

تقدر في أي وقت تعيد توجيه الطلب لفرع ثاني، أو تضيف ملاحظة، أو تلغيه مع ذكر السبب.

## 6. شاشة الفرع (الكاشير)
- تثبّتها على تابلت أو كمبيوتر الفرع كتطبيق من زر **تثبيت كتطبيق على الجهاز**.
- فعّل **الصوت** عشان يوصلك تنبيه لكل طلب جديد.
- لكل طلب: تفاصيل المنتجات، بيانات العميل، موقعه على الخريطة، وطباعة الفاتورة.
- زر **إرسال للمندوب** يعرض مناديب الفرع وحالتهم.

## 7. تطبيق المندوب
1. حمّل تطبيق أندرويد من رابط التحميل في لوحة التحكم، أو افتح **msarpro.com/driver** من الجوال.
2. سجّل الدخول بالإيميل أو برمز المتجر واسم المستخدم.
3. اضغط **متصل** لبدء استقبال الطلبات — التطبيق يرسل موقعك أثناء العمل فقط.
4. لكل طلب: **ملاحة** لفتح قوقل ماب، **اتصال** أو **واتساب** للعميل.
5. عند الاستلام اضغط **استلمت الطلب**، وعند التسليم **تم التوصيل** واختر طريقة الدفع (كاش/شبكة) إن كان الدفع عند الاستلام.
6. لو ما قدرت تسلّم، اضغط **إرجاع للفرع** واكتب السبب.

## 8. الخريطة المباشرة
- تعرض كل الفروع والمناديب المتصلين والطلبات النشطة.
- اضغط على أي مندوب لتشوف **مساره اليوم** وطلباته الحالية.
- الألوان توضّح حالة كل طلب.

## 9. تحديث الحالة في زد
- من **الربط مع زد والإعدادات** فعّل **تحديث حالة الطلبات في زد**.
- بعدها كل خطوة (تجهيز، جاهز، في الطريق، تم التوصيل) تتحدث تلقائياً في متجرك، والعميل يشوفها.
- إذا صار خطأ في التحديث يظهر في سجل الربط ويُعاد المحاولة تلقائياً.

## 10. التقارير
- عدد الطلبات والمبيعات لكل فرع ولكل مندوب.
- متوسط وقت التجهيز ووقت التوصيل.
- مبالغ الدفع عند الاستلام لكل مندوب.
- تصدير أي تقرير إلى Excel.

## 11. أكثر من متجر بحساب واحد
إذا عندك أكثر من متجر أو انضميت لفريق متجر ثاني، اضغط **حسابي** ثم اختر المتجر اللي تبي تنتقل له.

## 12. حسابك وكلمة المرور
- من **حسابي** تقدر تغيّر كلمة المرور أو تربط إيميلك.
- نسيت كلمة المرور؟ اضغط **نسيت كلمة المرور؟** في صفحة الدخول، أو اطلب من مدير المتجر رابط استعادة.
- الدخول بحساب قوقل متاح لأي حساب مسجل بإيميل.

## 13. حل المشاكل الشائعة
- **طلب ما ظهر:** تأكد إن موقع العميل موجود في الطلب. مسار يسوي مزامنة احتياطية دورية، وتقدر تستورد الطلب برقمه من لوحة التحكم.
- **الطلب راح لفرع غير متوقع:** راجع إحداثيات الفروع ونطاق كل فرع، وتأكد إن الفرع الأقرب "يستقبل طلبات".
- **التنبيه الصوتي ما يشتغل:** اضغط زر الصوت في الشريط الجانبي مرة (المتصفحات تطلب تفاعل قبل تشغيل الصوت).
- **المندوب ما يظهر على الخريطة:** تأكد إنه ضاغط "متصل" وإن صلاحية الموقع مفعّلة للتطبيق.

## 14. التواصل والدعم
راسلنا على [info@msarpro.com](mailto:info@msarpro.com) واذكر رمز متجرك ووصف المشكلة وصورة للشاشة إن أمكن. نرد عادة خلال يوم عمل.`,
      en: `This guide walks you through Msar step by step: from installation to the first order delivered. Come back to it any time.

> Tip: if you're just starting, follow sections 1–5 in order — it takes under 15 minutes.

## 1. Install from Zid
1. In your Zid dashboard open the **App Market** and search for **Msar**.
2. Click **Install** and approve the requested permissions (read orders and update their status).
3. After installation, the Msar **store setup** page opens automatically.
4. Enter your name, email and a password, or click **Continue with Google**.
5. You land on the dashboard and new store orders start arriving in real time.

> Msar also imports recent open orders from Zid when you connect, so nothing is missed.

## 2. Add branches
1. Open **Branches** from the side menu and click **New branch**.
2. Enter the branch name, city and phone.
3. Paste the **Google Maps link** of the branch or type its coordinates (e.g. 24.7136, 46.6753).
4. Set a **custom delivery radius** in km, or leave it empty to use the global radius.
5. Save — the branch appears on the map with its radius circle.

You can pause a branch temporarily from Edit; its orders go to the next nearest branch.

## 3. Delivery radius & automatic routing
- In **Delivery radius**, set the maximum distance (e.g. 5 km).
- For each new order Msar measures the distance from the customer to every branch and routes it to **the nearest one within range**.
- Orders **outside every radius** appear in Live Orders marked "needs routing" so you can pick the branch manually.
- The map on the same page shows the last 30 days of orders inside and outside the radius to help you choose.
- After changing the radius, click **Route pending orders** to re-route them.

## 4. Invite your team
Open **Staff & drivers**. You have two options:
- **Invite by email (recommended):** enter name, email, role (admin / cashier / driver) and branch, then share the invite link via WhatsApp or copy it. The person opens the link and sets a password or signs in with Google.
- **Username account:** for people without email; you choose a username and password, and they log in with the store code + username.

Roles:
- **Admin:** sees all branches, settings, reports and the team.
- **Cashier:** sees only their branch's orders, prepares and dispatches them.
- **Driver:** sees only orders assigned to them in the driver app.

## 5. Order lifecycle
1. **New:** the order arrived from Zid and was routed to a branch — sound alert on the branch screen.
2. **Preparing:** the cashier started preparing it.
3. **Ready:** ready for pickup.
4. **Assigned:** a cashier or admin picked a branch driver.
5. **Out for delivery:** the driver picked it up.
6. **Delivered:** the driver handed it over and recorded the payment method for COD orders.

At any time you can re-route an order to another branch, add a note, or cancel it with a reason.

## 6. Branch screen (cashier)
- Install it on the branch tablet or PC via **Install as app**.
- Turn **sound** on to get an alert for every new order.
- Each order shows items, customer details, location on the map and invoice printing.
- **Send to driver** lists the branch drivers and their status.

## 7. Driver app
1. Download the Android app from the link in the dashboard, or open **msarpro.com/driver** on the phone.
2. Log in with email, or with the store code and username.
3. Tap **Online** to start receiving orders — location is shared only while on duty.
4. For each order: **Navigate** opens Google Maps, **Call** or **WhatsApp** the customer.
5. Tap **Picked up** at pickup and **Delivered** at handover, choosing cash or card for COD orders.
6. If delivery fails, tap **Return to branch** and enter the reason.

## 8. Live map
- Shows all branches, online drivers and active orders.
- Click a driver to see **today's trail** and current orders.
- Colors indicate each order's status.

## 9. Status updates in Zid
- In **Zid connection & settings**, enable **Update order status in Zid**.
- Every step (preparing, ready, out for delivery, delivered) then updates in your store automatically, visible to the customer.
- If an update fails it appears in the integration log and is retried automatically.

## 10. Reports
- Orders and sales per branch and per driver.
- Average preparation and delivery time.
- Cash-on-delivery totals per driver.
- Export any report to Excel.

## 11. Multiple stores, one account
If you own several stores or joined another store's team, click **My account** and choose the store to switch to.

## 12. Account & password
- In **My account** you can change your password or link your email.
- Forgot your password? Click **Forgot password?** on the login page, or ask your store admin for a recovery link.
- Google sign-in works for any account registered with an email.

## 13. Troubleshooting
- **An order didn't appear:** make sure the order has a customer location. Msar runs a periodic backup sync, and you can import an order by its number from the dashboard.
- **An order went to an unexpected branch:** check branch coordinates and radii, and make sure the nearest branch is "accepting orders".
- **No sound alert:** click the sound button in the sidebar once (browsers require an interaction before playing sound).
- **A driver isn't on the map:** make sure they tapped "Online" and that location permission is enabled.

## 14. Support
Email [info@msarpro.com](mailto:info@msarpro.com) with your store code, a description and a screenshot if possible. We usually reply within one business day.`,
    },
  };
  root.MSAR_DOCS = DOCS;
  if (typeof module !== "undefined") module.exports = DOCS;
})(typeof window !== "undefined" ? window : globalThis);
