/* مسار — لوحة صاحب المنصة: نظرة عامة، العملاء (المتاجر) والاشتراكات، الدعم، الموقع، الربط مع زد */
(function () {
  const A = window.AZM, { sb, $, $$, esc, num, toast } = A;
  const app = document.getElementById("app");
  const FN = `${A.C.SUPABASE_URL}/functions/v1/zid`;
  const WEB = location.href.split("#")[0].split("?")[0].replace(/owner(\.html)?$/, "");
  const ST = { trial: ["تجريبي", "#fef3c7", "#92400e"], active: ["فعّال", "#dcfce7", "#166534"], suspended: ["موقوف", "#fee2e2", "#991b1b"], uninstalled: ["محذوف", "#f1f5f9", "#475569"] };
  const PLAN = { starter: ["الأساسية", "#e0f2fe", "#075985"], growth: ["النمو", "#ede9fe", "#5b21b6"], pro: ["الاحترافية", "#fef3c7", "#92400e"] };
  const ROLE_AR = { admin: "مدير", cashier: "كاشير", driver: "مندوب" };
  const NAV = [
    ["overview", "📊", "نظرة عامة"], ["stores", "🏪", "العملاء"], ["tree", "🌳", "شجرة العملاء"], ["support", "🎫", "الدعم الفني", "sup-badge"],
    ["leads", "📨", "طلبات التواصل", "lead-badge"], ["site", "🌐", "الموقع"], ["zid", "🔗", "تطبيق زد"], ["salla", "🛍️", "تطبيق سلة"], ["new", "➕", "متجر يدوي"], ["logs", "📜", "السجل"],
  ];
  const TITLES = Object.fromEntries(NAV.map(([k, , l]) => [k, l]));
  let D = null, ME = null;
  let tab = (location.hash.slice(1) || "overview").replace(/[^a-z]/g, "");
  const F = { q: "", status: "all", plan: "all", sort: "new" }; // فلاتر صفحة العملاء
  const money = (n) => `${num(Math.round(Number(n) || 0))} ر.س`;
  const days = (t) => (t ? Math.ceil((Date.parse(t) - Date.now()) / 86400000) : null);
  const sinceDays = (t) => (t ? Math.floor((Date.now() - Date.parse(t)) / 86400000) : null);

  async function boot() {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return renderLogin(A.oauthErrorMsg());
    const me = await A.myProfile().catch(() => null);
    if (me?.role !== "owner") { await sb.auth.signOut(); return renderLogin("هذا الحساب ليس حساب صاحب المنصة"); }
    ME = me; shell(); load();
  }

  async function renderLogin(msg) {
    let needs = false;
    try { needs = (await A.callFn("admin", { action: "owner_status" })).needs_bootstrap; } catch (_) {}
    app.innerHTML = `<div class="login-page"><form class="login-card" id="f">
      <div class="logo"><img class="logo-mark" src="icons/logo.png" alt="مسار"><div>مسار<div class="small muted" style="font-weight:600">لوحة صاحب المنصة</div></div></div>
      <div style="height:18px"></div>${msg ? `<p class="chip chip-warn" style="white-space:normal">${esc(msg)}</p>` : ""}
      ${needs ? `<h3 style="margin:0 0 6px">إنشاء حساب صاحب المنصة</h3><p class="small muted" style="margin-top:0">هذي الخطوة تظهر مرة وحدة فقط.</p>
        <label class="field"><span>الاسم</span><input name="n" required></label>` : ""}
      <label class="field"><span>${needs ? "اسم المستخدم" : "اسم المستخدم أو الإيميل"}</span><input name="u" required dir="ltr" autocapitalize="none" ${needs ? 'pattern="[a-zA-Z0-9._-]{3,32}"' : ""}></label>
      <label class="field"><span>كلمة المرور${needs ? " (8 أحرف أو أكثر)" : ""}</span><input name="p" type="password" ${needs ? 'minlength="8" autocomplete="new-password"' : 'autocomplete="current-password"'} required dir="ltr"></label>
      <button class="btn btn-primary btn-block btn-lg" type="submit">${needs ? "إنشاء الحساب والدخول" : "دخول"}</button>
      ${needs ? "" : A.authExtrasHtml()}
    </form></div>`;
    if (!needs) A.bindAuthExtras($("#f"), () => $("#f").u.value);
    $("#f").onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target, b = $("button[type=submit]", f); b.disabled = true;
      try {
        if (needs) await A.callFn("admin", { action: "owner_bootstrap", full_name: f.n.value, username: f.u.value, password: f.p.value, web_url: WEB });
        await A.login(f.u.value, f.p.value, "owner");
        location.replace(location.pathname);
      } catch (err) { toast(A.errMsg(err), "error"); b.disabled = false; }
    };
  }

  // =================================================================== الهيكل: قائمة جانبية يمين + محتوى عريض
  function shell() {
    if (!TITLES[tab]) tab = "overview";
    app.innerHTML = `<div class="shell o-shell">
      <aside class="side o-side" id="side">
        <div class="logo"><img class="logo-mark" src="icons/logo.png" alt="مسار"><div>مسار<div class="small" style="opacity:.75;font-weight:600">لوحة صاحب المنصة</div></div></div>
        <div class="o-route" aria-hidden="true"><i></i><i></i><i></i></div>
        <nav class="nav">${NAV.map(([k, ic, l, badge]) => `<a href="#${k}" data-t="${k}" class="${k === tab ? "active" : ""}"><span>${ic}</span>${l}${badge ? `<i class="o-badge" id="${badge}"></i>` : ""}</a>`).join("")}</nav>
        <div class="side-foot">
          <div class="side-user"><b>${esc(ME?.full_name || "")}</b> · صاحب المنصة</div>
          <div class="row" style="margin-top:8px">
            <a class="btn btn-sm" href="./" target="_blank" rel="noopener">🌐 الموقع</a>
            <a class="btn btn-sm" href="app" target="_blank" rel="noopener" title="تفتح بحساب متجر">🖥️ لوحة التاجر</a>
            <button class="btn btn-sm" id="acc">👤 حسابي</button>
            <button class="btn btn-sm" id="lo">خروج</button>
          </div>
        </div>
      </aside>
      <main class="main">
        <div class="topbar">
          <button class="icon-btn menu-btn" id="menu-btn" aria-label="القائمة">☰</button>
          <h2 id="page-title">${esc(TITLES[tab])}</h2><span class="spacer"></span>
          <span class="small muted" id="upd"></span>
          <button class="btn btn-sm" id="refresh" title="تحديث البيانات">⟳ تحديث</button>
        </div>
        <div class="content o-content"><div id="view"><div class="empty">جاري التحميل…</div></div></div>
      </main>
      <div class="o-backdrop" id="backdrop"></div>
    </div>`;
    $("#lo").onclick = A.logout;
    $("#acc").onclick = () => A.accountDialog();
    $("#refresh").onclick = () => load();
    $("#menu-btn").onclick = () => $("#side").classList.toggle("open");
    $("#backdrop").onclick = () => $("#side").classList.remove("open");
    $$(".o-side .nav a").forEach((a) => a.onclick = (e) => { e.preventDefault(); go(a.dataset.t); });
    window.addEventListener("hashchange", () => { const t = location.hash.slice(1).replace(/[^a-z]/g, ""); if (TITLES[t] && t !== tab) go(t, true); });
    const poll = () => {
      A.rpc("support_unread").then((n) => { const e = $("#sup-badge"); if (e) e.textContent = n ? n : ""; }).catch(() => {});
    };
    poll(); clearInterval(window.__supT); window.__supT = setInterval(poll, 60000);
  }
  function go(t, fromHash) {
    tab = t;
    if (!fromHash) history.replaceState(null, "", "#" + t);
    $$(".o-side .nav a").forEach((a) => a.classList.toggle("active", a.dataset.t === t));
    $("#page-title").textContent = TITLES[t];
    $("#side").classList.remove("open");
    render();
  }

  async function load() {
    $("#refresh").disabled = true;
    try {
      try { D = await A.rpc("owner_overview2"); D.v2 = true; }
      catch (_) { D = await A.rpc("owner_overview"); D.v2 = false; } // قبل تشغيل ترقية 007
    } catch (e) { toast(A.errMsg(e), "error"); $("#refresh").disabled = false; return; }
    $("#refresh").disabled = false;
    $("#upd").textContent = "آخر تحديث " + A.fmtTime(new Date());
    if (!D.web_url || D.web_url !== WEB) A.rpc("owner_set_setting", { p_key: "web_url", p_value: WEB }).catch(() => {});
    const lb = $("#lead-badge"); if (lb) lb.textContent = D.totals?.new_leads ? D.totals.new_leads : "";
    render();
  }

  function render() {
    if (!D) return;
    const v = $("#view");
    v.classList.toggle("leads-only", tab === "leads");
    if (tab === "overview") return renderOverview();
    if (tab === "stores") return renderStores();
    if (tab === "tree") return window.MSAR_OWNER_TREE.render(v, { openStore, stamp: D });
    if (tab === "zid") return renderZid();
    if (tab === "salla") return renderSalla();
    if (tab === "new") return renderNew();
    if (tab === "logs") return renderLogs();
    if (tab === "site") return window.MSAR_OWNER_SITE.render(v);
    if (tab === "support") return window.MSAR_OWNER_SUPPORT.render(v);
    if (tab === "leads") return window.MSAR_OWNER_SITE.render(v, "leads");
  }

  // =================================================================== أدوات العرض
  const kpi = (k, v, s = "", cls = "") => `<div class="o-kpi ${cls}"><div class="k">${k}</div><div class="v">${v}</div>${s ? `<div class="s">${s}</div>` : ""}</div>`;
  const stBadge = (s) => { const x = ST[s.status] || [s.status, "#eee", "#333"]; return `<span class="badge" style="background:${x[1]};color:${x[2]}">${x[0]}</span>`; };
  const planPill = (p) => { const x = PLAN[p]; return x ? `<span class="badge" style="background:${x[1]};color:${x[2]}">${x[0]}</span>` : `<span class="badge" style="background:#f1f5f9;color:#64748b">بدون باقة</span>`; };
  const avatar = (s) => s.logo_url ? `<img class="o-av" src="${esc(s.logo_url)}" alt="" loading="lazy">` : `<span class="o-av">${esc((s.name || "?").trim().charAt(0))}</span>`;
  function bars(series, h = 120) {
    if (!series?.length) return `<div class="empty">لا توجد بيانات</div>`;
    const max = Math.max(1, ...series.map((x) => x.n));
    const w = 100 / series.length;
    return `<svg class="o-bars" viewBox="0 0 100 ${h}" preserveAspectRatio="none" role="img" aria-label="رسم الطلبات اليومية">
      ${series.map((x, i) => { const bh = Math.max(x.n ? 2 : 0.6, (x.n / max) * (h - 6)); return `<rect x="${(series.length - 1 - i) * w + w * 0.15}" y="${h - bh}" width="${w * 0.7}" height="${bh}" rx="0.6"><title>${x.d}: ${x.n} طلب</title></rect>`; }).join("")}
    </svg><div class="o-bars-ax small muted"><span>قبل ${series.length - 1} يوم</span><span>اليوم</span></div>`;
  }
  // صحة المتجر: هل الإعداد مكتمل ويشتغل؟
  function health(s) {
    const issues = [];
    if (s.status === "uninstalled") return { lvl: "off", issues: ["التطبيق محذوف من زد"] };
    if (!s.zid_connected) issues.push("غير مربوط مع زد");
    if (!s.has_admin) issues.push("لم يُنشأ حساب المدير");
    if (!s.branches) issues.push("ما أضاف فروع");
    if (!s.drivers) issues.push("ما أضاف مناديب");
    if (s.errors_24h > 5) issues.push(`${s.errors_24h} خطأ مزامنة خلال 24 ساعة`);
    const idle = sinceDays(s.last_login_at);
    if (s.has_admin && (idle === null || idle > 7)) issues.push(idle === null ? "ما دخل أحد من الفريق أبداً" : `ما دخل أحد منذ ${idle} يوم`);
    const lvl = issues.length === 0 ? "ok" : (!s.zid_connected || !s.has_admin || s.errors_24h > 5) ? "bad" : "warn";
    return { lvl, issues };
  }
  const dot = (h) => `<span class="o-dot o-h-${h.lvl}" title="${esc(h.issues.join(" · ") || "كل شي سليم")}"></span>`;

  // =================================================================== نظرة عامة
  function renderOverview() {
    const t = D.totals || {}, S = D.stores || [];
    const live = S.filter((s) => s.status !== "uninstalled");
    const attention = [];
    live.forEach((s) => {
      const d = days(s.trial_ends_at);
      if (s.status === "trial" && d !== null && d >= 0 && d <= 7) attention.push([s, "⏳", `التجربة تنتهي خلال ${d} يوم`]);
      if (s.owner_followup && Date.parse(s.owner_followup) <= Date.now() + 86400000) attention.push([s, "📌", `متابعة مستحقة (${s.owner_followup})`]);
      const h = health(s); if (h.lvl === "bad") attention.push([s, "⚠️", h.issues.join(" · ")]);
      if (s.open_tickets) attention.push([s, "🎫", `${s.open_tickets} تذكرة دعم مفتوحة`]);
    });
    const recent = [...S].sort((a, b) => Date.parse(b.installed_at || b.created_at) - Date.parse(a.installed_at || a.created_at)).slice(0, 6);
    const byPlan = t.by_plan || {};
    const planTotal = Object.values(byPlan).reduce((a, b) => a + b, 0) || 1;
    $("#view").innerHTML = `
      ${D.v2 ? "" : `<div class="card o-warn">⚠️ شغّل ترقية قاعدة البيانات 007 لعرض مؤشرات الاشتراكات الكاملة.</div>`}
      <div class="o-kpis">
        ${kpi("الدخل الشهري المتكرر", t.mrr !== undefined ? money(t.mrr) : "—", `${num(t.paying ?? 0)} مشترك مدفوع`, "o-kpi-main")}
        ${kpi("المتاجر النشطة", num(t.stores), `${num(t.active)} فعّال · ${num(t.trial)} تجريبي`)}
        ${kpi("تثبيتات 30 يوم", num(t.new_30d ?? 0), `${num(t.churn_30d ?? 0)} إلغاء`)}
        ${kpi("تجارب تنتهي خلال أسبوع", num(t.trials_ending_7d ?? 0), "فرصة تحويل لمشترك")}
        ${kpi("طلبات 30 يوم", num(t.orders_30d), `${num(t.orders_today)} اليوم`)}
        ${kpi("قيمة الطلبات 30 يوم", t.gmv_30d !== undefined ? money(t.gmv_30d) : "—", "عبر كل المتاجر")}
        ${kpi("تذاكر مفتوحة", num(t.open_tickets ?? 0), `<a href="#support" data-go="support">افتح الدعم</a>`)}
        <div class="o-kpi" id="health"><div class="k">صحة النظام</div><div class="v">…</div></div>
      </div>
      <div class="o-grid">
        <div class="card"><div class="card-head"><h3>📦 الطلبات اليومية (آخر 30 يوم)</h3></div>${bars(D.orders_daily || [])}</div>
        <div class="card"><div class="card-head"><h3>💳 توزيع الباقات</h3></div>
          <div class="o-planbar">${["pro", "growth", "starter", "none"].filter((k) => byPlan[k]).map((k) => `<i class="o-pb-${k}" style="width:${(byPlan[k] / planTotal) * 100}%"></i>`).join("") || `<i class="o-pb-none" style="width:100%"></i>`}</div>
          <div class="o-legend">${["pro", "growth", "starter", "none"].map((k) => `<span><i class="o-pb-${k}"></i>${k === "none" ? "بدون باقة" : PLAN[k][0]} <b>${num(byPlan[k] || 0)}</b></span>`).join("")}</div>
          <p class="small muted" style="margin:10px 0 0">المتجر بدون باقة يعامل كالأساسية. الباقة تتحدّث تلقائياً من اشتراك زد.</p></div>
      </div>
      <div class="o-grid">
        <div class="card"><div class="card-head"><h3>🔔 تحتاج انتباهك</h3><span class="chip">${num(attention.length)}</span></div>
          ${attention.length ? `<div class="o-list">${attention.slice(0, 12).map(([s, ic, m]) => `<button class="o-li" data-open="${s.id}">${avatar(s)}<div class="grow"><b>${esc(s.name)}</b><div class="small muted">${ic} ${esc(m)}</div></div><span class="muted">‹</span></button>`).join("")}</div>`
            : `<div class="empty">ممتاز — ما فيه شي يحتاج تدخّل الحين ✨</div>`}</div>
        <div class="card"><div class="card-head"><h3>🆕 آخر المتاجر المنضمة</h3><span class="spacer"></span><a href="#stores" data-go="stores" class="small">كل العملاء ←</a></div>
          ${recent.length ? `<div class="o-list">${recent.map((s) => `<button class="o-li" data-open="${s.id}">${avatar(s)}<div class="grow"><b>${esc(s.name)}</b><div class="small muted">${A.ago(s.installed_at || s.created_at)} · ${num(s.orders_30d)} طلب/30 يوم</div></div>${stBadge(s)}</button>`).join("")}</div>`
            : `<div class="empty">لا يوجد متاجر بعد — أول ما يثبّت تاجر التطبيق من زد بيظهر هنا</div>`}</div>
      </div>`;
    bindCommon();
    A.rpc("owner_health").then((h) => {
      const age = h.cron_last_run ? Math.round((Date.now() - Date.parse(h.cron_last_run)) / 1000) : null;
      const bad = age === null || age > 300 || h.outbox_stuck > 0 || h.errors_1h > 20;
      const el = $("#health"); if (!el) return;
      el.innerHTML = `<div class="k">صحة النظام</div><div class="v" style="color:${bad ? "#b91c1c" : "#15803d"}">${bad ? "⚠️ تنبيه" : "✅ سليم"}</div>
        <div class="s">مزامنة ${age === null ? "لم تعمل" : age < 120 ? "قبل دقيقة" : `قبل ${Math.round(age / 60)} د`} · أخطاء ساعة ${num(h.errors_1h)} · القاعدة ${num(h.db_size_mb)}MB</div>`;
    }).catch(() => { const el = $("#health"); if (el) el.querySelector(".v").textContent = "—"; });
  }
  function bindCommon() {
    $$("[data-go]").forEach((a) => a.onclick = (e) => { e.preventDefault(); go(a.dataset.go); });
    $$("[data-open]").forEach((b) => b.onclick = () => openStore(Number(b.dataset.open)));
  }

  // =================================================================== العملاء
  function filtered() {
    const q = F.q.trim().toLowerCase();
    let rows = (D.stores || []).filter((s) => {
      if (F.status !== "all" && s.status !== F.status) return false;
      if (F.plan !== "all" && (s.plan || "none") !== F.plan) return false;
      if (q && ![s.name, s.code, s.owner_email, s.owner_phone, s.admin_email, s.admin_name, s.store_url, ...(s.owner_tags || [])].some((x) => String(x || "").toLowerCase().includes(q))) return false;
      return true;
    });
    const by = {
      new: (a, b) => Date.parse(b.installed_at || b.created_at) - Date.parse(a.installed_at || a.created_at),
      orders: (a, b) => (b.orders_30d || 0) - (a.orders_30d || 0),
      active: (a, b) => Date.parse(b.last_login_at || 0) - Date.parse(a.last_login_at || 0),
      trial: (a, b) => Date.parse(a.trial_ends_at || "2999-01-01") - Date.parse(b.trial_ends_at || "2999-01-01"),
      revenue: (a, b) => (b.paying ? b.price : 0) - (a.paying ? a.price : 0),
    }[F.sort];
    return rows.sort(by);
  }
  function renderStores() {
    const t = D.totals || {}, all = D.stores || [];
    const cnt = (st) => all.filter((s) => st === "all" || s.status === st).length;
    $("#view").innerHTML = `
      <div class="o-kpis o-kpis-sm">
        ${kpi("الدخل الشهري", t.mrr !== undefined ? money(t.mrr) : "—", "", "o-kpi-main")}
        ${kpi("مشتركين مدفوعين", num(t.paying ?? t.active ?? 0))}
        ${kpi("في التجربة", num(t.trial ?? 0), `${num(t.trials_ending_7d ?? 0)} تنتهي خلال أسبوع`)}
        ${kpi("موقوف / محذوف", `${num(t.suspended ?? 0)} / ${num(t.uninstalled ?? 0)}`)}
      </div>
      <div class="card o-tools">
        <div class="o-seg">${[["all", "الكل"], ["active", "فعّال"], ["trial", "تجريبي"], ["suspended", "موقوف"], ["uninstalled", "محذوف"]].map(([k, l]) => `<button data-st="${k}" class="${F.status === k ? "on" : ""}">${l} <small>${num(cnt(k))}</small></button>`).join("")}</div>
        <input id="q" type="search" placeholder="🔎 ابحث بالاسم أو الرمز أو الإيميل أو الجوال أو الوسم" value="${esc(F.q)}">
        <select id="fp"><option value="all">كل الباقات</option>${Object.entries(PLAN).map(([k, v]) => `<option value="${k}" ${F.plan === k ? "selected" : ""}>${v[0]}</option>`).join("")}<option value="none" ${F.plan === "none" ? "selected" : ""}>بدون باقة</option></select>
        <select id="fs">${[["new", "الأحدث انضماماً"], ["orders", "الأكثر طلبات"], ["active", "آخر نشاط"], ["trial", "أقرب نهاية تجربة"], ["revenue", "الأعلى دخلاً"]].map(([k, l]) => `<option value="${k}" ${F.sort === k ? "selected" : ""}>${l}</option>`).join("")}</select>
        <button class="btn btn-sm" id="csv">⬇️ تصدير CSV</button>
      </div>
      <div class="card" style="padding:0"><div class="table-wrap" id="tbl"></div></div>`;
    const draw = () => {
      const rows = filtered();
      $("#tbl").innerHTML = `<table class="o-table"><thead><tr><th>المتجر</th><th>الباقة</th><th>الحالة</th><th>النشاط (30 يوم)</th><th>آخر دخول</th><th>الإعداد</th><th></th></tr></thead><tbody>
        ${rows.map((s) => { const h = health(s), d = days(s.trial_ends_at); return `<tr data-open="${s.id}" tabindex="0">
          <td><div class="o-store">${avatar(s)}<div><b>${esc(s.name)}</b> <span class="mono small muted">${esc(s.code)}</span>
            <div class="small muted">${esc(s.admin_email || s.owner_email || s.admin_name || "—")}</div>
            ${(s.owner_tags || []).length ? `<div class="o-tags">${s.owner_tags.map((x) => `<span>${esc(x)}</span>`).join("")}</div>` : ""}</div></div></td>
          <td>${planPill(s.plan)}<div class="small muted">${s.paying ? `${money(s.price)}/شهر` : s.plan_status ? esc(s.plan_status) : ""}</div></td>
          <td>${stBadge(s)}${s.status === "trial" && d !== null ? `<div class="small ${d <= 3 ? "o-red" : "muted"}">${d >= 0 ? `باقي ${d} يوم` : "انتهت التجربة"}</div>` : ""}</td>
          <td><b>${num(s.orders_30d)}</b> طلب<div class="small muted">${s.gmv_30d !== undefined ? money(s.gmv_30d) : ""} · ${num(s.branches)} فرع · ${num(s.drivers)} مندوب</div></td>
          <td class="small">${s.last_login_at ? A.ago(s.last_login_at) : `<span class="muted">—</span>`}</td>
          <td>${dot(h)} <span class="small muted">${h.issues.length ? esc(h.issues[0]) : "مكتمل"}</span></td>
          <td><span class="muted">‹</span></td></tr>`; }).join("") || `<tr><td colspan="7" class="empty">${all.length ? "لا نتائج مطابقة للبحث" : "لا يوجد متاجر بعد — أول ما يثبّت تاجر التطبيق من زد بيظهر هنا"}</td></tr>`}
        </tbody></table>`;
      $$("#tbl [data-open]").forEach((r) => { r.onclick = () => openStore(Number(r.dataset.open)); r.onkeydown = (e) => { if (e.key === "Enter") openStore(Number(r.dataset.open)); }; });
    };
    draw();
    $$(".o-seg button").forEach((b) => b.onclick = () => { F.status = b.dataset.st; $$(".o-seg button").forEach((x) => x.classList.toggle("on", x === b)); draw(); });
    $("#q").oninput = (e) => { F.q = e.target.value; draw(); };
    $("#fp").onchange = (e) => { F.plan = e.target.value; draw(); };
    $("#fs").onchange = (e) => { F.sort = e.target.value; draw(); };
    $("#csv").onclick = () => exportCsv(filtered());
  }
  function exportCsv(rows) {
    const cols = [["id", "ID"], ["name", "المتجر"], ["code", "الرمز"], ["status", "الحالة"], ["plan", "الباقة"], ["plan_status", "حالة الاشتراك"], ["price", "السعر"], ["paying", "مدفوع"],
      ["trial_ends_at", "نهاية التجربة"], ["installed_at", "تاريخ التثبيت"], ["admin_name", "المدير"], ["admin_email", "إيميل المدير"], ["owner_email", "إيميل المتجر"], ["owner_phone", "الجوال"],
      ["store_url", "رابط المتجر"], ["branches", "فروع"], ["drivers", "مناديب"], ["staff", "الفريق"], ["orders_30d", "طلبات 30 يوم"], ["gmv_30d", "قيمة 30 يوم"], ["last_login_at", "آخر دخول"], ["owner_tags", "وسوم"], ["owner_note", "ملاحظات"]];
    const cell = (v) => { const s = Array.isArray(v) ? v.join("، ") : v === null || v === undefined ? "" : String(v); return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
    const csv = "﻿" + [cols.map((c) => c[1]).join(","), ...rows.map((r) => cols.map(([k]) => cell(r[k])).join(","))].join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv;charset=utf-8" }));
    a.download = `msar-customers-${new Date().toISOString().slice(0, 10)}.csv`; a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 2000);
  }

  // =================================================================== ملف العميل (لوحة جانبية)
  async function openStore(id) {
    const s = (D.stores || []).find((x) => x.id === id); if (!s) return;
    $("#drawer")?.remove();
    const el = document.createElement("div");
    el.id = "drawer"; el.className = "o-drawer-wrap";
    const h = health(s), d = days(s.trial_ends_at);
    const phone = s.owner_phone ? String(s.owner_phone).replace(/[^\d+]/g, "") : "";
    el.innerHTML = `<aside class="o-drawer" role="dialog" aria-modal="true" aria-label="ملف العميل">
      <div class="o-dh">
        <div class="o-store">${avatar(s)}<div><h3 style="margin:0">${esc(s.name)}</h3><div class="small"><span class="mono">${esc(s.code)}</span> · ${stBadge(s)} ${planPill(s.plan)}</div></div></div>
        <span class="spacer"></span><button class="icon-btn" data-x aria-label="إغلاق">✕</button>
      </div>
      <div class="o-actions">
        <button class="btn btn-sm btn-primary" id="d-edit">✏️ تعديل</button>
        ${phone ? `<a class="btn btn-sm" target="_blank" rel="noopener" href="${A.waLink(phone, `هلا ${s.admin_name || ""}، معك فريق مسار 👋`)}">💬 واتساب</a>` : ""}
        ${s.admin_email || s.owner_email ? `<a class="btn btn-sm" href="mailto:${esc(s.admin_email || s.owner_email)}">✉️ إيميل</a>` : ""}
        ${s.store_url ? `<a class="btn btn-sm" target="_blank" rel="noopener" href="${esc(s.store_url)}">🛍️ المتجر</a>` : ""}
        <button class="btn btn-sm" id="d-reset">🔑 استعادة دخول المدير</button>
      </div>
      <div class="o-dtabs">${[["sum", "نظرة"], ["team", "الفريق"], ["sub", "الاشتراك"], ["notes", "ملاحظات"], ["act", "النشاط"]].map(([k, l], i) => `<button data-dt="${k}" class="${i ? "" : "on"}">${l}</button>`).join("")}</div>
      <div class="o-dbody" id="dbody"><div class="empty">جاري التحميل…</div></div>
    </aside>`;
    document.body.appendChild(el);
    requestAnimationFrame(() => el.classList.add("in"));
    const close = () => { el.classList.remove("in"); setTimeout(() => el.remove(), 200); document.removeEventListener("keydown", esck); };
    const esck = (e) => { if (e.key === "Escape") close(); };
    document.addEventListener("keydown", esck);
    el.onclick = (e) => { if (e.target === el || e.target.closest("[data-x]")) close(); };
    $("#d-edit", el).onclick = () => editStore(s);
    $("#d-reset", el).onclick = () => resetAdmin(s);
    let X = null;
    try { X = await A.rpc("owner_store_detail", { p_id: id }); } catch (_) { X = null; }
    const steps = [["ربط زد", s.zid_connected], ["حساب المدير", s.has_admin], ["إضافة فرع", s.branches > 0], ["إضافة مندوب", s.drivers > 0], ["أول طلب", !!s.last_order_at]];
    const done = steps.filter((x) => x[1]).length;
    const T = {
      sum: () => `
        <div class="o-kpis o-kpis-sm">
          ${kpi("طلبات 30 يوم", num(s.orders_30d), `${num(s.orders_7d ?? 0)} آخر أسبوع`)}
          ${kpi("تم التوصيل", num(s.delivered_30d ?? 0), s.orders_30d ? `${Math.round(((s.delivered_30d || 0) / s.orders_30d) * 100)}% من الطلبات` : "")}
          ${kpi("قيمة الطلبات", s.gmv_30d !== undefined ? money(s.gmv_30d) : "—")}
          ${kpi("آخر طلب", s.last_order_at ? A.ago(s.last_order_at) : "—")}
        </div>
        <h4>إكمال الإعداد <span class="muted small">${done}/${steps.length}</span></h4>
        <div class="o-steps">${steps.map(([l, ok]) => `<span class="${ok ? "ok" : ""}">${ok ? "✓" : "○"} ${l}</span>`).join("")}</div>
        ${h.issues.length ? `<div class="o-warn small" style="margin-top:10px">${dot(h)} ${h.issues.map(esc).join(" · ")}</div>` : ""}
        <h4>الطلبات اليومية</h4>${X ? bars(X.orders_daily, 90) : `<div class="empty">شغّل ترقية 007</div>`}
        <div class="o-kv">
          <span>المدير</span><b>${esc(s.admin_name || "—")}</b>
          <span>الإيميل</span><b dir="ltr">${esc(s.admin_email || s.owner_email || "—")}</b>
          <span>الجوال</span><b class="mono">${esc(s.owner_phone || "—")}</b>
          <span>التثبيت</span><b>${s.installed_at ? A.fmtDateTime(s.installed_at) : "—"}</b>
          <span>آخر دخول</span><b>${s.last_login_at ? A.ago(s.last_login_at) : "—"}</b>
          <span>آخر مزامنة</span><b>${s.last_synced_at ? A.ago(s.last_synced_at) : "—"}</b>
          <span>تحديث الحالة في زد</span><b>${s.push_status === true ? "مفعّل" : "موقوف"}</b>
        </div>`,
      team: () => !X ? `<div class="empty">غير متاح</div>` : `
        <table><thead><tr><th>الاسم</th><th>الدور</th><th>الدخول</th><th>آخر دخول</th></tr></thead><tbody>
        ${X.team.map((m) => `<tr><td><b>${esc(m.name)}</b>${m.active ? "" : ` <span class="chip">موقوف</span>`}${m.branch ? `<div class="small muted">${esc(m.branch)}</div>` : ""}</td>
          <td>${ROLE_AR[m.role] || m.role}</td><td class="small" dir="ltr">${esc(m.email || m.username || "—")}</td><td class="small">${m.last_login_at ? A.ago(m.last_login_at) : "—"}</td></tr>`).join("") || `<tr><td colspan="4" class="empty">لا يوجد أعضاء</td></tr>`}
        </tbody></table>
        <h4>الفروع</h4><div class="o-steps">${X.branches.map((b) => `<span class="${b.active ? "ok" : ""}">🏬 ${esc(b.name)}${b.city ? ` · ${esc(b.city)}` : ""}</span>`).join("") || `<span>لا يوجد فروع</span>`}</div>`,
      sub: () => `<div class="o-kv">
          <span>الباقة</span><b>${planPill(s.plan)}</b>
          <span>السعر الشهري</span><b>${money(s.price ?? 0)}</b>
          <span>مشترك مدفوع؟</span><b>${s.paying ? "✅ نعم" : "لا"}</b>
          <span>حالة الاشتراك في زد</span><b>${esc(s.plan_status || "—")}</b>
          <span>ينتهي الاشتراك</span><b>${s.plan_ends_at ? A.fmtDateTime(s.plan_ends_at) : "—"}</b>
          <span>نهاية التجربة</span><b>${s.trial_ends_at ? `${A.fmtDateTime(s.trial_ends_at)}${d !== null ? ` (${d >= 0 ? `باقي ${d} يوم` : "انتهت"})` : ""}` : "—"}</b>
          <span>آخر تحقق من زد</span><b>${s.plan_checked_at ? A.ago(s.plan_checked_at) : "—"}</b>
          <span>معرّف المتجر في زد</span><b class="mono">${esc(s.zid_store_id || "—")}</b>
        </div><p class="small muted">الباقة وحالتها تتحدّث تلقائياً من اشتراك زد. تقدر تعدّلها يدوياً من زر "تعديل".</p>`,
      notes: () => `
        <label class="field"><span>ملاحظات داخلية (ما يشوفها التاجر)</span><textarea id="n-note" rows="6" placeholder="مثال: تواصلت معه بخصوص إضافة الفروع…">${esc(s.owner_note || "")}</textarea></label>
        <label class="field"><span>وسوم (افصل بفاصلة)</span><input id="n-tags" value="${esc((s.owner_tags || []).join("، "))}" placeholder="مهم، يحتاج تدريب، مطعم"></label>
        <label class="field"><span>تاريخ المتابعة القادمة</span><input id="n-fu" type="date" value="${esc(s.owner_followup || "")}"></label>
        <button class="btn btn-primary" id="n-save">حفظ</button>`,
      act: () => !X ? `<div class="empty">غير متاح</div>` : `
        <h4>تذاكر الدعم</h4>${X.tickets.length ? `<div class="o-list">${X.tickets.map((tk) => `<div class="o-li"><div class="grow"><b>#${tk.id} ${esc(tk.subject)}</b><div class="small muted">${esc(tk.user_name || "")} · ${A.ago(tk.updated_at)}</div></div><span class="chip">${({ open: "مفتوحة", answered: "تم الرد", closed: "مغلقة" })[tk.status] || tk.status}</span></div>`).join("")}</div>` : `<div class="empty">لا توجد تذاكر</div>`}
        <h4>سجل الربط مع زد</h4>${X.logs.length ? `<table><tbody>${X.logs.map((l) => `<tr><td class="small">${A.fmtDateTime(l.at)}</td><td class="small">${esc(l.kind)}</td><td>${l.ok ? "✅" : "❌"}</td><td class="small">${esc(l.message || "")}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">لا يوجد سجل</div>`}`,
    };
    const show = (k) => {
      $$(".o-dtabs button", el).forEach((b) => b.classList.toggle("on", b.dataset.dt === k));
      $("#dbody", el).innerHTML = T[k]();
      if (k === "notes") $("#n-save", el).onclick = async (e) => {
        e.target.disabled = true;
        try {
          const tags = $("#n-tags", el).value.split(/[،,]/).map((x) => x.trim()).filter(Boolean);
          await A.rpc("owner_store_note", { p_id: s.id, p_note: $("#n-note", el).value, p_tags: tags, p_followup: $("#n-fu", el).value || null });
          Object.assign(s, { owner_note: $("#n-note", el).value, owner_tags: tags, owner_followup: $("#n-fu", el).value || null });
          toast("تم الحفظ ✅", "ok"); if (tab === "stores") renderStores();
        } catch (er) { toast(A.errMsg(er), "error"); }
        e.target.disabled = false;
      };
    };
    $$(".o-dtabs button", el).forEach((b) => b.onclick = () => show(b.dataset.dt));
    show("sum");
  }

  async function resetAdmin(s) {
    const box = document.createElement("div");
    box.innerHTML = `<p class="small muted">ينشئ رابط استعادة (إذا عند المدير إيميل) أو كلمة مرور مؤقتة، وترسلها له بنفسك.</p><div id="r-out"></div>`;
    A.modal({ title: `🔑 استعادة دخول: ${s.name}`, body: box, actions: [{ label: "إغلاق", cls: "btn-ghost" }, { label: "أنشئ الآن", cls: "btn-primary", onClick: async () => {
      const r = await A.callFn("admin", { action: "owner_reset_admin", store_id: s.id });
      const msg = r.kind === "link"
        ? `هلا ${r.name}، هذا رابط تختار فيه كلمة مرور جديدة لحسابك في مسار:\n${r.link}`
        : `هلا ${r.name}، كلمة المرور المؤقتة لحسابك في مسار: ${r.password}\n(رمز المتجر: ${s.code} — اسم المستخدم: ${r.username}) — غيّرها من "حسابي" بعد الدخول.`;
      $("#r-out", box).innerHTML = `<textarea readonly rows="4" style="width:100%;font-size:12px">${esc(msg)}</textarea>
        <div class="row" style="margin-top:6px"><button type="button" class="btn btn-sm" id="r-copy">📋 نسخ</button>${s.owner_phone ? `<a class="btn btn-sm btn-primary" target="_blank" href="${A.waLink(s.owner_phone, msg)}">واتساب للتاجر</a>` : ""}</div>`;
      $("#r-copy", box).onclick = () => { A.copy(msg); };
      return false;
    } }] });
  }

  function editStore(s) {
    const body = document.createElement("div");
    body.innerHTML = `
      <label class="field"><span>اسم المتجر</span><input id="e-name" value="${esc(s.name)}"></label>
      <label class="field"><span>رمز الدخول</span><input id="e-code" dir="ltr" value="${esc(s.code)}"></label>
      <label class="field"><span>الحالة</span><select id="e-status">${Object.entries(ST).map(([k, v]) => `<option value="${k}" ${k === s.status ? "selected" : ""}>${v[0]}</option>`).join("")}</select></label>
      <label class="field"><span>الباقة <small class="muted">(تتحدّث تلقائياً من اشتراك زد)</small></span><select id="e-plan">${[["", "— بدون (تعامل كالأساسية)"], ["starter", "الأساسية — فرعين · 5 موظفين"], ["growth", "النمو — 5 فروع · 20 موظف · تتبع"], ["pro", "الاحترافية — بلا حدود"]].map(([k, l]) => `<option value="${k}" ${k === (s.plan || "") ? "selected" : ""}>${l}</option>`).join("")}</select></label>
      <label class="field"><span>نهاية الفترة التجريبية</span><input id="e-trial" type="date" value="${s.trial_ends_at ? s.trial_ends_at.slice(0, 10) : ""}"></label>
      <label class="row"><input type="checkbox" id="e-push" style="width:auto;min-height:auto" ${s.push_status === true ? "checked" : ""}> تحديث حالة الطلبات في زد لهذا المتجر</label>`;
    A.modal({ title: `تعديل: ${s.name}`, body, actions: [
      { label: "إلغاء", cls: "btn-ghost" },
      { label: "حفظ", cls: "btn-primary", onClick: async () => {
          const p = { name: $("#e-name", body).value.trim(), code: $("#e-code", body).value.trim().toLowerCase(), status: $("#e-status", body).value,
                      plan: $("#e-plan", body).value || "", push_status: $("#e-push", body).checked };
          const d = $("#e-trial", body).value; if (d) p.trial_ends_at = new Date(d + "T23:59:00+03:00").toISOString();
          await A.rpc("owner_update_store", { p_id: s.id, p });
          toast("تم الحفظ", "ok"); $("#drawer")?.remove(); load();
        } }] });
  }

  // =================================================================== تطبيق زد / متجر يدوي / السجل
  function renderZid() {
    $("#view").innerHTML = `
      <div class="card"><div class="card-head"><h3>🔑 مفاتيح تطبيق مسار في بوابة شركاء زد</h3></div>
        <p class="small muted" style="margin-top:0">من partners.zid.sa ← التطبيقات ← تطبيقك ← الإعدادات العامة ← مفاتيح API</p>
        <div class="grid-2">
          <label class="field"><span>Client ID</span><input id="z-id" dir="ltr" value="${esc(D.zid_client_id || "")}"></label>
          <label class="field"><span>Client Secret ${D.zid_client_secret_set ? "✅ (محفوظ — اتركه فاضي إذا ما تبي تغيّره)" : ""}</span><input id="z-sec" type="password" dir="ltr" autocomplete="off" placeholder="${D.zid_client_secret_set ? "••••••••" : ""}"></label>
        </div>
        <button class="btn btn-primary" id="z-save">حفظ المفاتيح</button></div>
      <div class="card"><div class="card-head"><h3>🌐 الروابط المطلوبة في إعدادات التطبيق داخل زد</h3></div>
        <div class="kv2">
          ${[["رابط التطبيق (Application URL)", WEB], ["رابط إعادة التوجيه (Redirect URL)", `${FN}?action=install`], ["رابط الاستدعاء (Callback URL)", `${FN}?action=callback`]]
            .map(([k, v]) => `<div class="small"><b>${k}</b></div><div class="row"><span class="mono small" style="word-break:break-all">${esc(v)}</span><button class="btn btn-sm" data-copy="${esc(v)}">📋</button></div>`).join("")}
        </div>
        <p class="small muted">الصلاحيات المطلوبة: الطلبات (قراءة وكتابة) · Webhooks (قراءة وكتابة) · تفاصيل المتجر (قراءة) · الحساب (قراءة) · المنتجات (قراءة) · المخزون (قراءة).</p></div>`;
    $$("[data-copy]").forEach((b) => b.onclick = () => { A.copy(b.dataset.copy); });
    $("#z-save").onclick = async (e) => {
      e.target.disabled = true;
      try {
        await A.rpc("owner_set_setting", { p_key: "zid_client_id", p_value: $("#z-id").value.trim() });
        if ($("#z-sec").value.trim()) await A.rpc("owner_set_setting", { p_key: "zid_client_secret", p_value: $("#z-sec").value.trim() });
        toast("تم حفظ المفاتيح ✅", "ok"); load();
      } catch (er) { toast(A.errMsg(er), "error"); }
      e.target.disabled = false;
    };
  }

  // =================================================================== تطبيق سلة
  async function renderSalla() {
    $("#view").innerHTML = `<div class="card"><div class="empty">جاري التحميل…</div></div>`;
    let I;
    try { I = await A.rpc("owner_salla_info"); } catch (e) { $("#view").innerHTML = `<div class="card"><p class="chip chip-warn">${esc(A.errMsg(e))} — شغّل ترقية قاعدة البيانات 009</p></div>`; return; }
    const SFN = `${A.C.SUPABASE_URL}/functions/v1/salla`;
    const links = [["رابط الـ Webhook (Webhooks / Notifications)", SFN], ["موقع التطبيق (App Website)", `${WEB}salla`], ["رابط سياسة الخصوصية", `${WEB}privacy`], ["رابط الدعم", `${WEB}support`]];
    const pending = (I.stores || []).filter((s) => !s.has_admin && s.status !== "uninstalled");
    $("#view").innerHTML = `
      <div class="card"><div class="card-head"><h3>🔑 مفاتيح تطبيق مسار في بوابة شركاء سلة</h3><span class="spacer"></span>
        ${I.last_event ? `<span class="chip">آخر حدث من سلة ${A.ago(I.last_event)}</span>` : `<span class="chip chip-warn">ما وصل أي حدث من سلة بعد</span>`}</div>
        <p class="small muted" style="margin-top:0">من portal.salla.partners ← تطبيقاتي ← مسار برو ← App Details: <b>App Keys</b> (اختر <b>Easy Mode</b>) و <b>Webhooks/Notifications</b> (Webhook Secret).</p>
        <div class="grid-2">
          <label class="field"><span>Client ID</span><input id="sl-id" dir="ltr" value="${esc(I.client_id || "")}"></label>
          <label class="field"><span>App ID (اختياري)</span><input id="sl-app" dir="ltr" value="${esc(I.app_id || "")}"></label>
          <label class="field"><span>Client Secret ${I.client_secret_set ? "✅ (محفوظ — اتركه فاضي إذا ما تبي تغيّره)" : ""}</span><input id="sl-sec" type="password" dir="ltr" autocomplete="off" placeholder="${I.client_secret_set ? "••••••••" : ""}"></label>
          <label class="field"><span>Webhook Secret ${I.webhook_secret_set ? "✅ (محفوظ)" : ""}</span><input id="sl-wh" type="password" dir="ltr" autocomplete="off" placeholder="${I.webhook_secret_set ? "••••••••" : ""}"></label>
        </div>
        <button class="btn btn-primary" id="sl-save">حفظ المفاتيح</button></div>
      <div class="card"><div class="card-head"><h3>🌐 الروابط المطلوبة في إعدادات التطبيق داخل سلة</h3></div>
        <div class="kv2">${links.map(([k, v]) => `<div class="small"><b>${k}</b></div><div class="row"><span class="mono small" style="word-break:break-all">${esc(v)}</span><button class="btn btn-sm" data-copy="${esc(v)}">📋</button></div>`).join("")}</div>
        <p class="small muted"><b>الصلاحيات (App Scope):</b> الطلبات (قراءة وكتابة) · الشحنات (قراءة) · الإعدادات/بيانات المتجر (قراءة) · Webhooks (قراءة وكتابة) · offline_access.<br>
        <b>الأحداث (Add Events):</b> كل أحداث التطبيق (تفعّل تلقائياً) + order.created · order.updated · order.status.updated · order.cancelled · order.shipping.address.updated.<br>
        <b>Security Strategy:</b> Signature (الافتراضي).</p></div>
      <div class="card"><div class="card-head"><h3>🛍️ متاجر سلة</h3><span class="spacer"></span><span class="chip">${(I.stores || []).length} متجر · ${pending.length} بانتظار إعداد المدير</span></div>
        ${(I.stores || []).length ? `<div class="table-wrap"><table><thead><tr><th>المتجر</th><th>الحالة</th><th>الإيميل</th><th>الجوال</th><th>المدير</th><th></th></tr></thead><tbody>
          ${I.stores.map((s) => { const st = ST[s.status] || ST.trial; return `<tr><td><b>${esc(s.name)}</b><div class="small muted mono">${esc(s.code)} · ${esc(String(s.merchant || ""))}</div></td>
            <td><span class="badge" style="background:${st[1]};color:${st[2]}">${st[0]}</span></td><td class="small" dir="ltr">${esc(s.owner_email || "—")}</td><td class="small" dir="ltr">${esc(s.owner_phone || "—")}</td>
            <td>${s.has_admin ? "✅" : "⏳ بانتظار"}</td><td>${!s.has_admin && s.status !== "uninstalled" ? `<button class="btn btn-sm" data-setup="${s.id}" data-phone="${esc(s.owner_phone || "")}">🔗 رابط الإعداد</button>` : ""}</td></tr>`; }).join("")}</tbody></table></div>`
          : `<div class="empty">ما فيه متاجر سلة بعد — أول ما يثبّت تاجر التطبيق بيظهر هنا</div>`}
        <p class="small muted" style="margin-bottom:0">التاجر يقدر يربط حسابه بنفسه من <b>${esc(WEB)}salla</b> بالدخول بقوقل بنفس إيميل سلة. إذا إيميله مختلف، أرسل له رابط الإعداد من الزر.</p></div>`;
    $$("[data-copy]").forEach((b) => b.onclick = () => { A.copy(b.dataset.copy); });
    $("#sl-save").onclick = async (e) => {
      e.target.disabled = true;
      try {
        await A.rpc("owner_set_setting", { p_key: "salla_client_id", p_value: $("#sl-id").value.trim() });
        await A.rpc("owner_set_setting", { p_key: "salla_app_id", p_value: $("#sl-app").value.trim() });
        if ($("#sl-sec").value.trim()) await A.rpc("owner_set_setting", { p_key: "salla_client_secret", p_value: $("#sl-sec").value.trim() });
        if ($("#sl-wh").value.trim()) await A.rpc("owner_set_setting", { p_key: "salla_webhook_secret", p_value: $("#sl-wh").value.trim() });
        toast("تم حفظ مفاتيح سلة ✅", "ok"); renderSalla();
      } catch (er) { toast(A.errMsg(er), "error"); }
      e.target.disabled = false;
    };
    $$("[data-setup]").forEach((b) => b.onclick = async () => {
      try {
        const tok = await A.rpc("owner_setup_link", { p_store: Number(b.dataset.setup) });
        const link = `${WEB}setup?t=${tok}`;
        const ph = String(b.dataset.phone || "").replace(/[^\d]/g, "");
        A.modal({ title: "🔗 رابط إعداد حساب المدير", body: `<p class="small muted" style="margin-top:0">صالح 7 أيام. أرسله لصاحب المتجر عشان ينشئ حسابه في مسار.</p>
          <div class="row"><span class="mono small" style="word-break:break-all">${esc(link)}</span></div>
          <div class="row" style="margin-top:12px"><button class="btn btn-primary" id="cp-link">📋 نسخ</button>${ph ? `<a class="btn" target="_blank" rel="noopener" href="https://wa.me/${ph}?text=${encodeURIComponent("أهلاً 👋 هذا رابط إعداد حسابك في مسار برو بعد تثبيت التطبيق في سلة:\n" + link)}">💬 واتساب</a>` : ""}</div>` });
        $("#cp-link").onclick = () => A.copy(link, "تم نسخ الرابط");
      } catch (e) { toast(A.errMsg(e), "error"); }
    });
  }

  function renderNew() {
    $("#view").innerHTML = `<form class="card" id="nf" style="max-width:620px">
      <div class="card-head"><h3>➕ إنشاء متجر يدوي (للتجربة أو لعميل خارج زد)</h3></div>
      <label class="field"><span>اسم المتجر</span><input name="n" required></label>
      <label class="field"><span>رمز الدخول (إنجليزي صغير)</span><input name="c" required dir="ltr" pattern="[a-z0-9-]{2,30}"></label>
      <label class="field"><span>رابط المتجر (اختياري)</span><input name="url" dir="ltr" placeholder="https://"></label>
      <div class="grid-2">
        <label class="field"><span>اسم مستخدم المدير</span><input name="au" required dir="ltr" pattern="[a-zA-Z0-9._-]{3,32}"></label>
        <label class="field"><span>كلمة مرور المدير (8 أحرف أو أكثر)</span><input name="ap" type="password" minlength="8" required dir="ltr" autocomplete="new-password"></label>
      </div>
      <label class="field"><span>اسم المدير</span><input name="an"></label>
      <button class="btn btn-primary">إنشاء المتجر</button></form>`;
    $("#nf").onsubmit = async (e) => {
      e.preventDefault(); const f = e.target, b = $("button", f); b.disabled = true;
      try {
        await A.callFn("admin", { action: "owner_create_store", name: f.n.value, code: f.c.value.trim().toLowerCase(), store_url: f.url.value || null,
          admin_username: f.au.value, admin_password: f.ap.value, admin_name: f.an.value || f.au.value });
        toast("تم إنشاء المتجر ✅", "ok"); f.reset(); await load(); go("stores");
      } catch (er) { toast(A.errMsg(er), "error"); }
      b.disabled = false;
    };
  }

  async function renderLogs() {
    $("#view").innerHTML = `<div class="card" style="padding:0"><div class="table-wrap" id="lg"><div class="empty">جاري التحميل…</div></div></div>`;
    try {
      const rows = await A.rpc("owner_logs", { p_store: null, p_limit: 150 });
      const name = (id) => (D.stores || []).find((s) => s.id === id)?.name || "—";
      $("#lg").innerHTML = rows.length ? `<table><thead><tr><th>الوقت</th><th>المتجر</th><th>النوع</th><th></th><th>التفاصيل</th></tr></thead><tbody>
        ${rows.map((l) => `<tr><td class="small">${A.fmtDateTime(l.at)}</td><td class="small">${esc(name(l.store_id))}</td><td>${esc(l.kind)}</td><td>${l.ok ? "✅" : "❌"}</td><td class="small">${esc(l.message || "")}</td></tr>`).join("")}</tbody></table>`
        : `<div class="empty">لا يوجد سجل</div>`;
    } catch (e) { toast(A.errMsg(e), "error"); }
  }

  boot().catch((e) => { console.error(e); toast(A.errMsg(e), "error"); });
})();
