/* مسار — لوحة صاحب المنصة: المتاجر المشتركة والاشتراكات والربط مع زد */
(function () {
  const A = window.AZM, { sb, $, $$, esc, num, toast } = A;
  const app = document.getElementById("app");
  const FN = `${A.C.SUPABASE_URL}/functions/v1/zid`;
  const WEB = location.href.split("#")[0].split("?")[0].replace(/owner\.html$/, "");
  const ST = { trial: ["🕒 تجريبي", "#fef3c7", "#92400e"], active: ["✅ فعّال", "#dcfce7", "#166534"], suspended: ["⏸️ موقوف", "#fee2e2", "#991b1b"], uninstalled: ["🗑️ محذوف", "#f1f5f9", "#475569"] };
  let D = null, tab = (location.hash.slice(1) || "stores").replace(/[^a-z]/g, "");

  async function boot() {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return renderLogin();
    const me = await A.myProfile().catch(() => null);
    if (me?.role !== "owner") { await sb.auth.signOut(); return renderLogin("هذا الحساب ليس حساب صاحب المنصة"); }
    shell(me);
    load();
  }

  async function renderLogin(msg) {
    let needs = false;
    try { needs = (await A.callFn("admin", { action: "owner_status" })).needs_bootstrap; } catch (_) {}
    app.innerHTML = `<div class="login-page"><form class="login-card" id="f">
      <div class="logo"><img class="logo-mark" src="icons/logo.png" alt="مسار"><div>مسار<div class="small muted" style="font-weight:600">لوحة صاحب المنصة</div></div></div>
      <div style="height:18px"></div>${msg ? `<p class="chip chip-warn">${esc(msg)}</p>` : ""}
      ${needs ? `<h3 style="margin:0 0 6px">إنشاء حساب صاحب المنصة</h3><p class="small muted" style="margin-top:0">هذي الخطوة تظهر مرة وحدة فقط.</p>
        <label class="field"><span>الاسم</span><input name="n" required></label>` : ""}
      <label class="field"><span>${needs ? "اسم المستخدم" : "اسم المستخدم أو الإيميل"}</span><input name="u" required dir="ltr" autocapitalize="none" ${needs ? 'pattern="[a-zA-Z0-9._-]{3,32}"' : ""}></label>
      <label class="field"><span>كلمة المرور${needs ? " (8 أحرف أو أكثر)" : ""}</span><input name="p" type="password" ${needs ? 'minlength="8" autocomplete="new-password"' : 'autocomplete="current-password"'} required dir="ltr"></label>
      <button class="btn btn-primary btn-block btn-lg" type="submit">${needs ? "إنشاء الحساب والدخول" : "دخول"}</button>
      ${needs ? "" : A.authExtrasHtml()}
    </form></div>`;
    if (!needs) A.bindAuthExtras($("#f"), () => $("#f").u.value);
    $("#f").onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target, b = $("button[type=submit]", f); b.disabled = true;
      try {
        if (needs) await A.callFn("admin", { action: "owner_bootstrap", full_name: f.n.value, username: f.u.value, password: f.p.value, web_url: WEB });
        await A.login(f.u.value, f.p.value, "owner");
        location.reload();
      } catch (err) { toast(A.errMsg(err), "error"); b.disabled = false; }
    };
  }

  function shell(me) {
    const TABS = [["stores", "🏪 المتاجر"], ["site", "🌐 الموقع"], ["leads", "📨 طلبات التواصل"], ["zid", "🔗 تطبيق زد"], ["new", "➕ متجر يدوي"], ["logs", "📜 السجل"]];
    if (!TABS.some(([k]) => k === tab)) tab = "stores";
    app.innerHTML = `<div class="o-top"><div class="o-top-in">
        <img class="logo-mark" src="icons/logo.png" alt="مسار">
        <div class="grow"><b style="font-size:19px">مسار — لوحة صاحب المنصة</b><div class="small" style="opacity:.8">أهلاً ${esc(me.full_name || "")} 👋</div></div>
        <a class="btn btn-sm o-ghost" href="./" target="_blank">🌐 الموقع</a>
        <a class="btn btn-sm o-ghost" href="app.html" target="_blank">🖥️ لوحة التاجر</a>
        <button class="btn btn-sm o-ghost" id="acc">👤 حسابي</button>
        <button class="btn btn-sm o-ghost" id="lo">خروج</button></div>
        <div class="o-wrap" style="padding-bottom:0"><div class="stats" id="totals"></div>
        <nav class="o-tabs">${TABS.map(([k, l]) => `<button data-t="${k}" class="${k === tab ? "on" : ""}">${l}</button>`).join("")}</nav></div></div>
      <div class="o-wrap"><div id="view"></div></div>`;
    $("#lo").onclick = A.logout;
    $("#acc").onclick = () => A.accountDialog();
    $$(".o-tabs button").forEach((b) => b.onclick = () => { tab = b.dataset.t; history.replaceState(null, "", "#" + tab); $$(".o-tabs button").forEach((x) => x.classList.toggle("on", x === b)); render(); });
  }

  async function load() {
    try { D = await A.rpc("owner_overview"); } catch (e) { toast(A.errMsg(e), "error"); return; }
    if (!D.web_url || D.web_url !== WEB) A.rpc("owner_set_setting", { p_key: "web_url", p_value: WEB }).catch(() => {});
    const t = D.totals;
    $("#totals").innerHTML = `
      <div class="stat"><div class="k">المتاجر</div><div class="v">${num(t.stores)}</div><div class="s">${num(t.active)} فعّال · ${num(t.trial)} تجريبي</div></div>
      <div class="stat"><div class="k">طلبات اليوم</div><div class="v">${num(t.orders_today)}</div></div>
      <div class="stat"><div class="k">طلبات 30 يوم</div><div class="v">${num(t.orders_30d)}</div></div>
      <div class="stat"><div class="k">المناديب</div><div class="v">${num(t.drivers)}</div></div>
      <div class="stat" id="health"><div class="k">صحة النظام</div><div class="v">…</div></div>`;
    A.rpc("owner_health").then((h) => {
      const age = h.cron_last_run ? Math.round((Date.now() - Date.parse(h.cron_last_run)) / 1000) : null;
      const bad = age === null || age > 300 || h.outbox_stuck > 0 || h.errors_1h > 20;
      $("#health").innerHTML = `<div class="k">صحة النظام</div><div class="v" style="color:${bad ? "#b91c1c" : "#15803d"}">${bad ? "⚠️ تنبيه" : "✅ سليم"}</div>
        <div class="s">آخر مزامنة: ${age === null ? "لم تعمل" : age < 120 ? "قبل دقيقة" : `قبل ${Math.round(age / 60)} د`} · أخطاء ساعة: ${num(h.errors_1h)} · عالقة: ${num(h.outbox_stuck)} · متأخرة: ${num(h.stores_sync_late)} · القاعدة ${num(h.db_size_mb)}MB</div>`;
    }).catch(() => { $("#health").innerHTML = `<div class="k">صحة النظام</div><div class="v">—</div><div class="s">شغّل ترقية 002</div>`; });
    render();
  }

  function render() {
    if (!D) return;
    if (tab === "stores") return renderStores();
    if (tab === "zid") return renderZid();
    if (tab === "new") return renderNew();
    if (tab === "logs") return renderLogs();
    if (tab === "site") return window.MSAR_OWNER_SITE.render($("#view"));
    if (tab === "leads") return window.MSAR_OWNER_SITE.render($("#view"), "leads");
  }

  function renderStores() {
    const rows = D.stores;
    $("#view").innerHTML = `<div class="card"><div class="table-wrap"><table><thead><tr>
      <th>المتجر</th><th>الرمز</th><th>الحالة</th><th>زد</th><th>تحديث زد</th><th>فروع</th><th>مناديب</th><th>طلبات اليوم</th><th>30 يوم</th><th>أخطاء 24س</th><th>نهاية التجربة</th><th></th></tr></thead><tbody>
      ${rows.map((s) => { const st = ST[s.status] || [s.status, "#eee", "#333"]; return `<tr>
        <td><b>${esc(s.name)}</b>${s.store_url ? `<div class="small"><a href="${esc(s.store_url)}" target="_blank" rel="noopener">${esc(s.store_url.replace(/^https?:\/\//, ""))}</a></div>` : ""}
          ${s.has_admin ? "" : `<div class="small" style="color:var(--warn)">لم يُنشأ حساب المدير بعد</div>`}</td>
        <td class="mono">${esc(s.code)}</td>
        <td><span class="badge" style="background:${st[1]};color:${st[2]}">${st[0]}</span></td>
        <td>${s.zid_connected ? "✅" : "—"}</td>
        <td>${s.push_status === true ? "✅" : "⏸️"}</td>
        <td>${num(s.branches)}</td><td>${num(s.drivers)}</td><td>${num(s.orders_today)}</td><td>${num(s.orders_30d)}</td>
        <td>${s.errors_24h ? `<b style="color:var(--danger)">${num(s.errors_24h)}</b>` : "0"}</td>
        <td class="small">${s.trial_ends_at ? A.fmtDateTime(s.trial_ends_at) : "—"}</td>
        <td><button class="btn btn-sm" data-edit="${s.id}">تعديل</button></td></tr>`; }).join("") || `<tr><td colspan="12" class="empty">لا يوجد متاجر بعد — أول ما يثبّت تاجر التطبيق من زد بيظهر هنا</td></tr>`}
      </tbody></table></div></div>`;
    $$("[data-edit]").forEach((b) => b.onclick = () => editStore(D.stores.find((x) => x.id === Number(b.dataset.edit))));
  }

  function editStore(s) {
    const body = document.createElement("div");
    body.innerHTML = `
      <label class="field"><span>اسم المتجر</span><input id="e-name" value="${esc(s.name)}"></label>
      <label class="field"><span>رمز الدخول</span><input id="e-code" dir="ltr" value="${esc(s.code)}"></label>
      <label class="field"><span>الحالة</span><select id="e-status">${Object.entries(ST).map(([k, v]) => `<option value="${k}" ${k === s.status ? "selected" : ""}>${v[0]}</option>`).join("")}</select></label>
      <label class="field"><span>الباقة</span><input id="e-plan" value="${esc(s.plan || "")}" placeholder="مثال: فرع واحد / 3 فروع / غير محدود"></label>
      <label class="field"><span>نهاية الفترة التجريبية</span><input id="e-trial" type="date" value="${s.trial_ends_at ? s.trial_ends_at.slice(0, 10) : ""}"></label>
      <label class="row"><input type="checkbox" id="e-push" style="width:auto;min-height:auto" ${s.push_status === true ? "checked" : ""}> تحديث حالة الطلبات في زد لهذا المتجر</label>
      <p class="small muted">📧 ${esc(s.owner_email || "—")} · 📞 <span class="mono">${esc(s.owner_phone || "—")}</span> · ركّب ${s.installed_at ? A.fmtDateTime(s.installed_at) : "—"}</p>
      <button type="button" class="btn btn-block" id="e-reset">🔑 التاجر نسي دخوله؟ أنشئ رابط استعادة / كلمة مؤقتة</button>
      <div id="e-reset-out"></div>`;
    $("#e-reset", body).onclick = async (ev) => {
      ev.target.disabled = true;
      try {
        const r = await A.callFn("admin", { action: "owner_reset_admin", store_id: s.id });
        const msg = r.kind === "link"
          ? `هلا ${r.name}، هذا رابط تختار فيه كلمة مرور جديدة لحسابك في مسار:\n${r.link}`
          : `هلا ${r.name}، كلمة المرور المؤقتة لحسابك في مسار: ${r.password}\n(رمز المتجر: ${s.code} — اسم المستخدم: ${r.username}) — غيّرها من "حسابي" بعد الدخول.`;
        $("#e-reset-out", body).innerHTML = `<textarea readonly rows="4" style="width:100%;margin-top:8px;font-size:12px">${esc(msg)}</textarea>
          <div class="row" style="margin-top:6px"><button type="button" class="btn btn-sm" id="e-copy">📋 نسخ</button>${s.owner_phone ? `<a class="btn btn-sm btn-primary" target="_blank" href="${A.waLink(s.owner_phone, msg)}">واتساب للتاجر</a>` : ""}</div>`;
        $("#e-copy", body).onclick = () => { navigator.clipboard?.writeText(msg); toast("تم النسخ", "ok"); };
      } catch (er) { toast(A.errMsg(er), "error"); ev.target.disabled = false; }
    };
    A.modal({ title: `تعديل: ${s.name}`, body, actions: [
      { label: "إلغاء", cls: "btn-ghost" },
      { label: "حفظ", cls: "btn-primary", onClick: async () => {
          const p = { name: $("#e-name", body).value.trim(), code: $("#e-code", body).value.trim().toLowerCase(), status: $("#e-status", body).value,
                      plan: $("#e-plan", body).value.trim() || null, push_status: $("#e-push", body).checked };
          const d = $("#e-trial", body).value; if (d) p.trial_ends_at = new Date(d + "T23:59:00+03:00").toISOString();
          await A.rpc("owner_update_store", { p_id: s.id, p });
          toast("تم الحفظ", "ok"); load();
        } }] });
  }

  function renderZid() {
    $("#view").innerHTML = `
      <div class="card"><div class="card-head"><h3>🔑 مفاتيح تطبيق مسار في بوابة شركاء زد</h3></div>
        <p class="small muted" style="margin-top:0">من partners.zid.sa ← التطبيقات ← تطبيقك ← الإعدادات العامة ← مفاتيح API</p>
        <div class="grid-2">
          <label class="field"><span>Client ID</span><input id="z-id" dir="ltr" value="${esc(D.zid_client_id || "")}"></label>
          <label class="field"><span>Client Secret ${D.zid_client_secret_set ? "✅ (محفوظ — اتركه فاضي إذا ما تبي تغيّره)" : ""}</span><input id="z-sec" type="password" dir="ltr" autocomplete="off" placeholder="${D.zid_client_secret_set ? "••••••••" : ""}"></label>
        </div>
        <button class="btn btn-primary" id="z-save">حفظ المفاتيح</button></div>
      <div class="card"><div class="card-head"><h3>🌐 الروابط المطلوبة في إعدادات التطبيق داخل زد</h3></div>
        <div class="kv2">
          ${[["رابط التطبيق (Application URL)", WEB], ["رابط إعادة التوجيه (Redirect URL)", `${FN}?action=install`], ["رابط الاستدعاء (Callback URL)", `${FN}?action=callback`]]
            .map(([k, v]) => `<div class="small"><b>${k}</b></div><div class="row"><span class="mono small" style="word-break:break-all">${esc(v)}</span><button class="btn btn-sm" data-copy="${esc(v)}">📋</button></div>`).join("")}
        </div>
        <p class="small muted">الصلاحيات المطلوبة: الطلبات (قراءة وكتابة) · Webhooks (قراءة وكتابة) · تفاصيل المتجر (قراءة) · الحساب (قراءة) · المنتجات (قراءة) · المخزون (قراءة).</p></div>`;
    $$("[data-copy]").forEach((b) => b.onclick = () => { navigator.clipboard?.writeText(b.dataset.copy); toast("تم النسخ", "ok"); });
    $("#z-save").onclick = async () => {
      try {
        await A.rpc("owner_set_setting", { p_key: "zid_client_id", p_value: $("#z-id").value.trim() });
        if ($("#z-sec").value.trim()) await A.rpc("owner_set_setting", { p_key: "zid_client_secret", p_value: $("#z-sec").value.trim() });
        toast("تم حفظ المفاتيح ✅", "ok"); load();
      } catch (e) { toast(A.errMsg(e), "error"); }
    };
  }

  function renderNew() {
    $("#view").innerHTML = `<form class="card" id="nf" style="max-width:560px">
      <div class="card-head"><h3>➕ إنشاء متجر يدوي (للتجربة أو لعميل خارج زد)</h3></div>
      <label class="field"><span>اسم المتجر</span><input name="n" required></label>
      <label class="field"><span>رمز الدخول (إنجليزي صغير)</span><input name="c" required dir="ltr" pattern="[a-z0-9-]{2,30}"></label>
      <label class="field"><span>رابط المتجر (اختياري)</span><input name="url" dir="ltr" placeholder="https://"></label>
      <div class="grid-2">
        <label class="field"><span>اسم مستخدم المدير</span><input name="au" required dir="ltr" pattern="[a-zA-Z0-9._-]{3,32}"></label>
        <label class="field"><span>كلمة مرور المدير</span><input name="ap" type="password" minlength="6" required dir="ltr" autocomplete="new-password"></label>
      </div>
      <label class="field"><span>اسم المدير</span><input name="an"></label>
      <button class="btn btn-primary">إنشاء المتجر</button></form>`;
    $("#nf").onsubmit = async (e) => {
      e.preventDefault(); const f = e.target;
      try {
        await A.callFn("admin", { action: "owner_create_store", name: f.n.value, code: f.c.value.trim().toLowerCase(), store_url: f.url.value || null,
          admin_username: f.au.value, admin_password: f.ap.value, admin_name: f.an.value || f.au.value });
        toast("تم إنشاء المتجر ✅", "ok"); f.reset(); tab = "stores"; shell({ full_name: "" }); load();
      } catch (er) { toast(A.errMsg(er), "error"); }
    };
  }

  async function renderLogs() {
    $("#view").innerHTML = `<div class="card"><div class="table-wrap" id="lg"><div class="empty">جاري التحميل…</div></div></div>`;
    try {
      const rows = await A.rpc("owner_logs", { p_store: null, p_limit: 120 });
      const name = (id) => D.stores.find((s) => s.id === id)?.name || "—";
      $("#lg").innerHTML = rows.length ? `<table><thead><tr><th>الوقت</th><th>المتجر</th><th>النوع</th><th></th><th>التفاصيل</th></tr></thead><tbody>
        ${rows.map((l) => `<tr><td class="small">${A.fmtDateTime(l.at)}</td><td class="small">${esc(name(l.store_id))}</td><td>${esc(l.kind)}</td><td>${l.ok ? "✅" : "❌"}</td><td class="small">${esc(l.message || "")}</td></tr>`).join("")}</tbody></table>`
        : `<div class="empty">لا يوجد سجل</div>`;
    } catch (e) { toast(A.errMsg(e), "error"); }
  }

  boot().catch((e) => { console.error(e); toast(A.errMsg(e), "error"); });
})();
