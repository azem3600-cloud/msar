/* مسار — محرك عرض الموقع التعريفي (يشتغل في المتصفح وفي Node للتوليد المسبق للـ SEO) */
(function (root) {
  "use strict";
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const isObj = (x) => x && typeof x === "object" && !Array.isArray(x);
  function merge(a, b) {
    if (!isObj(b)) return b === undefined ? a : b;
    const o = Array.isArray(a) ? a.slice() : { ...(a || {}) };
    for (const k of Object.keys(b)) o[k] = isObj(b[k]) && isObj(o[k]) ? merge(o[k], b[k]) : b[k];
    return o;
  }
  const safeUrl = (u) => { const s = String(u || "").trim(); return /^(https?:|mailto:|tel:|#|[a-z0-9._\/-]+(\.html)?([?#].*)?$)/i.test(s) && !/^javascript:/i.test(s) ? s : "#"; };

  // ------------------------------------------------------------------ نصوص الواجهة
  const T = {
    ar: {
      dir: "rtl", other: "en", other_label: "English", other_href: "en.html", home: "index.html",
      nav: [["#features", "المميزات"], ["#how", "كيف يعمل"], ["#roles", "لمن مسار"], ["#pricing", "الأسعار"], ["#faq", "الأسئلة"], ["guide.html", "الدليل"]],
      login: "تسجيل الدخول", dashboard: "لوحة التحكم", start: "ابدأ مجاناً", menu: "القائمة",
      problem_k: "المشكلة والحل", before: "قبل مسار", after: "مع مسار",
      features_k: "المميزات", features_t: "منصة واحدة لكل رحلة الطلب", features_s: "من لحظة ما يطلب العميل في زد إلى لحظة التسليم — كل خطوة واضحة ومؤتمتة.",
      how_k: "كيف يعمل", how_t: "تبدأ خلال دقائق، مو أسابيع",
      roles_k: "لمن مسار", roles_t: "كل شخص في فريقك له شاشته",
      demo_k: "شاهد بنفسك", demo_t: "كل طلب يروح لأقرب فرع تلقائياً", demo_s: "محاكاة حية: طلبات تنزل على الخريطة، ومسار يحسب المسافة لكل فرع ويوجّهها للأقرب ضمن النطاق.",
      demo_log: "سجل التوجيه", demo_to: "→", km: "كم", out: "خارج النطاق — يحتاج قرارك",
      stats_k: "بالأرقام",
      integ_k: "التكاملات", integ_t: "يشتغل مع الأدوات اللي تستخدمها",
      pricing_k: "الأسعار", pricing_t: "باقات تناسب حجم تجارتك", monthly: "شهري", yearly: "سنوي", save: "وفّر", per: "شهرياً", custom: "حسب الطلب", popular: "الأكثر طلباً", billed_y: "تُدفع سنوياً",
      security_k: "الأمان والخصوصية", security_t: "بيانات متجرك في أمان",
      faq_k: "الأسئلة الشائعة", faq_t: "عندك سؤال؟ عندنا جواب",
      contact_k: "تواصل معنا",
      f_name: "الاسم", f_phone: "رقم الجوال", f_email: "الإيميل", f_store: "رابط المتجر", f_branches: "عدد الفروع", f_msg: "رسالتك (اختياري)", f_send: "أرسل الطلب", f_ok: "وصلنا طلبك ✅ بنتواصل معك قريباً", f_err: "تعذر الإرسال، حاول مرة ثانية",
      or_reach: "أو تواصل مباشرة",
      f_links: "روابط", f_legal: "قانوني", f_contact: "تواصل", terms: "شروط الاستخدام", privacy: "سياسة الخصوصية", guide: "دليل الاستخدام", support: "الدعم",
      rights: "جميع الحقوق محفوظة", made: "صُنع في السعودية 🇸🇦", updated: "آخر تحديث", toc: "المحتويات", back_home: "الرئيسية",
    },
    en: {
      dir: "ltr", other: "ar", other_label: "العربية", other_href: "index.html", home: "en.html",
      nav: [["#features", "Features"], ["#how", "How it works"], ["#roles", "Who it's for"], ["#pricing", "Pricing"], ["#faq", "FAQ"], ["guide.html?lang=en", "Guide"]],
      login: "Log in", dashboard: "Dashboard", start: "Start free", menu: "Menu",
      problem_k: "Problem & solution", before: "Before Msar", after: "With Msar",
      features_k: "Features", features_t: "One platform for the whole order journey", features_s: "From the moment a customer checks out on Zid to the moment of delivery — every step clear and automated.",
      how_k: "How it works", how_t: "Live in minutes, not weeks",
      roles_k: "Who it's for", roles_t: "Everyone on your team gets their own screen",
      demo_k: "See it in action", demo_t: "Every order goes to the nearest branch automatically", demo_s: "A live simulation: orders drop on the map, Msar measures the distance to each branch and routes them to the closest one in range.",
      demo_log: "Routing log", demo_to: "→", km: "km", out: "Out of range — needs your call",
      stats_k: "By the numbers",
      integ_k: "Integrations", integ_t: "Works with the tools you already use",
      pricing_k: "Pricing", pricing_t: "Plans that fit the size of your business", monthly: "Monthly", yearly: "Yearly", save: "Save", per: "/ month", custom: "Custom", popular: "Most popular", billed_y: "billed yearly",
      security_k: "Security & privacy", security_t: "Your store data stays safe",
      faq_k: "FAQ", faq_t: "Questions? We've got answers",
      contact_k: "Contact us",
      f_name: "Name", f_phone: "Mobile", f_email: "Email", f_store: "Store URL", f_branches: "Number of branches", f_msg: "Message (optional)", f_send: "Send request", f_ok: "Got it ✅ We'll be in touch soon", f_err: "Couldn't send, please try again",
      or_reach: "Or reach us directly",
      f_links: "Links", f_legal: "Legal", f_contact: "Contact", terms: "Terms of Use", privacy: "Privacy Policy", guide: "User Guide", support: "Support",
      rights: "All rights reserved", made: "Made in Saudi Arabia 🇸🇦", updated: "Last updated", toc: "Contents", back_home: "Home",
    },
  };

  // ------------------------------------------------------------------ أيقونات
  const P = {
    route: '<circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="5" r="2.5"/><path d="M8.5 19H15a3.5 3.5 0 0 0 0-7H9a3.5 3.5 0 0 1 0-7h6.5"/>',
    store: '<path d="M3 9l1.6-5h14.8L21 9"/><path d="M4 9v11h16V9"/><path d="M3 9c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3s3-1.3 3-3c0 1.7 1.3 3 3 3s3-1.3 3-3"/><path d="M10 20v-5h4v5"/>',
    scooter: '<circle cx="6" cy="17" r="2.6"/><circle cx="18" cy="17" r="2.6"/><path d="M8.6 17h5.8l-2-7h-2.4"/><path d="M14.5 6h2.2l2.6 8.4"/><rect x="2.5" y="7" width="6" height="5" rx="1"/>',
    map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2-6-2z"/><path d="M9 4v14M15 6v14"/>',
    sync: '<path d="M20 11a8 8 0 0 0-14.9-3M4 13a8 8 0 0 0 14.9 3"/><path d="M5 3v5h5M19 21v-5h-5"/>',
    radius: '<circle cx="12" cy="12" r="9" stroke-dasharray="2.5 2.5"/><circle cx="12" cy="12" r="2.4"/><path d="M13.8 10.6L19 7"/>',
    cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 10v4M18 10v4"/>',
    chart: '<path d="M3 21h18"/><rect x="5" y="11" width="3" height="7" rx="1"/><rect x="10.5" y="6" width="3" height="12" rx="1"/><rect x="16" y="13" width="3" height="5" rx="1"/>',
    users: '<circle cx="9" cy="8" r="3.4"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><circle cx="17" cy="7.5" r="2.5"/><path d="M16.5 13.2A5 5 0 0 1 21.5 18"/>',
    bell: '<path d="M6 16v-5a6 6 0 1 1 12 0v5l1.8 2H4.2z"/><path d="M10 21h4"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    phone: '<rect x="7" y="2.5" width="10" height="19" rx="2.5"/><path d="M11 18h2"/>',
    shield: '<path d="M12 3l8 3v6c0 4.8-3.4 8-8 9-4.6-1-8-4.2-8-9V6z"/><path d="M8.8 12.2l2.2 2.2 4.2-4.4"/>',
    lock: '<rect x="4" y="10" width="16" height="11" rx="2.5"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/><circle cx="12" cy="15.5" r="1.4"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M17 6l2.5 2.5M15 8l2 2"/>',
    eye: '<path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    x: '<path d="M6 6l12 12M18 6L6 18"/>',
    pin: '<path d="M12 21s7-6.2 7-11.5A7 7 0 0 0 5 9.5C5 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
    zap: '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3.5 6l8.5 7 8.5-7"/>',
    chat: '<path d="M4 20l1.4-4.2A8 8 0 1 1 8.6 19z"/><path d="M9 10.5c.5 2 2 3.6 4 4.2l1.2-1.2 2 .8"/>',
    globe: '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 2.8 3.8 5.8 3.8 9s-1.2 6.2-3.8 9c-2.6-2.8-3.8-5.8-3.8-9S9.4 5.8 12 3z"/>',
    menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    plug: '<path d="M9 2v5M15 2v5M6 7h12v4a6 6 0 0 1-12 0z"/><path d="M12 17v5"/>',
    book: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v17H6.5A2.5 2.5 0 0 0 4 21.5z"/><path d="M4 19.5V4.5"/>',
    play: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5l5.5 3.5-5.5 3.5z"/>',
    x_social: '<path d="M4 4l16 16M20 4L4 20"/>',
    insta: '<rect x="3" y="3" width="18" height="18" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.3" cy="6.7" r="1"/>',
    linkedin: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M8 10v7M8 7v.01M12 17v-4a2 2 0 0 1 4 0v4M12 10v7"/>',
    tiktok: '<path d="M14 3v11.5a3.5 3.5 0 1 1-3.5-3.5"/><path d="M14 3c.5 2.6 2.4 4.4 5 4.6"/>',
    snap: '<path d="M12 3c3 0 5 2.2 5 5.2v2.3l2 .8-1.6 1.2c.8 1.6 2 2.6 3.6 3-1 .9-2.4.8-3.4 1.4-.5 1.1-1.6 1.4-3 1.1-1.2.8-2 1-2.6 1s-1.4-.2-2.6-1c-1.4.3-2.5 0-3-1.1-1-.6-2.4-.5-3.4-1.4 1.6-.4 2.8-1.4 3.6-3L5 11.3l2-.8V8.2C7 5.2 9 3 12 3z"/>',
    youtube: '<rect x="2.5" y="5.5" width="19" height="13" rx="4"/><path d="M10 9v6l5-3z"/>',
  };
  const ic = (n, cls) => `<svg class="ic${cls ? " " + cls : ""}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n] || P.zap}</svg>`;

  // ------------------------------------------------------------------ ماركداون مبسّط وآمن
  function inline(s) {
    return esc(s)
      .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
      .replace(/\[([^\]]+)\]\(([^)\s]+)\)/g, (m, t, u) => `<a href="${esc(safeUrl(u.replace(/&amp;/g, "&")))}"${/^https?:/.test(u) ? ' target="_blank" rel="noopener"' : ""}>${t}</a>`)
      .replace(/`([^`]+)`/g, "<code>$1</code>");
  }
  const slug = (s, i) => "s" + i + "-" + String(s).toLowerCase().replace(/[^\p{L}\p{N}]+/gu, "-").replace(/^-|-$/g, "").slice(0, 40);
  function md(src) {
    const lines = String(src || "").replace(/\r/g, "").split("\n");
    let out = "", list = null, para = [], hi = 0;
    const toc = [];
    const flushP = () => { if (para.length) { out += `<p>${inline(para.join(" "))}</p>`; para = []; } };
    const flushL = () => { if (list) { out += `</${list}>`; list = null; } };
    for (const raw of lines) {
      const l = raw.trimEnd();
      let m;
      if (!l.trim()) { flushP(); flushL(); continue; }
      if ((m = l.match(/^(#{1,3})\s+(.*)$/))) {
        flushP(); flushL();
        const lvl = Math.max(2, m[1].length), id = slug(m[2], hi++);
        if (lvl <= 3) toc.push({ id, t: m[2], lvl });
        out += `<h${lvl} id="${id}">${inline(m[2])}</h${lvl}>`; continue;
      }
      if (/^---+$/.test(l)) { flushP(); flushL(); out += "<hr>"; continue; }
      if ((m = l.match(/^>\s?(.*)$/))) { flushP(); flushL(); out += `<div class="note">${inline(m[1])}</div>`; continue; }
      if ((m = l.match(/^\s*[-*]\s+(.*)$/))) { flushP(); if (list !== "ul") { flushL(); out += "<ul>"; list = "ul"; } out += `<li>${inline(m[1])}</li>`; continue; }
      if ((m = l.match(/^\s*\d+[.)]\s+(.*)$/))) { flushP(); if (list !== "ol") { flushL(); out += "<ol>"; list = "ol"; } out += `<li>${inline(m[1])}</li>`; continue; }
      flushL(); para.push(l.trim());
    }
    flushP(); flushL();
    return { html: out, toc };
  }

  // ------------------------------------------------------------------ أجزاء مشتركة
  const L = (o, k, lang) => (o ? o[`${k}_${lang}`] ?? o[`${k}_ar`] ?? "" : "");
  const brandName = (c, lang) => L(c.brand, "name", lang);

  function header(c, lang, onLanding) {
    const t = T[lang], pre = onLanding ? "" : (lang === "en" ? "en.html" : "index.html");
    const otherHref = onLanding ? t.other_href : (lang === "en" ? location_swap("ar") : location_swap("en"));
    const navs = t.nav.map(([h, l]) => `<a href="${h.startsWith("#") ? pre + h : h}">${esc(l)}</a>`).join("");
    const ann = c.announce?.on && c.sections?.announce !== false && (c.announce[lang] || c.announce.ar)
      ? `<div class="ann"><a href="${esc(safeUrl(c.announce.link || "#"))}">${esc(c.announce[lang] || c.announce.ar)} <span class="ann-go">${ic("arrow")}</span></a></div>` : "";
    return `${ann}<header class="hdr" id="hdr"><div class="wrap hdr-in">
      <a class="logo" href="${t.home}" aria-label="${esc(brandName(c, lang))}"><img src="${esc(c.brand.logo)}" alt="" width="40" height="40"><span>${esc(brandName(c, lang))}</span></a>
      <nav class="nav" id="nav" aria-label="main">${navs}</nav>
      <div class="hdr-act">
        <a class="lang" href="${esc(otherHref)}" hreflang="${t.other}" data-lang-switch>${ic("globe")}<span>${t.other_label}</span></a>
        <a class="btn-s btn-ghost" href="${esc(safeUrl(c.links.login))}" data-login>${esc(t.login)}</a>
        <a class="btn-s btn-pri" href="${esc(safeUrl(c.links.zid_app || c.links.start))}">${esc(t.start)}</a>
        <button class="burger" id="burger" aria-label="${t.menu}" aria-expanded="false">${ic("menu")}</button>
      </div></div></header>`;
  }
  // لصفحات الوثائق: نفس الصفحة باللغة الثانية
  function location_swap(to) { return `?lang=${to}`; }

  function footer(c, lang) {
    const t = T[lang], k = c.links, q = lang === "en" ? "?lang=en" : "";
    const soc = [["twitter", "x_social", "X"], ["instagram", "insta", "Instagram"], ["linkedin", "linkedin", "LinkedIn"], ["tiktok", "tiktok", "TikTok"], ["snapchat", "snap", "Snapchat"], ["youtube", "youtube", "YouTube"]]
      .filter(([f]) => k[f]).map(([f, i, n]) => `<a href="${esc(safeUrl(k[f]))}" target="_blank" rel="noopener" aria-label="${n}">${ic(i)}</a>`).join("");
    const wa = k.whatsapp ? `https://wa.me/${String(k.whatsapp).replace(/\D/g, "")}` : "";
    return `<footer class="ftr"><div class="wrap ftr-grid">
      <div class="ftr-brand"><a class="logo logo-inv" href="${t.home}"><img src="${esc(c.brand.logo)}" alt="" width="40" height="40"><span>${esc(brandName(c, lang))}</span></a>
        <p>${esc(L(c.seo, "desc", lang))}</p>${soc ? `<div class="soc">${soc}</div>` : ""}</div>
      <div><h4>${t.f_links}</h4>${t.nav.slice(0, 5).map(([h, l]) => `<a href="${h.startsWith("#") ? t.home + h : h}">${esc(l)}</a>`).join("")}</div>
      <div><h4>${t.f_legal}</h4><a href="terms.html${q}">${t.terms}</a><a href="privacy.html${q}">${t.privacy}</a><a href="guide.html${q}">${t.guide}</a><a href="support.html">${t.support}</a></div>
      <div><h4>${t.f_contact}</h4>${k.email ? `<a href="mailto:${esc(k.email)}">${ic("mail")} <span dir="ltr">${esc(k.email)}</span></a>` : ""}
        ${wa ? `<a href="${wa}" target="_blank" rel="noopener">${ic("chat")} <span dir="ltr">${esc(k.whatsapp)}</span></a>` : ""}
        ${k.phone ? `<a href="tel:${esc(k.phone)}">${ic("phone")} <span dir="ltr">${esc(k.phone)}</span></a>` : ""}</div>
    </div><div class="wrap ftr-bot"><span>© <span data-year>2026</span> ${esc(brandName(c, lang))} — ${t.rights}</span><span>${t.made}</span></div></footer>`;
  }

  const sec = (c, key, html) => (c.sections?.[key] === false ? "" : html);
  const head = (k, title, sub) => `<div class="sh reveal"><span class="kicker">${esc(k)}</span><h2>${esc(title)}</h2>${sub ? `<p>${esc(sub)}</p>` : ""}</div>`;

  // ------------------------------------------------------------------ الصفحة الرئيسية
  function landing(c, lang) {
    const t = T[lang], h = c.hero;
    const title = L(h, "title", lang);
    const tl = L(c.brand, "tagline", lang);
    // نلوّن آخر كلمة في العنوان
    const tw = title.split(" ");
    const titleHtml = tw.length > 1 ? `${esc(tw.slice(0, -1).join(" "))} <span class="grad">${esc(tw[tw.length - 1])}</span>` : `<span class="grad">${esc(title)}</span>`;
    const startHref = esc(safeUrl(c.links.zid_app || c.links.start));

    const hero = sec(c, "hero", `<section class="hero" id="top">
      <div class="hero-bg" aria-hidden="true">${roadBg()}</div>
      <div class="wrap hero-in">
        <div class="hero-txt">
          <span class="pill reveal">${ic("zap")} ${esc(L(h, "badge", lang))}</span>
          <h1 class="reveal">${titleHtml}</h1>
          <p class="lead reveal">${esc(L(h, "sub", lang))}</p>
          <div class="hero-cta reveal">
            <a class="btn btn-pri btn-lg" href="${startHref}">${esc(L(h, "cta1", lang))} ${ic("arrow", "flip")}</a>
            <a class="btn btn-out btn-lg" href="#demo">${ic("play")} ${esc(L(h, "cta2", lang))}</a>
          </div>
          <ul class="hero-ticks reveal">${(c.trust?.[lang] || []).slice(0, 3).map((x) => `<li>${ic("check")} ${esc(x)}</li>`).join("")}</ul>
        </div>
        <div class="hero-vis reveal">
          <div class="hero-frame">${h.image ? `<img class="hero-img" src="${esc(h.image)}" alt="${esc(tl)}" width="1200" height="900" fetchpriority="high" onerror="this.remove()">` : ""}${heroScene()}</div>
          <div class="float f1" data-cycle>
            <div class="f-ic f-blue">${ic("bell")}</div><div><b data-c-title>${lang === "en" ? "New order #10428" : "طلب جديد #10428"}</b><small data-c-sub>${lang === "en" ? "Routed to Al-Shati branch · 2.3 km" : "تم توجيهه لفرع الشاطئ · 2.3 كم"}</small></div></div>
          <div class="float f2"><div class="f-ic f-green">${ic("scooter")}</div><div><b>${lang === "en" ? "Out for delivery" : "جاري التوصيل"}</b><small>${lang === "en" ? "ETA 12 min" : "يوصل خلال 12 دقيقة"}</small></div><span class="live"></span></div>
          <div class="float f3"><div class="f-ic f-orange">${ic("sync")}</div><div><b>${lang === "en" ? "Synced with Zid" : "تحدّثت الحالة في زد"}</b><small>${lang === "en" ? "Delivered ✓" : "تم التوصيل ✓"}</small></div></div>
        </div>
      </div></section>`);

    const trust = sec(c, "trust", `<section class="trust"><div class="marq" aria-hidden="false"><div class="marq-in">${[0, 1].map(() => (c.trust?.[lang] || []).map((x) => `<span>${ic("check")} ${esc(x)}</span>`).join("")).join("")}</div></div></section>`);

    const problem = sec(c, "problem", `<section class="sect" id="problem"><div class="wrap">
      ${head(t.problem_k, L(c.problem, "title", lang))}
      <div class="ba">${(c.problem?.items || []).map((it, i) => `<div class="ba-row reveal" style="--d:${i * 90}ms">
        <div class="ba-bad"><span class="ba-tag">${ic("x")} ${t.before}</span><p>${esc(L(it, "bad", lang))}</p></div>
        <div class="ba-arrow">${ic("arrow", "flip")}</div>
        <div class="ba-good"><span class="ba-tag">${ic("check")} ${t.after}</span><p>${esc(L(it, "good", lang))}</p></div></div>`).join("")}</div>
    </div></section>`);

    const features = sec(c, "features", `<section class="sect sect-alt" id="features"><div class="wrap">
      ${head(t.features_k, t.features_t, t.features_s)}
      <div class="fgrid">${(c.features || []).map((f, i) => `<article class="fcard reveal" style="--d:${(i % 4) * 70}ms">
        <div class="fic c${i % 4}">${ic(f.icon)}</div><h3>${esc(L(f, "t", lang))}</h3><p>${esc(L(f, "d", lang))}</p></article>`).join("")}</div>
    </div></section>`);

    const how = sec(c, "how", `<section class="sect" id="how"><div class="wrap">
      ${head(t.how_k, t.how_t)}
      <ol class="steps">${(c.steps || []).map((s, i) => `<li class="step reveal" style="--d:${i * 120}ms"><span class="step-n">${i + 1}</span><h3>${esc(L(s, "t", lang))}</h3><p>${esc(L(s, "d", lang))}</p></li>`).join("")}</ol>
    </div></section>`);

    const roles = sec(c, "roles", `<section class="sect sect-alt" id="roles"><div class="wrap">
      ${head(t.roles_k, t.roles_t)}
      <div class="tabs reveal" role="tablist">${(c.roles || []).map((r, i) => `<button role="tab" class="tab${i ? "" : " on"}" data-tab="${i}" aria-selected="${!i}">${ic(r.icon)} ${esc(L(r, "t", lang))}</button>`).join("")}</div>
      ${(c.roles || []).map((r, i) => `<div class="tabp${i ? "" : " on"}" data-panel="${i}" role="tabpanel">
        <div class="tabp-img">${r.img ? `<img src="${esc(r.img)}" alt="${esc(L(r, "t", lang))}" loading="lazy" width="1200" height="900" onerror="this.parentNode.classList.add('noimg');this.remove()">` : ""}<div class="tabp-ph">${ic(r.icon)}</div></div>
        <div class="tabp-txt"><h3>${esc(L(r, "t", lang))}</h3><ul class="checks">${(r[lang] || r.ar || []).map((x) => `<li>${ic("check")} ${esc(x)}</li>`).join("")}</ul>
          <a class="btn btn-pri" href="${startHref}">${esc(t.start)} ${ic("arrow", "flip")}</a></div></div>`).join("")}
    </div></section>`);

    const demo = sec(c, "demo", `<section class="sect demo-s" id="demo"><div class="wrap">
      ${head(t.demo_k, t.demo_t, t.demo_s)}
      <div class="demo reveal"><div class="demo-map"><svg id="demo-svg" viewBox="0 0 640 400" role="img" aria-label="${esc(t.demo_t)}">${demoBase(lang)}</svg></div>
        <aside class="demo-log"><h4>${ic("route")} ${t.demo_log}</h4><ul id="demo-log"></ul></aside></div>
    </div></section>`);

    const stats = sec(c, "stats", `<section class="stats-s"><div class="wrap stats">${(c.stats || []).map((s, i) => `<div class="stat reveal" style="--d:${i * 90}ms">
      <div class="stat-v"><span data-count="${esc(s.v)}">${esc(s.v)}</span><small>${esc(L(s, "s", lang))}</small></div><p>${esc(L(s, "l", lang))}</p></div>`).join("")}</div></section>`);

    const integ = sec(c, "integrations", `<section class="sect" id="integrations"><div class="wrap">
      ${head(t.integ_k, t.integ_t)}
      <div class="${c.integrations?.img ? "int-grid" : ""}">${c.integrations?.img ? `<div class="int-img reveal"><img src="${esc(c.integrations.img)}" alt="${esc(t.integ_t)}" loading="lazy" width="1200" height="900" onerror="this.parentNode.remove()"></div>` : ""}
      <div class="integ">${(c.integrations?.[lang] || []).map((x, i) => `<div class="int reveal" style="--d:${i * 70}ms"><div class="int-ic">${ic(["plug", "map", "chat", "chart", "layers"][i % 5])}</div><b>${esc(x.n)}</b><span>${esc(x.s)}</span></div>`).join("")}</div></div>
    </div></section>`);

    const pr = c.pricing || {};
    const cur = L(pr, "currency", lang);
    const pricing = sec(c, "pricing", `<section class="sect sect-alt" id="pricing"><div class="wrap">
      ${head(t.pricing_k, t.pricing_t)}
      <div class="bill reveal" role="group"><button class="on" data-bill="m">${t.monthly}</button><button data-bill="y">${t.yearly}${pr.yearly_discount ? ` <em>${t.save} ${esc(pr.yearly_discount)}%</em>` : ""}</button></div>
      <div class="plans">${(pr.plans || []).map((p, i) => {
        const m = p.price === null || p.price === "" || p.price === undefined ? null : Number(p.price);
        const y = m === null ? null : Math.round(m * (1 - (Number(pr.yearly_discount) || 0) / 100));
        return `<div class="plan reveal${p.featured ? " feat" : ""}" style="--d:${i * 90}ms">${p.featured ? `<span class="plan-badge">${t.popular}</span>` : ""}
          <h3>${esc(L(p, "name", lang))}</h3><p class="plan-d">${esc(L(p, "desc", lang))}</p>
          <div class="price">${m === null ? `<b class="custom">${t.custom}</b>` : `<b data-m="${m}" data-y="${y}">${m}</b><span>${esc(cur)} ${t.per}</span>`}</div>
          <div class="plan-y">${m === null ? "&nbsp;" : t.billed_y}</div>
          <a class="btn ${p.featured ? "btn-pri" : "btn-out"} btn-block" href="${m === null ? "#contact" : startHref}">${esc(L(p, "cta", lang))}</a>
          <ul class="checks">${(p[`f_${lang}`] || p.f_ar || []).map((x) => `<li>${ic("check")} ${esc(x)}</li>`).join("")}</ul></div>`; }).join("")}</div>
      <p class="pnote reveal">${esc(L(pr, "note", lang))}</p>
    </div></section>`);

    const security = sec(c, "security", `<section class="sect sec-dark" id="security"><div class="wrap sec-grid">
      <div class="sec-vis reveal" aria-hidden="true">${c.security?.img ? `<img src="${esc(c.security.img)}" alt="" loading="lazy" width="1000" height="1000" onerror="this.remove()">` : ""}<div class="shield">${ic("shield")}</div><span class="orb o1">${ic("lock")}</span><span class="orb o2">${ic("key")}</span><span class="orb o3">${ic("eye")}</span></div>
      <div>${head(t.security_k, t.security_t)}<div class="sec-list">${(c.security?.[lang] || []).map((s, i) => `<div class="sec-it reveal" style="--d:${i * 80}ms"><span>${ic(["layers", "lock", "users", "key"][i % 4])}</span><div><h3>${esc(s.t)}</h3><p>${esc(s.d)}</p></div></div>`).join("")}</div></div>
    </div></section>`);

    const faq = sec(c, "faq", `<section class="sect" id="faq"><div class="wrap narrow">
      ${head(t.faq_k, t.faq_t)}
      <div class="faq">${(c.faq || []).map((f) => `<details class="reveal"><summary>${esc(L(f, "q", lang))}<span class="pm"></span></summary><div class="ans">${esc(L(f, "a", lang))}</div></details>`).join("")}</div>
    </div></section>`);

    const k = c.links;
    const wa = k.whatsapp ? `https://wa.me/${String(k.whatsapp).replace(/\D/g, "")}` : "";
    const contact = sec(c, "contact", `<section class="sect sect-alt" id="contact"><div class="wrap ct-grid">
      <div class="reveal">${head(t.contact_k, L(c.contact, "title", lang), L(c.contact, "sub", lang))}
        <div class="ct-direct"><h4>${t.or_reach}</h4>${k.email ? `<a href="mailto:${esc(k.email)}">${ic("mail")} <span dir="ltr">${esc(k.email)}</span></a>` : ""}${wa ? `<a href="${wa}" target="_blank" rel="noopener">${ic("chat")} <span dir="ltr">${esc(k.whatsapp)}</span></a>` : ""}${k.phone ? `<a href="tel:${esc(k.phone)}">${ic("phone")} <span dir="ltr">${esc(k.phone)}</span></a>` : ""}</div></div>
      <form class="ct-form reveal" id="lead" novalidate>
        <div class="g2"><label><span>${t.f_name}</span><input name="name" required minlength="2" maxlength="120" autocomplete="name"></label>
        <label><span>${t.f_phone}</span><input name="phone" dir="ltr" inputmode="tel" maxlength="30" autocomplete="tel"></label></div>
        <div class="g2"><label><span>${t.f_email}</span><input name="email" type="email" dir="ltr" maxlength="160" autocomplete="email"></label>
        <label><span>${t.f_branches}</span><input name="branches" type="number" min="1" max="999"></label></div>
        <label><span>${t.f_store}</span><input name="store_url" dir="ltr" maxlength="300" placeholder="https://"></label>
        <label><span>${t.f_msg}</span><textarea name="message" rows="3" maxlength="2000"></textarea></label>
        <input name="website" class="hp" tabindex="-1" autocomplete="off" aria-hidden="true">
        <button class="btn btn-pri btn-lg btn-block" type="submit">${t.f_send} ${ic("arrow", "flip")}</button>
        <p class="ct-msg" id="lead-msg" role="status" data-ok="${esc(t.f_ok)}" data-err="${esc(t.f_err)}"></p>
      </form></div></section>`);

    const cta = sec(c, "cta", `<section class="cta"><div class="wrap cta-in reveal${c.cta?.img ? " has-img" : ""}"${c.cta?.img ? ` style="background-image:linear-gradient(120deg,rgba(20,79,116,.94),rgba(21,159,198,.78) 70%,rgba(115,174,70,.72)),url(&quot;${esc(c.cta.img)}&quot;)"` : ""}>
      <div class="cta-bg" aria-hidden="true">${roadBg(true)}</div>
      <h2>${esc(L(c.cta, "title", lang))}</h2><p>${esc(L(c.cta, "sub", lang))}</p>
      <div class="hero-cta"><a class="btn btn-wht btn-lg" href="${startHref}">${esc(t.start)} ${ic("arrow", "flip")}</a><a class="btn btn-gl btn-lg" href="#contact">${esc(t.contact_k)}</a></div>
    </div></section>`);

    return `${header(c, lang, true)}<main id="main">${hero}${trust}${problem}${features}${how}${roles}${demo}${stats}${integ}${pricing}${security}${faq}${contact}${cta}</main>${footer(c, lang)}`;
  }

  // ------------------------------------------------------------------ رسومات SVG متحركة
  function roadBg(light) {
    return `<svg viewBox="0 0 1440 640" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="rg${light ? "l" : ""}" x1="0" x2="1"><stop offset="0" stop-color="${light ? "#fff" : "var(--blue)"}" stop-opacity=".0"/><stop offset=".5" stop-color="${light ? "#fff" : "var(--blue)"}" stop-opacity="${light ? ".16" : ".13"}"/><stop offset="1" stop-color="${light ? "#fff" : "var(--green)"}" stop-opacity=".0"/></linearGradient></defs>
      <path class="road" d="M-40 520 C 260 380, 420 600, 720 430 S 1180 160, 1500 260" stroke="url(#rg${light ? "l" : ""})" stroke-width="90" fill="none" stroke-linecap="round"/>
      <path class="dash" d="M-40 520 C 260 380, 420 600, 720 430 S 1180 160, 1500 260" stroke="${light ? "#ffffff55" : "var(--blue)"}" stroke-opacity="${light ? "1" : ".35"}" stroke-width="3" fill="none" stroke-dasharray="18 22"/>
      <path class="road" d="M-60 140 C 300 40, 520 260, 860 150 S 1300 40, 1520 120" stroke="url(#rg${light ? "l" : ""})" stroke-width="56" fill="none" stroke-linecap="round" opacity=".7"/>
      <path class="dash d2" d="M-60 140 C 300 40, 520 260, 860 150 S 1300 40, 1520 120" stroke="${light ? "#ffffff44" : "var(--green)"}" stroke-opacity="${light ? "1" : ".3"}" stroke-width="2.5" fill="none" stroke-dasharray="12 18"/>
      <circle r="7" fill="var(--orange)"><animateMotion dur="14s" repeatCount="indefinite" path="M-40 520 C 260 380, 420 600, 720 430 S 1180 160, 1500 260"/></circle>
      <circle r="5" fill="${light ? "#fff" : "var(--green)"}"><animateMotion dur="18s" begin="-6s" repeatCount="indefinite" path="M-60 140 C 300 40, 520 260, 860 150 S 1300 40, 1520 120"/></circle></svg>`;
  }
  function heroScene() {
    // يظهر خلف الصورة وكبديل لو الصورة ما تحملت
    return `<svg class="hero-svg" viewBox="0 0 480 360" aria-hidden="true">
      <defs><linearGradient id="hs" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="var(--blue)"/><stop offset="1" stop-color="var(--navy)"/></linearGradient></defs>
      <rect width="480" height="360" rx="28" fill="#eaf5fa"/>
      <g opacity=".5" stroke="#cfe4ee" stroke-width="2">${[60, 120, 180, 240, 300].map((y) => `<path d="M0 ${y}H480"/>`).join("")}${[80, 160, 240, 320, 400].map((x) => `<path d="M${x} 0V360"/>`).join("")}</g>
      <path id="hp" d="M40 320 C 140 250, 120 170, 230 170 S 340 90, 440 50" stroke="url(#hs)" stroke-width="26" fill="none" stroke-linecap="round"/>
      <path d="M40 320 C 140 250, 120 170, 230 170 S 340 90, 440 50" stroke="#fff" stroke-width="3" fill="none" stroke-dasharray="10 12" class="dash"/>
      ${[[90, 255, "var(--green)"], [235, 150, "var(--orange)"], [405, 55, "var(--blue)"]].map(([x, y, col], i) => `<g class="pinpop" style="animation-delay:${i * 0.5}s"><circle cx="${x}" cy="${y - 34}" r="14" fill="${col}"/><circle cx="${x}" cy="${y - 34}" r="5" fill="#fff"/><path d="M${x - 9} ${y - 26} L${x} ${y - 10} L${x + 9} ${y - 26}" fill="${col}"/></g>`).join("")}
      <g><rect x="-13" y="-10" width="26" height="20" rx="6" fill="var(--orange)"/><circle cx="-8" cy="12" r="5" fill="var(--navy)"/><circle cx="9" cy="12" r="5" fill="var(--navy)"/>
        <animateMotion dur="7s" repeatCount="indefinite" rotate="auto" path="M40 320 C 140 250, 120 170, 230 170 S 340 90, 440 50"/></g></svg>`;
  }
  function demoBase(lang) {
    const roads = `<g class="dm-roads" stroke="#d7e9f1" stroke-width="10" stroke-linecap="round" fill="none">
      <path d="M0 120 C 160 90, 300 160, 640 110"/><path d="M0 300 C 200 260, 380 340, 640 280"/><path d="M150 0 C 130 140, 210 260, 170 400"/><path d="M460 0 C 430 120, 520 260, 470 400"/><path d="M0 210 H640" stroke-width="6"/></g>`;
    return `<rect width="640" height="400" rx="22" fill="#f2f8fb"/>${roads}<g id="dm-zones"></g><g id="dm-lines"></g><g id="dm-orders"></g><g id="dm-br"></g>`;
  }

  // ------------------------------------------------------------------ صفحات الوثائق
  function docPage(c, doc, lang) {
    const t = T[lang];
    const body = md(doc[lang] || doc.ar || "");
    const title = doc[`title_${lang}`] || doc.title_ar || "";
    const toc = body.toc.filter((x) => x.lvl === 2);
    return `${header(c, lang, false)}<main id="main" class="docs"><div class="wrap doc-wrap">
      ${toc.length > 2 ? `<aside class="doc-toc"><h4>${t.toc}</h4>${toc.map((x) => `<a href="#${x.id}">${inline(x.t)}</a>`).join("")}</aside>` : ""}
      <article class="doc"><nav class="crumbs"><a href="${t.home}">${t.back_home}</a> / <span>${esc(title)}</span></nav>
        <h1>${esc(title)}</h1>${doc.updated ? `<p class="doc-upd">${t.updated}: ${esc(doc.updated)}</p>` : ""}${body.html}</article>
    </div></main>${footer(c, lang)}`;
  }

  // ------------------------------------------------------------------ بيانات منظّمة (SEO / GEO / AEO)
  function jsonLd(c, lang, base) {
    const name = brandName(c, lang);
    const org = { "@type": "Organization", "@id": base + "#org", name: c.brand.name_en + " — " + c.brand.name_ar, alternateName: [c.brand.name_ar, c.brand.name_en, "msarpro"], url: base, logo: base + "icons/icon-512.png",
      email: c.links.email || undefined, areaServed: "SA", sameAs: ["twitter", "instagram", "linkedin", "tiktok", "snapchat", "youtube"].map((k) => c.links[k]).filter(Boolean) };
    const app = { "@type": "SoftwareApplication", name, applicationCategory: "BusinessApplication", applicationSubCategory: "Order routing & delivery management", operatingSystem: "Web, Android",
      inLanguage: ["ar", "en"], description: L(c.seo, "desc", lang), url: base + (lang === "en" ? "en.html" : ""), publisher: { "@id": base + "#org" },
      featureList: (c.features || []).map((f) => L(f, "t", lang)),
      offers: (c.pricing?.plans || []).filter((p) => p.price !== null && p.price !== "" && p.price !== undefined).map((p) => ({ "@type": "Offer", name: L(p, "name", lang), price: String(p.price), priceCurrency: "SAR" })) };
    const faq = { "@type": "FAQPage", mainEntity: (c.faq || []).map((f) => ({ "@type": "Question", name: L(f, "q", lang), acceptedAnswer: { "@type": "Answer", text: L(f, "a", lang) } })) };
    const how = { "@type": "HowTo", name: T[lang].how_t, step: (c.steps || []).map((s, i) => ({ "@type": "HowToStep", position: i + 1, name: L(s, "t", lang), text: L(s, "d", lang) })) };
    const site = { "@type": "WebSite", "@id": base + "#site", url: base, name, inLanguage: lang, publisher: { "@id": base + "#org" } };
    return JSON.stringify({ "@context": "https://schema.org", "@graph": [org, site, app, faq, how] }).replace(/</g, "\\u003c");
  }

  const api = { T, P, ic, esc, merge, md, landing, docPage, jsonLd, header, footer, safeUrl };
  root.MSAR_SITE = api;
  if (typeof module !== "undefined") module.exports = api;
})(typeof window !== "undefined" ? window : globalThis);
