/* مسار — تشغيل الموقع التعريفي: تحميل المحتوى من لوحة صاحب المنصة + الحركات + المحاكاة + نموذج التواصل */
(function () {
  "use strict";
  const S = window.MSAR_SITE, DEF = window.MSAR_DEFAULTS, DOCS = window.MSAR_DOCS || {};
  const C = window.AZM_CONFIG || {};
  const body = document.body, page = body.dataset.page || "landing", docKey = body.dataset.doc || "";
  document.documentElement.classList.add("js");

  // لغة صفحات الوثائق من الرابط (?lang=en)
  let lang = document.documentElement.lang === "en" ? "en" : "ar";
  if (page === "doc") {
    const q = new URLSearchParams(location.search).get("lang");
    if (q === "en" || q === "ar") lang = q;
    document.documentElement.lang = lang; document.documentElement.dir = lang === "en" ? "ltr" : "rtl";
  }

  const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
  let cfg = DEF;
  let timers = [], bound = false, observers = [];
  const clearRuntime = () => { timers.forEach(clearInterval); timers = []; observers.forEach((o) => o.disconnect()); observers = []; };

  // -------------------------------------------------------------- المحتوى من القاعدة
  async function fetchCms() {
    if (!C.SUPABASE_URL) return {};
    const keys = ["site"].concat(page === "doc" ? ["page:" + docKey] : []);
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 4500);
    try {
      const r = await fetch(`${C.SUPABASE_URL}/rest/v1/site_content?select=key,data&key=in.(${keys.map((k) => `"${k}"`).join(",")})`,
        { headers: { apikey: C.SUPABASE_ANON_KEY, Authorization: `Bearer ${C.SUPABASE_ANON_KEY}` }, signal: ctl.signal });
      if (!r.ok) return {};
      const rows = await r.json(); const o = {};
      rows.forEach((x) => (o[x.key] = x.data));
      return o;
    } catch (_) { return {}; } finally { clearTimeout(t); }
  }

  function applyTheme(c) {
    const th = c.theme || {}, st = document.documentElement.style;
    ["blue", "green", "navy", "orange", "cloud", "ink"].forEach((k) => { if (/^#[0-9a-f]{3,8}$/i.test(th[k] || "")) st.setProperty("--" + k, th[k]); });
    if (th.font && /^[\w\s-]{2,40}$/.test(th.font)) st.setProperty("--font", `"${th.font}", "IBM Plex Sans Arabic", system-ui, sans-serif`);
  }
  function applySeo(c) {
    if (page !== "landing") return;
    const t = c.seo?.[`title_${lang}`], d = c.seo?.[`desc_${lang}`];
    if (t) { document.title = t; $('meta[property="og:title"]')?.setAttribute("content", t); }
    if (d) { $('meta[name="description"]')?.setAttribute("content", d); $('meta[property="og:description"]')?.setAttribute("content", d); }
    if (c.seo?.[`keywords_${lang}`]) $('meta[name="keywords"]')?.setAttribute("content", c.seo[`keywords_${lang}`]);
  }

  function render() {
    const root = $("#site");
    if (page === "landing") root.innerHTML = S.landing(cfg, lang);
    else {
      const d = S.merge(DOCS[docKey] || {}, window.__docCms || {});
      root.innerHTML = S.docPage(cfg, d, lang);
      document.title = `${d[`title_${lang}`] || d.title_ar || ""} — ${cfg.brand[`name_${lang}`]}`;
    }
  }

  // -------------------------------------------------------------- التفاعل
  function bind() {
    clearRuntime();
    const onScroll = () => {
      const y = scrollY, prog = $(".progress");
      $("#hdr")?.classList.toggle("scrolled", y > 10);
      $(".to-top")?.classList.toggle("show", y > 900);
      if (prog) { const h = document.documentElement.scrollHeight - innerHeight; prog.style.transform = `scaleX(${h > 0 ? y / h : 0})`; }
    };
    if (!bound) {
      addEventListener("scroll", onScroll, { passive: true });
      document.addEventListener("click", (e) => { const nav = $("#nav"), bg = $("#burger"); if (nav?.classList.contains("open") && !nav.contains(e.target) && !bg?.contains(e.target)) nav.classList.remove("open"); });
      bound = true;
    }
    onScroll();
    const top = $(".to-top"); top && (top.onclick = () => scrollTo({ top: 0, behavior: "smooth" }));

    const nav = $("#nav"), bg = $("#burger");
    if (bg) bg.onclick = () => { const o = nav.classList.toggle("open"); bg.setAttribute("aria-expanded", o); };
    $$("#nav a").forEach((a) => a.addEventListener("click", () => { nav.classList.remove("open"); bg?.setAttribute("aria-expanded", "false"); }));

    // داخل بحسابه؟ نغيّر "تسجيل الدخول" إلى "لوحة التحكم"
    try {
      const k = Object.keys(localStorage).find((x) => /^sb-.*-auth-token$/.test(x));
      if (k && JSON.parse(localStorage.getItem(k) || "null")?.access_token) $$("[data-login]").forEach((a) => { a.textContent = S.T[lang].dashboard; a.href = cfg.links.login || "app.html"; });
    } catch (_) {}

    // ظهور تدريجي
    const io = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }) : null;
    if (io) observers.push(io);
    $$(".reveal").forEach((el) => (io ? io.observe(el) : el.classList.add("in")));

    $$("[data-year]").forEach((x) => (x.textContent = new Date().getFullYear()));

    // واتساب عائم
    if (cfg.links.whatsapp && !$(".wa-float")) {
      const a = document.createElement("a"); a.className = "wa-float"; a.target = "_blank"; a.rel = "noopener"; a.ariaLabel = "WhatsApp";
      a.href = `https://wa.me/${String(cfg.links.whatsapp).replace(/\D/g, "")}`; a.innerHTML = S.ic("chat"); document.body.appendChild(a);
    }

    if (page === "landing") bindLanding(); else bindDoc();
  }

  function bindLanding() {
    // تبويبات الأدوار
    $$("[data-tab]").forEach((b) => b.onclick = () => {
      $$("[data-tab]").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-selected", x === b); });
      $$("[data-panel]").forEach((p) => p.classList.toggle("on", p.dataset.panel === b.dataset.tab));
    });
    // شهري / سنوي
    $$("[data-bill]").forEach((b) => b.onclick = () => {
      $$("[data-bill]").forEach((x) => x.classList.toggle("on", x === b));
      const y = b.dataset.bill === "y";
      $("#pricing")?.classList.toggle("yearly", y);
      $$(".price b[data-m]").forEach((p) => animateNum(p, Number(p.textContent) || 0, Number(y ? p.dataset.y : p.dataset.m), 450));
    });
    // عدّاد الأرقام
    const cio = "IntersectionObserver" in window ? new IntersectionObserver((es) => es.forEach((e) => {
      if (!e.isIntersecting) return; cio.unobserve(e.target);
      const v = e.target.dataset.count; if (/^\d+$/.test(v)) animateNum(e.target, 0, Number(v), 1400);
    }), { threshold: 0.5 }) : null;
    if (cio) observers.push(cio);
    $$("[data-count]").forEach((x) => cio?.observe(x));
    // ميلان صورة الواجهة مع الماوس
    const fr = $(".hero-frame");
    if (fr && matchMedia("(hover:hover)").matches) {
      $(".hero-vis").addEventListener("mousemove", (e) => { const r = fr.getBoundingClientRect(); fr.style.setProperty("--ry", `${((e.clientX - r.left) / r.width - 0.5) * 8}deg`); fr.style.setProperty("--rx", `${-((e.clientY - r.top) / r.height - 0.5) * 6}deg`); });
      $(".hero-vis").addEventListener("mouseleave", () => { fr.style.setProperty("--ry", "0deg"); fr.style.setProperty("--rx", "0deg"); });
    }
    cycleHeroCard();
    demo();
    leadForm();
  }

  function animateNum(el, from, to, ms) {
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) { el.textContent = to; return; }
    const t0 = performance.now();
    const step = (t) => { const k = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - k, 3); el.textContent = Math.round(from + (to - from) * e); if (k < 1) requestAnimationFrame(step); };
    requestAnimationFrame(step);
  }

  // بطاقة "طلب جديد" تتبدّل
  const BR = { ar: ["فرع الشاطئ", "فرع العليا", "فرع الفيصلية", "فرع الروضة", "فرع النخيل"], en: ["Al-Shati branch", "Olaya branch", "Faisaliyah branch", "Rawdah branch", "Nakheel branch"] };
  function cycleHeroCard() {
    const card = $("[data-cycle]"); if (!card) return;
    let n = 10428;
    timers.push(setInterval(() => {
      if (document.hidden) return;
      n += 1 + Math.floor(Math.random() * 3);
      const b = BR[lang][Math.floor(Math.random() * 5)], km = (0.8 + Math.random() * 4).toFixed(1);
      $("[data-c-title]", card).textContent = lang === "en" ? `New order #${n}` : `طلب جديد #${n}`;
      $("[data-c-sub]", card).textContent = lang === "en" ? `Routed to ${b} · ${km} km` : `تم توجيهه ل${b} · ${km} كم`;
      card.classList.remove("swap"); void card.offsetWidth; card.classList.add("swap");
    }, 3200));
  }

  // -------------------------------------------------------------- محاكاة التوجيه على الخريطة
  function demo() {
    const svg = $("#demo-svg"); if (!svg) return;
    const NS = "http://www.w3.org/2000/svg", t = S.T[lang];
    const mk = (tag, a, parent) => { const e = document.createElementNS(NS, tag); for (const k in a) e.setAttribute(k, a[k]); parent && parent.appendChild(e); return e; };
    const pxKm = 26, R = 5; // نطاق 5 كم
    const cols = ["var(--blue)", "var(--green)", "var(--navy)"];
    const brs = [{ x: 150, y: 120, n: BR[lang][1] }, { x: 480, y: 100, n: BR[lang][0] }, { x: 330, y: 300, n: BR[lang][2] }];
    const zones = $("#dm-zones", svg), lines = $("#dm-lines", svg), ords = $("#dm-orders", svg), bg = $("#dm-br", svg), log = $("#demo-log");
    brs.forEach((b, i) => {
      mk("circle", { cx: b.x, cy: b.y, r: R * pxKm, fill: cols[i], "fill-opacity": ".07", stroke: cols[i], "stroke-opacity": ".35", "stroke-dasharray": "5 6", class: "dm-zone" }, zones);
      const g = mk("g", {}, bg);
      mk("rect", { x: b.x - 17, y: b.y - 17, width: 34, height: 34, rx: 10, fill: cols[i] }, g);
      const ic = mk("g", { transform: `translate(${b.x - 10} ${b.y - 10}) scale(.84)`, fill: "none", stroke: "#fff", "stroke-width": "2", "stroke-linecap": "round", "stroke-linejoin": "round" }, g);
      ic.innerHTML = S.P.store;
      const tx = mk("text", { x: b.x, y: b.y + 34, "text-anchor": "middle", "font-size": "13", "font-weight": "700", fill: "#144F74", "font-family": "inherit" }, g);
      tx.textContent = b.n;
    });
    let n = 2041, live = [];
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    function spawn() {
      if (document.hidden) return;
      const x = 30 + Math.random() * 580, y = 25 + Math.random() * 350;
      const ds = brs.map((b) => Math.hypot(b.x - x, b.y - y) / pxKm);
      const bi = ds.indexOf(Math.min(...ds)), km = ds[bi], inR = km <= R;
      const g = mk("g", { class: "dm-order" }, ords);
      const col = inR ? cols[bi] : "var(--orange)";
      if (inR) {
        const b = brs[bi];
        mk("line", { x1: b.x, y1: b.y, x2: x, y2: y, stroke: col, "stroke-width": "2.5", class: "dm-line", "stroke-linecap": "round" }, lines).dataset.o = n;
        if (!reduce) {
          const sc = mk("circle", { r: 6, fill: "var(--orange)", stroke: "#fff", "stroke-width": "2" }, lines); sc.dataset.o = n;
          const am = mk("animateMotion", { dur: "2.6s", begin: "0.6s", fill: "freeze", path: `M${b.x},${b.y} L${x},${y}` }, sc);
          am.beginElement?.();
        }
      } else {
        mk("circle", { cx: x, cy: y, r: 18, fill: "none", stroke: col, "stroke-width": "2", "stroke-dasharray": "4 4" }, g);
      }
      mk("circle", { cx: x, cy: y, r: 9, fill: col, stroke: "#fff", "stroke-width": "3" }, g);
      g.dataset.o = n;
      const li = document.createElement("li");
      li.style.setProperty("--c", col);
      li.innerHTML = inR ? `<b>#${n}</b> ${t.demo_to} ${brs[bi].n}<small>${km.toFixed(1)} ${t.km}</small>` : `<b>#${n}</b><small>${t.out}</small>`;
      log.prepend(li);
      while (log.children.length > 7) log.lastChild.remove();
      live.push(n); n++;
      if (live.length > 6) { const old = live.shift(); $$(`[data-o="${old}"]`, svg).forEach((e) => e.remove()); }
    }
    let timer = null;
    const io = new IntersectionObserver((es) => es.forEach((e) => {
      if (e.isIntersecting && !timer) { spawn(); timer = setInterval(spawn, 1900); timers.push(timer); }
      else if (!e.isIntersecting && timer) { clearInterval(timer); timer = null; }
    }), { threshold: 0.2 });
    io.observe(svg); observers.push(io);
  }

  // -------------------------------------------------------------- نموذج التواصل
  function leadForm() {
    const f = $("#lead"); if (!f) return;
    const msg = $("#lead-msg");
    f.onsubmit = async (e) => {
      e.preventDefault();
      if (f.website.value) return; // فخ للروبوتات
      if (f.name.value.trim().length < 2) { f.name.focus(); return; }
      if (!f.phone.value.trim() && !f.email.value.trim()) { f.phone.focus(); msg.className = "ct-msg err"; msg.textContent = lang === "en" ? "Add a mobile number or email" : "أضف رقم جوال أو إيميل"; return; }
      const b = $("button[type=submit]", f); b.disabled = true;
      const p = { name: f.name.value, phone: f.phone.value, email: f.email.value, store_url: f.store_url.value, branches: f.branches.value, message: f.message.value, lang };
      try {
        const r = await fetch(`${C.SUPABASE_URL}/rest/v1/rpc/site_lead_submit`, { method: "POST",
          headers: { "Content-Type": "application/json", apikey: C.SUPABASE_ANON_KEY, Authorization: `Bearer ${C.SUPABASE_ANON_KEY}` }, body: JSON.stringify({ p }) });
        if (!r.ok) throw new Error(await r.text());
        msg.className = "ct-msg ok"; msg.textContent = msg.dataset.ok; f.reset();
      } catch (_) { msg.className = "ct-msg err"; msg.textContent = msg.dataset.err; }
      b.disabled = false;
    };
  }

  function bindDoc() {
    const links = $$(".doc-toc a"); if (!links.length) return;
    const heads = links.map((a) => document.getElementById(a.getAttribute("href").slice(1))).filter(Boolean);
    addEventListener("scroll", () => {
      let cur = heads[0];
      for (const h of heads) if (h.getBoundingClientRect().top < 140) cur = h;
      links.forEach((a) => a.classList.toggle("on", a.getAttribute("href") === "#" + cur?.id));
    }, { passive: true });
  }

  // -------------------------------------------------------------- التشغيل
  async function boot() {
    const pre = $("#site")?.dataset.prerendered === lang;
    if (!pre) render();
    applyTheme(cfg); bind();
    const cms = await fetchCms();
    window.__docCms = cms["page:" + docKey];
    if (cms.site || window.__docCms) {
      cfg = S.merge(DEF, cms.site || {});
      render(); applyTheme(cfg); applySeo(cfg); bind();
      $$(".reveal").forEach((el) => { if (el.getBoundingClientRect().top < innerHeight) el.classList.add("in"); });
    }
  }
  boot();
})();
