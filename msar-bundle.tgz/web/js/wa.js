/* مسار — صفحة «الواتساب» للتاجر: المنيو + إعدادات الشات + المحادثات + الربط */
(function () {
  const A = window.AZM, { sb, $, $$, esc, toast } = A;
  const FN = `${(window.MSAR_CONFIG || window.AZM_CONFIG || {}).SUPABASE_URL || ""}/functions/v1/whatsapp`;
  const DEF = {
    methods: { popular: true, categories: true, text: true, web: true, repeat: true }, auto: true,
    welcome_order: ["repeat", "popular", "categories", "web", "info"], quick_add: true, delivery_fee: 0, free_over: 0, min_order: 0,
    require_location: true, ask_email: false, ai_agent: true, ai: { name: "", tone: "saudi", upsell: "light", memory: true, instructions: "" }, hours: { enabled: false, open: "12:00", close: "24:00" },
    texts: {
      welcome: "أهلاً وسهلاً فيك في {store} 👋\nوش تحب نخدمك فيه؟", welcome_back: "أهلاً فيك من جديد 👋\nوش تبي اليوم؟",
      hint: "✍️ أو اكتب طلبك مباشرة، مثل: «٢ برجر وبطاطس»", closed: "نعتذر، حالياً خارج أوقات الدوام. نداوم من {open} إلى {close} 🌙",
      ask_location: "📍 أرسل لنا موقعك عشان نتأكد إنه ضمن نطاق التوصيل ونحسب الرسوم.", out_of_range: "نعتذر، موقعك خارج نطاق التوصيل 🙏",
      min_order: "الحد الأدنى للطلب {min} ر.س. أضف أصناف إضافية وكمّل.", confirm_note: "طلبك ما يتسجّل إلا بعد تأكيدك",
      order_done: "🎉 تم استلام طلبك رقم {n}\nالمجموع: {total} ر.س — الدفع عند الاستلام.", status_preparing: "👨‍🍳 طلبك {n} قيد التجهيز الحين.",
      status_out: "🛵 طلبك {n} في الطريق إليك.", status_delivered: "✅ تم تسليم طلبك {n}. بالعافية! 🌷", status_cancelled: "❌ تم إلغاء طلبك {n}. لو فيه استفسار كلمنا.",
      handoff: "تمام، حوّلنا محادثتك لأحد الموظفين وبيرد عليك بأقرب وقت 🙏", unknown: "ما قدرت أفهم الأصناف من رسالتك 🙏\nجرّب تكتبها مثل: «٢ برجر وبطاطس»، أو اختر من الأزرار.",
      empty_menu: "المنيو غير جاهز حالياً. تواصل معنا مباشرة 🙏", info: "",
    },
  };
  const TXT = { welcome: "رسالة الترحيب (عميل جديد) — {store}", welcome_back: "ترحيب العميل المتكرر", hint: "تلميح الكتابة الحرة", closed: "خارج الدوام — {open} {close}", ask_location: "طلب الموقع", out_of_range: "خارج نطاق التوصيل", min_order: "الحد الأدنى — {min}", confirm_note: "ملاحظة التأكيد", order_done: "تأكيد الطلب — {n} {total}", status_preparing: "حالة: قيد التجهيز", status_out: "حالة: في الطريق", status_delivered: "حالة: تم التسليم", status_cancelled: "حالة: ملغي", handoff: "التحويل لموظف", unknown: "لم يُفهم الطلب", empty_menu: "المنيو فارغ", info: "معلومات المتجر (العنوان، الدوام…) — تظهر عند زر «معلومات»" };
  const METHODS = { popular: "⭐ الأكثر طلباً", categories: "📂 التصنيفات ثم الأصناف", text: "✍️ الكتابة الحرة (ذكاء اصطناعي)", web: "🌐 المنيو الكامل (رابط ويب)", repeat: "🔁 كرر طلبي السابق" };
  const ORDER_LBL = { repeat: "🔁 كرر طلبي", popular: "⭐ الأكثر طلباً", categories: "📂 التصنيفات", web: "🌐 المنيو الكامل", info: "ℹ️ معلومات" };
  let RAWCFG = {}; let SID = null, tab = "menu", cats = [], items = [], cfg = null, view = null;

  const merge = (raw) => { const c = JSON.parse(JSON.stringify(DEF)); const r = raw || {}; for (const k of Object.keys(c)) { if (r[k] === undefined) continue; c[k] = (c[k] && typeof c[k] === "object" && !Array.isArray(c[k])) ? { ...c[k], ...r[k] } : r[k]; } return c; };
  async function load() {
    const [c, i, f] = await Promise.all([
      sb.from("wa_categories").select("*").eq("store_id", SID).order("sort").order("id"),
      sb.from("wa_items").select("*").eq("store_id", SID).order("sort").order("id"),
      sb.from("wa_config").select("config").eq("store_id", SID).maybeSingle()]);
    if (c.error) throw c.error;
    cats = c.data || []; items = i.data || []; RAWCFG = f.data?.config || {}; cfg = merge(RAWCFG);
  }
  async function saveCfg() {
    const { error } = await sb.from("wa_config").upsert({ store_id: SID, config: { ...RAWCFG, ...cfg }, updated_at: new Date().toISOString() });
    if (error) throw error; toast("تم الحفظ ✅");
  }

  async function render(v, ctx) {
    view = v; SID = ctx.storeId;
    v.innerHTML = `<div class="empty">جاري التحميل…</div>`;
    try { await load(); } catch (e) { v.innerHTML = `<div class="card"><div class="empty">⚠️ ${esc(A.errMsg(e))}<br><span class="small">تأكد أن ترقية 014 مشغّلة في قاعدة البيانات.</span></div></div>`; return; }
    const T = [["menu", "🍽️ المنيو"], ["site", "🌐 المنيو الإلكتروني"], ["ai", "🤖 الشات الذكي"], ["chat", "💬 إعدادات الشات"], ["conv", "📨 المحادثات"], ["tpl", "🧩 القوالب"], ["link", "🔌 الربط"]];
    v.innerHTML = `<div class="row" style="margin-bottom:12px">${T.map(([k, l]) => `<button class="btn ${tab === k ? "btn-primary" : ""}" data-wt="${k}">${l}</button>`).join("")}</div><div id="wv"></div>`;
    $$("[data-wt]", v).forEach((b) => b.onclick = () => { tab = b.dataset.wt; render(v, ctx); });
    const w = $("#wv", v);
    if (tab === "menu") return menuTab(w); if (tab === "site") return siteTab(w); if (tab === "ai") return aiTab(w); if (tab === "chat") return chatTab(w); if (tab === "conv") return convTab(w); if (tab === "tpl") return tplTab(w); return linkTab(w);
  }

  // ------------------------------------------------------------ المنيو
  function menuTab(w) {
    const catName = (id) => cats.find((c) => c.id === id)?.name || "بدون تصنيف";
    w.innerHTML = `<div class="card"><div class="card-head"><h3>التصنيفات</h3><span class="spacer"></span><button class="btn btn-sm" id="add-cat">➕ تصنيف</button></div>
      <div class="row" style="flex-wrap:wrap;gap:8px">${cats.map((c) => `<span class="chip" style="font-size:14px;padding:6px 10px">${esc(c.emoji || "")} ${esc(c.name)} <a href="#" data-ec="${c.id}">✏️</a> <a href="#" data-dc="${c.id}">🗑️</a></span>`).join("") || '<span class="muted small">لا توجد تصنيفات (اختياري)</span>'}</div></div>
      <div class="card"><div class="card-head"><h3>الأصناف (${items.length})</h3><span class="spacer"></span><button class="btn btn-sm" id="scan-menu">📸 من صورة</button> <button class="btn btn-primary btn-sm" id="add-item">➕ صنف</button></div>
      ${items.length ? `<div class="table-wrap"><table><thead><tr><th></th><th>الصنف</th><th>التصنيف</th><th>السعر</th><th>⭐</th><th>متوفر</th><th></th></tr></thead><tbody>
      ${items.map((i) => `<tr><td style="width:44px">${i.image_url ? `<img src="${esc(i.image_url)}" alt="" style="width:40px;height:40px;object-fit:cover;border-radius:8px">` : `<span style="font-size:24px">${esc(i.emoji || "🍽️")}</span>`}</td>
        <td><b>${esc(i.name)}</b>${i.description ? `<div class="small muted">${esc(i.description)}</div>` : ""}</td><td>${esc(catName(i.category_id))}</td><td>${Number(i.price)} ر.س</td>
        <td><input type="checkbox" data-pop="${i.id}" ${i.is_popular ? "checked" : ""}></td><td><input type="checkbox" data-act="${i.id}" ${i.is_active ? "checked" : ""}></td>
        <td style="white-space:nowrap"><button class="btn btn-sm" data-ei="${i.id}">تعديل</button> <button class="btn btn-sm" data-di="${i.id}">🗑️</button></td></tr>`).join("")}</tbody></table></div>` : `<div class="empty">ما أضفت أصناف بعد. اضغط «➕ صنف» (أو أضف بسرعة بالأسفل).</div>`}
      <details style="margin-top:12px"><summary class="small" style="cursor:pointer">⚡ إضافة سريعة: سطر لكل صنف بصيغة «الاسم - السعر»</summary>
        <textarea id="bulk" rows="5" style="width:100%;margin-top:8px" placeholder="برجر دجاج - 18&#10;بطاطس كبير - 9"></textarea><button class="btn btn-sm" id="bulk-go" style="margin-top:6px">إضافة</button></details></div>`;
    const catForm = (c) => { const m = A.modal({ title: c ? "تعديل التصنيف" : "تصنيف جديد", body: `<label class="field"><span>الاسم</span><input id="cn" value="${esc(c?.name || "")}" maxlength="24"></label><label class="field"><span>إيموجي (اختياري)</span><input id="ce" value="${esc(c?.emoji || "")}" maxlength="4"></label>`,
      actions: [{ label: "حفظ", cls: "btn-primary", onClick: async (el) => { const name = $("#cn", el).value.trim(); if (!name) { toast("اكتب الاسم", "error"); return false; }
        const row = { store_id: SID, name, emoji: $("#ce", el).value.trim() || null }; const r = c ? await sb.from("wa_categories").update(row).eq("id", c.id) : await sb.from("wa_categories").insert({ ...row, sort: cats.length });
        if (r.error) throw r.error; await load(); if (!pre) menuTab(w); } }, { label: "إلغاء" }] }); return m; };
    $("#add-cat", w).onclick = () => catForm();
    $$("[data-ec]", w).forEach((a) => a.onclick = (e) => { e.preventDefault(); catForm(cats.find((c) => c.id == a.dataset.ec)); });
    $$("[data-dc]", w).forEach((a) => a.onclick = async (e) => { e.preventDefault(); if (!(await A.confirmBox("حذف التصنيف؟ (الأصناف تبقى بدون تصنيف)"))) return; await sb.from("wa_categories").delete().eq("id", a.dataset.dc); await load(); menuTab(w); });
    const itemForm = (it) => A.modal({ wide: true, title: it ? "تعديل الصنف" : "صنف جديد", body: `<div class="grid2" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      <label class="field"><span>الاسم (حد واتساب: 24 حرف في القوائم)</span><input id="in" value="${esc(it?.name || "")}" maxlength="60"></label>
      <label class="field"><span>السعر (ر.س)</span><input id="ip" type="number" min="0" step="0.5" value="${it ? Number(it.price) : ""}"></label>
      <label class="field"><span>التصنيف</span><select id="ic"><option value="">— بدون —</option>${cats.map((c) => `<option value="${c.id}" ${it?.category_id === c.id ? "selected" : ""}>${esc(c.name)}</option>`).join("")}</select></label>
      <label class="field"><span>إيموجي</span><input id="ie" value="${esc(it?.emoji || "")}" maxlength="4"></label>
      <label class="field" style="grid-column:1/-1"><span>الوصف (يظهر تحت الاسم)</span><input id="id" value="${esc(it?.description || "")}" maxlength="72"></label>
      <label class="field" style="grid-column:1/-1"><span>رابط الصورة (https)</span><input id="ii" value="${esc(it?.image_url || "")}" placeholder="https://…" dir="ltr"></label>
      <label class="field" style="grid-column:1/-1"><span>أسماء بديلة للكتابة الحرة (افصل بفاصلة) مثل: زنجر, كرسبي</span><input id="ia" value="${esc(it?.aliases || "")}"></label></div>`,
      actions: [{ label: "حفظ", cls: "btn-primary", onClick: async (el) => { const name = $("#in", el).value.trim(); const price = parseFloat($("#ip", el).value);
        if (!name || !(price >= 0)) { toast("الاسم والسعر مطلوبين", "error"); return false; }
        const img = $("#ii", el).value.trim(); if (img && !/^https:\/\//i.test(img)) { toast("رابط الصورة لازم يبدأ بـ https", "error"); return false; }
        const row = { store_id: SID, name, price, category_id: $("#ic", el).value ? +$("#ic", el).value : null, emoji: $("#ie", el).value.trim() || null, description: $("#id", el).value.trim() || null, image_url: img || null, aliases: $("#ia", el).value.trim() || null };
        const r = it ? await sb.from("wa_items").update(row).eq("id", it.id) : await sb.from("wa_items").insert({ ...row, sort: items.length });
        if (r.error) throw r.error; await load(); menuTab(w); } }, { label: "إلغاء" }] });
    $("#add-item", w).onclick = () => itemForm();
    $("#scan-menu", w).onclick = () => scanFlow(w);
    $$("[data-ei]", w).forEach((b) => b.onclick = () => itemForm(items.find((i) => i.id == b.dataset.ei)));
    $$("[data-di]", w).forEach((b) => b.onclick = async () => { if (!(await A.confirmBox("حذف الصنف؟"))) return; await sb.from("wa_items").delete().eq("id", b.dataset.di); await load(); menuTab(w); });
    $$("[data-pop]", w).forEach((c) => c.onchange = async () => { await sb.from("wa_items").update({ is_popular: c.checked }).eq("id", c.dataset.pop); const i = items.find((x) => x.id == c.dataset.pop); if (i) i.is_popular = c.checked; });
    $$("[data-act]", w).forEach((c) => c.onchange = async () => { await sb.from("wa_items").update({ is_active: c.checked }).eq("id", c.dataset.act); const i = items.find((x) => x.id == c.dataset.act); if (i) i.is_active = c.checked; });
    $("#bulk-go", w).onclick = async () => {
      const rows = $("#bulk", w).value.split("\n").map((l) => l.trim()).filter(Boolean).map((l, n) => { const m = l.match(/^(.+?)\s*[-–:،,]\s*([\d.٠-٩]+)\s*$/); if (!m) return null;
        const p = parseFloat(m[2].replace(/[٠-٩]/g, (d) => "٠١٢٣٤٥٦٧٨٩".indexOf(d))); return { store_id: SID, name: m[1].trim().slice(0, 60), price: p, sort: items.length + n }; }).filter((r) => r && r.price >= 0);
      if (!rows.length) return toast("ما فهمت الأسطر. الصيغة: الاسم - السعر", "error");
      const { error } = await sb.from("wa_items").insert(rows); if (error) return toast(A.errMsg(error), "error");
      toast(`أُضيف ${rows.length} صنف ✅`); await load(); menuTab(w);
    };
  }


  // ------------------------------------------------------------ إضافة المنيو من صورة
  const toJpeg = (file) => new Promise((res, rej) => {
    const img = new Image(), u = URL.createObjectURL(file);
    img.onload = () => { const k = Math.min(1, 1800 / Math.max(img.width, img.height)); const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL("image/jpeg", 0.85).split(",")[1]); };
    img.onerror = () => rej(new Error("الصورة غير مقروءة")); img.src = u;
  });
  function scanFlow(w, pre) {
    let found = null;
    const m = A.modal({ wide: true, title: "📸 إضافة المنيو من صورة",
      body: `<div class="small muted" style="margin-bottom:8px">صوّر المنيو أو ارفع صورته. الذكاء الاصطناعي يقرأ الأصناف والأسعار وأنت تراجعها وتعدّلها قبل الإضافة.</div><input type="file" id="sc-f" accept="image/*"><div id="sc-r" style="margin-top:12px"></div>`,
      actions: [{ label: "إضافة المحدد", cls: "btn-primary", onClick: async (el) => {
        if (!found) { toast("ارفع صورة المنيو أولاً", "error"); return false; }
        const pick = []; $$("[data-c]", el).forEach((cb) => { const ci = +cb.dataset.c; const cat = found[ci];
          $$(`[data-i^="${ci}-"]`, el).forEach((row) => { if (!$("input[type=checkbox]", row).checked) return; const name = $(".sn", row).value.trim(), price = parseFloat($(".sp", row).value);
            if (name && price >= 0) pick.push({ cat: $(".scat", el.querySelector(`[data-ch="${ci}"]`)).value.trim() || "المنيو", emoji: cat.emoji, name, price, description: row.dataset.d || null }); }); });
        if (!pick.length) { toast("ما اخترت أي صنف", "error"); return false; }
        const have = new Map(cats.map((c) => [c.name.trim(), c.id])); const names = new Set(items.map((i) => i.name.trim()));
        const need = [...new Set(pick.map((x) => x.cat))].filter((n) => !have.has(n));
        if (need.length) { const { data, error } = await sb.from("wa_categories").insert(need.map((n, k) => ({ store_id: SID, name: n.slice(0, 24), emoji: pick.find((x) => x.cat === n)?.emoji || null, sort: cats.length + k }))).select(); if (error) throw error; (data || []).forEach((c) => have.set(c.name.trim(), c.id)); }
        const rows = pick.filter((x) => !names.has(x.name)).map((x, k) => ({ store_id: SID, name: x.name.slice(0, 60), price: x.price, description: x.description, category_id: have.get(x.cat.slice(0, 24)) ?? null, sort: items.length + k }));
        if (rows.length) { const { error } = await sb.from("wa_items").insert(rows); if (error) throw error; }
        toast(`أُضيف ${rows.length} صنف${pick.length - rows.length ? ` (تخطيت ${pick.length - rows.length} مكرر)` : ""} ✅`); await load(); menuTab(w); } }, { label: "إلغاء" }] });
    const root = m.el, box = $("#sc-r", root);
    const onF = async (e) => {
      const f = e.target.files?.[0]; if (!f) return; found = null;
      box.innerHTML = `<div class="empty">⏳ جاري قراءة الصورة… (قد تأخذ 10–30 ثانية)</div>`;
      try {
        const b64 = await toJpeg(f); const r = await A.callFn("whatsapp", { image: b64, mime: "image/jpeg" }, "?action=menu_scan"); found = r.categories;
        box.innerHTML = found.map((c, ci) => `<div class="card" style="padding:10px;margin-bottom:8px"><div class="row" style="gap:8px"><input type="checkbox" data-c="${ci}" checked> <span>${esc(c.emoji || "")}</span> <input class="scat" value="${esc(c.name)}" maxlength="24" style="flex:1" data-ch-in><span class="muted small">${c.items.length} صنف</span></div>
          <div data-ch="${ci}" style="display:none"><input class="scat" value="${esc(c.name)}"></div>
          ${c.items.map((it, ii) => `<div class="row" data-i="${ci}-${ii}" data-d="${esc(it.description)}" style="gap:8px;padding:3px 0"><input type="checkbox" checked><input class="sn" value="${esc(it.name)}" style="flex:1"><input class="sp" type="number" min="0" step="0.5" value="${it.price}" style="width:90px"></div>`).join("")}</div>`).join("") || `<div class="empty">ما لقيت أصناف</div>`;
        $$("[data-ch-in]", root).forEach((inp, ci) => inp.oninput = () => { $(".scat", root.querySelector(`[data-ch="${ci}"]`)).value = inp.value; });
        $$("[data-c]", root).forEach((cb) => cb.onchange = () => $$(`[data-i^="${cb.dataset.c}-"] input[type=checkbox]`, root).forEach((x) => x.checked = cb.checked));
      } catch (er) { box.innerHTML = `<div class="empty">⚠️ ${esc(er.message || "تعذّرت القراءة")}</div>`; }
    };
    $("#sc-f", root).onchange = onF; if (pre) onF({ target: { files: [pre] } });
  }

  // ------------------------------------------------------------ المنيو الإلكتروني (صفحة عامة + قوالب + باركود)
  const SITE_BASE = "https://msarpro.com/m";
  const STPL = { rest: ["🍽️", "مطاعم وكافيهات"], buf: ["🥙", "بوفيهات"], cons: ["🛒", "منتجات استهلاكية"], sweet: ["🧁", "حلويات ومخابز"], gen: ["🛍️", "متجر عام"] };
  const SVIS = { all: "للجميع (رابط عام)", wa: "لمن يراسل الواتساب فقط", hours: "حسب ساعات الدوام", closed: "مغلق" };
  const SVIS_NOTE = { all: "أي أحد يفتح الرابط أو الباركود ويطلب.", wa: "الرابط العام ما يفتح المنيو. العميل يوصله من رابط يرسله الشات له.", hours: "يفتح ويقفل تلقائياً حسب ساعات الدوام (من «إعدادات الشات»).", closed: "المنيو العام مغلق للجميع." };
  const rndSlug = () => "s" + SID + "-" + Math.random().toString(36).slice(2, 6);
  const fileToImg = (file) => new Promise((res, rej) => { const u = URL.createObjectURL(file), im = new Image(); im.onload = () => res({ im, u }); im.onerror = () => rej(new Error("الصورة غير مقروءة")); im.src = u; });
  const shrink = (im, max, q, sq) => { // يصغّر الصورة ويرجّع data URL صغير (يخزَّن في الإعدادات)
    const sw = sq ? sq.s : im.width, sh = sq ? sq.s : im.height, sx = sq ? sq.x : 0, sy = sq ? sq.y : 0;
    const k = Math.min(1, max / Math.max(sw, sh)), c = document.createElement("canvas"); c.width = Math.round(sw * k); c.height = Math.round(sh * k);
    c.getContext("2d").drawImage(im, sx, sy, sw, sh, 0, 0, c.width, c.height); return c.toDataURL("image/jpeg", q);
  };
  const domColors = (im) => { // أبرز لونين (بدون الأبيض والرمادي والأسود)
    const c = document.createElement("canvas"); c.width = c.height = 64; const x = c.getContext("2d"); x.drawImage(im, 0, 0, 64, 64);
    const d = x.getImageData(0, 0, 64, 64).data, bins = new Map();
    for (let i = 0; i < d.length; i += 4) {
      const r = d[i], g = d[i + 1], b = d[i + 2], mx = Math.max(r, g, b), mn = Math.min(r, g, b), sat = mx ? (mx - mn) / mx : 0;
      if (d[i + 3] < 200 || mx > 235 && sat < .15 || mx < 40 || sat < .25) continue;
      const key = (r >> 5) << 6 | (g >> 5) << 3 | (b >> 5), e = bins.get(key) || { n: 0, r: 0, g: 0, b: 0 }; e.n++; e.r += r; e.g += g; e.b += b; bins.set(key, e);
    }
    const hex = (v) => Math.round(v).toString(16).padStart(2, "0"), out = [];
    [...bins.values()].sort((a, b) => b.n - a.n).forEach((e) => { const h = "#" + hex(e.r / e.n) + hex(e.g / e.n) + hex(e.b / e.n);
      if (!out.some((o) => Math.abs(parseInt(o.slice(1, 3), 16) - e.r / e.n) + Math.abs(parseInt(o.slice(3, 5), 16) - e.g / e.n) + Math.abs(parseInt(o.slice(5, 7), 16) - e.b / e.n) < 90)) out.push(h); });
    return out.slice(0, 4);
  };

  async function siteTab(w) {
    const ms = RAWCFG.msite || {}; let S = { enabled: false, slug: "", vis: "all", template: "rest", color: "#144F74", name: "", tagline: "", logo: "", cover: "", qr: { st: "sq", ey: "sq", lg: true, fr: "band", tx: "امسح واطلب", fg: "#144F74", bg: "#ffffff", brand: true }, ...ms };
    S.qr = { st: "sq", ey: "sq", lg: true, fr: "band", tx: "امسح واطلب", fg: "#144F74", bg: "#ffffff", brand: true, ...(ms.qr || {}) };
    if (!S.slug) S.slug = rndSlug();
    let branches = []; try { const r = await sb.from("branches").select("id,name,city").eq("store_id", SID).order("id"); branches = r.data || []; } catch (_) { /* */ }
    const link = () => `${SITE_BASE}?s=${S.slug || "…"}`;
    w.innerHTML = `
      <div class="card"><div class="card-head"><h3>🌐 المنيو الإلكتروني</h3><span class="spacer"></span><span class="chip" id="ms-state"></span></div>
        <p class="small muted">صفحة منيو بشكل جميل برابط وباركود خاص بمتجرك. يستخدم نفس أصناف الواتساب (تعدّلها من تبويب «المنيو»)، والطلب يكمل على واتساب ويوصل للكاشير.</p>
        <label class="row" style="gap:10px;padding:8px 0"><input type="checkbox" id="ms-on" ${S.enabled ? "checked" : ""}> <b>تشغيل المنيو الإلكتروني</b></label>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px">
          <label class="field"><span>رابط المنيو (حروف إنجليزية وأرقام و -)</span><input id="ms-slug" dir="ltr" maxlength="39" value="${esc(S.slug)}" placeholder="مثلاً: burger-house"></label>
          <label class="field"><span>لمن يظهر؟</span><select id="ms-vis">${Object.entries(SVIS).map(([k, l]) => `<option value="${k}" ${S.vis === k ? "selected" : ""}>${l}</option>`).join("")}</select></label></div>
        <div class="small muted" id="ms-visnote" style="margin:4px 0 8px"></div>
        <div class="row" style="gap:8px;flex-wrap:wrap"><input id="ms-link" readonly dir="ltr" style="flex:1;min-width:200px" value=""><button class="btn btn-sm" id="ms-copy">نسخ</button><a class="btn btn-sm" id="ms-open" target="_blank" rel="noopener">فتح</a></div></div>

      <div class="card"><div class="card-head"><h3>🎨 القالب والهوية</h3></div>
        <div class="small muted" style="margin-bottom:6px">القالب</div>
        <div class="row" style="gap:8px;flex-wrap:wrap" id="ms-tpls">${Object.entries(STPL).map(([k, [e, l]]) => `<button class="btn ${S.template === k ? "btn-primary" : ""}" data-t="${k}">${e} ${l}</button>`).join("")}</div>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:10px;margin-top:12px">
          <label class="field"><span>اسم المتجر في المنيو</span><input id="ms-name" maxlength="40" value="${esc(S.name)}" placeholder="اتركه فاضي لاسم المتجر"></label>
          <label class="field"><span>سطر تعريفي (اختياري)</span><input id="ms-tag" maxlength="60" value="${esc(S.tagline)}" placeholder="مثلاً: برجر طازج كل يوم"></label>
          <label class="field"><span>اللون الرئيسي</span><input type="color" id="ms-color" value="${esc(S.color)}" style="height:42px"></label></div>
        <div class="row" style="gap:10px;margin-top:10px;flex-wrap:wrap">
          <span id="ms-logo-p" style="width:56px;height:56px;border-radius:14px;background:${esc(S.color)} center/cover;display:grid;place-items:center;color:#fff;font-size:26px">${S.logo ? "" : STPL[S.template][0]}</span>
          <label class="btn btn-sm">رفع الشعار<input type="file" id="ms-logo" accept="image/*" hidden></label>
          <label class="btn btn-sm">رفع صورة الغلاف<input type="file" id="ms-cover" accept="image/*" hidden></label>
          <button class="btn btn-sm" id="ms-clear">حذف الشعار والغلاف</button></div></div>

      <div class="card"><div class="card-head"><h3>📸 رفع المنيو (سحب الألوان والأصناف والشعار)</h3></div>
        <p class="small muted">ارفع صورة منيوك المطبوع، واختر وش تبغى نسحب منها. النتيجة تظهر لك للمراجعة قبل ما تتطبق.</p>
        <label class="row" style="gap:10px;padding:4px 0"><input type="checkbox" id="im-col" checked> سحب الألوان</label>
        <label class="row" style="gap:10px;padding:4px 0"><input type="checkbox" id="im-items" checked> سحب الأصناف والأسعار (ذكاء اصطناعي)</label>
        <label class="row" style="gap:10px;padding:4px 0"><input type="checkbox" id="im-logo" checked> سحب الشعار (تحدد منطقته بنفسك)</label>
        <div class="row" style="margin-top:8px"><label class="btn btn-primary">اختيار صورة المنيو<input type="file" id="im-file" accept="image/*" hidden></label></div></div>

      <div class="card"><div class="card-head"><h3>▦ الباركود (QR)</h3></div>
        <div class="row" style="gap:16px;align-items:flex-start;flex-wrap:wrap">
          <div style="text-align:center;margin-inline:auto"><canvas id="qr-c" width="520" height="640" style="width:240px;max-width:100%;border:1px solid var(--line);border-radius:12px"></canvas>
            <div class="row" style="gap:6px;justify-content:center;margin-top:8px"><button class="btn btn-primary btn-sm" id="qr-png">تحميل PNG</button><button class="btn btn-sm" id="qr-svg">تحميل SVG</button></div></div>
          <div style="flex:1;min-width:230px;display:grid;gap:8px">
            <label class="field"><span>الفرع (اختياري)</span><select id="qr-br"><option value="">كل الفروع</option>${branches.map((b) => `<option value="${esc(b.name)}">${esc(b.name)}</option>`).join("")}</select></label>
            <label class="field"><span>شكل النقاط</span><select id="qr-st"><option value="sq">مربعة</option><option value="dot">دوائر</option><option value="rnd">مدورة</option></select></label>
            <label class="field"><span>شكل الزوايا</span><select id="qr-ey"><option value="sq">مربعة</option><option value="rnd">مدورة</option><option value="circ">دائرية</option></select></label>
            <label class="field"><span>الإطار</span><select id="qr-fr"><option value="band">شريط سفلي</option><option value="box">إطار كامل</option><option value="none">بدون إطار</option></select></label>
            <label class="field"><span>نص الإطار</span><input id="qr-tx" maxlength="24"></label>
            <div class="row" style="gap:10px;flex-wrap:wrap"><label class="field"><span>لون الباركود</span><input type="color" id="qr-fg"></label><label class="field"><span>الخلفية</span><input type="color" id="qr-bg"></label></div>
            <label class="row" style="gap:8px"><input type="checkbox" id="qr-brand"> نفس لون المتجر</label>
            <label class="row" style="gap:8px"><input type="checkbox" id="qr-lg"> الشعار في وسط الباركود</label>
            <div class="small" id="qr-warn"></div></div></div></div>

      <div class="row" style="position:sticky;bottom:8px;gap:8px"><button class="btn btn-primary" id="ms-save">💾 حفظ المنيو الإلكتروني</button></div>`;
    const q = (id) => w.querySelector("#" + id);
    const refresh = () => {
      S.enabled = q("ms-on").checked; S.slug = q("ms-slug").value.trim().toLowerCase(); S.vis = q("ms-vis").value; S.name = q("ms-name").value.trim(); S.tagline = q("ms-tag").value.trim(); S.color = q("ms-color").value;
      q("ms-visnote").textContent = SVIS_NOTE[S.vis]; q("ms-link").value = link(); q("ms-open").href = link();
      const okSlug = /^[a-z0-9][a-z0-9-]{1,38}$/.test(S.slug); q("ms-state").textContent = !S.enabled ? "متوقف" : !okSlug ? "الرابط غير صالح" : S.vis === "closed" ? "مغلق" : "شغّال"; q("ms-state").className = "chip " + (S.enabled && okSlug && S.vis !== "closed" ? "ok" : "");
      const lp = q("ms-logo-p"); lp.style.background = S.logo ? `url(${S.logo}) center/cover` : S.color; lp.textContent = S.logo ? "" : STPL[S.template][0];
      drawQR();
    };
    ["ms-on", "ms-slug", "ms-vis", "ms-name", "ms-tag", "ms-color"].forEach((id) => q(id).addEventListener("input", refresh));
    q("ms-tpls").onclick = (e) => { const b = e.target.closest("[data-t]"); if (!b) return; S.template = b.dataset.t; $$("[data-t]", q("ms-tpls")).forEach((x) => x.classList.toggle("btn-primary", x === b)); refresh(); };
    q("ms-copy").onclick = () => { navigator.clipboard?.writeText(link()).then(() => toast("تم نسخ الرابط ✅"), () => toast("انسخه يدوياً", "error")); };
    q("ms-clear").onclick = () => { S.logo = ""; S.cover = ""; refresh(); toast("تم الحذف (اضغط حفظ)"); };
    q("ms-logo").onchange = async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const { im, u } = await fileToImg(f); const s = Math.min(im.width, im.height); S.logo = shrink(im, 256, .85, { x: (im.width - s) / 2, y: (im.height - s) / 2, s }); URL.revokeObjectURL(u); refresh(); } catch (er) { toast(er.message, "error"); } };
    q("ms-cover").onchange = async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const { im, u } = await fileToImg(f); S.cover = shrink(im, 900, .8); URL.revokeObjectURL(u); refresh(); toast("تم رفع الغلاف (اضغط حفظ)"); } catch (er) { toast(er.message, "error"); } };

    // ---- QR
    const Q = S.qr; q("qr-st").value = Q.st; q("qr-ey").value = Q.ey; q("qr-fr").value = Q.fr; q("qr-tx").value = Q.tx; q("qr-fg").value = Q.fg; q("qr-bg").value = Q.bg; q("qr-brand").checked = !!Q.brand; q("qr-lg").checked = !!Q.lg;
    const lum = (h) => { const n = parseInt(h.slice(1), 16), f = (v) => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }; return .2126 * f(n >> 16 & 255) + .7152 * f(n >> 8 & 255) + .0722 * f(n & 255); };
    const contrast = (a, b) => { const x = lum(a), y = lum(b); return (Math.max(x, y) + .05) / (Math.min(x, y) + .05); };
    const qrUrl = () => link() + (q("qr-br").value ? "&b=" + encodeURIComponent(q("qr-br").value) : "");
    const rr = (c, x, y, ww, hh, r) => { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + ww, y, x + ww, y + hh, r); c.arcTo(x + ww, y + hh, x, y + hh, r); c.arcTo(x, y + hh, x, y, r); c.arcTo(x, y, x + ww, y, r); c.closePath(); };
    function getM() { const u = qrUrl(); try { return window.MSARQR.matrix(u, Q.lg ? "Q" : "M"); } catch (_) { try { return window.MSARQR.matrix(u, "M"); } catch (e2) { return null; } } }
    function drawQR(target) {
      Q.st = q("qr-st").value; Q.ey = q("qr-ey").value; Q.fr = q("qr-fr").value; Q.tx = q("qr-tx").value; Q.bg = q("qr-bg").value; Q.brand = q("qr-brand").checked; Q.lg = q("qr-lg").checked;
      if (Q.brand) q("qr-fg").value = S.color; Q.fg = q("qr-fg").value;
      const m = getM(), cv = target || q("qr-c"); if (!m) { q("qr-warn").textContent = "الرابط طويل جداً، اختصره."; return; }
      const n = m.length, W = 520, framed = Q.fr !== "none", box = Q.fr === "box", Hh = framed ? 640 : 560, pad = 34, qs = W - pad * 2 - (box ? 20 : 0), x0 = (W - qs) / 2, y0 = pad + (box ? 10 : 0), cs = qs / n;
      cv.width = W; cv.height = Hh; const c = cv.getContext("2d"); c.fillStyle = Q.bg; c.fillRect(0, 0, W, Hh);
      if (box) { c.strokeStyle = S.color; c.lineWidth = 14; rr(c, 7, 7, W - 14, Hh - 14, 26); c.stroke(); }
      const inEye = (i, j) => (i < 7 && j < 7) || (i < 7 && j >= n - 7) || (i >= n - 7 && j < 7);
      c.fillStyle = Q.fg;
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { if (!m[i][j] || inEye(i, j)) continue; const x = x0 + j * cs, y = y0 + i * cs;
        if (Q.st === "dot") { c.beginPath(); c.arc(x + cs / 2, y + cs / 2, cs * .43, 0, 7); c.fill(); } else if (Q.st === "rnd") { rr(c, x + .5, y + .5, cs - 1, cs - 1, cs * .35); c.fill(); } else c.fillRect(x, y, cs + .4, cs + .4); }
      [[0, 0], [0, n - 7], [n - 7, 0]].forEach(([r, cc]) => { const x = x0 + cc * cs, y = y0 + r * cs, s7 = 7 * cs;
        const shape = (px, py, sz) => { if (Q.ey === "circ") { c.beginPath(); c.arc(px + sz / 2, py + sz / 2, sz / 2, 0, 7); c.fill(); } else if (Q.ey === "rnd") { rr(c, px, py, sz, sz, sz * .28); c.fill(); } else c.fillRect(px, py, sz, sz); };
        c.fillStyle = Q.fg; shape(x, y, s7); c.fillStyle = Q.bg; shape(x + cs, y + cs, s7 - 2 * cs); c.fillStyle = Q.fg; shape(x + 2 * cs, y + 2 * cs, s7 - 4 * cs); });
      if (Q.lg) { const lw = qs * .2, cx = W / 2, cy = y0 + qs / 2; c.fillStyle = Q.bg; c.beginPath(); c.arc(cx, cy, lw * .72, 0, 7); c.fill();
        if (S.logo && window.__msLogoImg) { c.save(); c.beginPath(); c.arc(cx, cy, lw * .58, 0, 7); c.clip(); c.drawImage(window.__msLogoImg, cx - lw * .58, cy - lw * .58, lw * 1.16, lw * 1.16); c.restore(); }
        else { c.fillStyle = S.color; c.beginPath(); c.arc(cx, cy, lw * .58, 0, 7); c.fill(); c.font = lw * .62 + "px sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.fillStyle = "#fff"; c.fillText(STPL[S.template][0], cx, cy + 2); } }
      if (framed) { const by = y0 + qs + 16, bh = Hh - by - (box ? 24 : 18); c.fillStyle = S.color; rr(c, box ? 30 : pad, by, W - (box ? 60 : pad * 2), bh, 18); c.fill(); c.fillStyle = "#fff"; c.font = "700 38px 'IBM Plex Sans Arabic',Tahoma,sans-serif"; c.textAlign = "center"; c.textBaseline = "middle"; c.direction = "rtl"; c.fillText(Q.tx || "امسح واطلب", W / 2, by + bh / 2 + 2); }
      const ratio = contrast(Q.fg, Q.bg); q("qr-warn").innerHTML = ratio < 3 ? `<span style="color:#b42318">⚠️ التباين ضعيف، الباركود ممكن ما يُقرأ</span>` : `<span style="color:#2f7a2e">✓ التباين ممتاز</span>`;
    }
    ["qr-st", "qr-ey", "qr-fr", "qr-tx", "qr-fg", "qr-bg", "qr-brand", "qr-lg", "qr-br"].forEach((id) => q(id).addEventListener("input", () => drawQR()));
    const dl = (href, name) => { const a = document.createElement("a"); a.download = name; a.href = href; a.click(); };
    q("qr-png").onclick = () => { drawQR(); dl(q("qr-c").toDataURL("image/png"), "menu-qr.png"); };
    q("qr-svg").onclick = () => { const m = getM(); if (!m) return; const n = m.length, s = 10, W = n * s + 80; let d = ""; const inEye = (i, j) => (i < 7 && j < 7) || (i < 7 && j >= n - 7) || (i >= n - 7 && j < 7);
      for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) if (m[i][j] && !inEye(i, j)) d += `M${40 + j * s} ${40 + i * s}h${s}v${s}h-${s}z`;
      const eye = (r, cc) => { const x = 40 + cc * s, y = 40 + r * s; return `<rect x="${x}" y="${y}" width="${7 * s}" height="${7 * s}" fill="${Q.fg}"/><rect x="${x + s}" y="${y + s}" width="${5 * s}" height="${5 * s}" fill="${Q.bg}"/><rect x="${x + 2 * s}" y="${y + 2 * s}" width="${3 * s}" height="${3 * s}" fill="${Q.fg}"/>`; };
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${W}"><rect width="${W}" height="${W}" fill="${Q.bg}"/><path d="${d}" fill="${Q.fg}"/>${eye(0, 0)}${eye(0, n - 7)}${eye(n - 7, 0)}</svg>`;
      dl("data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg), "menu-qr.svg"); toast("SVG بدون الإطار والشعار، للطباعة الكبيرة"); };

    // ---- رفع المنيو: ألوان + شعار + أصناف
    q("im-file").onchange = async (e) => {
      const f = e.target.files?.[0]; if (!f) return; e.target.value = "";
      const wantCol = q("im-col").checked, wantItems = q("im-items").checked, wantLogo = q("im-logo").checked;
      if (!wantCol && !wantItems && !wantLogo) { toast("اختر شي واحد على الأقل", "error"); return; }
      let im, u; try { ({ im, u } = await fileToImg(f)); } catch (er) { toast(er.message, "error"); return; }
      const cols = wantCol ? domColors(im) : [];
      let pickedColor = cols[0] || null, sq = { x: Math.round(im.width * .35), y: 0, s: Math.round(Math.min(im.width, im.height) * .3) };
      const body = `<div class="small muted">راجع اللي نسحبه. ما يتطبق شي إلا بعد ضغط «تطبيق».</div>
        ${wantCol ? `<h4 style="margin:12px 0 6px">الألوان (اضغط لون لاختياره رئيسياً)</h4>${cols.length ? `<div class="row" style="gap:8px" id="im-sw">${cols.map((c, i) => `<button class="btn" data-c="${c}" style="background:${c};width:48px;height:48px;border:${i ? "2px solid #fff" : "3px solid #123"}"></button>`).join("")}</div>` : `<div class="small muted">ما لقينا ألوان واضحة بالصورة.</div>`}` : ""}
        ${wantLogo ? `<h4 style="margin:12px 0 6px">الشعار: حرّك المربع على الشعار</h4><canvas id="im-cv" style="max-width:100%;border:1px solid var(--line);border-radius:10px"></canvas>
          <label class="field"><span>الموضع أفقياً</span><input type="range" id="im-x" min="0" max="100" value="${Math.round(sq.x / Math.max(1, im.width - sq.s) * 100)}"></label>
          <label class="field"><span>الموضع رأسياً</span><input type="range" id="im-y" min="0" max="100" value="0"></label>
          <label class="field"><span>الحجم</span><input type="range" id="im-s" min="10" max="100" value="${Math.round(sq.s / Math.min(im.width, im.height) * 100)}"></label>` : ""}
        ${wantItems ? `<div class="small muted" style="margin-top:12px">بعد التطبيق تفتح لك شاشة مراجعة الأصناف والأسعار.</div>` : ""}`;
      const mm = A.modal({ wide: true, title: "📸 نتيجة سحب المنيو", body, actions: [{ label: "تطبيق", cls: "btn-primary", onClick: () => {
        if (wantCol && pickedColor) { q("ms-color").value = pickedColor; }
        if (wantLogo) { const s = sq.s; S.logo = shrink(im, 256, .85, { x: sq.x, y: sq.y, s }); }
        refresh(); if (wantItems) setTimeout(() => scanFlow(w, f), 50); else toast("تم التطبيق (اضغط حفظ)"); } }, { label: "إلغاء" }] });
      const root = mm.el;
      $$("[data-c]", root).forEach((b) => b.onclick = () => { pickedColor = b.dataset.c; $$("[data-c]", root).forEach((x) => x.style.border = x === b ? "3px solid #123" : "2px solid #fff"); });
      if (wantLogo) {
        const cv = $("#im-cv", root), cx = cv.getContext("2d"), k = Math.min(1, 520 / im.width); cv.width = Math.round(im.width * k); cv.height = Math.round(im.height * k);
        const draw = () => { cx.drawImage(im, 0, 0, cv.width, cv.height); cx.fillStyle = "rgba(0,0,0,.45)"; cx.fillRect(0, 0, cv.width, cv.height); cx.save(); cx.beginPath(); cx.rect(sq.x * k, sq.y * k, sq.s * k, sq.s * k); cx.clip(); cx.drawImage(im, 0, 0, cv.width, cv.height); cx.restore(); cx.strokeStyle = "#fff"; cx.lineWidth = 3; cx.strokeRect(sq.x * k, sq.y * k, sq.s * k, sq.s * k); };
        const upd = () => { const mn = Math.min(im.width, im.height); sq.s = Math.max(20, Math.round(mn * +$("#im-s", root).value / 100)); sq.x = Math.round((im.width - sq.s) * +$("#im-x", root).value / 100); sq.y = Math.round((im.height - sq.s) * +$("#im-y", root).value / 100); draw(); };
        ["im-x", "im-y", "im-s"].forEach((id) => $("#" + id, root).addEventListener("input", upd)); upd();
      }
    };

    // ---- حفظ
    q("ms-save").onclick = async () => {
      refresh();
      if (S.enabled && !/^[a-z0-9][a-z0-9-]{1,38}$/.test(S.slug)) { toast("رابط المنيو: حروف إنجليزية صغيرة وأرقام و - فقط (من 2 إلى 39)", "error"); return; }
      if (!S.slug) S.slug = rndSlug();
      RAWCFG.msite = { enabled: S.enabled, slug: S.slug, vis: S.vis, template: S.template, color: S.color, name: S.name, tagline: S.tagline, logo: S.logo, cover: S.cover, qr: { ...S.qr } };
      try { await saveCfg(); q("ms-slug").value = S.slug; refresh(); }
      catch (e) { delete RAWCFG.msite; toast(/uniq|duplicate/i.test(String(e.message)) ? "هذا الرابط مستخدم، اختر غيره" : A.errMsg(e), "error"); }
    };
    // صورة الشعار للباركود
    window.__msLogoImg = null; if (S.logo) { const li = new Image(); li.onload = () => { window.__msLogoImg = li; drawQR(); }; li.src = S.logo; }
    refresh();
  }

  // ------------------------------------------------------------ الشات الذكي (شخصية المساعد)
  const TONES = { saudi: "سعودي أبيض (الافتراضي)", youth: "سعودي شبابي مرح", gulf: "خليجي ودود", formal: "فصحى مبسطة ورسمية", english: "English", auto: "يطابق لغة العميل (عربي/إنجليزي)" };
  const UPSELL = { off: "بدون اقتراحات (يرشّح فقط لو العميل سأل)", light: "خفيف — اقتراح بين وقت وآخر (موصى به)", active: "نشط — يقترح إضافة في أغلب الردود" };
  function aiTab(w) {
    const a = cfg.ai || DEF.ai;
    w.innerHTML = `<div class="card"><div class="card-head"><h3>شخصية المساعد</h3></div>
      <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="ai-on" ${cfg.ai_agent !== false ? "checked" : ""}> 🤖 تفعيل الشات الذكي (يرد على أي رسالة ويبني السلة)</label>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:10px">
        <label class="field"><span>اسم المساعد</span><input id="ai-name" maxlength="40" value="${esc(a.name || "")}" placeholder="مثلاً: مساعد كافيه الندى"></label>
        <label class="field"><span>اللهجة والنبرة</span><select id="ai-tone">${Object.entries(TONES).map(([k, l]) => `<option value="${k}" ${(a.tone || "saudi") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <label class="field"><span>مستوى التسويق</span><select id="ai-up">${Object.entries(UPSELL).map(([k, l]) => `<option value="${k}" ${(a.upsell || "light") === k ? "selected" : ""}>${l}</option>`).join("")}</select></label></div>
      <label class="row" style="gap:10px;padding:8px 0"><input type="checkbox" id="ai-mem" ${a.memory !== false ? "checked" : ""}> 🧠 يتذكر طلبات العميل السابقة ويخمّن طلبه، ويرشّح الأصناف الجديدة</label>
      <label class="field"><span>تعليمات خاصة (اختياري) — مثال: «لا تذكر الحلويات»، «أكّد على عرض الغداء»، «نغلق الجمعة»</span><textarea id="ai-ins" rows="4" maxlength="700" style="width:100%">${esc(a.instructions || "")}</textarea></label>
      <div class="small muted">المساعد ما يخترع أصنافاً أو أسعاراً ولا يخالف منيوك مهما كتبت في التعليمات.</div>
      <div class="row" style="margin-top:10px"><button class="btn btn-primary" id="ai-save">💾 حفظ</button></div></div>
      <div class="card"><div class="card-head"><h3>🧪 جرّب المساعد قبل الحفظ</h3></div>
      <div id="ai-chat" style="min-height:90px;max-height:300px;overflow:auto;display:flex;flex-direction:column;gap:6px;padding:8px;background:#efeae2;border-radius:10px"><div class="small muted">اكتب رسالة كأنك عميل (مثلاً: «ابغى شي للعشاء لأربعة»)، وشوف رده بالإعدادات الحالية.</div></div>
      <div class="row" style="margin-top:8px"><input id="ai-msg" placeholder="رسالة العميل…" style="flex:1"><button class="btn" id="ai-send">إرسال</button><button class="btn btn-sm" id="ai-clear">مسح</button></div></div>`;
    const read = () => ({ name: $("#ai-name", w).value.trim(), tone: $("#ai-tone", w).value, upsell: $("#ai-up", w).value, memory: $("#ai-mem", w).checked, instructions: $("#ai-ins", w).value.trim() });
    $("#ai-save", w).onclick = async () => { cfg.ai = read(); cfg.ai_agent = $("#ai-on", w).checked; try { await saveCfg(); } catch (e) { toast(A.errMsg(e), "error"); } };
    let hist = []; const chat = $("#ai-chat", w);
    const bub = (t, me) => { const d = document.createElement("div"); d.style.cssText = `align-self:${me ? "flex-start" : "flex-end"};max-width:85%;background:${me ? "#fff" : "#d9fdd3"};padding:6px 10px;border-radius:10px;white-space:pre-wrap;font-size:14px`; d.textContent = t; chat.appendChild(d); chat.scrollTop = chat.scrollHeight; return d; };
    const send = async () => { const inp = $("#ai-msg", w), t = inp.value.trim(); if (!t) return; inp.value = ""; bub(t, true); const wait = bub("…", false);
      try { const r = await A.callFn("whatsapp", { message: t, hist, ai: read() }, "?action=ai_preview"); wait.textContent = (r.reply || "(بدون رد)") + (r.add?.length ? "\n\n🧾 أضاف للسلة: " + r.add.map((x) => `${x.qty}× ${x.name}`).join("، ") : "");
        hist.push({ r: "u", t }, { r: "b", t: r.reply || "" }); hist = hist.slice(-8); } catch (e) { wait.textContent = "⚠️ " + (e.message || "تعذّر"); } };
    $("#ai-send", w).onclick = send; $("#ai-msg", w).onkeydown = (e) => { if (e.key === "Enter") send(); };
    $("#ai-clear", w).onclick = () => { hist = []; chat.innerHTML = ""; };
  }

  // ------------------------------------------------------------ إعدادات الشات
  function chatTab(w) {
    const ord = cfg.welcome_order.filter((k) => ORDER_LBL[k]);
    w.innerHTML = `<div class="card"><div class="card-head"><h3>طرق الطلب</h3></div>
      ${Object.entries(METHODS).map(([k, l]) => `<label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" data-m="${k}" ${cfg.methods[k] ? "checked" : ""}> ${l}</label>`).join("")}
      <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="quick" ${cfg.quick_add ? "checked" : ""}> ضغطة واحدة على الصنف تضيفه للسلة (بدون شاشة تفاصيل)</label>
      <hr><label class="row" style="gap:10px"><input type="checkbox" id="auto" ${cfg.auto ? "checked" : ""}> <b>اختيار تلقائي</b> للأزرار حسب حجم المنيو والعميل (موصى به)</label>
      <div id="ordbox" style="margin-top:10px;${cfg.auto ? "display:none" : ""}"><div class="small muted">ترتيب أزرار الترحيب (واتساب يعرض 3 أزرار فقط؛ أول 3 مفعّلة تظهر):</div>
        ${ord.map((k, i) => `<div class="row" style="gap:6px;padding:3px 0">${i + 1}. ${ORDER_LBL[k]} <span class="spacer"></span><button class="btn btn-sm" data-up="${k}" ${i ? "" : "disabled"}>↑</button><button class="btn btn-sm" data-dn="${k}" ${i < ord.length - 1 ? "" : "disabled"}>↓</button></div>`).join("")}</div></div>
      <div class="card"><div class="card-head"><h3>التوصيل والدوام</h3></div><div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px">
        <label class="field"><span>رسوم التوصيل (ر.س)</span><input id="fee" type="number" min="0" step="0.5" value="${cfg.delivery_fee}"></label>
        <label class="field"><span>توصيل مجاني فوق (0 = مغلق)</span><input id="free" type="number" min="0" value="${cfg.free_over}"></label>
        <label class="field"><span>الحد الأدنى للطلب</span><input id="min" type="number" min="0" value="${cfg.min_order}"></label></div>
        <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="aiag" ${cfg.ai_agent !== false ? "checked" : ""}> 🤖 الشات الذكي: يرد على أي كلام ويسوّق ويقترح ويبني السلة (موصى به)</label>
        <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="askmail" ${cfg.ask_email ? "checked" : ""}> ✉️ اطلب إيميل العميل قبل تأكيد الطلب (اختياري للعميل — يقدر يتخطاه)</label>
        <div class="small muted" style="padding:0 0 6px">اسم العميل يُسأل دائماً قبل التأكيد عشان يظهر الطلب كامل في لوحة التاجر والكاشير.</div>
        <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="loc" ${cfg.require_location ? "checked" : ""}> يطلب موقع العميل ويتحقق من نطاق التوصيل (يوجّه الطلب لأقرب فرع)</label>
        <label class="row" style="gap:10px;padding:6px 0"><input type="checkbox" id="hon" ${cfg.hours.enabled ? "checked" : ""}> تفعيل ساعات الدوام (خارجها يرد الشات برسالة اعتذار)</label>
        <div class="row" style="gap:10px"><label class="field"><span>من</span><input id="ho" type="time" value="${esc(cfg.hours.open)}"></label><label class="field"><span>إلى (24:00 = منتصف الليل)</span><input id="hc" type="text" value="${esc(cfg.hours.close)}" style="width:100px" dir="ltr"></label></div></div>
      <div class="card"><div class="card-head"><h3>نصوص الرسائل</h3><span class="spacer"></span><button class="btn btn-sm" id="txt-reset">استعادة الافتراضي</button></div>
        ${Object.keys(TXT).map((k) => `<label class="field"><span>${TXT[k]}</span><textarea data-t="${k}" rows="${k === "info" || k === "welcome" || k === "order_done" ? 3 : 2}" style="width:100%">${esc(cfg.texts[k] ?? "")}</textarea></label>`).join("")}</div>
      <div class="row"><button class="btn btn-primary" id="save">💾 حفظ الإعدادات</button><span class="small muted">الحفظ يسري فوراً على الشات.</span></div>`;
    const move = (k, d) => { const a = cfg.welcome_order.slice(); const i = a.indexOf(k); const j = i + d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; cfg.welcome_order = a; chatTab(w); };
    $$("[data-up]", w).forEach((b) => b.onclick = () => { collect(w); move(b.dataset.up, -1); }); $$("[data-dn]", w).forEach((b) => b.onclick = () => { collect(w); move(b.dataset.dn, 1); });
    $("#auto", w).onchange = (e) => { $("#ordbox", w).style.display = e.target.checked ? "none" : ""; };
    $("#txt-reset", w).onclick = () => { cfg.texts = { ...DEF.texts }; chatTab(w); };
    $("#save", w).onclick = async () => { collect(w); try { await saveCfg(); } catch (e) { toast(A.errMsg(e), "error"); } };
  }
  function collect(w) {
    $$("[data-m]", w).forEach((c) => cfg.methods[c.dataset.m] = c.checked);
    cfg.quick_add = $("#quick", w).checked; cfg.auto = $("#auto", w).checked;
    cfg.delivery_fee = Math.max(0, +$("#fee", w).value || 0); cfg.free_over = Math.max(0, +$("#free", w).value || 0); cfg.min_order = Math.max(0, +$("#min", w).value || 0);
    cfg.ai_agent = $("#aiag", w).checked; cfg.ask_email = $("#askmail", w).checked;
    cfg.require_location = $("#loc", w).checked; cfg.hours = { enabled: $("#hon", w).checked, open: $("#ho", w).value || "12:00", close: ($("#hc", w).value || "24:00").trim() };
    $$("[data-t]", w).forEach((t) => cfg.texts[t.dataset.t] = t.value);
  }

  // ------------------------------------------------------------ المحادثات
  let curSess = null, poll = null;
  // ------------------------------------------------------------ المحادثات (نسخة واتساب)
  const PAUSES = [[60, "ساعة"], [360, "6 ساعات"], [1440, "24 ساعة"], [-1, "لين أرجعه يدوياً"]];
  const PAUSE_AUTO = [[0, "لا يوقف"], [60, "ساعة"], [360, "6 ساعات"], [1440, "24 ساعة"], [-1, "لين أرجعه يدوياً"]];
  const botState = (s) => s.human ? { k: "off", t: "🙋 أنت تتولى المحادثة" } : s.bot_paused_until && new Date(s.bot_paused_until) > new Date() ? { k: "pause", t: `⏸ البوت موقوف حتى ${new Date(s.bot_paused_until).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}` } : { k: "on", t: "🤖 البوت شغال" };
  const hhmm = (d) => new Date(d).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" });
  const fromNow = (d) => { const m = Math.round((Date.now() - new Date(d)) / 60000); return m < 1 ? "الحين" : m < 60 ? `${m} د` : m < 1440 ? `${Math.floor(m / 60)} س` : `${Math.floor(m / 1440)} يوم`; };
  const mediaCache = new Map();
  let CV = null;

  async function convTab(w) {
    clearInterval(poll);
    const { data: qr } = await sb.from("wa_quick").select("*").eq("store_id", SID).order("sort").order("id");
    CV = { w, sessions: [], q: "", filter: "all", cur: curSess || null, quick: qr || [], busy: false, lastMsgId: 0 };
    w.innerHTML = `<div class="card" style="padding:10px;margin-bottom:10px"><div class="row" style="gap:14px;flex-wrap:wrap;align-items:center">
        <label class="row small" style="gap:6px"><input type="checkbox" id="g-bot" style="width:auto;min-height:auto" ${RAWCFG.bot_off ? "" : "checked"}> 🤖 البوت شغال لكل المحادثات</label>
        <label class="row small" style="gap:6px">لما أرد أنا يوقف البوت: <select id="g-pause" style="width:auto">${PAUSE_AUTO.map(([v, l]) => `<option value="${v}" ${(RAWCFG.agent_pause ?? 60) == v ? "selected" : ""}>${l}</option>`).join("")}</select></label>
        <span class="spacer"></span><button class="btn btn-sm" id="g-quick">⚡ إدارة الردود السريعة</button></div></div>
      <div class="wa-cv" id="cv"><div class="card wa-list"><div style="padding:8px"><input id="cv-q" placeholder="🔍 ابحث بالاسم أو الرقم" style="width:100%">
        <div class="row" style="gap:6px;margin-top:8px"><button class="btn btn-sm btn-primary" data-f="all">الكل</button><button class="btn btn-sm" data-f="unread">غير مقروء</button><button class="btn btn-sm" data-f="paused">البوت موقوف</button></div></div>
        <div id="cv-list"></div></div>
      <div class="card wa-thread" id="thr"><div class="empty">اختر محادثة من القائمة</div></div></div>`;
    $("#g-bot", w).onchange = async (e) => { try { RAWCFG.bot_off = !e.target.checked; cfg.bot_off = RAWCFG.bot_off; await saveCfg(); toast(e.target.checked ? "البوت رجع يشتغل" : "البوت متوقف لكل المحادثات — لا يرد أحد إلا أنت"); } catch (er) { toast(A.errMsg(er), "error"); e.target.checked = !e.target.checked; } };
    $("#g-pause", w).onchange = async (e) => { try { RAWCFG.agent_pause = +e.target.value; cfg.agent_pause = RAWCFG.agent_pause; await saveCfg(); } catch (er) { toast(A.errMsg(er), "error"); } };
    $("#g-quick", w).onclick = () => quickManager();
    $("#cv-q", w).oninput = (e) => { CV.q = e.target.value.trim().toLowerCase(); drawList(); };
    $$("[data-f]", w).forEach((b) => (b.onclick = () => { CV.filter = b.dataset.f; $$("[data-f]", w).forEach((x) => x.classList.toggle("btn-primary", x === b)); drawList(); }));
    await refreshList(true);
    if (CV.cur) openThread(CV.cur, true);
    poll = setInterval(() => { if (!document.body.contains(w)) return clearInterval(poll); refreshList(); if (CV.cur) refreshThread(); }, 5000);
  }
  async function refreshList(first) {
    const { data, error } = await sb.from("wa_sessions").select("id,wa_id,name,human,bot_paused_until,unread,last_msg_at,last_in_at,orders_count,note").eq("store_id", SID).order("last_msg_at", { ascending: false }).limit(200);
    if (error) { if (first) CV.w.innerHTML = `<div class="card"><div class="empty">${esc(A.errMsg(error))}<br><span class="small">شغّل ملف 018_wa_chat.sql من Supabase.</span></div></div>`; return; }
    CV.sessions = data || []; drawList();
    if (CV.cur) { const s = CV.sessions.find((x) => x.id === CV.cur); if (s) drawHead(s); }
  }
  function drawList() {
    const el = $("#cv-list", CV.w); if (!el) return;
    let rows = CV.sessions;
    if (CV.filter === "unread") rows = rows.filter((s) => s.unread > 0);
    if (CV.filter === "paused") rows = rows.filter((s) => botState(s).k !== "on");
    if (CV.q) rows = rows.filter((s) => (s.name || "").toLowerCase().includes(CV.q) || String(s.wa_id).includes(CV.q));
    el.innerHTML = rows.length ? rows.map((s) => { const st = botState(s); return `<div class="wa-row ${CV.cur === s.id ? "on" : ""}" data-s="${s.id}">
        <div class="wa-av">${esc((s.name || "؟").trim().slice(0, 1))}</div>
        <div style="flex:1;min-width:0"><div class="row" style="gap:6px"><b class="wa-nm">${esc(s.name || "عميل")}</b><span class="spacer"></span><span class="small muted">${fromNow(s.last_msg_at)}</span></div>
          <div class="row small muted" style="gap:6px"><span dir="ltr">+${esc(s.wa_id)}</span><span class="spacer"></span>${st.k !== "on" ? `<span title="${esc(st.t)}">${st.k === "off" ? "🙋" : "⏸"}</span>` : ""}${s.unread ? `<span class="wa-badge">${s.unread}</span>` : ""}</div></div></div>`; }).join("") : `<div class="empty small">ما فيه محادثات</div>`;
    $$("[data-s]", el).forEach((d) => (d.onclick = () => openThread(+d.dataset.s)));
  }
  function drawHead(s) {
    const h = $("#t-head", CV.w); if (!h) return; const st = botState(s);
    h.querySelector(".t-state").textContent = st.t; h.querySelector(".t-state").className = "t-state chip " + (st.k === "on" ? "" : "chip-warn");
    const inWin = s.last_in_at && Date.now() - new Date(s.last_in_at).getTime() < 86400000;
    const rt = $("#rt", CV.w), rs = $("#rs", CV.w);
    if (rt) { rt.disabled = !inWin; rt.placeholder = inWin ? "اكتب رسالة… (Enter للإرسال، Shift+Enter سطر جديد)" : "مرّت 24 ساعة — ميتا تسمح بالرد فقط بعد رسالة جديدة من العميل"; }
    if (rs) rs.disabled = !inWin; const at = $("#t-attach", CV.w); if (at) at.disabled = !inWin;
    const rs2 = $("#t-resume", CV.w); if (rs2) rs2.classList.toggle("hidden", st.k === "on");
  }
  async function openThread(id, keepList) {
    CV.cur = curSess = id; CV.lastMsgId = 0; drawList();
    const s = CV.sessions.find((x) => x.id === id); if (!s) return;
    const el = $("#thr", CV.w);
    el.innerHTML = `<div id="t-head" class="wa-head"><div class="wa-av">${esc((s.name || "؟").trim().slice(0, 1))}</div><div style="flex:1;min-width:0"><b>${esc(s.name || "عميل")}</b><div class="small muted" dir="ltr" style="text-align:right">+${esc(s.wa_id)}</div></div>
        <span class="t-state chip"></span>
        <select id="t-pause" style="width:auto"><option value="">⏸ إيقاف البوت…</option>${PAUSES.map(([v, l]) => `<option value="${v}">${l}</option>`).join("")}</select>
        <button class="btn btn-sm btn-primary" id="t-resume">▶ تشغيل البوت</button></div>
      <div id="t-msgs" class="wa-msgs"><div class="empty small">جاري التحميل…</div></div>
      <div id="t-quick" class="row small" style="gap:6px;flex-wrap:wrap;padding:6px 0"></div>
      <div class="wa-compose"><button class="btn" id="t-attach" title="إرفاق صورة أو ملف">📎</button><input type="file" id="t-file" accept="image/jpeg,image/png,application/pdf,.doc,.docx,.xls,.xlsx,.txt" hidden>
        <textarea id="rt" rows="1" placeholder=""></textarea><button class="btn btn-primary" id="rs">إرسال ➤</button></div>
      <div id="t-pend" class="small muted"></div>`;
    $("#t-quick", el).innerHTML = CV.quick.map((q, i) => `<button class="btn btn-sm" data-q="${i}" title="${esc(q.body)}">⚡ ${esc(q.title)}</button>`).join("");
    $$("[data-q]", el).forEach((b) => (b.onclick = () => { const t = $("#rt", el); t.value = (t.value ? t.value + "\n" : "") + CV.quick[+b.dataset.q].body; t.focus(); autoGrow(t); }));
    const upd = async (patch, msg) => { const { error } = await sb.from("wa_sessions").update(patch).eq("id", id); if (error) return toast(A.errMsg(error), "error"); Object.assign(s, patch); drawHead(s); drawList(); if (msg) toast(msg); };
    $("#t-pause", el).onchange = (e) => { const v = +e.target.value; e.target.value = ""; if (!v) return; if (v === -1) upd({ human: true, bot_paused_until: null }, "البوت متوقف لهذا العميل لين تشغّله"); else upd({ human: false, bot_paused_until: new Date(Date.now() + v * 60000).toISOString() }, "تم إيقاف البوت لهذا العميل"); };
    $("#t-resume", el).onclick = () => upd({ human: false, bot_paused_until: null }, "البوت رجع يشتغل مع هذا العميل");
    const rt = $("#rt", el); const autoGrow = (t) => { t.style.height = "auto"; t.style.height = Math.min(120, t.scrollHeight) + "px"; };
    rt.oninput = () => autoGrow(rt);
    rt.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } };
    $("#rs", el).onclick = () => send();
    $("#t-attach", el).onclick = () => $("#t-file", el).click();
    $("#t-file", el).onchange = (e) => { const f = e.target.files[0]; e.target.value = ""; if (f) attach(f); };
    drawHead(s);
    if (s.unread) upd({ unread: 0 });
    await refreshThread(true); rt.focus();
  }
  async function refreshThread(force) {
    const id = CV.cur; if (!id) return;
    const { data: ms } = await sb.from("wa_messages").select("id,dir,kind,body,payload,status,sender_name,created_at").eq("session_id", id).order("id", { ascending: false }).limit(150);
    if (id !== CV.cur) return;
    const list = (ms || []).slice().reverse(); const last = list.length ? list[list.length - 1] : null;
    const sig = list.map((m) => m.id + (m.status || "")).join(",");
    if (!force && sig === CV.sig) return; CV.sig = sig;
    const box = $("#t-msgs", CV.w); if (!box) return;
    const atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 80;
    let day = "";
    box.innerHTML = list.length ? list.map((m) => {
      const d = new Date(m.created_at).toLocaleDateString("ar-SA", { day: "numeric", month: "long" }); const sep = d !== day ? `<div class="wa-day">${d}</div>` : ""; day = d;
      const mine = m.dir === "out"; const who = mine ? (m.kind === "agent" ? "👤 " + esc(m.sender_name || "موظف") : m.kind === "status" ? "🔔 تحديث طلب" : "🤖 البوت") : "";
      const media = m.payload?.media; const failed = m.payload?.failed || m.status === "failed";
      const tick = !mine ? "" : failed ? `<span class="wa-fail" title="${esc(m.payload?.error || "فشل الإرسال")}">⚠️ فشل</span>` : m.status === "read" ? `<span style="color:#34b7f1">✓✓</span>` : m.status === "delivered" ? "✓✓" : "✓";
      return `${sep}<div class="wa-b ${mine ? "out" : "in"} ${m.kind === "agent" ? "agent" : ""}">${who ? `<div class="wa-who">${who}</div>` : ""}${media ? `<div class="wa-media" data-mid="${m.id}" data-md="${esc(media.id)}" data-k="${esc(media.kind || m.kind)}" data-fn="${esc(media.filename || "")}">⏳ جاري تحميل ${media.kind === "image" || m.kind === "image" ? "الصورة" : "الملف"}…</div>` : ""}<div style="white-space:pre-wrap">${esc(m.body || "")}</div><div class="wa-t">${hhmm(m.created_at)} ${tick}</div></div>`;
    }).join("") : `<div class="empty small">ما فيه رسائل</div>`;
    if (atBottom || force) box.scrollTop = box.scrollHeight;
    $$(".wa-media", box).forEach(loadMedia);
  }
  async function loadMedia(el) {
    const key = el.dataset.md; const kind = el.dataset.k; const fn = el.dataset.fn;
    const paint = (url, mime) => {
      if (kind === "image" || kind === "sticker" || /^image\//.test(mime || "")) el.innerHTML = `<a href="${url}" target="_blank" rel="noopener"><img src="${url}" alt="" style="max-width:100%;max-height:260px;border-radius:8px;display:block"></a>`;
      else if (kind === "audio") el.innerHTML = `<audio controls src="${url}" style="max-width:100%"></audio>`;
      else if (kind === "video") el.innerHTML = `<video controls src="${url}" style="max-width:100%;max-height:260px;border-radius:8px"></video>`;
      else el.innerHTML = `<a class="btn btn-sm" href="${url}" download="${esc(fn || "file")}">📎 ${esc(fn || "تحميل الملف")}</a>`;
    };
    if (mediaCache.has(key)) return paint(...mediaCache.get(key));
    try {
      const { data: { session } } = await sb.auth.getSession();
      const r = await fetch(`${FN}?action=media`, { method: "POST", headers: { "Content-Type": "application/json", apikey: A.C.SUPABASE_ANON_KEY, Authorization: `Bearer ${session?.access_token}` }, body: JSON.stringify({ message_id: +el.dataset.mid, media_id: key }) });
      if (!r.ok) { const j = await r.json().catch(() => ({})); el.textContent = "⚠️ " + (j.error || "تعذر عرض الملف"); return; }
      const blob = await r.blob(); const url = URL.createObjectURL(blob); mediaCache.set(key, [url, blob.type]); paint(url, blob.type);
    } catch (_) { el.textContent = "⚠️ تعذر عرض الملف"; }
  }
  async function send(file) {
    const rt = $("#rt", CV.w); if (!rt || CV.busy) return; const text = rt.value.trim(); if (!text && !file) return;
    CV.busy = true; const btn = $("#rs", CV.w); if (btn) btn.disabled = true; $("#t-pend", CV.w).textContent = "⏳ جاري الإرسال…";
    try {
      const { data: { session } } = await sb.auth.getSession(); const h = { apikey: A.C.SUPABASE_ANON_KEY, Authorization: `Bearer ${session?.access_token}` };
      let r; const ctl = new AbortController(); const to = setTimeout(() => ctl.abort(), 30000);
      if (file) { const fd = new FormData(); fd.append("session_id", CV.cur); fd.append("text", text); fd.append("file", file); r = await fetch(`${FN}?action=reply`, { method: "POST", headers: h, body: fd, signal: ctl.signal }); }
      else r = await fetch(`${FN}?action=reply`, { method: "POST", headers: { ...h, "Content-Type": "application/json" }, body: JSON.stringify({ session_id: CV.cur, text }), signal: ctl.signal });
      clearTimeout(to);
      const j = await r.json().catch(() => ({}));
      if (!r.ok || j.error) throw new Error(j.error || `خطأ ${r.status}`);
      if (!j.ok) throw new Error("ميتا رفضت الرسالة — راجع سجل الربط");
      rt.value = ""; rt.style.height = "auto"; $("#t-pend", CV.w).textContent = "";
      if (j.paused) toast(j.paused === "manual" ? "تم الإرسال — البوت متوقف لهذا العميل لين تشغّله" : "تم الإرسال — البوت موقوف لهذا العميل مؤقتاً");
      await refreshList(); await refreshThread(true);
    } catch (e) { $("#t-pend", CV.w).textContent = ""; toast(e.name === "AbortError" ? "انتهت مهلة الإرسال، حاول مرة ثانية (رسالتك محفوظة بالمربع)" : A.errMsg(e), "error", 7000); }
    finally { CV.busy = false; const b2 = $("#rs", CV.w); if (b2) b2.disabled = false; $("#rt", CV.w)?.focus(); }
  }
  function attach(f) {
    if (f.size > 5 * 1024 * 1024) return toast("الملف أكبر من 5 ميجا", "error");
    A.confirmBox("إرسال للعميل", `إرسال «${f.name}» للعميل؟${$("#rt", CV.w).value.trim() ? " (النص المكتوب يُرسل كتعليق على الملف)" : ""}`, "إرسال").then((ok) => ok && send(f));
  }
  function quickManager() {
    const draw = () => `<div class="small muted" style="margin-bottom:8px">ردود جاهزة تضغطها بالمحادثة وتنحط في مربع الكتابة (تقدر تعدّلها قبل الإرسال).</div>
      ${CV.quick.map((q) => `<div class="row" style="gap:6px;margin-bottom:6px" data-qid="${q.id}"><input class="q-t" value="${esc(q.title)}" placeholder="العنوان" style="width:30%"><input class="q-b" value="${esc(q.body)}" placeholder="نص الرد" style="flex:1"><button class="btn btn-sm q-s">حفظ</button><button class="btn btn-sm q-d">🗑</button></div>`).join("") || `<div class="empty small">ما فيه ردود بعد</div>`}
      <div class="row" style="gap:6px;margin-top:10px"><input id="nq-t" placeholder="عنوان جديد" style="width:30%"><input id="nq-b" placeholder="نص الرد" style="flex:1"><button class="btn btn-primary btn-sm" id="nq-a">إضافة</button></div>`;
    const m = A.modal({ title: "⚡ الردود السريعة", body: draw(), actions: [{ label: "تم", cls: "btn-primary" }], wide: true, onClose: () => { if (CV.cur) openThread(CV.cur); } });
    const wire = () => {
      const root = m.el || document.querySelector(".modal-wrap:last-of-type");
      const reload = async () => { const { data } = await sb.from("wa_quick").select("*").eq("store_id", SID).order("sort").order("id"); CV.quick = data || []; root.querySelector(".modal-body").innerHTML = draw(); wire(); };
      root.querySelector("#nq-a").onclick = async () => { const t = root.querySelector("#nq-t").value.trim(), b = root.querySelector("#nq-b").value.trim(); if (!t || !b) return toast("اكتب العنوان والنص", "error"); const { error } = await sb.from("wa_quick").insert({ store_id: SID, title: t.slice(0, 40), body: b.slice(0, 1000), sort: CV.quick.length }); if (error) return toast(A.errMsg(error), "error"); reload(); };
      root.querySelectorAll("[data-qid]").forEach((r) => { const id = +r.dataset.qid;
        r.querySelector(".q-s").onclick = async () => { const { error } = await sb.from("wa_quick").update({ title: r.querySelector(".q-t").value.trim().slice(0, 40), body: r.querySelector(".q-b").value.trim().slice(0, 1000) }).eq("id", id); if (error) toast(A.errMsg(error), "error"); else { toast("تم الحفظ"); reload(); } };
        r.querySelector(".q-d").onclick = async () => { const { error } = await sb.from("wa_quick").delete().eq("id", id); if (error) toast(A.errMsg(error), "error"); else reload(); }; });
    };
    wire();
  }

  // ------------------------------------------------------------ الربط
  const ES = { appId: "1860542181636270", configId: "1945364019769430", ver: "v23.0" };
  let fbReady = null;
  const loadFB = () => fbReady || (fbReady = new Promise((res, rej) => {
    if (window.FB) { res(); return; }
    window.fbAsyncInit = () => { window.FB.init({ appId: ES.appId, cookie: true, xfbml: false, version: ES.ver }); res(); };
    const sc = document.createElement("script"); sc.async = true; sc.src = "https://connect.facebook.net/ar_AR/sdk.js"; sc.onerror = () => { fbReady = null; rej(new Error("تعذر تحميل أداة ميتا، تأكد من الاتصال وأن حاجب الإعلانات متوقف")); };
    document.head.appendChild(sc);
  }));
  async function esStart(btn, done) {
    btn.disabled = true; const old = btn.textContent; btn.textContent = "جاري فتح نافذة ميتا…";
    try {
      await loadFB();
      let info = null, code = null, cancelled = false;
      const onMsg = (ev) => {
        if (!/(^|\.)facebook\.com$/.test(new URL(ev.origin).hostname)) return;
        try { const d = typeof ev.data === "string" ? JSON.parse(ev.data) : ev.data; if (d?.type === "WA_EMBEDDED_SIGNUP") { if (d.event === "FINISH" || d.event === "FINISH_ONLY_WABA") info = d.data; else if (d.event === "CANCEL") cancelled = true; } } catch { /* */ }
      };
      window.addEventListener("message", onMsg);
      const resp = await new Promise((res) => window.FB.login(res, { config_id: ES.configId, response_type: "code", override_default_response_type: true, extras: { setup: {}, featureType: "", sessionInfoVersion: "3" } }));
      code = resp?.authResponse?.code;
      for (let i = 0; i < 20 && code && !info && !cancelled; i++) await new Promise((r) => setTimeout(r, 250));
      window.removeEventListener("message", onMsg);
      if (!code || cancelled) { toast("تم إلغاء الربط"); return; }
      if (!info?.phone_number_id || !info?.waba_id) { toast("ما وصلتنا بيانات الرقم من ميتا، أعد المحاولة", "error"); return; }
      btn.textContent = "جاري إكمال الربط…";
      const r = await A.callFn("whatsapp", { code, waba_id: info.waba_id, phone_number_id: info.phone_number_id }, "?action=es_connect");
      toast("تم ربط الرقم " + (r.display_phone || "") + " ✅"); done();
    } catch (e) { toast(e.message || "تعذر الربط", "error"); }
    finally { btn.disabled = false; btn.textContent = old; }
  }
  async function linkTab(w) {
    const { data: ch } = await sb.from("wa_channels").select("id,display_phone,phone_number_id,status,label").eq("store_id", SID).order("id");
    const rows = ch || [];
    w.innerHTML = `<div class="card"><div class="card-head"><h3>رقم الواتساب المربوط</h3></div>
      ${rows.length ? rows.map((c) => `<div class="row" style="gap:10px;padding:8px 0;border-bottom:1px solid var(--line,#e2e8f0)">📱 <b dir="ltr">${esc(c.display_phone || c.phone_number_id)}</b>${c.label ? `<span class="small muted">${esc(c.label)}</span>` : ""} <span class="chip ${c.status === "active" ? "chip-paid" : "chip-warn"}">${c.status === "active" ? "يعمل" : "مفصول"}</span>${c.status === "active" ? `<button class="btn btn-sm" data-dc="${c.id}" style="margin-inline-start:auto">فصل الرقم</button>` : ""}</div>`).join("") : `<div class="empty">لم يُربط رقم بعد. اضغط «ربط واتساب» وأكمل الخطوات في نافذة ميتا.</div>`}
      <div class="row" style="margin-top:12px"><button class="btn btn-primary" id="es-go">🔗 ربط واتساب</button></div>
      <div class="small muted" style="margin-top:8px">تُفتح نافذة ميتا الرسمية: تسجّل دخولك، وتختار حساب واتساب للأعمال ورقمك وتتحقق منه برمز يوصلك. لا نطّلع على كلمة مرورك.<br>الرقم لازم يكون غير مسجّل في تطبيق واتساب العادي. عندما يراسل عميلك الرقم، يرد الشات تلقائياً، وتنزل الطلبات في «الطلبات الحالية» موجّهة لأقرب فرع بمصدر «واتساب».<br>عند «فصل الرقم» نحذف رمز الوصول فوراً ونوقف استقبال الرسائل، وتبقى طلباتك ومحادثاتك الحالية محفوظة.</div></div>
      <div class="card"><div class="card-head"><h3>حدود واتساب المهمة</h3></div><div class="small">• الرد الحر على العميل ممكن خلال 24 ساعة من آخر رسالة منه، وبعدها يلزم قالب معتمد (تبويب «القوالب»).<br>• الأزرار 3 كحد أقصى، والقوائم 10 صفوف في الصفحة (الشات يقسّمها تلقائياً).<br>• تحديثات حالة الطلب تُرسل تلقائياً للعميل (تجهيز، في الطريق، تسليم) ضمن نافذة الـ24 ساعة.</div></div>`;
    $("#es-go", w).onclick = (e) => esStart(e.currentTarget, () => linkTab(w));
    $$("[data-dc]", w).forEach((b) => b.onclick = () => {
      A.modal({ title: "فصل الرقم", body: `<div class="small">سيتوقف الشات عن الرد على هذا الرقم فوراً ويُحذف رمز الوصول من مسار. طلباتك ومحادثاتك الحالية تبقى. تقدر تربطه مرة ثانية في أي وقت.</div>`,
        actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "فصل الرقم", cls: "btn-primary", onClick: async () => { await A.callFn("whatsapp", { channel_id: Number(b.dataset.dc) }, "?action=es_disconnect"); toast("تم فصل الرقم"); linkTab(w); } }] });
    });
  }

  // ------------------------------------------------------------ القوالب (رسائل معتمدة من ميتا خارج نافذة 24 ساعة)
  const TPL_ST = { APPROVED: ["معتمد", "chip-paid"], PENDING: ["قيد المراجعة", "chip-warn"], REJECTED: ["مرفوض", "chip-warn"], PAUSED: ["موقوف", "chip-warn"] };
  async function tplTab(w) {
    w.innerHTML = `<div class="empty">جاري تحميل القوالب…</div>`;
    let list = [];
    try { list = (await A.callFn("whatsapp", {}, "?action=tpl_list")).templates || []; } catch (e) { w.innerHTML = `<div class="card"><div class="empty">${esc(e.message || "تعذر جلب القوالب")}<br><span class="small">اربط رقم واتساب أولاً من تبويب «الربط».</span></div></div>`; return; }
    w.innerHTML = `<div class="card"><div class="card-head"><h3>قوالب الرسائل</h3><button class="btn btn-primary btn-sm" id="tp-new">+ قالب جديد</button></div>
      <div class="small muted" style="margin-bottom:8px">القالب رسالة جاهزة تعتمدها ميتا، وتحتاجها لمراسلة العميل بعد مرور 24 ساعة من آخر رسالة منه (مثل تحديث حالة الطلب). المراجعة عادة خلال دقائق إلى يوم.</div>
      ${list.length ? list.map((t) => { const st = TPL_ST[t.status] || [t.status, "chip-warn"]; return `<div style="padding:10px 0;border-bottom:1px solid var(--line,#e2e8f0)"><div class="row" style="gap:8px"><b dir="ltr">${esc(t.name)}</b><span class="chip ${st[1]}">${esc(st[0])}</span><span class="small muted">${esc(t.category)} · ${esc(t.language)}</span><button class="btn btn-sm" data-td="${esc(t.name)}" style="margin-inline-start:auto">حذف</button></div><div class="small" style="margin-top:4px;white-space:pre-wrap">${esc(t.body)}</div>${t.rejected_reason && t.rejected_reason !== "NONE" ? `<div class="small" style="color:#b45309">سبب الرفض: ${esc(t.rejected_reason)}</div>` : ""}</div>`; }).join("") : `<div class="empty">ما فيه قوالب بعد.</div>`}</div>`;
    $("#tp-new", w).onclick = () => {
      A.modal({ title: "قالب جديد", wide: true, body: `<div class="grid2" style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
        <label class="field"><span>اسم القالب (إنجليزي صغير و_)</span><input id="tn" dir="ltr" maxlength="60" placeholder="order_ready"></label>
        <label class="field"><span>اللغة</span><select id="tl"><option value="ar">العربية</option><option value="en">English</option></select></label>
        <label class="field"><span>النوع</span><select id="tc"><option value="UTILITY">خدمة (تحديث طلب)</option><option value="MARKETING">تسويقي</option></select></label></div>
        <label class="field"><span>نص الرسالة — المتغيرات {{1}} {{2}}</span><textarea id="tb" rows="4" maxlength="1000" placeholder="أهلاً {{1}}، طلبك رقم {{2}} جاهز للاستلام 🎉"></textarea></label>
        <label class="field"><span>أمثلة للمتغيرات (افصل بـ | حسب الترتيب)</span><input id="te" placeholder="محمد | 1042"></label>
        <div class="small muted">ميتا ترفض القوالب الدعائية المبهمة. اكتب نصاً واضحاً ومحدداً.</div>`, actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "إرسال للمراجعة", cls: "btn-primary", onClick: async (el) => {
        const body = { name: el.querySelector("#tn").value.trim(), language: el.querySelector("#tl").value, category: el.querySelector("#tc").value, body: el.querySelector("#tb").value.trim(), examples: el.querySelector("#te").value.split("|").map((v) => v.trim()).filter(Boolean) };
        await A.callFn("whatsapp", body, "?action=tpl_create"); toast("أُرسل القالب لمراجعة ميتا ✅"); tplTab(w);
      } }] });
    };
    $$("[data-td]", w).forEach((b) => b.onclick = async () => { if (!confirm("حذف القالب " + b.dataset.td + "؟")) return; try { await A.callFn("whatsapp", { name: b.dataset.td }, "?action=tpl_delete"); toast("تم الحذف"); tplTab(w); } catch (e) { toast(e.message || "تعذر الحذف", "error"); } });
  }

  window.MSAR_WA = { render, FN };
})();
