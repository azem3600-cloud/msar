/* مسار — لوحة المالك: التحكم بميزة الواتساب (تفعيل لكل متجر / إظهار للكل / ربط الأرقام) */
(function () {
  const A = window.AZM, { $, $$, esc, toast } = A;
  const HOOK = `${(window.AZM_CONFIG || {}).SUPABASE_URL}/functions/v1/whatsapp`;
  async function render(v) {
    v.innerHTML = `<div class="empty">جاري التحميل…</div>`;
    let D; try { D = await A.rpc("owner_wa_overview"); } catch (e) { v.innerHTML = `<div class="card"><div class="empty">⚠️ ${esc(A.errMsg(e))}<br><span class="small">شغّل ترقية 014 من Supabase SQL Editor أولاً.</span></div></div>`; return; }
    v.innerHTML = `<div class="card"><div class="card-head"><h3>💬 ميزة الواتساب</h3><span class="spacer"></span>
        <span class="chip ${D.all ? "chip-paid" : "chip-warn"}" style="font-size:14px">${D.all ? "ظاهرة لكل المتاجر" : (D.stores.some((x) => x.enabled) ? "ظاهرة لمتاجر محددة (" + D.stores.filter((x) => x.enabled).length + ")" : "مخفية عن الجميع")}</span></div>
        <div class="small muted" style="margin-bottom:8px">ثلاث حالات: <b>للكل</b> (زر إظهار للكل) · <b>لمتاجر محددة</b> (علّم المتجر في الجدول بالأسفل) · <b>مخفية</b> (لا متجر معلّم وغير مفعّلة للكل).</div>
        <div class="row" style="gap:10px"><button class="btn ${D.all ? "" : "btn-primary"}" id="all-on" ${D.all ? "disabled" : ""}>👁️ إظهار للكل</button><button class="btn" id="all-off" ${D.all ? "" : "disabled"}>🙈 إخفاء عن الكل</button></div>
        <div class="small muted" style="margin-top:8px">قبل «إظهار للكل» تظهر الميزة فقط للمتاجر المفعّلة يدوياً بالجدول. اضغط «إظهار للكل» بعد اجتماع زد.</div></div>
      <div class="card"><div class="card-head"><h3>🔌 بيانات الربط مع ميتا</h3></div>
        <div class="small" style="line-height:2">Callback URL: <code dir="ltr" id="hk">${esc(HOOK)}</code> <button class="btn btn-sm" id="cp">نسخ</button><br>
        Verify token: القيمة اللي حطيتها في سر <code>WA_VERIFY_TOKEN</code> · الاشتراك: <code>messages</code><br>
        الأسرار في Supabase: <code>WA_VERIFY_TOKEN</code>, <code>WA_APP_SECRET</code>, (اختياري) <code>WA_ACCESS_TOKEN</code>, <code>GEMINI_API_KEY</code>, <code>WA_GRAPH_VERSION</code></div>
        <div class="row" style="margin-top:8px"><button class="btn btn-sm" id="hc">فحص الدالة</button><span class="small" id="hc-r"></span></div></div>
      <div class="card" style="padding:0"><div class="table-wrap"><table class="o-table"><thead><tr><th>المتجر</th><th>مفعّل</th><th>الأصناف</th><th>محادثات</th><th>طلبات واتساب</th><th>الأرقام</th><th></th></tr></thead><tbody>
      ${D.stores.map((s) => `<tr><td><b>${esc(s.name)}</b><div class="small muted">${esc(s.code || "")}</div></td>
        <td><label class="row" style="gap:6px"><input type="checkbox" data-en="${s.id}" ${s.enabled ? "checked" : ""}> ${s.enabled ? "نعم" : "لا"}</label></td>
        <td>${s.items}</td><td>${s.sessions}</td><td>${s.orders}</td>
        <td>${(s.channels || []).map((c) => `<div dir="ltr" style="text-align:right">📱 ${esc(c.display_phone || c.phone_number_id)} ${c.has_token ? "🔑" : "⚠️بدون توكن"} <a href="#" data-dc="${c.id}">✕</a></div>`).join("") || '<span class="muted small">—</span>'}</td>
        <td><button class="btn btn-sm" data-ch="${s.id}">➕ ربط رقم</button></td></tr>`).join("")}</tbody></table></div></div>`;
    const reload = () => render(v);
    $("#all-on", v).onclick = async () => { if (!(await A.confirmBox("إظهار ميزة الواتساب لكل المتاجر الآن؟"))) return; await A.rpc("owner_wa_set_all", { p_on: true }); toast("ظهرت للكل ✅"); reload(); };
    $("#all-off", v).onclick = async () => { await A.rpc("owner_wa_set_all", { p_on: false }); toast("اختفت عن الكل"); reload(); };
    $("#cp", v).onclick = () => A.copy(HOOK);
    $("#hc", v).onclick = async () => { const r = $("#hc-r", v); r.textContent = "…"; try { const j = await (await fetch(HOOK + "?action=health")).json(); const s = j.secrets || {};
      r.innerHTML = `الدالة تعمل ✅ — verify:${s.verify ? "✅" : "❌"} app_secret:${s.app_secret ? "✅" : "❌"} token:${s.token ? "✅" : "—"} ai:${s.ai ? "✅" : "—"}`; } catch (_) { r.textContent = "❌ الدالة غير منشورة بعد"; } };
    $$("[data-en]", v).forEach((c) => c.onchange = async () => { try { await A.rpc("owner_wa_set_store", { p_store: +c.dataset.en, p_on: c.checked }); toast(c.checked ? "فُعّلت لهذا المتجر ✅" : "أُوقفت"); reload(); } catch (e) { toast(A.errMsg(e), "error"); c.checked = !c.checked; } });
    $$("[data-dc]", v).forEach((a) => a.onclick = async (e) => { e.preventDefault(); if (!(await A.confirmBox("فصل هذا الرقم؟"))) return; await A.rpc("owner_wa_channel_delete", { p_channel: +a.dataset.dc }); reload(); });
    $$("[data-ch]", v).forEach((b) => b.onclick = () => A.modal({ title: "ربط رقم واتساب", body: `<label class="field"><span>Phone Number ID (من Meta → WhatsApp → API Setup)</span><input id="pn" dir="ltr" inputmode="numeric"></label>
      <label class="field"><span>WhatsApp Business Account ID (اختياري)</span><input id="wb" dir="ltr" inputmode="numeric"></label>
      <label class="field"><span>الرقم للعرض (مثل 966500000000)</span><input id="dp" dir="ltr"></label>
      <label class="field"><span>Access Token (اختياري إذا حطيت WA_ACCESS_TOKEN في الأسرار)</span><input id="tk" type="password" autocomplete="off" dir="ltr"></label>
      <div class="small muted">التوكن يُحفظ في جدول سري لا يقرأه المتصفح أبداً.</div>`,
      actions: [{ label: "حفظ", cls: "btn-primary", onClick: async (el) => { await A.rpc("owner_wa_channel_save", { p_store: +b.dataset.ch, p_phone_number_id: $("#pn", el).value, p_waba_id: $("#wb", el).value, p_display: $("#dp", el).value, p_token: $("#tk", el).value || null }); toast("تم الربط ✅"); reload(); } }, { label: "إلغاء" }] }));
  }
  window.MSAR_OWNER_WA = { render };
})();
