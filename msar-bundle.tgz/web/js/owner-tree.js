/* مسار — لوحة صاحب المنصة: شجرة العملاء (متجر ← فرع وكاشيره ← مناديب)
   - استدعاء واحد (owner_org_tree) ثم كل شي يصير في المتصفح.
   - الأبناء تُبنى عند أول فتح فقط (رندر كسول) + مستمع نقر واحد للشجرة كلها.
   - الأنيميشن CSS فقط (grid-template-rows / transform / opacity) ويحترم prefers-reduced-motion. */
(function () {
  const A = window.AZM, { $, $$, esc, toast } = A;
  const NC = []; const num = (n) => (Number.isInteger(n) && n >= 0 && n < 2000 ? (NC[n] ??= A.num(n)) : A.num(n)); // تنسيق الأرقام مع كاش (Intl بطيء مع آلاف الصفوف)
  const ST = { trial: ["تجريبي", "#fef3c7", "#92400e"], active: ["فعّال", "#dcfce7", "#166534"], suspended: ["موقوف", "#fee2e2", "#991b1b"], uninstalled: ["محذوف", "#f1f5f9", "#475569"] };
  const PLAN = { starter: "الأساسية", growth: "النمو", pro: "الاحترافية" };
  const T = { data: null, stamp: null, q: "", status: "live", online: false, open: new Set(), chart: null, timer: null };
  let host = null, opts = {}, IDX = null, QRX = null;

  // ------------------------------------------------------------ تحميل
  async function render(view, o) {
    host = view; opts = o || {};
    clearInterval(T.timer); T.timer = null;
    if (!T.data || (opts.stamp && opts.stamp !== T.stamp)) {
      view.innerHTML = `<div class="tr-skel">${"<i></i>".repeat(4)}</div>`;
      try { T.data = await A.rpc("owner_org_tree"); T.stamp = opts.stamp || Date.now(); index(); }
      catch (e) { view.innerHTML = `<div class="card"><p class="chip chip-warn" style="white-space:normal">${esc(A.errMsg(e))} — شغّل ترقية قاعدة البيانات 010</p></div>`; return; }
    }
    draw();
    // تحديث هادئ كل 90 ثانية ما دامت الصفحة ظاهرة (يحافظ على العُقد المفتوحة)
    T.timer = setInterval(async () => {
      if (document.hidden || !host.isConnected || !$("#tr-tree", host) || document.activeElement?.id === "tr-q") return;
      try { T.data = await A.rpc("owner_org_tree"); index(); draw(true); } catch (_) {}
    }, 90000);
  }

  // فهرس للبحث: نص صغير لكل متجر + أعضاءه
  function index() {
    IDX = new Map(); T.byId = new Map();
    for (const s of T.data.stores || []) {
      T.byId.set(s.id, s);
      const mem = [...s.admins, ...s.un.cashiers, ...s.un.drivers, ...s.branches.flatMap((b) => [...b.cashiers, ...b.drivers])];
      s._n = { br: s.branches.length, ca: s.un.cashiers.length, dr: s.un.drivers.length, on: s.un.drivers.filter((d) => d.on).length };
      s.branches.forEach((b) => { s._n.ca += b.cashiers.length; s._n.dr += b.drivers.length; s._n.on += b.drivers.filter((d) => d.on).length; b._n = { on: b.drivers.filter((d) => d.on).length }; });
      IDX.set(s.id, { store: [s.name, s.code, ...(s.admins.map((a) => a.e || ""))].join(" ").toLowerCase(), mem: mem.map((m) => `${m.n} ${m.p || ""} ${m.e || ""}`.toLowerCase()) });
    }
  }

  // ------------------------------------------------------------ أدوات
  const badge = (st) => { const x = ST[st] || [st, "#eee", "#333"]; return `<span class="badge" style="background:${x[1]};color:${x[2]}">${x[0]}</span>`; };
  const q = () => T.q.trim().toLowerCase();
  const hit = (txt) => { const k = q(); return !!k && String(txt || "").toLowerCase().includes(k); };
  const hl = (txt) => { const k = q(); const s = esc(txt || ""); if (!k) return s; QRX = QRX && QRX.k === k ? QRX : Object.assign(new RegExp(`(${k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi"), { k }); return s.replace(QRX, "<mark>$1</mark>"); };
  const memHit = (m) => hit(m.n) || hit(m.p) || hit(m.e);
  const av = (s) => s.logo_url ? `<img class="tr-av" src="${esc(s.logo_url)}" alt="" loading="lazy">` : `<span class="tr-av">${esc((s.name || "?").trim().charAt(0))}</span>`;
  const ini = (n) => esc((n || "?").trim().charAt(0));
  const wa = (m) => m.p ? `<a class="tr-wa" title="واتساب" target="_blank" rel="noopener" href="${A.waLink(String(m.p).replace(/[^\d+]/g, ""), `هلا ${m.n}، معك فريق مسار 👋`)}" onclick="event.stopPropagation()">💬</a>` : "";
  const chip = (ic, n, l, cls = "") => `<span class="tr-chip ${cls}">${ic} <b>${num(n)}</b> ${l}</span>`;

  function visibleStores() {
    const k = q();
    return (T.data.stores || []).filter((s) => {
      if (T.status === "live" ? !["trial", "active"].includes(s.status) : T.status !== "all" && s.status !== T.status) return false;
      if (T.online && !s._n.on) return false;
      if (!k) return true;
      const ix = IDX.get(s.id); return ix.store.includes(k) || ix.mem.some((x) => x.includes(k));
    });
  }

  // ------------------------------------------------------------ الرسم
  function draw(keep) {
    if (!host) return;
    if (T.chart) return drawChart();
    const S = T.data.stores || [], vis = visibleStores();
    const tot = S.filter((s) => s.status !== "uninstalled").reduce((a, s) => ({ br: a.br + s._n.br, ca: a.ca + s._n.ca, dr: a.dr + s._n.dr, on: a.on + s._n.on, st: a.st + 1 }), { br: 0, ca: 0, dr: 0, on: 0, st: 0 });
    const cnt = (k) => S.filter((s) => k === "all" || (k === "live" ? ["trial", "active"].includes(s.status) : s.status === k)).length;
    host.innerHTML = `
      <div class="tr-sum">
        ${chip("🏪", tot.st, "متجر", "tr-c-st")}${chip("🏬", tot.br, "فرع", "tr-c-br")}${chip("👤", tot.ca, "كاشير", "tr-c-ca")}${chip("🛵", tot.dr, "مندوب", "tr-c-dr")}
        <span class="tr-chip tr-c-on"><i class="tr-pulse"></i> <b>${num(tot.on)}</b> مندوب متصل الآن</span>
        <span class="spacer"></span><span class="small muted">${T.data.generated_at ? "البيانات قبل " + A.ago(T.data.generated_at) : ""}</span>
      </div>
      <div class="card o-tools tr-tools">
        <div class="o-seg">${[["live", "النشطة"], ["all", "الكل"], ["trial", "تجريبي"], ["suspended", "موقوف"], ["uninstalled", "محذوف"]].map(([k, l]) => `<button data-st="${k}" class="${T.status === k ? "on" : ""}">${l} <small>${num(cnt(k))}</small></button>`).join("")}</div>
        <input id="tr-q" type="search" placeholder="🔎 ابحث باسم المتجر أو الموظف أو الجوال" value="${esc(T.q)}" autocomplete="off">
        <label class="tr-tg"><input type="checkbox" id="tr-on" ${T.online ? "checked" : ""}><span><i></i></span> المتصلين فقط</label>
        <button class="btn btn-sm" id="tr-exp">⤵ توسيع الكل</button><button class="btn btn-sm" id="tr-col">⤴ طي الكل</button>
      </div>
      <div class="tr-tree ${keep ? "tr-noanim" : ""}" id="tr-tree">${vis.map((s, i) => storeNode(s, i)).join("") || `<div class="card"><div class="empty">${S.length ? "لا نتائج مطابقة" : "لا يوجد متاجر بعد — أول ما يثبّت تاجر التطبيق بيظهر هنا"}</div></div>`}</div>`;
    bind();
    // إعادة فتح العُقد المفتوحة سابقاً (أو المطابقة للبحث)
    const tree = $("#tr-tree", host);
    const auto = !!q();
    vis.forEach((s) => {
      const ix = IDX.get(s.id);
      const want = T.open.has("s:" + s.id) || (auto && ix.mem.some((x) => x.includes(q())));
      if (want) openNode(tree.querySelector(`.tr-store[data-sid="${s.id}"]`), true, true);
    });
    if (keep) requestAnimationFrame(() => tree.classList.remove("tr-noanim"));
  }

  function storeNode(s, i) {
    const admin = s.admins[0];
    return `<div class="tr-node tr-store tr-item" data-sid="${s.id}" style="--i:${Math.min(i, 12)}">
      <div class="tr-head" data-tg="s:${s.id}" role="button" tabindex="0" aria-expanded="false">
        <i class="tr-car"></i>${av(s)}
        <div class="tr-main"><div class="tr-title"><b>${hl(s.name)}</b><span class="mono small muted">${hl(s.code)}</span>${badge(s.status)}${s.plan ? `<span class="badge tr-plan">${PLAN[s.plan] || esc(s.plan)}</span>` : ""}${s.platform === "salla" ? `<span class="badge tr-salla">سلة</span>` : ""}</div>
          <div class="small muted tr-sub">${admin ? `👑 ${hl(admin.n)}${admin.p ? ` · <span class="mono">${hl(admin.p)}</span>` : ""}${admin.ll ? ` · آخر دخول ${A.ago(admin.ll)}` : ""}` : "ما أنشأ حساب المدير بعد"}</div></div>
        <div class="tr-stats">${chip("🏬", s._n.br, "")}${chip("👤", s._n.ca, "")}${chip("🛵", s._n.dr, "")}<span class="tr-chip ${s._n.on ? "tr-c-on" : "tr-c-off"}"><i class="${s._n.on ? "tr-pulse" : "tr-dot"}"></i> ${num(s._n.on)}</span>${s.oo ? chip("📦", s.oo, "مفتوح", "tr-c-oo") : ""}</div>
        <div class="tr-acts"><button class="btn btn-sm" data-chart="${s.id}" title="مخطط تنظيمي">🗺️</button><button class="btn btn-sm" data-prof="${s.id}" title="ملف العميل">👁️</button></div>
      </div>
      <div class="tr-kids"><div class="tr-kids-in"></div></div>
    </div>`;
  }
  function storeKids(s) {
    const parts = [];
    if (s.admins.length > 1) parts.push(`<div class="tr-item tr-group" style="--i:0"><div class="tr-gl">👑 المدراء</div>${s.admins.map((m) => leaf(m, "admin")).join("")}</div>`);
    s.branches.forEach((b, i) => parts.push(branchNode(s, b, i + 1)));
    if (s.un.cashiers.length || s.un.drivers.length) parts.push(branchNode(s, { id: 0, name: "بدون فرع", city: "", active: true, oo: 0, cashiers: s.un.cashiers, drivers: s.un.drivers, _n: { on: s._n.on - s.branches.reduce((a, b) => a + b._n.on, 0) } }, s.branches.length + 1, true));
    return parts.join("") || `<div class="tr-item tr-empty" style="--i:0">ما أضاف فروع ولا موظفين بعد</div>`;
  }
  function branchNode(s, b, i, un) {
    const dr = T.online ? b.drivers.filter((d) => d.on) : b.drivers;
    return `<div class="tr-node tr-branch tr-item ${un ? "tr-un" : ""} ${b.active ? "" : "tr-off"}" data-bid="${s.id}:${b.id}" style="--i:${Math.min(i, 12)}">
      <div class="tr-head" data-tg="b:${s.id}:${b.id}" role="button" tabindex="0" aria-expanded="false">
        <i class="tr-car"></i><span class="tr-av tr-av-b">${un ? "❔" : "🏬"}</span>
        <div class="tr-main"><div class="tr-title"><b>${hl(b.name)}</b>${b.city ? `<span class="small muted">${esc(b.city)}</span>` : ""}${b.active ? "" : `<span class="badge" style="background:#f1f5f9;color:#475569">موقوف</span>`}</div>
          <div class="small muted tr-sub">${b.cashiers.length ? `👤 ${b.cashiers.map((c) => hl(c.n)).join("، ")}` : "بدون كاشير"}</div></div>
        <div class="tr-stats">${chip("👤", b.cashiers.length, "")}${chip("🛵", dr.length, "")}<span class="tr-chip ${b._n.on ? "tr-c-on" : "tr-c-off"}"><i class="${b._n.on ? "tr-pulse" : "tr-dot"}"></i> ${num(b._n.on)}</span>${b.oo ? chip("📦", b.oo, "مفتوح", "tr-c-oo") : ""}</div>
      </div>
      <div class="tr-kids"><div class="tr-kids-in"></div></div>
    </div>`;
  }
  function branchKids(b) {
    const dr = (T.online ? b.drivers.filter((d) => d.on) : b.drivers);
    return `
      <div class="tr-item tr-group" style="--i:0"><div class="tr-gl">👤 الكاشير <small>${num(b.cashiers.length)}</small></div>${b.cashiers.map((m) => leaf(m, "cashier")).join("") || `<div class="tr-empty">ما فيه كاشير في هذا الفرع</div>`}</div>
      <div class="tr-item tr-group" style="--i:1"><div class="tr-gl">🛵 المناديب <small>${num(dr.length)}</small></div>${dr.map((m, i) => leaf(m, "driver", i)).join("") || `<div class="tr-empty">${T.online ? "ما فيه مندوب متصل الآن" : "ما فيه مناديب في هذا الفرع"}</div>`}</div>`;
  }
  function leaf(m, role, i = 0) {
    const on = role === "driver" && m.on, stale = on && m.ls && A.minutesSince(m.ls) > 10;
    const st = role === "driver"
      ? (on ? `<span class="tr-on">${stale ? "🟡 متصل (بدون موقع حديث)" : "🟢 متصل"}</span>${m.bz ? ` · 📦 ${num(m.bz)} بيده` : ""}` : `<span class="muted">⚪ غير متصل${m.ls ? ` · ${A.ago(m.ls)}` : ""}</span>`)
      : (m.ll ? `آخر دخول ${A.ago(m.ll)}` : `<span class="muted">ما دخل بعد</span>`);
    return `<div class="tr-leaf tr-${role} ${m.a ? "" : "tr-off"} ${on ? "is-on" : ""} ${memHit(m) ? "is-hit" : ""}" style="--j:${Math.min(i, 10)}">
      <span class="tr-av tr-av-m">${ini(m.n)}${on ? `<i class="tr-live"></i>` : ""}</span>
      <div class="tr-main"><div class="tr-title"><b>${hl(m.n)}</b>${m.a ? "" : `<span class="badge" style="background:#f1f5f9;color:#475569">موقوف</span>`}${m.v ? `<span class="small muted">🚗 ${esc(m.v)}</span>` : ""}</div>
        <div class="small tr-sub">${st}${role === "driver" && m.d30 ? ` · ✅ ${num(m.d30)} توصيلة/30 يوم` : ""}</div></div>
      <div class="tr-meta small muted">${m.p ? `<span class="mono">${hl(m.p)}</span>` : ""}${m.e ? `<span dir="ltr">${hl(m.e)}</span>` : ""}</div>${wa(m)}
    </div>`;
  }

  // ------------------------------------------------------------ تفاعل
  function bind() {
    const tree = $("#tr-tree", host);
    tree.onclick = (e) => {
      const a = e.target.closest("[data-prof],[data-chart],[data-tg]"); if (!a || !tree.contains(a)) return;
      if (a.dataset.prof) { e.stopPropagation(); return opts.openStore && opts.openStore(Number(a.dataset.prof)); }
      if (a.dataset.chart) { e.stopPropagation(); T.chart = Number(a.dataset.chart); return drawChart(); }
      toggle(a.closest(".tr-node"));
    };
    tree.onkeydown = (e) => { if ((e.key === "Enter" || e.key === " ") && e.target.matches("[data-tg]")) { e.preventDefault(); toggle(e.target.closest(".tr-node")); } };
    $$(".o-seg button", host).forEach((b) => b.onclick = () => { T.status = b.dataset.st; draw(true); });
    let deb; $("#tr-q", host).oninput = (e) => { clearTimeout(deb); deb = setTimeout(() => { T.q = e.target.value; draw(true); const i = $("#tr-q", host); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }, 140); };
    $("#tr-on", host).onchange = (e) => { T.online = e.target.checked; draw(true); };
    $("#tr-exp", host).onclick = () => { tree.classList.add("tr-noanim"); $$(".tr-store", tree).forEach((n) => { openNode(n, true, true); $$(".tr-branch", n).forEach((b) => openNode(b, true, true)); }); requestAnimationFrame(() => tree.classList.remove("tr-noanim")); };
    $("#tr-col", host).onclick = () => { $$(".tr-node.open", tree).forEach((n) => openNode(n, false)); T.open.clear(); };
  }
  function toggle(node) { if (node) openNode(node, !node.classList.contains("open")); }
  function openNode(node, open, silent) {
    if (!node) return;
    const key = node.dataset.sid ? "s:" + node.dataset.sid : "b:" + node.dataset.bid;
    const kids = node.querySelector(":scope > .tr-kids > .tr-kids-in");
    if (open && !kids.dataset.built) {                       // رندر كسول عند أول فتح
      if (node.dataset.sid) { const s = T.byId.get(Number(node.dataset.sid)); kids.innerHTML = storeKids(s); }
      else { const [sid, bid] = node.dataset.bid.split(":").map(Number); const s = T.byId.get(sid); const b = bid ? s.branches.find((x) => x.id === bid) : { cashiers: s.un.cashiers, drivers: s.un.drivers }; kids.innerHTML = branchKids(b); }
      kids.dataset.built = "1";
      // عند البحث: افتح الفروع اللي فيها مطابقة تلقائياً
      if (q() && node.dataset.sid) $$(".tr-branch", kids).forEach((bn) => { const [sid, bid] = bn.dataset.bid.split(":").map(Number); const s = T.byId.get(sid); const b = bid ? s.branches.find((x) => x.id === bid) : { cashiers: s.un.cashiers, drivers: s.un.drivers }; if ([...b.cashiers, ...b.drivers].some(memHit)) openNode(bn, true, true); });
    }
    node.classList.toggle("open", open);
    if (open && !silent) { kids.classList.add("tr-anim"); clearTimeout(kids._t); kids._t = setTimeout(() => kids.classList.remove("tr-anim"), 1500); }
    node.querySelector(":scope > .tr-head").setAttribute("aria-expanded", open ? "true" : "false");
    if (open) T.open.add(key); else T.open.delete(key);
    if (!silent && open && node.dataset.sid) requestAnimationFrame(() => { const r = node.getBoundingClientRect(); if (r.top < 60) node.scrollIntoView({ behavior: "smooth", block: "start", inline: "nearest" }); });
  }

  // ------------------------------------------------------------ المخطط التنظيمي لمتجر واحد
  function drawChart() {
    const s = T.byId.get(T.chart);
    if (!s) { T.chart = null; return draw(true); }
    const card = (cls, avatar, title, sub, extra = "") => `<div class="tc-card ${cls}">${avatar}<div class="tc-t"><b>${title}</b>${sub ? `<div class="small">${sub}</div>` : ""}</div>${extra}</div>`;
    const mem = (m, role) => { const on = role === "driver" && m.on; return card(`tc-${role} ${m.a ? "" : "tr-off"} ${on ? "is-on" : ""}`, `<span class="tr-av tr-av-m">${ini(m.n)}${on ? `<i class="tr-live"></i>` : ""}</span>`, esc(m.n),
      role === "driver" ? (on ? `🟢 متصل${m.bz ? ` · ${num(m.bz)} بيده` : ""}` : `⚪ ${m.ls ? A.ago(m.ls) : "غير متصل"}`) : (role === "admin" ? "مدير المتجر" : "كاشير"), wa(m)); };
    const branch = (b, un, k = 0) => `<li class="tc-li" style="--k:${Math.min(k, 10)}">${card(`tc-branch ${b.active ? "" : "tr-off"}`, `<span class="tr-av tr-av-b">${un ? "❔" : "🏬"}</span>`, esc(b.name), `${b.city ? esc(b.city) + " · " : ""}${num(b.cashiers.length)} كاشير · ${num(b.drivers.length)} مندوب${b.oo ? ` · 📦 ${num(b.oo)}` : ""}`)}
      ${(b.cashiers.length || b.drivers.length) ? `<ul class="tc-ul tc-stack">${[...b.cashiers.map((m) => ["cashier", m]), ...b.drivers.map((m) => ["driver", m])].map(([r, m], j) => `<li class="tc-li" style="--k:${Math.min(j + k, 12)}">${mem(m, r)}</li>`).join("")}</ul>` : ""}</li>`;
    const kids = [...s.branches.map((b, k) => branch(b, false, k)), ...((s.un.cashiers.length || s.un.drivers.length) ? [branch({ name: "بدون فرع", city: "", active: true, oo: 0, cashiers: s.un.cashiers, drivers: s.un.drivers }, true, s.branches.length)] : [])];
    host.innerHTML = `
      <div class="tr-sum"><button class="btn btn-sm" id="tc-back">→ رجوع للشجرة</button><span class="spacer"></span>
        ${chip("🏬", s._n.br, "فرع")}${chip("👤", s._n.ca, "كاشير")}${chip("🛵", s._n.dr, "مندوب")}<span class="tr-chip ${s._n.on ? "tr-c-on" : "tr-c-off"}"><i class="${s._n.on ? "tr-pulse" : "tr-dot"}"></i> <b>${num(s._n.on)}</b> متصل</span>
        <button class="btn btn-sm" data-prof="${s.id}">👁️ ملف العميل</button></div>
      <div class="card tc-wrap"><div class="tc" dir="rtl">
        <ul class="tc-ul tc-root"><li class="tc-li">
          ${card("tc-store", av(s), esc(s.name), `<span class="mono">${esc(s.code)}</span> · ${badge(s.status)}${s.plan ? ` · ${PLAN[s.plan] || esc(s.plan)}` : ""}`)}
          ${s.admins.length ? `<ul class="tc-ul tc-admins">${s.admins.map((m) => `<li class="tc-li">${mem(m, "admin")}</li>`).join("")}</ul>` : ""}
          ${kids.length ? `<ul class="tc-ul tc-branches">${kids.join("")}</ul>` : `<div class="tr-empty" style="margin-top:18px">ما أضاف فروع ولا موظفين بعد</div>`}
        </li></ul>
      </div></div>`;
    $("#tc-back", host).onclick = () => { T.chart = null; draw(true); };
    requestAnimationFrame(() => { const r = $(".tc-store", host); if (r && r.scrollIntoView) r.scrollIntoView({ inline: "center", block: "nearest" }); });
    const p = $("[data-prof]", host); if (p) p.onclick = () => opts.openStore && opts.openStore(s.id);
  }

  window.MSAR_OWNER_TREE = { render, invalidate: () => { T.data = null; } };
})();
