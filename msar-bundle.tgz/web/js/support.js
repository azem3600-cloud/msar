/* مسار — قناة الدعم داخل التطبيق: مساعد ذكي + تذاكر + مرفقات (لوحة التاجر وتطبيق المندوب) */
(function () {
  const A = window.AZM; if (!A) return;
  const { sb, esc, toast } = A;
  const BUCKET = "support";
  const RESP = "المساعد يرد فوراً · فريق الدعم يرد عادة خلال يوم عمل (الأحد – الخميس)";
  const CHIPS = ["كيف أضيف فرع جديد؟", "كيف أدعو مندوب أو كاشير؟", "طلب ما وصل من زد، وش أسوي؟", "وش الفرق بين الباقات؟", "المندوب ما يظهر على الخريطة"];
  const ST = { open: ["مفتوحة", "#dbeafe", "#1d4ed8"], answered: ["تم الرد", "#dcfce7", "#166534"], closed: ["مغلقة", "#f1f5f9", "#475569"] };
  let user = null, root = null, tab = "ai", chat = [], pendingImg = null, ticketView = null, pollT = null;
  const conv = (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 12));

  const css = `
  .sp-fab{position:fixed;left:18px;bottom:calc(18px + var(--sp-offset,0px));z-index:1500;display:flex;align-items:center;gap:8px;background:#144F74;color:#fff;border:0;border-radius:8px;padding:10px 16px;font:inherit;font-weight:500;box-shadow:none;cursor:pointer}
  .sp-fab:hover{background:#0f3d5a}.sp-fab .sp-dot{min-width:20px;height:20px;border-radius:99px;background:#F5A126;font-size:12px;display:none;place-items:center;padding:0 5px}
  .sp-fab.has .sp-dot{display:grid}
  .sp-panel{position:fixed;left:18px;bottom:calc(80px + var(--sp-offset,0px));z-index:1501;width:min(410px,calc(100vw - 24px));height:min(640px,calc(100vh - 110px));background:#fff;border-radius:22px;box-shadow:0 30px 70px -20px #0b2b3e88;display:flex;flex-direction:column;overflow:hidden;font-size:14px;direction:rtl}
  @media(max-width:560px){.sp-panel{left:0;right:0;bottom:0;width:100%;height:100%;border-radius:0}}
  @media(max-width:600px){.sp-fab{padding:0;width:50px;height:50px;justify-content:center;left:12px;bottom:calc(14px + var(--sp-offset,0px))}.sp-fab span:nth-child(2){display:none}.sp-fab span:first-child{font-size:22px}.sp-fab .sp-dot{position:absolute;top:-4px;right:-4px}}
  .sp-hd{background:#144F74;color:#fff;padding:14px 16px}
  .sp-hd b{font-size:17px}.sp-hd small{display:block;opacity:.85;font-size:12px;margin-top:2px}
  .sp-x{float:left;background:rgba(255,255,255,.15);border:0;color:#fff;width:32px;height:32px;border-radius:10px;cursor:pointer;font-size:16px}
  .sp-tabs{display:flex;gap:4px;margin-top:10px}.sp-tabs button{flex:1;border:0;border-radius:10px;padding:8px 6px;background:rgba(255,255,255,.12);color:#fff;font:inherit;font-weight:700;cursor:pointer;font-size:13px}
  .sp-tabs button.on{background:#fff;color:#144F74}.sp-tabs i{font-style:normal;background:#F5A126;color:#fff;border-radius:99px;padding:0 6px;margin-inline-start:4px;font-size:11px}
  .sp-bd{flex:1;overflow:auto;padding:14px;background:#f4f9fb}
  .sp-ft{border-top:1px solid #e3eef3;padding:10px;background:#fff}
  .sp-m{max-width:88%;padding:10px 12px;border-radius:16px;margin-bottom:10px;line-height:1.7;white-space:pre-wrap;word-wrap:break-word}
  .sp-m.u{background:#144F74;color:#fff;margin-inline-start:auto;border-end-start-radius:4px}
  .sp-m.a{background:#fff;border:1px solid #e3eef3;border-end-end-radius:4px}
  .sp-m.s{background:#ecf7e6;border:1px solid #cfe8bf}
  .sp-who{font-size:11px;color:#7c939b;margin-bottom:3px;font-weight:700}
  .sp-chips{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0 4px}.sp-chips button{border:1px solid #cfe4ee;background:#fff;color:#144F74;border-radius:99px;padding:6px 11px;font:inherit;font-size:13px;cursor:pointer}
  .sp-row{display:flex;gap:6px;align-items:flex-end}.sp-row textarea{flex:1;resize:none;border:1.5px solid #e3eef3;border-radius:14px;padding:9px 11px;font:inherit;max-height:120px;min-height:42px}
  .sp-ib{width:42px;height:42px;border-radius:12px;border:1px solid #e3eef3;background:#fff;cursor:pointer;font-size:18px;flex:none}
  .sp-send{background:#159FC6;color:#fff;border:0;transform:scaleX(-1)}
  .sp-esc{display:flex;gap:6px;flex-wrap:wrap;margin:-4px 0 12px}.sp-esc button{border:0;border-radius:10px;padding:7px 11px;font:inherit;font-size:13px;font-weight:700;cursor:pointer}
  .sp-esc .go{background:#F5A126;color:#fff}.sp-esc .ok{background:#eef6f9;color:#144F74}
  .sp-att{display:flex;gap:6px;flex-wrap:wrap;margin-top:6px}.sp-att a,.sp-att span{display:inline-flex;align-items:center;gap:4px;font-size:12px;background:#eef6f9;border-radius:8px;padding:3px 7px;color:#144F74}
  .sp-att img{width:96px;height:72px;object-fit:cover;border-radius:8px;display:block}
  .sp-prev{display:flex;align-items:center;gap:8px;background:#eef6f9;border-radius:10px;padding:6px 8px;margin-bottom:6px;font-size:12px}.sp-prev img{width:40px;height:40px;object-fit:cover;border-radius:6px}
  .sp-t{background:#fff;border:1px solid #e3eef3;border-radius:14px;padding:11px 12px;margin-bottom:8px;cursor:pointer;display:block;width:100%;text-align:start;font:inherit}
  .sp-t:hover{border-color:#159FC6}.sp-t b{display:block}.sp-t small{color:#7c939b}.sp-chip{display:inline-block;border-radius:6px;padding:1px 7px;font-size:11px;font-weight:700;margin-inline-start:6px}
  .sp-new{position:relative}.sp-new:after{content:"";position:absolute;top:12px;left:12px;width:9px;height:9px;border-radius:50%;background:#F5A126}
  .sp-f label{display:block;font-weight:700;font-size:13px;margin-bottom:10px;color:#47616a}.sp-f input,.sp-f textarea{width:100%;border:1.5px solid #e3eef3;border-radius:12px;padding:10px;font:inherit;margin-top:4px;box-sizing:border-box}
  .sp-btn{border:0;border-radius:12px;padding:10px 16px;font:inherit;font-weight:700;cursor:pointer;background:#144F74;color:#fff}.sp-btn.gh{background:#eef6f9;color:#144F74}
  .sp-note{font-size:12px;color:#7c939b;text-align:center;margin:4px 0 0}
  .sp-typing span{display:inline-block;width:7px;height:7px;border-radius:50%;background:#9fbfcc;margin:0 2px;animation:spb 1s infinite}.sp-typing span:nth-child(2){animation-delay:.15s}.sp-typing span:nth-child(3){animation-delay:.3s}
  @keyframes spb{50%{transform:translateY(-5px)}}`;

  const fmt = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
    .replace(/!\[([^\]]{0,80})\]\((https:\/\/[^\s)"'<>]+)\)/g, '<a href="$2" target="_blank" rel="noopener"><img class="sp-img" src="$2" alt="$1" loading="lazy" style="max-width:100%;border-radius:10px;margin-top:6px;display:block"></a>')
    .replace(/\[([^\]]{1,80})\]\((https:\/\/[^\s)"'<>]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  const el = (h) => { const d = document.createElement("div"); d.innerHTML = h.trim(); return d.firstElementChild; };
  const ago = (d) => A.fmtDateTime ? A.fmtDateTime(d) : new Date(d).toLocaleString("ar-SA");

  // ------------------------------------------------------------------ المرفقات
  async function shrink(file, max = 1400) {
    if (!/^image\/(png|jpeg|webp)$/.test(file.type)) return { blob: file, type: file.type };
    const img = await new Promise((r, j) => { const i = new Image(); i.onload = () => r(i); i.onerror = j; i.src = URL.createObjectURL(file); });
    const k = Math.min(1, max / Math.max(img.width, img.height));
    const c = document.createElement("canvas"); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
    c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
    const blob = await new Promise((r) => c.toBlob(r, "image/jpeg", 0.85));
    return { blob, type: "image/jpeg" };
  }
  async function upload(file) {
    if (file.size > 6 * 1024 * 1024) throw new Error("الحد الأقصى للملف 6MB");
    const { blob, type } = await shrink(file);
    const name = (file.name || "file").replace(/\.[^.]+$/, "").replace(/[^A-Za-z0-9._-]+/g, "-").slice(0, 60) || "file";
    const ext = type === "application/pdf" ? "pdf" : type.split("/")[1].replace("jpeg", "jpg");
    const path = `${user.id}/${Date.now()}-${name}.${ext}`;
    const { error } = await sb.storage.from(BUCKET).upload(path, blob, { contentType: type, upsert: false });
    if (error) throw new Error("تعذر رفع الملف: " + error.message);
    return { path, name: file.name || name, type, blob };
  }
  const b64 = (blob) => new Promise((r) => { const f = new FileReader(); f.onload = () => r(String(f.result).split(",")[1]); f.readAsDataURL(blob); });
  async function attHtml(list) {
    if (!list?.length) return "";
    const items = await Promise.all(list.map(async (a) => {
      const { data } = await sb.storage.from(BUCKET).createSignedUrl(a.path, 3600);
      const u = data?.signedUrl; if (!u) return `<span>📎 ${esc(a.name)}</span>`;
      return /image/.test(a.type) || /\.(png|jpe?g|webp|gif)$/i.test(a.path) ? `<a href="${u}" target="_blank" rel="noopener"><img src="${u}" alt="${esc(a.name)}"></a>` : `<a href="${u}" target="_blank" rel="noopener">📎 ${esc(a.name)}</a>`;
    }));
    return `<div class="sp-att">${items.join("")}</div>`;
  }

  // ------------------------------------------------------------------ الواجهة
  function mount() {
    if (document.getElementById("sp-fab")) return;
    const st = document.createElement("style"); st.textContent = css; document.head.appendChild(st);
    const fab = el(`<button class="sp-fab" id="sp-fab" aria-label="الدعم الفني"><span>🛟</span><span>الدعم</span><span class="sp-dot" id="sp-dot"></span></button>`);
    document.body.appendChild(fab);
    fab.onclick = () => (root ? close() : open());
    if (/driver/.test(location.pathname)) document.documentElement.style.setProperty("--sp-offset", "70px");
    root = null; poll(); pollT = setInterval(poll, 60000);
  }
  async function poll() {
    try { const n = await A.rpc("support_unread"); const f = document.getElementById("sp-fab"); if (!f) return; f.classList.toggle("has", n > 0); document.getElementById("sp-dot").textContent = n || ""; window.__spUnread = n; } catch (_) {}
  }
  function close() { root?.remove(); root = null; }
  function open(t) {
    close(); if (t) tab = t;
    root = el(`<div class="sp-panel" role="dialog" aria-label="الدعم الفني"><div class="sp-hd"><button class="sp-x" aria-label="إغلاق">✕</button><b>🛟 الدعم الفني</b><small>${RESP}</small>
      <div class="sp-tabs"><button data-t="ai">💬 المساعد</button><button data-t="list">🎫 تذاكري${window.__spUnread ? `<i>${window.__spUnread}</i>` : ""}</button><button data-t="new">➕ تذكرة جديدة</button></div></div>
      <div class="sp-bd" id="sp-bd"></div><div class="sp-ft" id="sp-ft"></div></div>`);
    document.body.appendChild(root);
    root.querySelector(".sp-x").onclick = close;
    root.querySelectorAll("[data-t]").forEach((b) => b.onclick = () => { tab = b.dataset.t; ticketView = null; draw(); });
    draw();
  }
  function draw() {
    root.querySelectorAll("[data-t]").forEach((b) => b.classList.toggle("on", b.dataset.t === tab));
    if (ticketView) return drawTicket(ticketView);
    if (tab === "ai") return drawAi();
    if (tab === "list") return drawList();
    return drawNew();
  }

  // ------------------------------------------------------------------ المساعد
  function drawAi() {
    const bd = root.querySelector("#sp-bd"), ft = root.querySelector("#sp-ft");
    bd.innerHTML = `<div class="sp-m a"><div class="sp-who">مساعد مسار</div>هلا ${esc((user.full_name || "").split(" ")[0])} 👋 أنا مساعد مسار. اسألني عن أي شي في المنصة، وتقدر ترفق لقطة شاشة 📎. إذا احتجت موظف، أحوّلك لتذكرة.</div>
      ${chat.length ? "" : `<div class="sp-chips">${CHIPS.map((c) => `<button>${esc(c)}</button>`).join("")}</div>`}
      <div id="sp-msgs">${chat.map((m, i) => msgHtml(m, i)).join("")}</div>`;
    bd.querySelectorAll(".sp-chips button").forEach((b) => b.onclick = () => ask(b.textContent));
    bindEsc(bd);
    ft.innerHTML = `${pendingImg ? `<div class="sp-prev"><img src="${URL.createObjectURL(pendingImg.blob)}"><span>${esc(pendingImg.name)}</span><span style="flex:1"></span><button class="sp-ib" style="width:30px;height:30px" id="sp-rmimg">✕</button></div>` : ""}
      <div class="sp-row"><label class="sp-ib" title="إرفاق لقطة شاشة" style="display:grid;place-items:center">📎<input type="file" accept="image/png,image/jpeg,image/webp" hidden id="sp-file"></label>
      <textarea id="sp-in" rows="1" placeholder="اكتب سؤالك…" maxlength="2000"></textarea><button class="sp-ib sp-send" id="sp-go" aria-label="إرسال">➤</button></div>
      <p class="sp-note">المساعد يجاوب من دليل مسار. للمشاكل الخاصة بحسابك افتح تذكرة.</p>`;
    const inp = ft.querySelector("#sp-in");
    inp.onkeydown = (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); ask(inp.value); } };
    ft.querySelector("#sp-go").onclick = () => ask(inp.value);
    ft.querySelector("#sp-file").onchange = async (e) => { const f = e.target.files[0]; if (!f) return; try { pendingImg = await upload(f); drawAi(); } catch (er) { toast(A.errMsg(er), "error"); } };
    const rm = ft.querySelector("#sp-rmimg"); if (rm) rm.onclick = () => { pendingImg = null; drawAi(); };
    bd.scrollTop = bd.scrollHeight; inp.focus();
    // صور المحادثة
    chat.forEach(async (m, i) => { if (m.attachments?.length) { const h = await attHtml(m.attachments); const n = bd.querySelector(`[data-att="${i}"]`); if (n) n.innerHTML = h; } });
  }
  function msgHtml(m, i) {
    if (m.role === "typing") return `<div class="sp-m a sp-typing"><span></span><span></span><span></span></div>`;
    const last = i === chat.length - 1 && m.role === "ai";
    return `<div class="sp-m ${m.role === "user" ? "u" : "a"}">${m.role === "ai" ? `<div class="sp-who">مساعد مسار</div>` : ""}${fmt(m.text)}<div data-att="${i}"></div></div>
      ${last ? `<div class="sp-esc">${m.escalate ? `<button class="go" data-esc>📨 حوّلها لتذكرة لفريق الدعم</button>` : `<button class="ok" data-esc>📨 أحتاج موظف</button>`}</div>` : ""}`;
  }
  function bindEsc(bd) {
    bd.querySelectorAll("[data-esc]").forEach((b) => b.onclick = () => { tab = "new"; draw(); });
    bd.querySelectorAll("[data-solved]").forEach((b) => b.onclick = () => { b.parentNode.innerHTML = `<span class="sp-note">سعيدين إنها انحلّت 🌟</span>`; });
  }
  async function ask(text) {
    text = String(text || "").trim();
    if (!text && !pendingImg) return;
    if (!text) text = "شوف لقطة الشاشة المرفقة";
    const img = pendingImg; pendingImg = null;
    chat.push({ role: "user", text, attachments: img ? [{ path: img.path, name: img.name, type: img.type }] : [] });
    chat.push({ role: "typing" }); drawAi();
    try {
      const r = await A.callFn("support", { action: "ask", conv, page: location.pathname.split("/").pop() + location.hash,
        messages: chat.filter((m) => m.role !== "typing").map((m) => ({ role: m.role, text: m.text })),
        image: img && /^image\//.test(img.type) ? { type: img.type, data: await b64(img.blob) } : null });
      chat.pop(); chat.push({ role: "ai", text: r.answer, escalate: !!r.escalate });
    } catch (e) {
      chat.pop(); chat.push({ role: "ai", text: "صار خطأ في الاتصال بالمساعد. تقدر تفتح تذكرة مباشرة وفريق الدعم يرد عليك.", escalate: true });
    }
    if (root && tab === "ai") drawAi();
  }

  // ------------------------------------------------------------------ تذكرة جديدة
  let draftAtt = [];
  function drawNew() {
    const bd = root.querySelector("#sp-bd"), ft = root.querySelector("#sp-ft");
    const fromChat = chat.filter((m) => m.role === "user" || m.role === "ai");
    const firstQ = fromChat.find((m) => m.role === "user")?.text || "";
    const chatAtt = fromChat.flatMap((m) => m.attachments || []);
    bd.innerHTML = `<form class="sp-f" id="sp-nf">
      ${fromChat.length ? `<div class="sp-m a" style="max-width:100%"><div class="sp-who">بنرفق محادثتك مع المساعد (${fromChat.length} رسائل)${chatAtt.length ? ` و${chatAtt.length} مرفق` : ""} عشان فريق الدعم يفهم المشكلة</div></div>` : ""}
      <label>عنوان المشكلة<input name="s" maxlength="200" required value="${esc(firstQ.slice(0, 120))}" placeholder="مثال: الطلبات ما توصل لفرع العليا"></label>
      <label>اشرح المشكلة بالتفصيل<textarea name="b" rows="6" required maxlength="6000" placeholder="وش صار؟ ومتى؟ رقم الطلب إن وجد…"></textarea></label>
      <label>مرفقات (لقطات شاشة أو PDF — حتى 4)<input type="file" name="f" accept="image/png,image/jpeg,image/webp,application/pdf" multiple></label>
      <div id="sp-da" class="sp-att">${draftAtt.map((a) => `<span>📎 ${esc(a.name)}</span>`).join("")}</div>
      <p class="sp-note">⏱️ نرد عادة خلال يوم عمل. ستصلك الإجابة هنا في "تذاكري". لا ترسل كلمات مرور أبداً.</p></form>`;
    ft.innerHTML = `<button class="sp-btn" id="sp-send" style="width:100%">📨 إرسال التذكرة</button>`;
    const f = bd.querySelector("#sp-nf");
    f.f.onchange = async () => {
      for (const file of [...f.f.files].slice(0, 4 - draftAtt.length)) { try { draftAtt.push(await upload(file)); } catch (e) { toast(A.errMsg(e), "error"); } }
      f.f.value = ""; bd.querySelector("#sp-da").innerHTML = draftAtt.map((a) => `<span>📎 ${esc(a.name)}</span>`).join("");
    };
    ft.querySelector("#sp-send").onclick = async (e) => {
      if (!f.s.reportValidity() || !f.b.reportValidity()) return;
      e.target.disabled = true;
      try {
        const id = await A.rpc("support_ticket_create", { p_subject: f.s.value, p_body: f.b.value,
          p_attachments: draftAtt.map(({ path, name, type }) => ({ path, name, type })),
          p_transcript: fromChat.map((m) => ({ role: m.role, text: m.text, attachments: m.attachments || [] })),
          p_page: location.pathname.split("/").pop() + location.hash });
        draftAtt = []; chat = [];
        toast("وصلت تذكرتك ✅ رقمها #" + id, "ok");
        ticketView = id; tab = "list"; draw();
      } catch (er) { toast(A.errMsg(er), "error"); e.target.disabled = false; }
    };
  }

  // ------------------------------------------------------------------ تذاكري
  async function drawList() {
    const bd = root.querySelector("#sp-bd"), ft = root.querySelector("#sp-ft");
    ft.innerHTML = `<button class="sp-btn gh" style="width:100%" id="sp-nt">➕ تذكرة جديدة</button>`;
    ft.querySelector("#sp-nt").onclick = () => { tab = "new"; draw(); };
    bd.innerHTML = `<p class="sp-note">جاري التحميل…</p>`;
    const { data, error } = await sb.from("support_tickets").select("id, subject, status, updated_at, user_unread").eq("user_id", user.id).order("updated_at", { ascending: false }).limit(50);
    if (error) { bd.innerHTML = `<p class="sp-note">${esc(error.message)}</p>`; return; }
    bd.innerHTML = data.length ? data.map((t) => { const s = ST[t.status] || ST.open; return `<button class="sp-t ${t.user_unread ? "sp-new" : ""}" data-id="${t.id}"><b>#${t.id} · ${esc(t.subject)}</b>
      <small>${ago(t.updated_at)}</small><span class="sp-chip" style="background:${s[1]};color:${s[2]}">${s[0]}</span></button>`; }).join("")
      : `<div class="sp-m a" style="max-width:100%">ما عندك تذاكر. جرّب تسأل المساعد أولاً، أو افتح تذكرة جديدة.</div>`;
    bd.querySelectorAll("[data-id]").forEach((b) => b.onclick = () => { ticketView = Number(b.dataset.id); draw(); });
  }
  async function drawTicket(id) {
    const bd = root.querySelector("#sp-bd"), ft = root.querySelector("#sp-ft");
    bd.innerHTML = `<p class="sp-note">جاري التحميل…</p>`;
    const [{ data: t }, { data: ms }] = await Promise.all([
      sb.from("support_tickets").select("*").eq("id", id).single(),
      sb.from("support_messages").select("*").eq("ticket_id", id).order("id"),
    ]);
    A.rpc("support_ticket_seen", { p_ticket: id }).then(poll).catch(() => {});
    if (!t) { bd.innerHTML = `<p class="sp-note">التذكرة غير موجودة</p>`; return; }
    const s = ST[t.status] || ST.open;
    bd.innerHTML = `<button class="sp-btn gh" id="sp-back" style="margin-bottom:10px">→ رجوع</button>
      <div style="margin-bottom:10px"><b>#${t.id} · ${esc(t.subject)}</b><span class="sp-chip" style="background:${s[1]};color:${s[2]}">${s[0]}</span></div>
      ${(ms || []).map((m, i) => `<div class="sp-m ${m.sender === "user" ? "u" : m.sender === "staff" ? "s" : "a"}"><div class="sp-who" ${m.sender === "user" ? 'style="color:#cfe6f0"' : ""}>${m.sender === "user" ? "أنت" : m.sender === "staff" ? "فريق دعم مسار" : "مساعد مسار"} · ${ago(m.created_at)}</div>${fmt(m.body)}<div data-tatt="${i}"></div></div>`).join("")}`;
    bd.querySelector("#sp-back").onclick = () => { ticketView = null; draw(); };
    (ms || []).forEach(async (m, i) => { if (m.attachments?.length) { const n = bd.querySelector(`[data-tatt="${i}"]`); if (n) n.innerHTML = await attHtml(m.attachments); } });
    let att = [];
    ft.innerHTML = t.status === "closed" ? `<div class="sp-row"><span class="sp-note" style="flex:1">التذكرة مغلقة</span><button class="sp-btn gh" id="sp-reo">إعادة فتح</button></div>`
      : `<div id="sp-ra" class="sp-att" style="margin:0 0 6px"></div><div class="sp-row"><label class="sp-ib" style="display:grid;place-items:center" title="إرفاق">📎<input type="file" hidden accept="image/png,image/jpeg,image/webp,application/pdf" id="sp-rf"></label>
        <textarea id="sp-rt" rows="1" placeholder="اكتب ردك…" maxlength="6000"></textarea><button class="sp-ib sp-send" id="sp-rs">➤</button></div>
        <div class="sp-row" style="margin-top:6px"><span style="flex:1"></span><button class="sp-btn gh" id="sp-cl" style="padding:6px 10px;font-size:12px">✅ انحلّت — أغلق التذكرة</button></div>`;
    const reo = ft.querySelector("#sp-reo"); if (reo) reo.onclick = async () => { await A.rpc("support_ticket_status", { p_ticket: id, p_status: "open" }); draw(); };
    const rf = ft.querySelector("#sp-rf");
    if (rf) {
      rf.onchange = async () => { const f = rf.files[0]; if (!f) return; try { att.push(await upload(f)); ft.querySelector("#sp-ra").innerHTML = att.map((a) => `<span>📎 ${esc(a.name)}</span>`).join(""); } catch (e) { toast(A.errMsg(e), "error"); } rf.value = ""; };
      ft.querySelector("#sp-rs").onclick = async (e) => {
        const txt = ft.querySelector("#sp-rt").value.trim(); if (!txt && !att.length) return;
        e.target.disabled = true;
        try { await A.rpc("support_ticket_reply", { p_ticket: id, p_body: txt, p_attachments: att.map(({ path, name, type }) => ({ path, name, type })) }); draw(); }
        catch (er) { toast(A.errMsg(er), "error"); e.target.disabled = false; }
      };
      ft.querySelector("#sp-cl").onclick = async () => { await A.rpc("support_ticket_status", { p_ticket: id, p_status: "closed" }); toast("تم إغلاق التذكرة", "ok"); draw(); };
    }
    bd.scrollTop = bd.scrollHeight;
  }

  // ------------------------------------------------------------------ التشغيل بعد تسجيل الدخول
  async function check() {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) { document.getElementById("sp-fab")?.remove(); close(); clearInterval(pollT); user = null; return; }
    if (user?.id === session.user.id) return;
    const { data: p } = await sb.from("profiles").select("id, full_name, role").eq("id", session.user.id).maybeSingle();
    if (!p || p.role === "owner") return; // صاحب المنصة يرد من لوحته
    user = p; mount();
  }
  sb.auth.onAuthStateChange(() => setTimeout(check, 300));
  setTimeout(check, 1200);
  window.MSAR_SUPPORT = { open: (t) => { if (user) open(t); } };
})();
