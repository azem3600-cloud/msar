/* مسار — لوحة تحكم المتجر وشاشة الكاشير */
(function () {
  const A = window.AZM;
  const { sb, $, $$, esc, money, num, STATUS, ROLES, ACTIVE, toast } = A;
  const app = $("#app");

  const S = {
    me: null, branches: [], staff: [], orders: new Map(), route: "live",
    filter: { branch: "", q: "" }, muted: false, seen: new Set(), channel: null,
    maps: {}, lastLoad: 0, radius: 5, fx: {},
  };
  const isAdmin = () => S.me?.role === "admin";
  const branchName = (id) => S.branches.find((b) => b.id === id)?.name || "بدون فرع";
  const staffName = (id) => S.staff.find((p) => p.id === id)?.full_name || "—";
  const drivers = (branchId) => S.staff.filter((p) => p.role === "driver" && p.is_active && (!branchId || p.branch_id === branchId));
  const activeCountFor = (driverId) => [...S.orders.values()].filter((o) => o.driver_id === driverId && ["assigned", "out_for_delivery"].includes(o.status)).length;

  // =================================================================== boot
  async function boot() {
    A.unlockAudio();
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return renderLogin(A.oauthErrorMsg());
    try {
      S.me = await A.resolveProfile();
    } catch (e) { toast(A.errMsg(e), "error"); return renderLogin(); }
    if (!S.me) { await sb.auth.signOut(); return renderLogin("حسابك غير مرتبط بأي متجر فعّال — اطلب من التاجر يرسل لك دعوة"); }
    if (!S.me.is_active) { await sb.auth.signOut(); return renderLogin("الحساب موقوف"); }
    if (S.me.role === "driver") { location.href = "driver"; return; }
    if (S.me.role === "owner") return renderOwnerNotice();
    if (!A.store || !["trial", "active"].includes(A.store.status)) return renderSuspended();
    if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
    if ("Notification" in window && Notification.permission === "default") Notification.requestPermission().catch(() => {});
    try { S.plan = await A.rpc("my_plan"); } catch (_) { S.plan = null; }
    try { S.wa = !!(await A.rpc("my_wa_enabled")); } catch (_) { S.wa = false; } // ميزة الواتساب (مخفية افتراضياً، يفعّلها المدير)
    // مفاتيح المزايا: يتحكم فيها المدير من لوحته. لو الدالة غير موجودة = كل المزايا الجديدة مطفية.
    try { S.fx = (await A.rpc("app_features")) || {}; } catch (_) { S.fx = {}; }
    applyTheme();
    if (window.MSAR_LANG && window.MSAR_LANG.isEn && !S.fx.english) return window.MSAR_LANG.set("ar");
    renderShell();
    await Promise.all([loadBranches(), loadStaff(), loadRadius()]);
    await loadOrders();
    subscribe();
    route();
    window.addEventListener("hashchange", route);
    setInterval(() => { if (S.route === "live") renderLive(true); }, 30000);
    setInterval(() => loadOrders().then(() => S.route === "live" && renderLive(true)), 90000);
    if (isAdmin() && !S.branches.length && !S.fx.wizard) { location.hash = "#branches"; welcome(); }
  }

  // المدير (صاحب المنصة) ما له متجر: نوضح له بدل التحويل الصامت
  function renderOwnerNotice() {
    app.innerHTML = `<div class="login-page"><div class="login-card" style="text-align:center">
      <div class="logo" style="justify-content:center"><img class="logo-mark" src="icons/logo.png" alt="مسار">مسار</div>
      <div style="font-size:44px;margin-top:14px">👑</div>
      <h3>أنت داخل بحساب المدير</h3>
      <p class="muted">لوحة التاجر تفتح بحساب متجر (تاجر أو كاشير). المتصفح يحفظ حساب واحد في نفس الوقت، فعشان تدخل لوحة متجر سجّل خروج وادخل بحساب المتجر، أو افتحها في نافذة خاصة (Incognito).</p>
      <a class="btn btn-primary btn-block" href="owner">الرجوع للوحة المدير</a>
      <button class="btn btn-block" id="sw" style="margin-top:8px">تسجيل خروج والدخول بحساب متجر</button></div></div>`;
    $("#sw").onclick = async () => { try { await sb.auth.signOut(); } catch (_) {} location.replace(location.pathname); };
  }

  function renderSuspended() {
    app.innerHTML = `<div class="login-page"><div class="login-card" style="text-align:center">
      <div class="logo" style="justify-content:center"><img class="logo-mark" src="icons/logo.png" alt="مسار">مسار</div>
      <div style="font-size:48px;margin-top:16px">⏸️</div>
      <h3>اشتراك المتجر موقوف</h3>
      <p class="muted">${esc(A.store?.name || "")} — تقدر تفعّل الاشتراك من متجر تطبيقات ${A.platformName()}، أو تواصل مع فريق مسار.</p>
      <button class="btn btn-block" id="lo">تسجيل خروج</button></div></div>`;
    $("#lo").onclick = A.logout;
  }

  function welcome() {
    A.modal({ title: "👋 أهلاً بك في مسار", body: `
      <p class="lead">متجرك <b>${esc(A.store?.name || "")}</b> مربوط. باقي 3 خطوات ويصير كل شي يشتغل تلقائياً:</p>
      <ol style="line-height:2.1">
        <li><b>أضف فروعك</b> بالضغط على موقع كل فرع في الخريطة (هنا في صفحة الفروع).</li>
        <li><b>حدد نطاق التوصيل</b> من صفحة "نطاق التوصيل" (الافتراضي 5 كم).</li>
        <li><b>أضف الكاشير والمناديب</b> من صفحة "الموظفين والمناديب"، وحمّلهم تطبيق المندوب.</li>
      </ol>
      <p class="small muted">رمز متجرك للدخول: <b class="mono">${esc(A.store?.code || "")}</b> — يحتاجه الموظفين والمناديب عند تسجيل الدخول.</p>`,
      actions: [{ label: "يلا نبدأ", cls: "btn-primary" }] });
  }

  // =================================================================== login
  async function renderLogin(msg) {
    app.innerHTML = `<div class="auth">
      <section class="auth-form">
        <header class="auth-top"><a class="auth-logo" href="./"><img src="icons/logo.png" alt=""><b>مسار</b></a></header>
        <form class="auth-box" id="login-form" novalidate>
          <h1>حياك في مسار</h1>
          <p class="auth-sub">سجّل دخولك وتابع طلبات متجرك وفروعك من مكان واحد</p>
          ${msg ? `<p class="auth-msg">${esc(msg)}</p>` : ""}
          <label class="auth-field"><span>الإيميل أو اسم المستخدم</span>
            <input name="u" autocomplete="username" required dir="ltr" autocapitalize="none" spellcheck="false" placeholder="name@example.com"></label>
          <label class="auth-field hidden" id="code-field"><span>رمز المتجر</span>
            <input name="c" dir="ltr" autocapitalize="none" spellcheck="false" value="${esc(A.savedStore())}" placeholder="مثال: mystore">
            <small>تدخل باسم مستخدم؟ اكتب رمز متجرك (تلقاه عند التاجر). الدخول بالإيميل ما يحتاجه.</small></label>
          <label class="auth-field"><span class="auth-row"><span>كلمة المرور</span><a href="#" id="forgot" tabindex="-1">نسيت كلمة المرور؟</a></span>
            <input name="p" type="password" autocomplete="current-password" required dir="ltr"></label>
          <button class="auth-btn" type="submit">دخول</button>
          <div class="or-sep"><span>أو</span></div>
          <div class="g-box" id="g-login"></div>
          <p class="auth-alt">ثبّت مسار من ${A.platformName ? esc(A.platformName()) : "زد"} وما كمّلت إنشاء حسابك؟ <a href="https://api.msarpro.com/zid?action=install">كمّل الإعداد</a></p>
        </form>
        <footer class="auth-foot"><a href="driver">تطبيق المندوب</a><i></i><a href="support">الدعم</a></footer>
      </section>
      <aside class="auth-art" aria-hidden="true">
        <div class="auth-scene">
          <svg class="auth-path" viewBox="0 0 420 260" preserveAspectRatio="none"><path d="M30 215 C 120 215, 110 130, 205 130 S 300 45, 392 45" /></svg>
          <span class="auth-node n1"></span><span class="auth-node n2"></span><span class="auth-node n3"></span>
          <div class="auth-chip c1"><b>طلب جديد #1042</b><small>توجّه لأقرب فرع · 2.1 كم</small></div>
          <div class="auth-chip c2"><b>مع المندوب</b><small>في الطريق · 8 دقايق</small></div>
          <div class="auth-chip c3"><b>تم التسليم</b><small>العميل قيّم الطلب 5 من 5</small></div>
        </div>
        <h2>كل طلب في مساره</h2>
        <p>الطلب يوصل، يتوجّه لأقرب فرع، ويطلع مع المندوب، وأنت تتابع كل شي من شاشة وحدة.</p>
        <div class="auth-bars"><i></i><i></i><i></i></div>
      </aside>
    </div>`;
    const lf = $("#login-form");
    // رمز المتجر يظهر فقط لمن يدخل باسم مستخدم (بدون @)
    const syncCode = () => { const v = lf.u.value.trim(), need = !!v && !v.includes("@"); $("#code-field").classList.toggle("hidden", !need); lf.c.required = need; };
    lf.u.oninput = syncCode; lf.u.onchange = syncCode; syncCode(); setTimeout(syncCode, 600);
    A.bindAuthExtras(lf, () => lf.u.value);
    lf.onsubmit = async (e) => {
      e.preventDefault();
      const f = e.target, btn = $("button[type=submit]", f);
      syncCode();
      if (!f.u.value.trim() || !f.p.value) return toast("اكتب الإيميل أو اسم المستخدم وكلمة المرور", "error");
      if (f.c.required && !f.c.value.trim()) { f.c.focus(); return toast("اكتب رمز المتجر — مطلوب للدخول باسم المستخدم", "error"); }
      btn.disabled = true; btn.textContent = "جاري الدخول…";
      try { await A.login(f.u.value, f.p.value, f.c.value); location.replace(location.pathname); }
      catch (err) { toast(A.errMsg(err), "error"); btn.disabled = false; btn.textContent = "دخول"; }
    };
  }

  // =================================================================== shell
  const NAV = [
    { id: "live", icon: "📋", label: "الطلبات الحالية" },
    { id: "map", icon: "🗺️", label: "الخريطة المباشرة" },
    { id: "orders", icon: "🗂️", label: "سجل الطلبات" },
    { id: "reports", icon: "📊", label: "التقارير" },
    { id: "staff", icon: "👥", label: "الموظفين والمناديب" },
    { id: "branches", icon: "🏪", label: "الفروع", admin: true },
    { id: "routing", icon: "🎯", label: "نطاق التوصيل", admin: true },
    { id: "wa", icon: "💬", label: "الواتساب", admin: true, wa: true },
    { id: "brand", icon: "🎨", label: "هوية المتجر", admin: true },
    { id: "settings", icon: "⚙️", label: "الربط مع {PN} والإعدادات", admin: true },
  ];

  function renderShell() {
    app.innerHTML = `<div class="shell">
      <aside class="side" id="side">
        <div class="logo"><img class="logo-mark" src="icons/logo.png" alt="مسار"><div>${esc(A.store?.name || "مسار")}<div class="small" style="opacity:.7;font-weight:600">${isAdmin() ? "لوحة التاجر · مسار" : "صفحة الكاشير · " + esc(S.me.branch?.name || "")}</div></div></div>
        <nav class="nav">${NAV.filter((n) => (!n.admin || isAdmin()) && (!n.wa || S.wa)).map((n) =>
          `<a href="#${n.id}" data-r="${n.id}"><span>${n.icon}</span>${n.label.replace("{PN}", A.platformName())}${n.id === "live" ? `<span class="count hidden" id="nav-count"></span>` : ""}</a>`).join("")}</nav>
        <div class="side-foot">
          ${S.plan ? `<button class="plan-pill" id="plan-btn" title="تفاصيل الباقة">💳 باقة ${esc(S.plan.name_ar || "")}${isAdmin() && S.plan.code !== "pro" ? ` <u>ترقية</u>` : ""}</button>` : ""}
          <div class="side-user"><b>${esc(S.me.full_name)}</b> · ${ROLES[S.me.role]}</div>
          <div class="row" style="margin-top:8px">
            <button class="btn btn-sm" id="mute-btn">🔔 الصوت مفعل</button>
            <button class="btn btn-sm" id="account-btn">👤 حسابي</button>
            <button class="btn btn-sm" id="logout-btn">خروج</button>
          </div>
          ${S.fx.dark || S.fx.english ? `<div class="row" style="margin-top:8px">
            ${S.fx.dark ? `<button class="btn btn-sm" id="theme-btn"></button>` : ""}
            ${S.fx.english ? `<button class="btn btn-sm" id="lang-btn">🌐 ${window.MSAR_LANG && window.MSAR_LANG.isEn ? "العربية" : "English"}</button>` : ""}
          </div>` : ""}
          <button class="btn btn-sm btn-block" id="support-btn" style="margin-top:8px">🛟 الدعم الفني والمساعدة</button>
          <button class="btn btn-sm btn-block hidden" id="install-btn" style="margin-top:8px;background:#14b8a6;color:#04201d;border:0">💻 تثبيت كتطبيق على الجهاز</button>
        </div>
      </aside>
      <main class="main">
        <div class="topbar">
          <button class="icon-btn menu-btn" id="menu-btn" aria-label="القائمة">☰</button>
          <h2 id="page-title"></h2>
          <div class="spacer"></div>
          <div id="top-actions" class="row"></div>
        </div>
        <div class="content" id="view"></div>
      </main>
    </div>`;
    $("#logout-btn").onclick = A.logout;
    $("#account-btn").onclick = () => A.accountDialog();
    $("#support-btn").onclick = () => window.MSAR_SUPPORT ? window.MSAR_SUPPORT.open("ai") : window.open("support", "_blank");
    const pb = $("#plan-btn"); if (pb) pb.onclick = () => planDialog();
    const tb = $("#theme-btn");
    if (tb) { const lbl = () => { tb.textContent = isDark() ? "☀️ الوضع النهاري" : "🌙 الوضع الليلي"; }; lbl();
      tb.onclick = () => { try { localStorage.setItem("msar-dark", isDark() ? "0" : "1"); } catch (_) {} applyTheme(); lbl(); }; }
    const lgb = $("#lang-btn"); if (lgb && window.MSAR_LANG) lgb.onclick = () => window.MSAR_LANG.set(window.MSAR_LANG.isEn ? "ar" : "en");
    setupInstall();
    $("#menu-btn").onclick = () => $("#side").classList.toggle("open");
    $("#mute-btn").onclick = (e) => {
      S.muted = !S.muted;
      e.currentTarget.textContent = S.muted ? "🔕 الصوت مكتوم" : "🔔 الصوت مفعل"; e.currentTarget.classList.toggle("off", S.muted);
      if (S.muted) A.stopAlarm(); else A.playSound("order");
    };
    $$(".nav a").forEach((a) => a.addEventListener("click", () => $("#side").classList.remove("open")));
  }

  // =================================================================== مزايا تجربة المستخدم (تتحكم فيها مفاتيح المدير)
  const isDark = () => { try { return !!(S.fx && S.fx.dark) && localStorage.getItem("msar-dark") === "1"; } catch (_) { return false; } };
  function applyTheme() { document.documentElement.classList.toggle("dark", isDark()); }
  const SKEL = `<div class="skel-wrap" aria-hidden="true"><div class="skel skel-row"></div><div class="skel-grid"><div class="skel skel-card"></div><div class="skel skel-card"></div><div class="skel skel-card"></div></div><div class="skel skel-tall"></div></div>`;

  // معالج الإعداد: قائمة خطوات تظهر للتاجر فوق الطلبات لين يكمل تجهيز متجره
  const wizKey = (k) => `msar-wiz-${k}-${A.store?.id || S.me?.store_id || 0}`;
  const wizGet = (k) => { try { return localStorage.getItem(wizKey(k)) === "1"; } catch (_) { return false; } };
  const wizSet = (k) => { try { localStorage.setItem(wizKey(k), "1"); } catch (_) {} };
  function renderWizard() {
    const el = $("#wiz"); if (!el) return;
    if (!isAdmin() || !S.fx.wizard || wizGet("hide")) { el.innerHTML = ""; return; }
    const steps = [
      { ok: S.branches.length > 0, t: "أضف فرعك الأول", d: "حدّد موقع الفرع على الخريطة عشان الطلبات تتوجّه له تلقائياً.", go: "branches", b: "🏪 إضافة فرع" },
      { ok: wizGet("radius"), t: "راجع نطاق التوصيل", d: `النطاق الحالي ${num(S.radius, 1)} كم حول كل فرع — عدّله لو تحتاج.`, go: "routing", b: "🎯 فتح نطاق التوصيل" },
      { ok: S.staff.some((x) => ["cashier", "driver"].includes(x.role)), t: "ادعُ الكاشير والمندوب", d: "كل فرع له كاشير يشوف طلباته، والمندوب يحمّل تطبيقه ويستقبل الطلبات.", go: "staff", b: "👥 دعوة الفريق" },
    ];
    // متجر شغّال من قبل (فروع وفريق وطلبات)؟ ما نزعجه بالمعالج
    if (steps[0].ok && steps[2].ok && S.orders.size >= 10) { wizSet("hide"); el.innerHTML = ""; return; }
    if (S.fx.test_order) steps.push({ ok: wizGet("test"), t: "جرّب طلب تجريبي", d: "شوف الطلب يمشي من الكاشير للمندوب قبل ما يوصلك أول طلب حقيقي.", test: true, b: "🧪 إنشاء طلب تجريبي" });
    const done = steps.filter((x) => x.ok).length;
    if (done === steps.length) { wizSet("hide"); el.innerHTML = ""; toast("🎉 متجرك جاهز — كل خطوات الإعداد مكتملة", "ok", 6000); return; }
    const cur = steps.findIndex((x) => !x.ok);
    el.innerHTML = `<div class="card wiz">
      <div class="card-head"><h3>🚀 جهّز متجرك في ${steps.length} خطوات</h3><span class="spacer"></span>
        <span class="chip">${done} من ${steps.length}</span><button class="btn btn-sm btn-ghost" id="wiz-hide">إخفاء</button></div>
      <div class="wiz-bar"><i style="width:${Math.round((done / steps.length) * 100)}%"></i></div>
      <ol class="wiz-steps">${steps.map((x, i) => `<li class="${x.ok ? "ok" : i === cur ? "cur" : ""}"><span class="wiz-n">${x.ok ? "✓" : i + 1}</span><b>${x.t}</b></li>`).join("")}</ol>
      <div class="wiz-cur"><div class="grow"><b>${steps[cur].t}</b><div class="small muted">${steps[cur].d}</div></div>
        ${steps[cur].test ? `<button class="btn btn-primary" id="wiz-test">${steps[cur].b}</button>` : `<a class="btn btn-primary" href="#${steps[cur].go}">${steps[cur].b}</a>`}</div></div>`;
    $("#wiz-hide").onclick = () => { wizSet("hide"); el.innerHTML = ""; };
    const wt = $("#wiz-test"); if (wt) wt.onclick = () => testOrder(wt);
  }

  // طلب تجريبي بضغطة: يتوجّه لأول فرع ويمشي في نفس مسار الطلب الحقيقي
  async function testOrder(btn) {
    const b = S.branches.find((x) => x.is_active && x.lat != null && x.lon != null);
    if (!b) return toast("أضف فرع أولاً عشان نوجّه له الطلب التجريبي", "error");
    if (btn) btn.disabled = true;
    try {
      const o = await A.rpc("create_manual_order", { p: {
        customer_name: "عميل تجريبي 🧪", customer_phone: "0500000000", lat: Number(b.lat) + 0.004, lon: Number(b.lon) + 0.004,
        district: "طلب تجريبي", city: "", address_text: "طلب تجريبي — للتجربة فقط",
        items: [{ name: "منتج تجريبي", quantity: 1 }], total: 25, is_cod: true, branch_id: b.id,
        customer_note: "طلب تجريبي من مسار — مشّه للآخر أو ألغه بعد التجربة" } });
      S.orders.set(o.id, o); S.seen.add(o.id); S.flash = o.id; wizSet("test");
      toast(`🧪 تم إنشاء طلب تجريبي في ${branchName(o.branch_id)} — جرّب تمشّيه: تجهيز ← جاهز ← إرسال للمندوب`, "ok", 8000);
      if (S.route === "live") renderLive(true); else location.hash = "#live";
    } catch (e) { toast(A.errMsg(e), "error"); }
    finally { if (btn) btn.disabled = false; }
  }

  // تراجع عن آخر تغيير حالة (للانتقالات اللي يسمح النظام بعكسها)
  const UNDO = { new: "preparing", preparing: "ready" };
  function undoToast(o, prev, status) {
    let box = $("#toasts");
    if (!box) { box = document.createElement("div"); box.id = "toasts"; document.body.appendChild(box); }
    const t = document.createElement("div");
    t.className = "toast toast-ok toast-undo";
    t.innerHTML = `<span>تم: ${esc(STATUS[status].label)} — #${esc(o.invoice_number || o.id)}</span><button type="button">↩️ تراجع</button>`;
    const kill = () => { t.classList.add("hide"); setTimeout(() => t.remove(), 400); };
    const tm = setTimeout(kill, 7000);
    $("button", t).onclick = async () => {
      clearTimeout(tm); t.remove();
      if (S.orders.get(o.id)?.status !== status) return toast("حالة الطلب تغيّرت — ما يمكن التراجع", "error");
      const r = await setStatus(o.id, prev, null, true);
      if (r) toast("↩️ تم التراجع", "ok");
    };
    box.appendChild(t);
  }

  // تثبيت لوحة التحكم كتطبيق (ويندوز / ماك / أندرويد)
  let installEvt = window.__msarInstallEvt || null;
  window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); installEvt = e; $("#install-btn")?.classList.remove("hidden"); });
  window.addEventListener("appinstalled", () => { $("#install-btn")?.classList.add("hidden"); toast("تم تثبيت التطبيق ✅ تلقاه في قائمة ابدأ وسطح المكتب", "ok", 6000); });
  function setupInstall() {
    const btn = $("#install-btn"); if (!btn) return;
    const standalone = matchMedia("(display-mode: standalone)").matches || navigator.standalone;
    if (standalone) return;
    btn.classList.remove("hidden");
    btn.onclick = async () => {
      if (installEvt) { installEvt.prompt(); const r = await installEvt.userChoice; if (r.outcome === "accepted") btn.classList.add("hidden"); installEvt = null; return; }
      A.modal({ title: "💻 تثبيت لوحة التحكم كتطبيق", body: `
        <p class="lead">خلّ لوحة التحكم تفتح كتطبيق مستقل على الويندوز بأيقونة على سطح المكتب:</p>
        <ol style="line-height:2">
          <li>افتح هذا الموقع في متصفح <b>Google Chrome</b> أو <b>Microsoft Edge</b>.</li>
          <li>اضغط أيقونة التثبيت <b>⊕</b> في آخر شريط العنوان (يمين الرابط)<br>أو من القائمة <b>⋮</b> ← <b>حفظ ومشاركة</b> ← <b>تثبيت الصفحة كتطبيق</b>.</li>
          <li>اضغط <b>تثبيت</b> — بيطلع لك التطبيق في قائمة ابدأ وسطح المكتب، وتقدر تثبّته في شريط المهام.</li>
        </ol>
        <p class="small muted">💡 لكل فرع: ثبّت التطبيق على جهاز الكاشير وسجّل دخول بحساب الفرع.</p>` });
    };
  }

  // =================================================================== الباقة
  const trackUrl = (o) => `${A.C.SITE_URL || A.BASE}track?t=${o.track_token}`;
  const PLAN_ROWS = [["starter", "الأساسية", "129", "500 طلب", "فرعين", "5 موظفين", false], ["growth", "النمو", "199", "2,000 طلب", "5 فروع", "20 موظف", true], ["pro", "الاحترافية", "449", "بلا حدود (استخدام عادل)", "بلا حدود", "بلا حدود", true]];
  function usageLine(kind) {
    const p = S.plan; if (!p) return "";
    const lim = p[kind], used = kind === "branches" ? p.used_branches : kind === "orders" ? (p.used_orders || 0) : (p.used_staff + (p.pending_invites || 0));
    const full = lim != null && used >= lim;
    const label = kind === "branches" ? "🏪 الفروع" : kind === "orders" ? "🧾 طلبات هذا الشهر" : "👥 الموظفين";
    const note = kind === "orders" ? " — تجاوزت رصيد الباقة، طلباتك تستمر بدون توقف. <a href=\"#\" data-plan>ترقية الباقة</a>" : " — وصلت للحد. <a href=\"#\" data-plan>ترقية الباقة</a>";
    return `<div class="plan-use ${full ? "full" : ""}">${label}: <b>${used}</b> من <b>${lim ?? "∞"}</b> في باقة ${esc(p.name_ar)}${full ? note : ""}</div>`;
  }
  function bindPlanLinks(root = document) { $$("[data-plan]", root).forEach((a) => a.onclick = (e) => { e.preventDefault(); planDialog(); }); }
  function planDialog() {
    const p = S.plan || {};
    A.modal({ title: "💳 باقتك في مسار", wide: true, body: `
      <p class="lead" style="margin-top:0">باقتك الحالية: <b>${esc(p.name_ar || "الأساسية")}</b>${p.plan_status ? ` · حالة الاشتراك في ${A.platformName()}: <span class="chip">${esc(p.plan_status)}</span>` : ""}${p.plan_ends_at ? ` · تنتهي ${A.fmtDateTime(p.plan_ends_at)}` : ""}</p>
      <div class="table-wrap"><table><thead><tr><th>الباقة</th><th>السعر الشهري</th><th>الطلبات/شهر</th><th>الفروع</th><th>الموظفين</th><th>التتبع المباشر للعميل والمناديب</th></tr></thead><tbody>
      ${PLAN_ROWS.map(([c, n, pr, ord, b, st, live]) => `<tr ${c === (p.code || "starter") ? 'style="background:#e7f4fa;font-weight:700"' : ""}><td>${n}${c === (p.code || "starter") ? " ✓" : ""}</td><td>${pr} ر.س</td><td>${ord}</td><td>${b}</td><td>${st}</td><td>${live ? "✅" : "—"}</td></tr>`).join("")}
      </tbody></table></div>
      <p style="margin-bottom:0"><b>للترقية:</b> ${A.isSalla() ? "من لوحة متجرك في سلة ← <b>متجر التطبيقات</b> ← <b>تطبيقاتي</b> ← <b>مسار برو</b> ← <b>ترقية الباقة</b>" : "من لوحة متجرك في زد ← <b>التطبيقات المثبتة</b> ← <b>مسار برو</b> ← <b>تغيير الباقة</b>"}. الحدود الجديدة تتفعّل تلقائياً خلال دقائق بعد تأكيد ${A.platformName()}.</p>
      <p class="small muted">الأسعار لا تشمل الضريبة · "الموظفين" تشمل كل أعضاء الفريق ما عدا حسابك الأساسي.</p>` });
  }

  function setTitle(t, actionsHtml = "") {
    $("#page-title").textContent = t;
    $("#top-actions").innerHTML = actionsHtml;
    document.title = `${t} — ${A.store?.name || "مسار"}`;
  }

  async function renderWa() {
    setTitle("الواتساب 💬", "");
    if (!window.MSAR_WA) { $("#view").innerHTML = `<div class="card"><div class="empty">تعذر تحميل الصفحة</div></div>`; return; }
    return window.MSAR_WA.render($("#view"), { storeId: A.store?.id || S.me.store_id });
  }

  async function renderBrand() {
    setTitle("هوية المتجر 🎨", "");
    if (!window.MSAR_BRAND) { $("#view").innerHTML = `<div class="card"><div class="empty">تعذر تحميل الصفحة</div></div>`; return; }
    return window.MSAR_BRAND.render($("#view"), { storeId: A.store?.id || S.me.store_id });
  }

  function route() {
    const r = (location.hash || "#live").slice(1).split("?")[0];
    const item = NAV.find((n) => n.id === r && (!n.admin || isAdmin()) && (!n.wa || S.wa)) || NAV[0];
    S.route = item.id;
    $$(".nav a").forEach((a) => a.classList.toggle("active", a.dataset.r === item.id));
    Object.values(S.maps).forEach((m) => { try { m.remove(); } catch (_) {} });
    S.maps = {};
    if (S.fx.skeleton && $("#view")) $("#view").innerHTML = SKEL;
    Promise.resolve(({ live: renderLive, map: renderMap, orders: renderOrders, reports: renderReports, staff: renderStaff, routing: renderRouting, branches: renderBranches, wa: renderWa, brand: renderBrand, settings: renderSettings })[item.id]()).then(() => bindPlanLinks($("#view")));
  }

  // =================================================================== data
  async function loadBranches() {
    const { data, error } = await sb.from("branches").select("*").order("id");
    if (error) return toast(A.errMsg(error), "error");
    S.branches = data;
  }
  async function loadRadius() {
    try { S.radius = Number(await A.rpc("get_route_radius")) || 5; } catch (_) {}
  }
  const branchRadius = (b) => (b?.max_radius_km != null ? Number(b.max_radius_km) : S.radius);
  async function loadStaff() {
    try { S.staff = (await A.rpc("store_staff")) || []; } catch (e) { toast(A.errMsg(e), "error"); }
  }
  async function loadOrders() {
    const since = new Date(); since.setHours(0, 0, 0, 0);
    const { data, error } = await sb.from("orders").select("*")
      .or(`status.in.(${ACTIVE.join(",")}),updated_at.gte.${since.toISOString()}`)
      .order("order_created_at", { ascending: false }).limit(600);
    if (error) return toast(A.errMsg(error), "error");
    const first = S.lastLoad === 0;
    S.orders = new Map(data.map((o) => [o.id, o]));
    if (first) data.forEach((o) => S.seen.add(o.id));
    else {
      // طلبات جديدة وصلت أثناء انقطاع الاتصال اللحظي
      const fresh = data.filter((o) => o.status === "new" && !S.seen.has(o.id));
      fresh.forEach((o) => S.seen.add(o.id));
      if (fresh.length) {
        if (!S.muted) A.playSound("order");
        toast(`🛒 ${fresh.length} طلب جديد`, "ok", 6000);
        A.notify("🛒 طلبات جديدة", `${fresh.length} طلب جديد بانتظار التجهيز`);
      }
    }
    S.lastLoad = Date.now();
    updateNavCount();
  }

  function subscribe() {
    S.channel = sb.channel("msar-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, (p) => onOrderChange(p))
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, (p) => {
        if (p.new?.id) {
          const i = S.staff.findIndex((x) => x.id === p.new.id);
          if (i >= 0) S.staff[i] = { ...S.staff[i], ...p.new }; else S.staff.push(p.new);
          if (S.route === "map") updateMapDrivers();
        }
      })
      .subscribe((status) => {
        if (status === "SUBSCRIBED") loadOrders().then(() => S.route === "live" && renderLive(true));
      });
  }

  function onOrderChange(p) {
    if (p.eventType === "DELETE") { S.orders.delete(p.old.id); }
    else {
      const o = p.new;
      const isNew = !S.orders.has(o.id) && !S.seen.has(o.id);
      S.orders.set(o.id, o);
      if (isNew && o.status === "new") {
        S.seen.add(o.id);
        if (!S.muted) A.playSound("order");
        A.notify("🛒 طلب جديد #" + (o.invoice_number || o.id), `${o.customer_name || ""} — ${branchName(o.branch_id)} — ${money(o.total)}`);
        toast(`طلب جديد #${o.invoice_number || o.id} — ${branchName(o.branch_id)}`, "ok", 6000);
        S.flash = o.id;
      }
      if (S.openOrder === o.id) openOrder(o.id, true);
    }
    updateNavCount();
    checkAlarm();
    if (S.route === "live") renderLive(true);
    if (S.route === "map") updateMapOrders();
  }

  function visibleOrders() {
    return [...S.orders.values()].filter((o) => !S.filter.branch || String(o.branch_id ?? "none") === S.filter.branch);
  }
  function updateNavCount() {
    const n = visibleOrders().filter((o) => o.status === "new").length;
    const el = $("#nav-count");
    if (el) { el.textContent = n; el.classList.toggle("hidden", !n); }
  }
  // الصوت يطلع فقط عند وصول طلب جديد (مو مستمر)
  function checkAlarm() {}

  // =================================================================== actions
  async function setStatus(id, status, note, silent) {
    try {
      const prev = S.orders.get(id)?.status;
      const o = await A.rpc("set_order_status", { p_order_id: id, p_status: status, p_note: note ?? null });
      S.orders.set(o.id, o);
      if (silent) { /* بدون إشعار */ }
      else if (S.fx.undo && !note && UNDO[prev] === status) undoToast(o, prev, status);
      else toast(`تم: ${STATUS[status].label}`, "ok");
      if (S.route === "live") renderLive(true);
      checkAlarm();
      return o;
    } catch (e) { toast(A.errMsg(e), "error"); }
  }

  async function dispatchOrder(id, driverId) {
    try {
      const o = await A.rpc("dispatch_order", { p_order_id: id, p_driver_id: driverId || null });
      S.orders.set(o.id, o);
      toast(`🛵 تم إرسال الطلب إلى ${staffName(o.driver_id)}`, "ok");
      if (S.route === "live") renderLive(true);
      return o;
    } catch (e) { toast(A.errMsg(e), "error"); }
  }

  function dispatchDialog(o) {
    const list = drivers(isAdmin() ? null : o.branch_id).sort((a, b) =>
      (a.branch_id === o.branch_id ? 0 : 1) - (b.branch_id === o.branch_id ? 0 : 1) || activeCountFor(a.id) - activeCountFor(b.id));
    if (!list.length) return toast("لا يوجد مناديب مسجلين — أضف مندوب من صفحة الموظفين", "error");
    const body = `<p class="muted small">اختر المندوب أو اترك النظام يختار المندوب الفاضي تلقائياً.</p>
      <label class="row" style="padding:10px;border:1px solid var(--line);border-radius:10px;margin-bottom:8px;cursor:pointer">
        <input type="radio" name="drv" value="" checked style="width:auto;min-height:auto"> <b>⚡ تلقائي — المندوب الفاضي في الفرع</b></label>
      ${list.map((d) => {
        const n = activeCountFor(d.id);
        const dist = A.haversine(d.last_lat, d.last_lon, o.lat, o.lon);
        return `<label class="row" style="padding:10px;border:1px solid var(--line);border-radius:10px;margin-bottom:8px;cursor:pointer">
        <input type="radio" name="drv" value="${d.id}" style="width:auto;min-height:auto">
        <span class="dot ${d.is_online ? "on" : ""}"></span><b>${esc(d.full_name)}</b>
        <span class="chip">${esc(branchName(d.branch_id))}</span>
        <span class="chip ${n ? "chip-cod" : "chip-paid"}">${n ? `معه ${n} طلب` : "فاضي"}</span>
        ${dist !== null ? `<span class="chip">📍 ${dist.toFixed(1)} كم من العميل</span>` : ""}
        ${d.last_battery != null ? `<span class="chip">🔋 ${d.last_battery}%</span>` : ""}
      </label>`; }).join("")}`;
    A.modal({
      title: `إرسال الطلب #${o.invoice_number || o.id} للمندوب`, body,
      actions: [
        { label: "إلغاء", cls: "btn-ghost" },
        { label: "🛵 إرسال", cls: "btn-primary", onClick: async (w) => { await dispatchOrder(o.id, $("input[name=drv]:checked", w)?.value); } },
      ],
    });
  }

  async function rerouteDialog(o) {
    const body = `<label class="field"><span>الفرع الجديد</span><select id="rr-b">${S.branches.filter((b) => b.is_active).map((b) => {
      const d = A.haversine(o.lat, o.lon, b.lat, b.lon);
      return `<option value="${b.id}" ${b.id === o.branch_id ? "selected" : ""}>${esc(b.name)}${d !== null ? ` — ${d.toFixed(1)} كم` : ""}</option>`; }).join("")}</select></label>
      <label class="field"><span>السبب (اختياري)</span><input id="rr-n" placeholder="مثال: المنتج غير متوفر في الفرع"></label>`;
    A.modal({
      title: "تحويل الطلب لفرع آخر", body,
      actions: [
        { label: "إلغاء", cls: "btn-ghost" },
        { label: "تحويل", cls: "btn-primary", onClick: async (w) => {
            const r = await A.rpc("reroute_order", { p_order_id: o.id, p_branch_id: Number($("#rr-b", w).value), p_note: $("#rr-n", w).value || null });
            S.orders.set(r.id, r); toast("تم تحويل الطلب", "ok");
            if (S.route === "live") renderLive(true);
            if (S.openOrder === o.id) openOrder(o.id, true);
          } },
      ],
    });
  }

  async function cancelDialog(o) {
    const reason = await A.promptBox("إلغاء الطلب", "سبب الإلغاء", { required: true, okLabel: "إلغاء الطلب" });
    if (reason) await setStatus(o.id, "cancelled", reason);
  }

  function nextActions(o) {
    const a = [];
    switch (o.status) {
      case "new": a.push({ k: "preparing", label: "🧺 بدء التجهيز", cls: "btn-warn" }); break;
      case "preparing": a.push({ k: "ready", label: "📦 جاهز", cls: "btn-info" }); break;
      case "ready": a.push({ k: "dispatch", label: "🛵 إرسال للمندوب", cls: "btn-primary" }); break;
    }
    return a;
  }
  async function runAction(o, k) {
    if (k === "dispatch") return dispatchDialog(o);
    if (k === "cancel") return cancelDialog(o);
    if (k === "reroute") return rerouteDialog(o);
    if (k === "unassign") { if (await A.confirmBox("سحب الطلب من المندوب", "سيرجع الطلب لحالة جاهز ويمكنك إرساله لمندوب آخر.")) return setStatus(o.id, "ready", "سحب من المندوب"); return; }
    if (k === "print") return printSlip(o);
    if (k === "delivered") { if (await A.confirmBox("تأكيد التسليم", "تأكيد أن الطلب تم تسليمه للعميل؟")) return setStatus(o.id, "delivered", "تم التأكيد من الإدارة"); return; }
    return setStatus(o.id, k);
  }

  // =================================================================== live board
  function renderLive(soft) {
    if (!soft || !$("#board")) {
      setTitle(isAdmin() ? "الطلبات الحالية — كل الفروع" : `الطلبات — ${S.me.branch?.name || ""}`,
        `${isAdmin() && S.fx.test_order ? `<button class="btn" id="test-order-btn">🧪 طلب تجريبي</button>` : ""}<button class="btn btn-primary" id="new-order-btn">➕ طلب يدوي</button>`);
      $("#view").innerHTML = `
        <div id="wiz"></div>
        <div class="stats" id="live-stats"></div>
        <div class="filters">
          ${isAdmin() ? `<select id="f-branch"><option value="">كل الفروع</option>${S.branches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}<option value="none">⚠️ بدون فرع</option></select>` : ""}
          <input id="f-q" placeholder="🔎 بحث بالاسم أو الجوال أو رقم الطلب" style="min-width:240px">
          <span class="spacer"></span>
          <span class="small muted" id="live-updated"></span>
        </div>
        <div id="unrouted"></div>
        <div class="board" id="board"></div>
        <h3 style="margin-top:22px">✅ المكتملة اليوم</h3>
        <div class="card table-wrap" id="done-today"></div>`;
      if ($("#f-branch")) { $("#f-branch").value = S.filter.branch; $("#f-branch").onchange = (e) => { S.filter.branch = e.target.value; renderLive(true); updateNavCount(); }; }
      $("#f-q").value = S.filter.q;
      $("#f-q").oninput = (e) => { S.filter.q = e.target.value.trim(); renderLive(true); };
      $("#new-order-btn").onclick = () => manualOrderDialog();
      const tob = $("#test-order-btn"); if (tob) tob.onclick = () => testOrder(tob);
    }
    const q = S.filter.q.toLowerCase();
    const list = visibleOrders().filter((o) => !q || [o.customer_name, o.customer_phone, o.invoice_number, String(o.id), o.district].some((x) => String(x ?? "").toLowerCase().includes(q)));
    const cols = [
      { k: ["new"], t: "🆕 جديد" },
      { k: ["preparing"], t: "🧺 قيد التجهيز" },
      { k: ["ready"], t: "📦 جاهز للإرسال" },
      { k: ["assigned", "out_for_delivery"], t: "🛵 مع المندوب" },
    ];
    const active = list.filter((o) => ACTIVE.includes(o.status));
    const unrouted = active.filter((o) => !o.branch_id);
    $("#unrouted").innerHTML = unrouted.length && isAdmin() ? `<div class="card" style="border:2px solid var(--danger);margin-bottom:14px">
      <div class="card-head"><h3>⚠️ طلبات تحتاج توجيه منك (${unrouted.length})</h3><span class="spacer"></span>
        <a class="small" href="#routing">النطاق التلقائي: ${num(S.radius, 1)} كم ✏️</a></div>
      ${unrouted.map((o) => unroutedHtml(o)).join("")}</div>` : "";
    $("#board").innerHTML = cols.map((c) => {
      const items = active.filter((o) => c.k.includes(o.status) && o.branch_id)
        .sort((a, b) => new Date(a.order_created_at) - new Date(b.order_created_at));
      return `<div class="col"><div class="col-head">${c.t}<span class="n">${items.length}</span></div>
        ${items.map((o) => cardHtml(o)).join("") || `<div class="empty">لا يوجد</div>`}</div>`;
    }).join("");

    const today = list.filter((o) => ["delivered", "cancelled"].includes(o.status)).sort((a, b) => new Date(b.updated_at) - new Date(a.updated_at));
    $("#done-today").innerHTML = today.length ? `<table><thead><tr><th>الطلب</th><th>العميل</th><th>الفرع</th><th>المندوب</th><th>الحالة</th><th>الإجمالي</th><th>مدة التوصيل</th></tr></thead><tbody>
      ${today.map((o) => `<tr class="click" data-open="${o.id}"><td><b>#${esc(o.invoice_number || o.id)}</b></td><td>${esc(o.customer_name)}</td><td>${esc(branchName(o.branch_id))}</td>
      <td>${esc(staffName(o.driver_id))}</td><td>${A.statusBadge(o.status)}</td><td>${money(o.total)}</td>
      <td>${o.delivered_at ? Math.round((new Date(o.delivered_at) - new Date(o.received_at)) / 60000) + " د" : "—"}</td></tr>`).join("")}</tbody></table>`
      : `<div class="empty">لا يوجد طلبات مكتملة اليوم بعد</div>`;

    const by = (s) => active.filter((o) => s.includes(o.status)).length;
    const deliveredToday = today.filter((o) => o.status === "delivered");
    const onlineDrivers = drivers(isAdmin() ? null : S.me.branch_id).filter((d) => d.is_online).length;
    $("#live-stats").innerHTML = `
      <div class="stat"><div class="k">طلبات جديدة</div><div class="v" style="color:${by(["new"]) ? "var(--danger)" : "inherit"}">${by(["new"])}</div><div class="s">بانتظار التجهيز</div></div>
      <div class="stat"><div class="k">قيد التجهيز / جاهز</div><div class="v">${by(["preparing", "ready"])}</div></div>
      <div class="stat"><div class="k">مع المناديب</div><div class="v">${by(["assigned", "out_for_delivery"])}</div></div>
      <div class="stat"><div class="k">تم تسليمها اليوم</div><div class="v">${deliveredToday.length}</div><div class="s">${money(deliveredToday.reduce((a, o) => a + Number(o.total || 0), 0))}</div></div>
      <div class="stat"><div class="k">مناديب متصلين</div><div class="v">${onlineDrivers}</div><div class="s">من ${drivers(isAdmin() ? null : S.me.branch_id).length}</div></div>`;
    $("#live-updated").textContent = "آخر تحديث " + A.fmtTime(new Date());
    bindCards($("#view"));
    S.flash = null;
    renderWizard();
  }

  function unroutedHtml(o) {
    const opts = (o.routing && o.routing.length ? o.routing : S.branches.filter((b) => b.is_active).map((b) => ({ id: b.id, name: b.name, km: A.haversine(o.lat, o.lon, b.lat, b.lon) })))
      .slice().sort((a, b) => (a.km ?? 1e9) - (b.km ?? 1e9));
    const why = o.routing_method === "out_of_range" ? `📏 خارج النطاق — أقرب فرع ${num(o.distance_km, 1)} كم` : "📍 الطلب بدون إحداثيات — راجع العنوان";
    return `<div class="ocard late" data-open="${o.id}" style="cursor:default">
      <div class="top"><span class="num">#${esc(o.invoice_number || o.id)}</span><span class="chip chip-warn">${why}</span>
        <span class="time">${A.ago(o.order_created_at)}</span></div>
      <div class="cust">${esc(o.customer_name || "عميل")} · <span class="mono small">${esc(o.customer_phone || "")}</span></div>
      <div class="addr">📍 ${esc(o.address_text || o.district || o.city || "—")}</div>
      <div class="meta"><span class="chip">${num(o.items_count)} منتج</span>${A.payChip(o)}</div>
      <div class="row" style="margin-top:10px;gap:6px">${opts.slice(0, 5).map((b, i) =>
        `<button class="btn btn-sm ${i === 0 ? "btn-primary" : ""}" data-route="${o.id}" data-b="${b.id}">🏪 ${esc(String(b.name).replace("بقالة ", ""))}${b.km != null ? ` · ${num(b.km, 1)} كم` : ""}</button>`).join("")}
        <button class="btn btn-sm btn-ghost" style="color:var(--danger)" data-act="cancel" data-id="${o.id}">✖ إلغاء</button></div>
    </div>`;
  }

  function cardHtml(o) {
    const mins = A.minutesSince(o.order_created_at);
    const late = (o.status === "new" && mins > 10) || (["preparing", "ready"].includes(o.status) && mins > 30) || (o.status === "out_for_delivery" && A.minutesSince(o.picked_up_at) > 45);
    const acts = nextActions(o);
    return `<div class="ocard ${late ? "late" : ""} ${S.flash === o.id ? "flash" : ""}" data-open="${o.id}">
      <div class="top"><span class="num">#${esc(o.invoice_number || o.id)}</span>${o.source === "manual" ? `<span class="chip">يدوي</span>` : ""}
        <span class="time" title="${A.fmtDateTime(o.order_created_at)}">${A.ago(o.order_created_at)}</span></div>
      <div class="cust">${esc(o.customer_name || "عميل")}</div>
      <div class="addr">📍 ${esc(o.district || o.address_text || "—")}</div>
      <div class="meta">
        ${isAdmin() ? `<span class="chip">🏪 ${esc(branchName(o.branch_id).replace("بقالة ", ""))}</span>` : ""}
        ${o.distance_km != null ? `<span class="chip">${num(o.distance_km, 1)} كم</span>` : ""}
        <span class="chip">${num(o.items_count)} منتج</span>
        ${A.payChip(o)}
        ${o.driver_id ? `<span class="chip">🛵 ${esc(staffName(o.driver_id))}</span>` : ""}
        ${o.status === "out_for_delivery" ? `<span class="chip" style="background:#ccfbf1">في الطريق ${A.ago(o.picked_up_at)}</span>` : ""}
        ${o.status === "assigned" ? `<span class="chip">بانتظار استلام المندوب</span>` : ""}
      </div>
      ${acts.length ? `<div class="acts">${acts.map((a) => `<button class="btn btn-sm ${a.cls}" data-act="${a.k}" data-id="${o.id}">${a.label}</button>`).join("")}</div>` : ""}
    </div>`;
  }

  function bindCards(root) {
    $$("[data-act]", root).forEach((b) => b.onclick = (e) => {
      e.stopPropagation();
      const o = S.orders.get(Number(b.dataset.id));
      if (o) runAction(o, b.dataset.act);
    });
    $$("[data-open]", root).forEach((c) => c.onclick = () => openOrder(Number(c.dataset.open)));
    $$("[data-route]", root).forEach((b) => b.onclick = async (e) => {
      e.stopPropagation(); b.disabled = true;
      try {
        const r = await A.rpc("reroute_order", { p_order_id: Number(b.dataset.route), p_branch_id: Number(b.dataset.b), p_note: "توجيه يدوي من الإدارة" });
        S.orders.set(r.id, r); toast(`تم توجيه الطلب إلى ${branchName(r.branch_id)}`, "ok"); renderLive(true);
      } catch (er) { toast(A.errMsg(er), "error"); b.disabled = false; }
    });
  }

  // =================================================================== order drawer
  async function openOrder(id, refresh) {
    let o = S.orders.get(id);
    if (!o || refresh) {
      const { data } = await sb.from("orders").select("*").eq("id", id).maybeSingle();
      if (data) { o = data; if (S.orders.has(id) || ACTIVE.includes(o.status)) S.orders.set(id, o); }
    }
    if (!o) return toast("الطلب غير متاح", "error");
    S.openOrder = id;
    let wrap = $("#drawer");
    if (!wrap) {
      wrap = document.createElement("div");
      wrap.className = "drawer-wrap"; wrap.id = "drawer";
      wrap.onclick = (e) => { if (e.target === wrap) closeDrawer(); };
      document.body.appendChild(wrap);
    }
    const { data: events } = await sb.from("order_events").select("*").eq("order_id", id).order("at");
    const br = S.branches.find((b) => b.id === o.branch_id);
    const drv = S.staff.find((p) => p.id === o.driver_id);
    const canManage = isAdmin() || o.branch_id === S.me.branch_id;
    const acts = canManage ? nextActions(o) : [];
    const msg = `السلام عليكم ${o.customer_name || ""}، معك ${A.C.STORE_NAME} بخصوص طلبك رقم ${o.invoice_number || o.id}`;
    wrap.innerHTML = `<div class="drawer">
      <div class="drawer-head">
        <button class="icon-btn" id="dclose">✕</button>
        <h3 style="margin:0">طلب #${esc(o.invoice_number || o.id)}</h3>${A.statusBadge(o.status)}
        <span class="spacer"></span>
        <button class="btn btn-sm" data-act="print" data-id="${o.id}">🖨️ طباعة</button>
      </div>
      <div class="drawer-body">
        ${acts.length || canManage ? `<div class="card"><div class="row">
          ${acts.map((a) => `<button class="btn ${a.cls}" data-act="${a.k}" data-id="${o.id}">${a.label}</button>`).join("")}
          ${canManage && ["new", "preparing", "ready", "assigned"].includes(o.status) ? `<button class="btn" data-act="reroute" data-id="${o.id}">🔀 تحويل لفرع</button>` : ""}
          ${canManage && o.status === "assigned" ? `<button class="btn" data-act="unassign" data-id="${o.id}">↩️ سحب من المندوب</button>` : ""}
          ${canManage && o.status === "assigned" ? `<button class="btn" data-act="dispatch" data-id="${o.id}">🔁 مندوب آخر</button>` : ""}
          ${isAdmin() && o.status === "out_for_delivery" ? `<button class="btn btn-ok" data-act="delivered" data-id="${o.id}">✅ تأكيد التسليم</button>` : ""}
          ${canManage && ACTIVE.includes(o.status) ? `<button class="btn btn-ghost" style="color:var(--danger)" data-act="cancel" data-id="${o.id}">✖ إلغاء</button>` : ""}
        </div></div>` : ""}

        ${o.status !== "cancelled" && o.track_token ? `<div class="card track-card">
          <div class="card-head"><h3>📍 تتبع العميل</h3>${S.plan?.live ? "" : `<span class="chip">🔒 باقة النمو</span>`}</div>
          ${S.plan?.live
            ? `<p class="small muted" style="margin:0 0 8px">رابط يفتحه العميل ويشوف حالة طلبه وموقع المندوب لحظياً وهو في الطريق.</p>
               <div class="row"><button class="btn btn-sm" id="trk-copy">🔗 نسخ رابط التتبع</button>${o.customer_phone ? `<a class="btn btn-sm btn-ok" target="_blank" rel="noopener" href="${A.waLink(o.customer_phone, `${msg}\nتقدر تتابع طلبك من هنا: ${trackUrl(o)}`)}">💬 أرسله للعميل واتساب</a>` : ""}<a class="btn btn-sm btn-ghost" target="_blank" rel="noopener" href="${trackUrl(o)}">👁️ معاينة</a></div>`
            : `<p class="small muted" style="margin:0">رابط تتبع مباشر للعميل (حالة الطلب وموقع المندوب) متاح في باقتي النمو والاحترافية. <a href="#" data-plan>عرض الباقات</a></p>`}
        </div>` : ""}

        <div class="card">
          <div class="card-head"><h3>👤 العميل</h3></div>
          <dl class="kv">
            <dt>الاسم</dt><dd>${esc(o.customer_name || "—")}</dd>
            <dt>الجوال</dt><dd><span class="mono">${esc(o.customer_phone || "—")}</span></dd>
            <dt>العنوان</dt><dd>${esc(o.address_text || "—")}</dd>
            ${o.short_address ? `<dt>العنوان المختصر</dt><dd class="mono">${esc(o.short_address)}</dd>` : ""}
            <dt>وقت الطلب</dt><dd>${A.fmtDateTime(o.order_created_at)} <span class="muted small">(${A.ago(o.order_created_at)})</span></dd>
            <dt>الدفع</dt><dd>${A.payChip(o)} <span class="muted small">${esc(o.payment_method || "")}</span>
              ${o.is_cod && canManage && o.status !== "cancelled" ? `<div class="pay-row"><span class="small muted">كيف دفع العميل عند الاستلام؟</span>${A.payToggle(o)}</div>` : ""}</dd>
            ${o.shipping_method ? `<dt>طريقة الشحن</dt><dd>${esc(o.shipping_method)}</dd>` : ""}
            ${o.customer_note ? `<dt>ملاحظة العميل</dt><dd style="color:var(--warn)">${esc(o.customer_note)}</dd>` : ""}
          </dl>
          <div class="row" style="margin-top:12px">
            <a class="btn btn-sm" href="${A.telLink(o.customer_phone)}">📞 اتصال</a>
            <a class="btn btn-sm" target="_blank" href="${A.waLink(o.customer_phone, msg)}">💬 واتساب</a>
            ${o.lat ? `<a class="btn btn-sm" target="_blank" href="${A.mapsLink(o.lat, o.lon)}">🗺️ قوقل ماب</a>
            <button class="btn btn-sm" id="copy-loc">📋 نسخ الموقع</button>` : `<span class="chip chip-warn">لا توجد إحداثيات للعميل</span>`}
          </div>
          ${o.lat ? `<div class="mini-map" id="omap"></div>` : ""}
        </div>

        <div class="card">
          <div class="card-head"><h3>🏪 التوجيه والتوصيل</h3></div>
          <dl class="kv">
            <dt>الفرع</dt><dd>${esc(br?.name || "غير محدد")} ${o.distance_km != null ? `<span class="chip">${num(o.distance_km, 2)} كم</span>` : ""}
              <span class="chip">${({ nearest: "تلقائي — الأقرب", manual: "يدوي", city_fallback: "حسب المدينة", none: "بدون إحداثيات", out_of_range: "خارج النطاق" })[o.routing_method] || ""}</span></dd>
            ${o.routing?.length ? `<dt>المسافات</dt><dd class="small">${o.routing.map((r) => `${esc(r.name.replace("بقالة ", ""))}: ${r.km} كم`).join(" · ")}</dd>` : ""}
            <dt>المندوب</dt><dd>${drv ? `${esc(drv.full_name)} <a class="small" href="${A.telLink(drv.phone)}">${esc(drv.phone || "")}</a>` : "—"}</dd>
            <dt>استلام النظام</dt><dd>${A.fmtDateTime(o.received_at)}</dd>
            ${o.ready_at ? `<dt>جاهز</dt><dd>${A.fmtDateTime(o.ready_at)} <span class="muted small">(${Math.round((new Date(o.ready_at) - new Date(o.received_at)) / 60000)} د تجهيز)</span></dd>` : ""}
            ${o.picked_up_at ? `<dt>خرج للتوصيل</dt><dd>${A.fmtDateTime(o.picked_up_at)}</dd>` : ""}
            ${o.delivered_at ? `<dt>تم التسليم</dt><dd>${A.fmtDateTime(o.delivered_at)} <span class="muted small">(إجمالي ${Math.round((new Date(o.delivered_at) - new Date(o.received_at)) / 60000)} د)</span></dd>` : ""}
            ${o.cancel_reason ? `<dt>سبب الإلغاء</dt><dd style="color:var(--danger)">${esc(o.cancel_reason)}</dd>` : ""}
            ${o.zid_order_id ? `<dt>حالة ${o.source === "salla" ? "سلة" : "زد"}</dt><dd>${esc(o.zid_status || "—")} <span class="muted small">(#${o.zid_order_id})</span></dd>` : ""}
          </dl>
        </div>

        <div class="card">
          <div class="card-head"><h3>🛒 المنتجات (${num(o.items_count)})</h3><span class="spacer"></span><b>${money(o.total)}</b></div>
          ${A.itemsHtml(o.items)}
          ${o.shipping_fee ? `<div class="row small" style="margin-top:8px"><span>رسوم التوصيل</span><span class="spacer"></span>${money(o.shipping_fee)}</div>` : ""}
        </div>

        <div class="card">
          <div class="card-head"><h3>🕓 سجل الطلب</h3><span class="spacer"></span><button class="btn btn-sm" id="add-note">➕ ملاحظة</button></div>
          <ul class="timeline">${(events || []).map((e) => `<li><b>${esc(e.type === "status" ? `${STATUS[e.from_status]?.label || ""} ← ${STATUS[e.to_status]?.label || ""}` : e.note || e.type)}</b>
            ${e.type === "status" && e.note ? esc(e.note) : ""}<span class="muted small">${A.fmtDateTime(e.at)} · ${esc(e.actor_name || "النظام")}</span></li>`).join("")}</ul>
        </div>
      </div></div>`;
    $("#dclose").onclick = closeDrawer;
    $("#trk-copy")?.addEventListener("click", () => A.copy(trackUrl(o), "تم نسخ رابط التتبع"));
    bindPlanLinks(wrap);
    bindCards(wrap);
    A.bindPayToggle(wrap, (r) => { if (r?.id) S.orders.set(r.id, r); openOrder(o.id, true); });
    $("#add-note").onclick = async () => {
      const n = await A.promptBox("إضافة ملاحظة", "الملاحظة", { required: true });
      if (n) { try { await A.rpc("add_order_note", { p_order_id: o.id, p_note: n }); openOrder(o.id, true); } catch (e) { toast(A.errMsg(e), "error"); } }
    };
    $("#copy-loc")?.addEventListener("click", () => { A.copy(A.mapsLink(o.lat, o.lon), "تم نسخ رابط الموقع"); });
    if (o.lat) {
      const m = L.map("omap", { zoomControl: true, attributionControl: false });
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(m);
      const pts = [[o.lat, o.lon]];
      L.marker([o.lat, o.lon], { icon: pin("#dc2626", "👤", 34) }).addTo(m).bindPopup(esc(o.customer_name));
      if (br) { L.marker([br.lat, br.lon], { icon: pin("#0f766e", "🏪", 34) }).addTo(m).bindPopup(esc(br.name)); pts.push([br.lat, br.lon]); }
      if (drv?.last_lat) { L.marker([drv.last_lat, drv.last_lon], { icon: pin("#2563eb", "🛵", 34) }).addTo(m).bindPopup(esc(drv.full_name)); pts.push([drv.last_lat, drv.last_lon]); }
      if (pts.length > 1) m.fitBounds(pts, { padding: [30, 30] }); else if (pts.length) m.setView(pts[0], 15); else m.setView([24.7, 45.5], 5);
      setTimeout(() => m.invalidateSize(), 200);
    }
  }
  function closeDrawer() { $("#drawer")?.remove(); S.openOrder = null; }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closeDrawer(); });

  function pin(color, label, size = 30) {
    return L.divIcon({ className: "", html: `<div class="map-pin" style="background:${color};width:${size}px;height:${size}px">${label}</div>`, iconSize: [size, size], iconAnchor: [size / 2, size / 2] });
  }

  // =================================================================== print
  function printSlip(o) {
    const br = S.branches.find((b) => b.id === o.branch_id);
    $("#print-area").innerHTML = `<div style="font-family:Tahoma;direction:rtl;padding:6px">
      <h2 style="text-align:center;margin:0">${esc(A.C.STORE_NAME)}</h2>
      <div style="text-align:center">${esc(br?.name || "")}</div><hr>
      <div><b>طلب #${esc(o.invoice_number || o.id)}</b> — ${A.fmtDateTime(o.order_created_at)}</div>
      <div>العميل: ${esc(o.customer_name || "")}</div><div>الجوال: ${esc(o.customer_phone || "")}</div>
      <div>العنوان: ${esc(o.address_text || "")}</div><hr>
      <table style="width:100%;font-size:12px">${(o.items || []).map((i) => `<tr><td>${esc(i.name)}</td><td>×${num(i.quantity)}</td><td>${i.total != null ? num(i.total, 2) : ""}</td></tr>`).join("")}</table><hr>
      <div><b>الإجمالي: ${money(o.total)}</b></div>
      <div>${o.is_cod ? `<b>المطلوب تحصيله: ${money(o.cod_amount || o.total)}</b> — ${o.cod_method === "card" ? "💳 شبكة / بطاقة" : o.cod_method === "cash" ? "💵 نقداً" : "عند الاستلام"}` : "✅ مدفوع مسبقاً"}</div>
      ${o.customer_note ? `<div>ملاحظة: ${esc(o.customer_note)}</div>` : ""}
    </div>`;
    window.print();
  }

  // =================================================================== manual order
  function manualOrderDialog() {
    const body = document.createElement("div");
    body.innerHTML = `
      <div class="grid-2">
        <label class="field"><span>اسم العميل *</span><input id="m-name" required></label>
        <label class="field"><span>الجوال *</span><input id="m-phone" dir="ltr" placeholder="05xxxxxxxx" required></label>
      </div>
      <label class="field"><span>رابط الموقع من قوقل ماب / واتساب أو الإحداثيات</span><input id="m-loc" dir="ltr" placeholder="https://maps.google.com/... أو 26.4, 50.1"></label>
      <div class="small muted" style="margin:-6px 0 6px">أو اضغط على الخريطة لتحديد موقع العميل</div>
      <div class="pick-map" id="m-map"></div>
      <div class="row small" id="m-route" style="margin:8px 0"></div>
      <div class="grid-2">
        <label class="field"><span>الحي</span><input id="m-district"></label>
        <label class="field"><span>المدينة</span><select id="m-city"><option>الدمام</option><option>الجبيل</option><option>الخبر</option></select></label>
      </div>
      <label class="field"><span>العنوان / وصف</span><input id="m-addr"></label>
      <label class="field"><span>المنتجات (كل منتج في سطر — مثال: 2 خبز)</span><textarea id="m-items" rows="4"></textarea></label>
      <div class="grid-3">
        <label class="field"><span>الإجمالي (ر.س)</span><input id="m-total" type="number" step="0.01" min="0"></label>
        <label class="field"><span>الدفع</span><select id="m-cod"><option value="1">💵 عند الاستلام — نقداً</option><option value="card">💳 عند الاستلام — شبكة</option><option value="0">✅ مدفوع مسبقاً</option></select></label>
        <label class="field"><span>الفرع</span><select id="m-branch"><option value="">تلقائي (الأقرب)</option>${S.branches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}</select></label>
      </div>
      <label class="field"><span>ملاحظة</span><input id="m-note"></label>`;
    if (!isAdmin()) { $("#m-branch", body).value = S.me.branch_id; $("#m-branch", body).disabled = true; }
    let pos = null, marker = null, map;
    const setPos = (lat, lon) => {
      pos = { lat, lon };
      if (marker) marker.setLatLng([lat, lon]); else marker = L.marker([lat, lon], { icon: pin("#dc2626", "👤", 32) }).addTo(map);
      map.setView([lat, lon], Math.max(map.getZoom(), 14));
      const near = S.branches.filter((b) => b.is_active).map((b) => ({ b, d: A.haversine(lat, lon, b.lat, b.lon) })).sort((a, c) => a.d - c.d);
      const inR = near.find((x) => x.d <= branchRadius(x.b));
      $("#m-route", body).innerHTML = !near.length ? "" : inR ? `🏪 سيتوجه تلقائياً إلى: <b>${esc(inR.b.name)}</b> (${inR.d.toFixed(1)} كم)`
        : `<span class="chip chip-warn">📏 خارج النطاق — أقرب فرع ${esc(near[0].b.name)} (${near[0].d.toFixed(1)} كم). اختر الفرع يدوياً</span>`;
      if (near[0]) $("#m-city", body).value = near[0].b.city;
    };
    const dlg = A.modal({
      title: "➕ طلب يدوي (هاتف / واتساب)", body, wide: true,
      actions: [
        { label: "إلغاء", cls: "btn-ghost" },
        { label: "حفظ الطلب", cls: "btn-primary", onClick: async () => {
            const name = $("#m-name", body).value.trim(), phone = $("#m-phone", body).value.trim();
            if (!name || !phone) { toast("الاسم والجوال مطلوبين", "error"); return false; }
            const items = $("#m-items", body).value.split("\n").map((l) => l.trim()).filter(Boolean).map((l) => {
              const m = l.match(/^(\d+)\s*[x×*-]?\s*(.+)$/) || l.match(/^(.+?)\s*[x×*]\s*(\d+)$/);
              if (m && /^\d+$/.test(m[1])) return { name: m[2], quantity: Number(m[1]) };
              if (m) return { name: m[1], quantity: Number(m[2]) };
              return { name: l, quantity: 1 };
            });
            const o = await A.rpc("create_manual_order", { p: {
              customer_name: name, customer_phone: phone, lat: pos?.lat ?? "", lon: pos?.lon ?? "",
              district: $("#m-district", body).value, city: $("#m-city", body).value, address_text: $("#m-addr", body).value,
              items, total: $("#m-total", body).value || 0, is_cod: $("#m-cod", body).value !== "0",
              branch_id: $("#m-branch", body).value, customer_note: $("#m-note", body).value } });
            let oo = o;
            if (o.is_cod) oo = await A.rpc("set_cod_method", { p_order_id: o.id, p_method: $("#m-cod", body).value === "card" ? "card" : "cash" }).catch(() => o);
            S.orders.set(oo.id, oo); S.seen.add(oo.id);
            toast(`تم إنشاء الطلب ووجّه إلى ${branchName(o.branch_id)}`, "ok");
            if (S.route === "live") renderLive(true);
          } },
      ],
    });
    map = L.map($("#m-map", body), { attributionControl: false }).setView([26.7, 49.9], 8);
    S.maps.manual = map;
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(map);
    S.branches.forEach((b) => L.marker([b.lat, b.lon], { icon: pin("#0f766e", "🏪", 26) }).addTo(map).bindTooltip(b.name));
    map.on("click", (e) => setPos(e.latlng.lat, e.latlng.lng));
    $("#m-loc", body).addEventListener("input", (e) => { const c = A.parseCoords(e.target.value); if (c) setPos(c.lat, c.lon); });
    setTimeout(() => map.invalidateSize(), 250);
    return dlg;
  }

  // =================================================================== live map
  function renderMap() {
    if (S.plan && !S.plan.live) {
      setTitle("الخريطة المباشرة");
      $("#view").innerHTML = `<div class="card" style="text-align:center;padding:40px 20px"><div style="font-size:54px">🗺️</div>
        <h3>التتبع المباشر للمناديب متاح في باقة النمو والاحترافية</h3>
        <p class="muted">شوف مواقع مناديبك لحظة بلحظة ومسار كل مندوب خلال اليوم. باقتك الحالية: <b>${esc(S.plan.name_ar)}</b>.</p>
        <button class="btn btn-primary" data-plan>💳 عرض الباقات والترقية</button></div>`;
      bindPlanLinks($("#view"));
      return;
    }
    setTitle("الخريطة المباشرة", `<span class="small muted">🏪 الفروع · 🛵 المناديب · 📦 الطلبات النشطة</span>`);
    $("#view").innerHTML = `<div class="big-map" id="bigmap"></div>`;
    const m = L.map("bigmap", { attributionControl: false });
    S.maps.big = m;
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(m);
    const bs = S.branches.filter((b) => isAdmin() || b.id === S.me.branch_id);
    bs.forEach((b) => L.marker([b.lat, b.lon], { icon: pin("#0f766e", "🏪", 36), zIndexOffset: 500 }).addTo(m).bindPopup(`<b>${esc(b.name)}</b>`));
    if (bs.length) m.fitBounds(bs.map((b) => [b.lat, b.lon]), { padding: [40, 40] }); else m.setView([26.7, 49.9], 9);
    S.mapLayers = { drivers: L.layerGroup().addTo(m), orders: L.layerGroup().addTo(m), trail: L.layerGroup().addTo(m) };
    updateMapDrivers(); updateMapOrders();
    setTimeout(() => m.invalidateSize(), 200);
  }
  function updateMapDrivers() {
    if (!S.maps.big || !S.mapLayers) return;
    S.mapLayers.drivers.clearLayers();
    drivers(isAdmin() ? null : S.me.branch_id).filter((d) => d.last_lat).forEach((d) => {
      const stale = A.minutesSince(d.last_location_at) > 10;
      const color = d.is_online && !stale ? "#2563eb" : "#94a3b8";
      const mk = L.marker([d.last_lat, d.last_lon], { icon: pin(color, "🛵", 38), zIndexOffset: 1000 }).addTo(S.mapLayers.drivers);
      mk.bindPopup(`<b>${esc(d.full_name)}</b><br>${esc(branchName(d.branch_id))}<br>
        ${d.is_online ? "🟢 متصل" : "⚪ غير متصل"} · آخر موقع ${A.ago(d.last_location_at)}<br>
        ${d.last_battery != null ? `🔋 ${d.last_battery}% · ` : ""}${d.last_speed ? `🚀 ${Math.round(d.last_speed * 3.6)} كم/س · ` : ""}طلبات نشطة: ${activeCountFor(d.id)}<br>
        <a href="${A.telLink(d.phone)}">📞 اتصال</a> · <a href="#" data-trail="${d.id}">🧭 مسار اليوم</a>`);
      mk.on("popupopen", (e) => {
        e.popup.getElement().querySelector("[data-trail]")?.addEventListener("click", (ev) => { ev.preventDefault(); showTrail(d.id); });
      });
    });
  }
  async function showTrail(driverId) {
    const since = new Date(); since.setHours(0, 0, 0, 0);
    const { data } = await sb.from("driver_locations").select("lat,lon,at").eq("driver_id", driverId).gte("at", since.toISOString()).order("at").limit(5000);
    S.mapLayers.trail.clearLayers();
    if (!data?.length) return toast("لا يوجد مسار مسجل اليوم");
    const line = L.polyline(data.map((p) => [p.lat, p.lon]), { color: "#2563eb", weight: 4, opacity: .75 }).addTo(S.mapLayers.trail);
    S.maps.big.fitBounds(line.getBounds(), { padding: [30, 30] });
  }
  function updateMapOrders() {
    if (!S.maps.big || !S.mapLayers) return;
    S.mapLayers.orders.clearLayers();
    visibleOrders().filter((o) => ACTIVE.includes(o.status) && o.lat).forEach((o) => {
      const st = STATUS[o.status];
      L.marker([o.lat, o.lon], { icon: pin(st.color, st.icon, 30) }).addTo(S.mapLayers.orders)
        .bindPopup(`<b>#${esc(o.invoice_number || o.id)}</b> — ${esc(o.customer_name || "")}<br>${st.label} · ${esc(branchName(o.branch_id))}<br>${money(o.total)}<br><a href="#" data-o="${o.id}">فتح الطلب</a>`)
        .on("popupopen", (e) => e.popup.getElement().querySelector("[data-o]")?.addEventListener("click", (ev) => { ev.preventDefault(); openOrder(o.id); }));
    });
  }

  // =================================================================== history
  async function renderOrders() {
    setTitle("سجل الطلبات", `<button class="btn" id="export-btn">⬇️ تصدير Excel</button>`);
    const today = new Date().toISOString().slice(0, 10);
    const weekAgo = new Date(Date.now() - 6 * 86400000).toISOString().slice(0, 10);
    $("#view").innerHTML = `<div class="card">
      <div class="filters">
        <label class="row small">من <input type="date" id="h-from" value="${weekAgo}"></label>
        <label class="row small">إلى <input type="date" id="h-to" value="${today}"></label>
        ${isAdmin() ? `<select id="h-branch"><option value="">كل الفروع</option>${S.branches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}</select>` : ""}
        <select id="h-status"><option value="">كل الحالات</option>${Object.entries(STATUS).map(([k, v]) => `<option value="${k}">${v.label}</option>`).join("")}</select>
        <select id="h-driver"><option value="">كل المناديب</option>${drivers().map((d) => `<option value="${d.id}">${esc(d.full_name)}</option>`).join("")}</select>
        <input id="h-q" placeholder="🔎 اسم / جوال / رقم" style="min-width:180px">
        <button class="btn btn-primary" id="h-go">عرض</button>
      </div>
      <div id="h-sum" class="small muted" style="margin-bottom:8px"></div>
      <div class="table-wrap" id="h-table"></div>
      <div class="row" style="justify-content:center;margin-top:12px"><button class="btn hidden" id="h-more">تحميل المزيد</button></div>
    </div>`;
    let page = 0, rows = [];
    const query = (from, to) => {
      let q = sb.from("orders").select("*", { count: "exact" })
        .gte("order_created_at", new Date($("#h-from").value + "T00:00:00+03:00").toISOString())
        .lt("order_created_at", new Date(new Date($("#h-to").value + "T00:00:00+03:00").getTime() + 86400000).toISOString())
        .order("order_created_at", { ascending: false }).range(from, to);
      const b = $("#h-branch")?.value, s = $("#h-status").value, d = $("#h-driver").value, t = $("#h-q").value.trim();
      if (b) q = q.eq("branch_id", b);
      if (s) q = q.eq("status", s);
      if (d) q = q.eq("driver_id", d);
      if (t) q = q.or(`customer_name.ilike.%${t}%,customer_phone.ilike.%${t}%,invoice_number.ilike.%${t}%`);
      return q;
    };
    const load = async (reset) => {
      if (reset) { page = 0; rows = []; }
      const { data, error, count } = await query(page * 50, page * 50 + 49);
      if (error) return toast(A.errMsg(error), "error");
      rows = rows.concat(data); page++;
      $("#h-sum").textContent = `${num(count)} طلب`;
      $("#h-more").classList.toggle("hidden", rows.length >= count);
      $("#h-table").innerHTML = rows.length ? `<table><thead><tr><th>الطلب</th><th>الوقت</th><th>العميل</th><th>الجوال</th><th>الفرع</th><th>المندوب</th><th>الحالة</th><th>الإجمالي</th><th>الدفع</th></tr></thead><tbody>
        ${rows.map((o) => `<tr class="click" data-open="${o.id}"><td><b>#${esc(o.invoice_number || o.id)}</b></td><td class="small">${A.fmtDateTime(o.order_created_at)}</td>
        <td>${esc(o.customer_name)}</td><td class="mono small">${esc(o.customer_phone || "")}</td><td class="small">${esc(branchName(o.branch_id))}</td>
        <td class="small">${esc(staffName(o.driver_id))}</td><td>${A.statusBadge(o.status)}</td><td>${money(o.total)}</td>
        <td>${A.payChip(o, false)}</td></tr>`).join("")}</tbody></table>`
        : `<div class="empty">لا توجد طلبات بهذه الفلاتر</div>`;
      bindCards($("#h-table"));
    };
    $("#h-go").onclick = () => load(true);
    $("#h-more").onclick = () => load(false);
    $("#h-q").onkeydown = (e) => { if (e.key === "Enter") load(true); };
    $("#export-btn").onclick = async () => {
      const all = [];
      for (let i = 0; i < 20; i++) {
        const { data, error } = await query(i * 1000, i * 1000 + 999);
        if (error) return toast(A.errMsg(error), "error");
        all.push(...data); if (data.length < 1000) break;
      }
      exportXlsx(all);
    };
    load(true);
  }

  function loadScript(src) {
    return new Promise((res, rej) => { const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = rej; document.head.appendChild(s); });
  }
  async function exportXlsx(rows) {
    if (!window.XLSX) await loadScript("vendor/xlsx.full.min.js");
    const data = rows.map((o) => ({
      "رقم الطلب": o.invoice_number || o.id, "المصدر": o.source === "zid" ? "زد" : o.source === "salla" ? "سلة" : "يدوي",
      "وقت الطلب": A.fmtDateTime(o.order_created_at), "العميل": o.customer_name, "الجوال": o.customer_phone,
      "المدينة": o.city, "الحي": o.district, "العنوان": o.address_text, "خط العرض": o.lat, "خط الطول": o.lon,
      "الفرع": branchName(o.branch_id), "المسافة كم": o.distance_km, "المندوب": staffName(o.driver_id),
      "الحالة": STATUS[o.status]?.label, "عدد المنتجات": o.items_count,
      "المنتجات": (o.items || []).map((i) => `${i.name} × ${i.quantity}`).join(" | "),
      "الإجمالي": Number(o.total), "طريقة الدفع": o.payment_method, "عند الاستلام": o.is_cod ? "نعم" : "لا", "طريقة التحصيل": A.payInfo(o).label,
      "وقت التجهيز (د)": o.ready_at ? Math.round((new Date(o.ready_at) - new Date(o.received_at)) / 60000) : "",
      "وقت التوصيل (د)": o.delivered_at && o.picked_up_at ? Math.round((new Date(o.delivered_at) - new Date(o.picked_up_at)) / 60000) : "",
      "وقت التسليم": o.delivered_at ? A.fmtDateTime(o.delivered_at) : "", "سبب الإلغاء": o.cancel_reason || "",
    }));
    const ws = XLSX.utils.json_to_sheet(data);
    ws["!cols"] = Object.keys(data[0] || {}).map((k) => ({ wch: Math.max(10, k.length + 4) }));
    const wb = XLSX.utils.book_new(); wb.Workbook = { Views: [{ RTL: true }] };
    XLSX.utils.book_append_sheet(wb, ws, "الطلبات");
    XLSX.writeFile(wb, `msar-orders-${new Date().toISOString().slice(0, 10)}.xlsx`);
  }

  // =================================================================== reports
  async function renderReports() {
    setTitle("التقارير والإحصائيات");
    $("#view").innerHTML = `<div class="filters">
      <select id="r-range"><option value="today">اليوم</option><option value="yesterday">أمس</option><option value="7" selected>آخر 7 أيام</option><option value="30">آخر 30 يوم</option><option value="month">هذا الشهر</option><option value="90">آخر 90 يوم</option></select>
      ${isAdmin() ? `<select id="r-branch"><option value="">كل الفروع</option>${S.branches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}</select>` : ""}
    </div><div id="r-body"><div class="empty">جاري التحميل…</div></div>`;
    const load = async () => {
      const r = $("#r-range").value;
      const start = new Date(); start.setHours(0, 0, 0, 0);
      let from = new Date(start), to = new Date(start.getTime() + 86400000);
      if (r === "yesterday") { from = new Date(start - 86400000); to = start; }
      else if (r === "month") from = new Date(start.getFullYear(), start.getMonth(), 1);
      else if (/^\d+$/.test(r)) from = new Date(start - (Number(r) - 1) * 86400000);
      try {
        const d = await A.rpc("dashboard_stats", { p_from: from.toISOString(), p_to: to.toISOString(), p_branch: $("#r-branch")?.value ? Number($("#r-branch").value) : null });
        renderReportBody(d);
        if (S.fx.rating) loadRatings(from, to, $("#r-branch")?.value ? Number($("#r-branch").value) : null);
      } catch (e) { toast(A.errMsg(e), "error"); }
    };
    $("#r-range").onchange = load; $("#r-branch") && ($("#r-branch").onchange = load);
    load();
  }
  // تقييمات العملاء (من صفحة التتبع بعد التسليم)
  async function loadRatings(from, to, branch) {
    let q = sb.from("orders").select("id,invoice_number,customer_name,rating,rating_note,rated_at,driver_id,branch_id")
      .not("rating", "is", null).gte("rated_at", from.toISOString()).lt("rated_at", to.toISOString()).order("rated_at", { ascending: false }).limit(300);
    if (branch) q = q.eq("branch_id", branch);
    const { data, error } = await q;
    const host = $("#r-body"); if (error || !host) return;
    const stars = (n) => "★".repeat(n) + "☆".repeat(5 - n);
    const avg = data.length ? data.reduce((a, o) => a + o.rating, 0) / data.length : 0;
    const box = document.createElement("div");
    box.className = "card"; box.style.marginTop = "14px";
    box.innerHTML = `<div class="card-head"><h3>⭐ تقييمات العملاء</h3><span class="spacer"></span>
        ${data.length ? `<span class="chip">${num(avg, 1)} من 5 · ${data.length} تقييم</span>` : ""}</div>
      ${data.length ? `<div class="table-wrap"><table><thead><tr><th>الطلب</th><th>العميل</th><th>التقييم</th><th>التعليق</th><th>المندوب</th><th>الفرع</th><th>الوقت</th></tr></thead><tbody>
        ${data.slice(0, 50).map((o) => `<tr><td><b>#${esc(o.invoice_number || o.id)}</b></td><td>${esc(o.customer_name || "")}</td><td style="color:#d97706;white-space:nowrap">${stars(o.rating)}</td>
          <td>${esc(o.rating_note || "—")}</td><td>${esc(staffName(o.driver_id))}</td><td>${esc(branchName(o.branch_id))}</td><td class="small muted">${A.fmtDateTime(o.rated_at)}</td></tr>`).join("")}</tbody></table></div>`
        : `<div class="empty">لا يوجد تقييمات في هذه الفترة — العميل يقيّم من صفحة التتبع بعد التسليم</div>`}`;
    host.appendChild(box);
  }
  function renderReportBody(d) {
    const maxB = Math.max(1, ...d.by_branch.map((b) => b.total));
    const maxH = Math.max(1, ...d.by_hour.map((h) => h.n));
    const maxD = Math.max(1, ...d.by_day.map((x) => x.n));
    const hours = Array.from({ length: 24 }, (_, h) => d.by_hour.find((x) => x.h === h)?.n || 0);
    $("#r-body").innerHTML = `
      <div class="stats">
        <div class="stat"><div class="k">إجمالي الطلبات</div><div class="v">${num(d.total)}</div></div>
        <div class="stat"><div class="k">تم التسليم</div><div class="v" style="color:var(--ok)">${num(d.delivered)}</div><div class="s">${d.total ? Math.round(d.delivered / d.total * 100) : 0}%</div></div>
        <div class="stat"><div class="k">ملغية</div><div class="v" style="color:var(--danger)">${num(d.cancelled)}</div></div>
        <div class="stat"><div class="k">المبيعات المسلّمة</div><div class="v" style="font-size:21px">${money(d.revenue)}</div></div>
        <div class="stat"><div class="k">💵 تحصيل نقدي</div><div class="v" style="font-size:21px">${money(d.cod_collected)}</div></div>
        <div class="stat"><div class="k">💳 شبكة عند الاستلام</div><div class="v" style="font-size:21px;color:#1d4ed8">${money(d.cod_card || 0)}</div><div class="s">مدفوع مسبقاً: ${money(d.prepaid || 0)}</div></div>
        <div class="stat"><div class="k">متوسط التجهيز</div><div class="v">${d.avg_prep_min ?? "—"}<small> د</small></div></div>
        <div class="stat"><div class="k">متوسط التوصيل</div><div class="v">${d.avg_delivery_min ?? "—"}<small> د</small></div></div>
        <div class="stat"><div class="k">متوسط المدة الكاملة</div><div class="v">${d.avg_total_min ?? "—"}<small> د</small></div><div class="s">متوسط المسافة ${d.avg_distance_km ?? "—"} كم</div></div>
      </div>
      <div class="grid-2" style="gap:14px">
        <div class="card"><div class="card-head"><h3>🏪 الطلبات حسب الفرع</h3></div><div class="bars">
          ${d.by_branch.map((b) => `<div class="bar"><span>${esc(b.name.replace("بقالة ", ""))}</span><div class="track"><div class="fill" style="width:${b.total / maxB * 100}%"></div></div><b>${b.total}</b></div>`).join("")}</div>
          <div class="table-wrap" style="margin-top:12px"><table><thead><tr><th>الفرع</th><th>مسلّم</th><th>ملغي</th><th>المبيعات</th><th>متوسط المدة</th></tr></thead><tbody>
          ${d.by_branch.map((b) => `<tr><td>${esc(b.name)}</td><td>${b.delivered}</td><td>${b.cancelled}</td><td>${money(b.revenue)}</td><td>${b.avg_total_min ?? "—"} د</td></tr>`).join("")}</tbody></table></div></div>
        <div class="card"><div class="card-head"><h3>🛵 أداء المناديب</h3></div><div class="table-wrap"><table><thead><tr><th>المندوب</th><th>الفرع</th><th>طلبات مسلّمة</th><th>💵 نقدي محصّل</th><th>💳 شبكة</th><th>متوسط التوصيل</th></tr></thead><tbody>
          ${d.by_driver.sort((a, b) => b.delivered - a.delivered).map((x) => `<tr><td>${esc(x.name)}</td><td class="small">${esc(branchName(x.branch_id))}</td><td><b>${x.delivered}</b></td><td>${money(x.cod)}</td><td>${money(x.card || 0)}</td><td>${x.avg_delivery_min ?? "—"} د</td></tr>`).join("") || `<tr><td colspan="6" class="empty">لا يوجد</td></tr>`}</tbody></table></div></div>
      </div>
      <div class="card" style="margin-top:14px"><div class="card-head"><h3>⏰ الطلبات حسب الساعة</h3></div>
        <div class="vbars" style="margin-bottom:22px">${hours.map((n, h) => `<div class="vb" style="height:${n / maxH * 100}%" data-v="${n}"><span>${h}</span></div>`).join("")}</div></div>
      <div class="grid-2" style="gap:14px;margin-top:14px">
        <div class="card"><div class="card-head"><h3>📅 الطلبات اليومية</h3></div><div class="bars">
          ${d.by_day.map((x) => `<div class="bar"><span>${new Date(x.d).toLocaleDateString("ar-SA", { weekday: "short", day: "numeric", month: "short" })}</span><div class="track"><div class="fill" style="width:${x.n / maxD * 100}%"></div></div><b>${x.n}</b></div>`).join("") || `<div class="empty">لا يوجد</div>`}</div></div>
        <div class="card"><div class="card-head"><h3>🏆 الأكثر طلباً</h3></div><ol style="margin:0;padding-inline-start:20px">
          ${d.top_products.map((p) => `<li style="margin-bottom:6px">${esc(p.name)} <span class="chip">${num(p.qty)}</span></li>`).join("") || `<div class="empty">لا يوجد</div>`}</ol></div>
      </div>`;
  }

  // =================================================================== staff
  async function renderStaff() {
    await loadStaff();
    try { S.plan = await A.rpc("my_plan"); } catch (_) {}
    setTitle("الموظفين والمناديب", isAdmin() ? `<button class="btn btn-primary" id="invite-user">📧 دعوة بالإيميل</button><button class="btn" id="add-user">➕ حساب باسم مستخدم</button>` : "");
    const rows = S.staff.filter((p) => isAdmin() || p.branch_id === S.me.branch_id);
    const groups = [["driver", "🛵 المناديب"], ["cashier", "🧾 الكاشير"], ["admin", "👑 المدراء"]];
    $("#view").innerHTML = (isAdmin() ? usageLine("staff") : "") + groups.map(([r, t]) => {
      const list = rows.filter((p) => p.role === r);
      if (!list.length && r !== "driver") return "";
      return `<div class="card"><div class="card-head"><h3>${t} (${list.length})</h3></div><div class="table-wrap"><table><thead><tr>
        <th>الاسم</th><th>الدخول</th><th>الجوال</th><th>الفرع</th>${r === "driver" ? "<th>الحالة</th><th>آخر ظهور</th><th>البطارية</th><th>نشطة</th>" : ""}<th>الحساب</th>${isAdmin() ? "<th></th>" : ""}</tr></thead><tbody>
        ${list.map((p) => `<tr>
          <td><b>${esc(p.full_name)}</b>${p.vehicle ? `<div class="small muted">${esc(p.vehicle)}</div>` : ""}</td><td class="mono small">${esc(p.email || p.username)}</td>
          <td><a href="${A.telLink(p.phone)}" class="mono">${esc(p.phone || "—")}</a></td><td class="small">${esc(p.branch_id ? branchName(p.branch_id) : "كل الفروع")}</td>
          ${r === "driver" ? `<td><span class="dot ${p.is_online ? "on" : ""}"></span> ${p.is_online ? "متصل" : "غير متصل"}</td><td class="small">${A.ago(p.last_seen_at) || "—"}</td>
          <td>${p.last_battery != null ? p.last_battery + "%" : "—"}</td><td>${activeCountFor(p.id)}</td>` : ""}
          <td>${p.is_active ? `<span class="chip chip-paid">فعّال</span>` : `<span class="chip chip-warn">موقوف</span>`}</td>
          ${isAdmin() ? `<td class="row" style="flex-wrap:nowrap">
            <button class="btn btn-sm" data-edit="${p.id}">تعديل</button>
            <button class="btn btn-sm" data-pass="${p.id}">🔑</button>
            ${p.id !== S.me.id ? `<button class="btn btn-sm" data-toggle="${p.id}">${p.is_active ? "إيقاف" : "تفعيل"}</button>
            <button class="btn btn-sm" style="color:var(--danger)" data-del="${p.id}">حذف</button>` : ""}</td>` : ""}
        </tr>`).join("") || `<tr><td colspan="10" class="empty">لا يوجد — أضف ${r === "driver" ? "مندوب" : "مستخدم"}</td></tr>`}</tbody></table></div></div>`;
    }).join("") + `<div id="invites-card"></div><div class="card"><h3>📱 تطبيق المندوب</h3>
      <p class="muted small">أرسل للمندوب أحد الرابطين، وسجّل له حساب من هنا (اسم مستخدم + كلمة مرور).</p>
      <div class="row"><a class="btn" href="driver" target="_blank">🌐 نسخة الويب (PWA)</a>
      <a class="btn btn-primary" href="${esc(A.C.APK_URL || "#")}" target="_blank">⬇️ تحميل تطبيق أندرويد APK</a>
      <button class="btn" id="copy-driver-link">📋 نسخ رابط التطبيق</button></div></div>`;
    $("#copy-driver-link").onclick = () => { A.copy(new URL("driver", location.href).href); };
    if (!isAdmin()) return;
    loadInvites();
    $("#invite-user").onclick = () => inviteDialog();
    $("#add-user").onclick = () => userDialog();
    $$("[data-edit]").forEach((b) => b.onclick = () => userDialog(S.staff.find((p) => p.id === b.dataset.edit)));
    $$("[data-pass]").forEach((b) => b.onclick = async () => {
      const p = S.staff.find((x) => x.id === b.dataset.pass);
      if (p.email) {
        try { const r = await A.callFn("admin", { action: "staff_reset_link", user_id: p.id }); shareLinkDialog(`رابط استعادة كلمة المرور — ${p.full_name}`, r.link, `هلا ${p.full_name}، هذا رابط تختار فيه كلمة مرور جديدة لحسابك في مسار (صالح لفترة محدودة):`); }
        catch (e) { toast(A.errMsg(e), "error"); }
        return;
      }
      A.modal({ title: `تغيير كلمة مرور ${p.full_name}`, body: `<label class="field"><span>كلمة المرور الجديدة</span><input id="np" type="text" dir="ltr" minlength="8"></label>`,
        actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "حفظ", cls: "btn-primary", onClick: async (w) => {
          await A.callFn("admin", { action: "set_password", user_id: p.id, password: $("#np", w).value }); toast("تم تغيير كلمة المرور", "ok"); } }] });
    });
    $$("[data-toggle]").forEach((b) => b.onclick = async () => {
      const p = S.staff.find((x) => x.id === b.dataset.toggle);
      try { await A.callFn("admin", { action: "set_active", user_id: p.id, active: !p.is_active }); toast("تم", "ok"); renderStaff(); } catch (e) { toast(A.errMsg(e), "error"); }
    });
    $$("[data-del]").forEach((b) => b.onclick = async () => {
      const p = S.staff.find((x) => x.id === b.dataset.del);
      if (!(await A.confirmBox("حذف المستخدم", `حذف ${p.full_name}؟ (إذا عنده طلبات سابقة سيتم إيقافه فقط للحفاظ على السجل)`, "حذف", "btn-danger"))) return;
      try { const r = await A.callFn("admin", { action: "delete_user", user_id: p.id }); toast(r.deactivated ? "تم إيقاف الحساب" : "تم الحذف", "ok"); renderStaff(); } catch (e) { toast(A.errMsg(e), "error"); }
    });
  }

  // ---------------------------------------------------------------- الدعوات
  function shareLinkDialog(title, link, msg) {
    const text = `${msg}\n${link}`;
    const m = A.modal({ title, body: `<p class="small muted">أرسل الرابط للشخص نفسه فقط (واتساب أو أي طريقة). الرابط شخصي ولمرة وحدة.</p>
      <textarea readonly dir="ltr" rows="3" style="width:100%;font-size:12px">${esc(link)}</textarea>`,
      actions: [{ label: "📋 نسخ", cls: "btn", onClick: () => { A.copy(link); return false; } },
        { label: "واتساب", cls: "btn-primary", onClick: () => { window.open(`https://wa.me/?text=${encodeURIComponent(text)}`, "_blank"); return false; } },
        { label: "إغلاق", cls: "btn-ghost" }] });
    return m;
  }
  async function loadInvites() {
    const box = $("#invites-card"); if (!box) return;
    const { data } = await sb.from("invites").select("token,email,role,full_name,branch_id,expires_at,created_at").is("accepted_at", null).order("created_at", { ascending: false });
    const list = (data || []).filter((i) => Date.parse(i.expires_at) > Date.now());
    if (!list.length) { box.innerHTML = ""; return; }
    box.innerHTML = `<div class="card"><div class="card-head"><h3>📨 دعوات بانتظار القبول (${list.length})</h3></div><div class="table-wrap"><table><thead><tr><th>الاسم</th><th>الإيميل</th><th>الدور</th><th>الفرع</th><th>تنتهي</th><th></th></tr></thead><tbody>
      ${list.map((i) => `<tr><td>${esc(i.full_name)}</td><td class="mono small">${esc(i.email)}</td><td>${ROLES[i.role] || i.role}</td><td class="small">${esc(i.branch_id ? branchName(i.branch_id) : "كل الفروع")}</td>
        <td class="small">${A.fmtDateTime(i.expires_at)}</td><td class="row" style="flex-wrap:nowrap"><button class="btn btn-sm" data-inv-link="${i.token}">🔗 الرابط</button><button class="btn btn-sm" style="color:var(--danger)" data-inv-del="${i.token}">إلغاء</button></td></tr>`).join("")}
      </tbody></table></div></div>`;
    $$("[data-inv-link]", box).forEach((b) => b.onclick = () => { const i = list.find((x) => x.token === b.dataset.invLink); shareLinkDialog(`دعوة ${i.full_name}`, `${A.BASE}join?i=${i.token}`, `هلا ${i.full_name}، هذي دعوتك للانضمام إلى ${A.store?.name || "متجرنا"} في مسار:`); });
    $$("[data-inv-del]", box).forEach((b) => b.onclick = async () => { try { await A.callFn("admin", { action: "invite_revoke", token: b.dataset.invDel }); toast("تم إلغاء الدعوة", "ok"); loadInvites(); } catch (e) { toast(A.errMsg(e), "error"); } });
  }
  function inviteDialog() {
    const body = `<p class="small muted" style="margin-top:0">الشخص يستلم رابط، ويدخل بإيميله (أو بقوقل) ويختار كلمة مروره بنفسه — ما تحتاج تعرفها.</p><div class="grid-2">
      <label class="field"><span>الاسم الكامل *</span><input id="i-name"></label>
      <label class="field"><span>الإيميل *</span><input id="i-email" type="email" dir="ltr" placeholder="name@gmail.com"></label>
      <label class="field"><span>الدور *</span><select id="i-role">${Object.entries(ROLES).map(([k, v]) => `<option value="${k}" ${k === "driver" ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="field"><span>الفرع</span><select id="i-branch"><option value="">— (للتاجر: كل الفروع)</option>${S.branches.map((b) => `<option value="${b.id}">${esc(b.name)}</option>`).join("")}</select></label>
      <label class="field"><span>الجوال</span><input id="i-phone" dir="ltr" placeholder="05xxxxxxxx"></label>
      <label class="field"><span>المركبة / ملاحظة</span><input id="i-veh"></label></div>`;
    A.modal({ title: "📧 دعوة موظف / مندوب", body, actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "إنشاء الدعوة", cls: "btn-primary", onClick: async (w) => {
      const v = (id) => $(id, w)?.value?.trim();
      const r = await A.callFn("admin", { action: "invite_create", full_name: v("#i-name"), email: v("#i-email"), role: v("#i-role"), branch_id: v("#i-branch"), phone: v("#i-phone"), vehicle: v("#i-veh") });
      shareLinkDialog(`دعوة ${v("#i-name")}`, r.link, `هلا ${v("#i-name")}، هذي دعوتك للانضمام إلى ${A.store?.name || "متجرنا"} في مسار:`);
      loadInvites();
    } }] });
  }

  function userDialog(p) {
    const edit = !!p;
    const body = `<div class="grid-2">
      <label class="field"><span>الاسم الكامل *</span><input id="u-name" value="${esc(p?.full_name || "")}"></label>
      <label class="field"><span>الدور *</span><select id="u-role">${Object.entries(ROLES).map(([k, v]) => `<option value="${k}" ${p?.role === k || (!p && k === "driver") ? "selected" : ""}>${v}</option>`).join("")}</select></label>
      <label class="field"><span>اسم المستخدم (إنجليزي) *</span><input id="u-user" dir="ltr" value="${esc(p?.username || "")}" ${edit ? "disabled" : ""} placeholder="ahmed1"></label>
      ${edit ? "" : `<label class="field"><span>كلمة المرور * <small class="muted">(8 أحرف أو أكثر)</small></span><input id="u-pass" dir="ltr" minlength="8"></label>`}
      <label class="field"><span>الجوال <small class="muted">(إلزامي للمندوب — يدخل به التطبيق)</small></span><input id="u-phone" dir="ltr" value="${esc(p?.phone || "")}" placeholder="05xxxxxxxx"></label>
      <label class="field"><span>الفرع</span><select id="u-branch"><option value="">— (للتاجر: كل الفروع)</option>${S.branches.map((b) => `<option value="${b.id}" ${p?.branch_id === b.id ? "selected" : ""}>${esc(b.name)}</option>`).join("")}</select></label>
      <label class="field"><span>المركبة / ملاحظة</span><input id="u-veh" value="${esc(p?.vehicle || "")}" placeholder="مثال: دباب — لوحة 1234"></label>
    </div>`;
    A.modal({
      title: edit ? `تعديل ${p.full_name}` : "إضافة موظف / مندوب", body,
      actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "حفظ", cls: "btn-primary", onClick: async (w) => {
        const v = (id) => $(id, w)?.value?.trim();
        if (v("#u-role") === "driver" && String(v("#u-phone") || "").replace(/\D/g, "").length < 9) throw new Error("جوال المندوب مطلوب — يدخل به التطبيق (مثال: 0501234567)");
        if (edit) {
          await A.rpc("admin_update_profile", { p_id: p.id, p: { full_name: v("#u-name"), role: v("#u-role"), phone: v("#u-phone"), branch_id: v("#u-branch"), vehicle: v("#u-veh") } });
        } else {
          await A.callFn("admin", { action: "create_user", full_name: v("#u-name"), role: v("#u-role"), username: v("#u-user"), password: $("#u-pass", w).value, phone: v("#u-phone"), branch_id: v("#u-branch"), vehicle: v("#u-veh") });
        }
        toast("تم الحفظ", "ok"); renderStaff();
      } }],
    });
  }

  // =================================================================== branches
  async function renderBranches() {
    await loadBranches();
    try { S.plan = await A.rpc("my_plan"); } catch (_) {}
    setTitle("الفروع", `<button class="btn btn-primary" id="add-branch">➕ فرع جديد</button>`);
    $("#view").innerHTML = `${usageLine("branches")}<div class="card table-wrap"><table><thead><tr><th>#</th><th>الفرع</th><th>المدينة</th><th>الإحداثيات</th><th>الجوال</th><th>نطاق التوصيل</th><th>الحالة</th><th>مناديب</th><th></th></tr></thead><tbody>
      ${S.branches.map((b) => `<tr><td>${b.id}</td><td><b>${esc(b.name)}</b></td><td>${esc(b.city)}</td>
        <td class="mono small"><a target="_blank" href="${A.mapsLink(b.lat, b.lon)}">${b.lat.toFixed(5)}, ${b.lon.toFixed(5)}</a></td>
        <td class="mono">${esc(b.phone || "—")}</td><td>${num(branchRadius(b), 1)} كم ${b.max_radius_km != null ? `<span class="chip">خاص</span>` : `<span class="chip">عام</span>`}</td><td>${b.is_active ? `<span class="chip chip-paid">يستقبل طلبات</span>` : `<span class="chip chip-warn">متوقف</span>`}</td>
        <td>${drivers(b.id).length}</td><td><button class="btn btn-sm" data-b="${b.id}">تعديل</button></td></tr>`).join("")}</tbody></table></div>
      <div class="card"><div class="card-head"><h3>🗺️ مواقع الفروع ومناطق التغطية</h3><span class="small muted">الدائرة = نطاق التوجيه التلقائي — أي طلب خارج كل الدوائر يحتاج توجيه منك</span></div><div class="big-map" style="height:460px" id="bmap"></div></div>`;
    const m = L.map("bmap", { attributionControl: false });
    S.maps.b = m;
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(m);
    const colors = ["#0f766e", "#2563eb", "#7c3aed", "#d97706", "#dc2626", "#0891b2"];
    S.branches.forEach((b, i) => {
      L.circle([b.lat, b.lon], { radius: branchRadius(b) * 1000, color: colors[i % 6], fillOpacity: .08, weight: 1 }).addTo(m);
      L.marker([b.lat, b.lon], { icon: pin(colors[i % 6], "🏪", 34) }).addTo(m).bindTooltip(b.name, { permanent: true, direction: "top", offset: [0, -16] });
    });
    $("#add-branch").onclick = () => branchDialog();
    $$("[data-b]").forEach((x) => x.onclick = () => branchDialog(S.branches.find((b) => b.id === Number(x.dataset.b))));
    if (S.branches.length) m.fitBounds(S.branches.map((b) => [b.lat, b.lon]), { padding: [40, 40] }); else m.setView([24.7, 45.5], 5);
    if (!S.branches.length) setTimeout(() => branchDialog(), 300);
  }
  function branchDialog(b) {
    const body = `<label class="field"><span>اسم الفرع</span><input id="b-name" value="${esc(b?.name || "")}"></label>
      <div class="grid-2"><label class="field"><span>المدينة</span><input id="b-city" value="${esc(b?.city || "")}"></label>
      <label class="field"><span>الجوال</span><input id="b-phone" dir="ltr" value="${esc(b?.phone || "")}"></label></div>
      <label class="field"><span>الموقع (رابط قوقل ماب أو lat, lon)</span><input id="b-loc" dir="ltr" value="${b ? `${b.lat}, ${b.lon}` : ""}"></label>
      <label class="field"><span>نطاق توصيل خاص لهذا الفرع (كم) — اتركه فاضي ليستخدم النطاق العام (${num(S.radius, 1)} كم)</span><input id="b-radius" type="number" step="0.5" min="0.5" max="100" value="${b?.max_radius_km ?? ""}" placeholder="${S.radius}"></label>
      <label class="row"><input type="checkbox" id="b-active" ${!b || b.is_active ? "checked" : ""} style="width:auto;min-height:auto"> يستقبل طلبات (عند الإيقاف تتحول الطلبات للفرع الأقرب التالي)</label>`;
    A.modal({ title: b ? "تعديل الفرع" : "فرع جديد", body, actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "حفظ", cls: "btn-primary", onClick: async (w) => {
      const c = await A.resolveCoords($("#b-loc", w).value);
      if (!c) { toast("ما قدرت أقرأ الموقع — الصق رابط قوقل ماب أو اكتب الإحداثيات مثل: 26.4207, 50.0888", "error", 6000); return false; }
      const row = { name: $("#b-name", w).value.trim(), city: $("#b-city", w).value.trim(), phone: $("#b-phone", w).value.trim() || null, lat: c.lat, lon: c.lon, is_active: $("#b-active", w).checked,
        max_radius_km: $("#b-radius", w).value.trim() === "" ? null : Number($("#b-radius", w).value) };
      const { error } = b ? await sb.from("branches").update(row).eq("id", b.id) : await sb.from("branches").insert(row);
      if (error) throw error;
      toast("تم الحفظ", "ok"); renderBranches();
    } }] });
  }

  // =================================================================== routing radius
  async function renderRouting() {
    wizSet("radius");
    await Promise.all([loadBranches(), loadRadius()]);
    setTitle("نطاق التوصيل التلقائي");
    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const { data: hist } = await sb.from("orders").select("lat,lon").not("lat", "is", null).gte("order_created_at", since).limit(5000);
    const pts = hist || [];
    let radius = S.radius;
    $("#view").innerHTML = `
      <div class="card">
        <div class="card-head"><h3>🎯 الطلبات داخل هذا النطاق تروح تلقائياً لأقرب فرع — والأبعد منه يوصلك أنت لتوجّهه</h3></div>
        <div class="row" style="gap:16px;align-items:center">
          <input type="range" id="rr" min="1" max="30" step="0.5" value="${radius}" style="flex:1;min-width:200px;accent-color:var(--brand)">
          <div class="row" style="gap:6px"><input type="number" id="rn" min="0.5" max="100" step="0.5" value="${radius}" style="width:90px;text-align:center;font-size:20px;font-weight:800"><b>كم</b></div>
        </div>
        <div class="row" style="gap:6px;margin-top:10px">${[2, 3, 5, 7, 10, 15].map((k) => `<button class="btn btn-sm" data-k="${k}">${k} كم</button>`).join("")}</div>
        <div id="rprev" class="stats" style="margin:14px 0 0"></div>
        <div class="row" style="margin-top:12px">
          <button class="btn btn-primary btn-lg" id="rsave">💾 حفظ النطاق</button>
          <button class="btn" id="rapply">🔄 وجّه الطلبات المعلّقة حسب النطاق الجديد</button>
        </div>
        <p class="small muted" style="margin-top:10px">💡 تقدر تحدد نطاق مختلف لفرع معيّن من صفحة <a href="#branches">الفروع</a> (مثلاً فرع الجبيل 8 كم وباقي الفروع 5 كم).</p>
      </div>
      <div class="card"><div class="card-head"><h3>🗺️ التغطية الحالية</h3><span class="small muted">النقاط = طلبات آخر 30 يوم (🟢 داخل النطاق · 🔴 خارجه)</span></div>
        <div class="big-map" style="height:480px" id="rmap"></div></div>`;
    const m = L.map("rmap", { attributionControl: false });
    S.maps.r = m;
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19 }).addTo(m);
    const circles = [], dots = L.layerGroup().addTo(m);
    S.branches.filter((b) => b.is_active).forEach((b) => {
      circles.push({ b, c: L.circle([b.lat, b.lon], { radius: 1, color: "#0f766e", fillOpacity: .1, weight: 2 }).addTo(m) });
      L.marker([b.lat, b.lon], { icon: pin("#0f766e", "🏪", 30) }).addTo(m).bindTooltip(b.name);
    });
    if (S.branches.length) m.fitBounds(S.branches.map((b) => [b.lat, b.lon]), { padding: [60, 60] }); else m.setView([24.7, 45.5], 5);
    const inRange = (p, r) => S.branches.some((b) => b.is_active && A.haversine(p.lat, p.lon, b.lat, b.lon) <= (b.max_radius_km != null ? Number(b.max_radius_km) : r));
    const update = (r, fromInput) => {
      radius = Math.max(0.5, Math.min(100, Number(r) || 5));
      if (fromInput !== "range") $("#rr").value = Math.min(30, radius);
      if (fromInput !== "num") $("#rn").value = radius;
      circles.forEach(({ b, c }) => c.setRadius((b.max_radius_km != null ? Number(b.max_radius_km) : radius) * 1000));
      dots.clearLayers();
      let inside = 0;
      pts.forEach((p) => { const ok = inRange(p, radius); if (ok) inside++;
        L.circleMarker([p.lat, p.lon], { radius: 4, color: ok ? "#16a34a" : "#dc2626", fillOpacity: .8, weight: 1 }).addTo(dots); });
      const pct = pts.length ? Math.round(inside / pts.length * 100) : 0;
      $("#rprev").innerHTML = `
        <div class="stat"><div class="k">النطاق</div><div class="v">${num(radius, 1)} كم</div><div class="s">${radius === S.radius ? "المحفوظ حالياً" : "غير محفوظ"}</div></div>
        <div class="stat"><div class="k">تلقائي (آخر 30 يوم)</div><div class="v" style="color:var(--ok)">${pct}%</div><div class="s">${inside} من ${pts.length} طلب</div></div>
        <div class="stat"><div class="k">يحتاج توجيه منك</div><div class="v" style="color:var(--danger)">${pts.length - inside}</div><div class="s">طلب خارج النطاق</div></div>`;
    };
    $("#rr").oninput = (e) => update(e.target.value, "range");
    $("#rn").oninput = (e) => update(e.target.value, "num");
    $$("[data-k]").forEach((b) => b.onclick = () => update(b.dataset.k));
    $("#rsave").onclick = async () => {
      try { await A.rpc("admin_set_setting", { p_key: "radius_km", p_value: radius }); S.radius = radius; update(radius); toast(`تم حفظ النطاق: ${num(radius, 1)} كم`, "ok"); }
      catch (e) { toast(A.errMsg(e), "error"); }
    };
    $("#rapply").onclick = async () => {
      try { const n = await A.rpc("route_pending_orders"); toast(n ? `تم توجيه ${n} طلب تلقائياً` : "ما فيه طلبات معلّقة داخل النطاق", "ok"); loadOrders(); }
      catch (e) { toast(A.errMsg(e), "error"); }
    };
    update(radius);
    setTimeout(() => m.invalidateSize(), 200);
  }

  // =================================================================== settings / zid
  async function renderSettings() {
    const SL = A.isSalla(), PN = A.platformName();
    setTitle(`الربط مع ${PN} والإعدادات`);
    let st = {};
    try { st = await A.rpc("admin_get_settings"); } catch (e) { toast(A.errMsg(e), "error"); }
    const fn = `${A.C.SUPABASE_URL}/functions/v1/${SL ? "salla" : "zid"}`;
    const connected = SL ? !!st.salla_connected : !!st.zid_connected, connectedAt = SL ? st.salla_connected_at : st.zid_connected_at;
    const imp = st.import_statuses || ["new", "preparing", "ready"];
    const trialLeft = st.trial_ends_at ? Math.ceil((new Date(st.trial_ends_at) - Date.now()) / 86400000) : null;
    try { S.plan = await A.rpc("my_plan"); } catch (_) {}
    $("#view").innerHTML = `${usageLine("orders")}
      <div class="card">
        <div class="card-head"><h3>🏪 متجرك</h3><span class="spacer"></span>
          <span class="badge" style="background:${st.status === "active" ? "#dcfce7;color:#166534" : "#fef3c7;color:#92400e"}">${st.status === "active" ? "✅ اشتراك فعّال" : `🕒 فترة تجريبية${trialLeft !== null ? ` · باقي ${Math.max(trialLeft, 0)} يوم` : ""}`}</span></div>
        <div class="grid-2">
          <label class="field"><span>اسم المتجر (يظهر للموظفين وفي رسائل العملاء)</span><input id="s-name" value="${esc(st.store_name || "")}"></label>
          <div class="field"><span>رمز المتجر (للدخول)</span><div class="row"><b class="mono" style="font-size:18px">${esc(st.store_code || "")}</b><button class="btn btn-sm" id="copy-code">📋 نسخ</button></div></div>
        </div>
        <button class="btn btn-primary" id="s-save-name">حفظ الاسم</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>🔗 الربط مع ${PN}</h3><span class="spacer"></span>
          ${connected ? `<span class="badge" style="background:#dcfce7;color:#166534">✅ مربوط</span>` : `<span class="badge" style="background:#fee2e2;color:#991b1b">غير مربوط</span>`}</div>
        <div class="small muted">${connected ? `تم الربط ${A.fmtDateTime(connectedAt)} · آخر طلب وصل من ${PN}: ${st.zid_last_sync ? A.ago(st.zid_last_sync) : "—"}` : SL ? "ثبّت مسار برو من متجر تطبيقات سلة، والربط يتم تلقائياً." : "اربط متجرك من سوق تطبيقات زد أو من الزر بالأسفل."}</div>
        <div class="row" style="margin-top:12px">
          ${SL ? `<a class="btn ${connected ? "" : "btn-primary"}" href="https://apps.salla.sa/ar" target="_blank" rel="noopener">${connected ? "🛍️ متجر تطبيقات سلة" : "🔗 ثبّت مسار برو من سلة"}</a>`
               : `<a class="btn ${connected ? "" : "btn-primary"}" href="${fn}?action=install" target="_blank">${connected ? "🔄 إعادة الربط" : "🔗 ربط متجري في زد"}</a>`}
          <button class="btn" id="z-test" ${connected ? "" : "disabled"}>🩺 فحص الاتصال</button>
          <button class="btn" id="z-sync" ${connected ? "" : "disabled"}>⬇️ جلب آخر الطلبات</button>
          ${SL ? "" : `<button class="btn" id="z-hooks" ${connected ? "" : "disabled"}>📡 إعادة تسجيل الإشعارات</button>`}
          <button class="btn" id="z-import" ${connected ? "" : "disabled"}>➕ استيراد طلب برقمه</button>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>🔄 تحديث حالة الطلب في ${PN} تلقائياً</h3><span class="spacer"></span>
          ${st.push_status === true ? `<span class="badge" style="background:#dcfce7;color:#166534">✅ مفعّل</span>` : `<span class="badge" style="background:#f1f5f9;color:#475569">⏸️ موقوف</span>`}</div>
        <p class="small muted" style="margin-top:0">لما يتغيّر الطلب عندك يتحدّث في ${PN} مباشرة، والعميل يوصله إشعار ${PN}:
          ${(SL ? [["قيد التجهيز", "قيد التنفيذ"], ["جاهز", "تم التنفيذ"], ["خرج مع المندوب", "جاري التوصيل"], ["تم التسليم", "تم التوصيل"], ["ملغي", "ملغي"]] : [["قيد التجهيز", "جاري التجهيز"], ["جاهز", "جاهز"], ["خرج مع المندوب", "جاري التوصيل"], ["تم التسليم", "تم التوصيل"], ["ملغي", "ملغي"]]).map(([a, b]) => `<span class="chip">${a} → ${b}</span>`).join(" ")}</p>
        <label class="row" style="margin-bottom:10px"><input type="checkbox" id="o-push" style="width:auto;min-height:auto" ${st.push_status === true ? "checked" : ""}> <b>فعّل تحديث الحالات في ${PN}</b></label>
        ${SL ? "" : `<label class="field"><span>معرّف مخزون زد (مطلوب أحياناً لحالة "جاهز" — اختياري)</span><input id="o-loc" dir="ltr" value="${esc(st.location_id || "")}"></label>`}
        <div class="row small" style="gap:6px">
          <span class="chip">أُرسل اليوم: <b>${num(st.zid_outbox_sent_today ?? 0)}</b></span>
          <span class="chip">بالانتظار: <b>${num(st.zid_outbox_pending ?? 0)}</b></span>
          <span class="chip ${st.zid_outbox_failed ? "chip-warn" : ""}">فشل: <b>${num(st.zid_outbox_failed ?? 0)}</b></span>
          <span class="spacer"></span><button class="btn btn-sm" id="zh-log">📜 آخر التحديثات المرسلة</button>
        </div>
        <div class="table-wrap hidden" id="zh-table" style="margin-top:10px"></div>
      </div>

      <div class="card">
        <div class="card-head"><h3>⚙️ أي طلبات تدخل النظام؟</h3></div>
        <div class="field"><span>استيراد الطلبات اللي حالتها في ${PN}:</span><div class="row">
          ${["new", "preparing", "ready", "indelivery"].map((x) => `<label class="row small"><input type="checkbox" class="o-imp" value="${x}" style="width:auto;min-height:auto" ${imp.includes(x) ? "checked" : ""}> ${(SL ? { new: "بإنتظار المراجعة", preparing: "قيد التنفيذ", ready: "تم التنفيذ", indelivery: "جاري التوصيل" } : { new: "جديد", preparing: "قيد التجهيز", ready: "جاهز", indelivery: "جاري التوصيل" })[x]}</label>`).join("")}</div></div>
        <label class="field"><span>طرق الشحن اللي تخص مناديبك فقط (فاضي = كل الطلبات، افصل بفاصلة)</span><input id="o-ship" value="${esc((st.shipping_filter || []).join("، "))}" placeholder="مثال: توصيل المتجر"></label>
        <button class="btn btn-primary" id="o-save">حفظ الإعدادات</button>
      </div>

      <div class="card"><div class="card-head"><h3>📜 سجل الربط مع ${PN}</h3><span class="spacer"></span><button class="btn btn-sm" id="log-refresh">تحديث</button></div><div class="table-wrap" id="zlog"></div></div>`;

    const save = (k, v) => A.rpc("admin_set_setting", { p_key: k, p_value: v });
    $("#copy-code").onclick = () => { A.copy(st.store_code || "", "تم نسخ رمز المتجر"); };
    $("#s-save-name").onclick = async () => { try { await save("store_name", $("#s-name").value.trim()); toast("تم الحفظ", "ok"); } catch (e) { toast(A.errMsg(e), "error"); } };
    $("#o-push").onchange = async (e) => {
      try { await save("push_status", e.target.checked); toast(e.target.checked ? `✅ تحديث الحالات في ${PN} مفعّل` : `تم إيقاف تحديث الحالات في ${PN}`, "ok"); renderSettings(); }
      catch (er) { toast(A.errMsg(er), "error"); e.target.checked = !e.target.checked; }
    };
    $("#o-save").onclick = async () => {
      try {
        await save("import_statuses", $$(".o-imp:checked").map((x) => x.value));
        const ship = $("#o-ship").value.split(/[,،]/).map((x) => x.trim()).filter(Boolean);
        await save("shipping_filter", ship.length ? ship : null);
        if ($("#o-loc")) await save("location_id", $("#o-loc").value.trim() || null);
        toast("تم الحفظ", "ok");
      } catch (e) { toast(A.errMsg(e), "error"); }
    };
    $("#zh-log").onclick = async () => {
      const t = $("#zh-table"); t.classList.toggle("hidden"); if (t.classList.contains("hidden")) return;
      try {
        const rows = await A.rpc("admin_zid_outbox", { p_limit: 40 });
        const lbl = SL ? { preparing: "قيد التنفيذ", ready: "تم التنفيذ", indelivery: "جاري التوصيل", delivered: "تم التوصيل", cancelled: "ملغي" } : { preparing: "جاري التجهيز", ready: "جاهز", indelivery: "جاري التوصيل", delivered: "تم التوصيل", cancelled: "ملغي" };
        t.innerHTML = rows?.length ? `<table><thead><tr><th>الوقت</th><th>طلب ${PN}</th><th>الحالة المرسلة</th><th>النتيجة</th><th>محاولات</th></tr></thead><tbody>
          ${rows.map((r) => `<tr><td class="small">${A.fmtDateTime(r.created_at)}</td><td class="mono">#${esc(r.zid_order_id)}</td><td>${esc(lbl[r.zid_status] || r.zid_status)}</td>
          <td class="small">${r.done ? (r.last_error ? `⏭️ ${esc(r.last_error)}` : "✅ وصل") : r.attempts >= 5 ? `❌ فشل ${esc(r.last_error || "")}` : "⏳ جاري الإرسال"}</td><td>${r.attempts}</td></tr>`).join("")}</tbody></table>`
          : `<div class="empty">لا يوجد تحديثات بعد</div>`;
      } catch (e) { toast(A.errMsg(e), "error"); }
    };
    const fnCall = async (action, extra = "") => {
      const { data: { session } } = await sb.auth.getSession();
      const r = await fetch(`${fn}?action=${action}${extra}`, { method: "POST", headers: { Authorization: `Bearer ${session.access_token}`, apikey: A.C.SUPABASE_ANON_KEY } });
      const j = await r.json(); if (!r.ok || j.ok === false || j.error) throw new Error(j.error || "خطأ"); return j;
    };
    $("#z-test").onclick = async () => { try { const j = await fnCall("status"); toast(j.ok ? `✅ الاتصال سليم — إجمالي طلبات المتجر: ${j.total_orders ?? "?"}` : `⚠️ ${j.error}`, j.ok ? "ok" : "error", 6000); } catch (e) { toast(A.errMsg(e), "error"); } };
    $("#z-sync").onclick = async (e) => { e.target.disabled = true; try { const j = await fnCall("sync", "&pages=2"); toast(`تمت المزامنة: ${j.added} جديد، ${j.updated} محدّث`, "ok"); loadOrders(); loadLog(); } catch (er) { toast(A.errMsg(er), "error"); } e.target.disabled = false; };
    if ($("#z-hooks")) $("#z-hooks").onclick = async () => { try { const j = await fnCall("webhooks"); A.modal({ title: "تسجيل الإشعارات", body: `<ul>${j.results.map((r) => `<li>${esc(r)}</li>`).join("")}</ul>` }); loadLog(); } catch (e) { toast(A.errMsg(e), "error"); } };
    $("#z-import").onclick = async () => {
      const id = await A.promptBox(`استيراد طلب من ${PN}`, `رقم الطلب في ${PN}`, { required: true, okLabel: "استيراد" });
      if (id) { try { await fnCall("import", "&id=" + encodeURIComponent(id.trim())); toast("تم الاستيراد", "ok"); loadOrders(); } catch (e) { toast(A.errMsg(e), "error"); } }
    };
    const loadLog = async () => {
      const { data } = await sb.from("zid_log").select("*").order("at", { ascending: false }).limit(60);
      $("#zlog").innerHTML = data?.length ? `<table><thead><tr><th>الوقت</th><th>النوع</th><th></th><th>التفاصيل</th></tr></thead><tbody>
        ${data.map((l) => `<tr><td class="small">${A.fmtDateTime(l.at)}</td><td>${esc(l.kind)}</td><td>${l.ok ? "✅" : "❌"}</td><td class="small">${esc(l.message || "")}</td></tr>`).join("")}</tbody></table>` : `<div class="empty">لا يوجد سجل بعد</div>`;
    };
    $("#log-refresh").onclick = loadLog;
    loadLog();
  }

  boot().catch((e) => { console.error(e); toast(A.errMsg(e), "error"); });
})();
