// عنوان نظيف بدون .html
(function(){try{var P=location.pathname;if(/\.html$/.test(P))history.replaceState(history.state,"",P.replace(/(index)?\.html$/,"")+location.search+location.hash);}catch(e){}})();
/* مسار — أدوات مشتركة */
(function () {
  const C = window.AZM_CONFIG;
  // خطأ رجوع قوقل (مثل إيميل غير مسجل): نحفظ الرسالة ونشيلها من الرابط قبل تشغيل Supabase،
  // وإلا المكتبة تمسح أي جلسة جديدة كل ما انفتحت الصفحة بنفس الرابط
  const OAUTH_ERR = (() => {
    try {
      const h = new URLSearchParams(location.hash.slice(1)), q = new URLSearchParams(location.search);
      const d = h.get("error_description") || q.get("error_description");
      if (!d) return "";
      if (/(^|\/)(app|owner|driver)(\.html)?$/.test(location.pathname)) {
        ["error", "error_code", "error_description"].forEach((k) => q.delete(k));
        const qs = q.toString();
        history.replaceState(history.state, "", location.pathname + (qs ? "?" + qs : ""));
      }
      return d.replace(/\+/g, " ");
    } catch (_) { return ""; }
  })();
  const oauthErrorMsg = () => {
    if (!OAUTH_ERR) return "";
    if (/signups? not allowed|not allowed for this instance/i.test(OAUTH_ERR)) return "حساب قوقل هذا غير مسجّل في مسار. ادخل باسم المستخدم وكلمة المرور، ثم اربط إيميلك من «حسابي» عشان تقدر تدخل بقوقل بعدين.";
    return "تعذّر الدخول بقوقل: " + OAUTH_ERR;
  };
  const sb = window.supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, storageKey: "msar-auth" },
    realtime: { params: { eventsPerSecond: 10 } },
  });

  const STATUS = {
    new:              { label: "جديد",          color: "#2563eb", bg: "#dbeafe", icon: "🆕" },
    preparing:        { label: "قيد التجهيز",   color: "#b45309", bg: "#fef3c7", icon: "🧺" },
    ready:            { label: "جاهز للإرسال",  color: "#7c3aed", bg: "#ede9fe", icon: "📦" },
    assigned:         { label: "عند المندوب",   color: "#0e7490", bg: "#cffafe", icon: "🛵" },
    out_for_delivery: { label: "في الطريق",     color: "#0f766e", bg: "#ccfbf1", icon: "🚚" },
    delivered:        { label: "تم التسليم",    color: "#15803d", bg: "#dcfce7", icon: "✅" },
    cancelled:        { label: "ملغي",          color: "#b91c1c", bg: "#fee2e2", icon: "✖" },
  };
  const ROLES = { admin: "مدير", cashier: "كاشير", driver: "مندوب" };
  const ACTIVE = ["new", "preparing", "ready", "assigned", "out_for_delivery"];

  const $ = (s, el = document) => el.querySelector(s);
  const $$ = (s, el = document) => [...el.querySelectorAll(s)];
  const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const money = (n) => (n === null || n === undefined ? "—" : Number(n).toLocaleString("ar-SA", { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + " ر.س");
  const num = (n, d = 0) => (n === null || n === undefined ? "—" : Number(n).toLocaleString("ar-SA", { maximumFractionDigits: d }));

  function fmtTime(t) {
    if (!t) return "—";
    return new Date(t).toLocaleTimeString("ar-SA", { hour: "numeric", minute: "2-digit", timeZone: "Asia/Riyadh" });
  }
  function fmtDateTime(t) {
    if (!t) return "—";
    return new Date(t).toLocaleString("ar-SA", { day: "numeric", month: "short", hour: "numeric", minute: "2-digit", timeZone: "Asia/Riyadh" });
  }
  function ago(t) {
    if (!t) return "";
    const s = Math.max(0, (Date.now() - new Date(t).getTime()) / 1000);
    if (s < 60) return "الآن";
    const m = Math.floor(s / 60);
    if (m < 60) return `قبل ${m} د`;
    const h = Math.floor(m / 60);
    if (h < 24) return `قبل ${h} س ${m % 60 ? (m % 60) + " د" : ""}`;
    return `قبل ${Math.floor(h / 24)} يوم`;
  }
  function minutesSince(t) { return t ? Math.floor((Date.now() - new Date(t).getTime()) / 60000) : 0; }

  function haversine(lat1, lon1, lat2, lon2) {
    if ([lat1, lon1, lat2, lon2].some((v) => v === null || v === undefined)) return null;
    const R = 6371.0088, r = (x) => (x * Math.PI) / 180;
    const a = Math.sin(r(lat2 - lat1) / 2) ** 2 + Math.cos(r(lat1)) * Math.cos(r(lat2)) * Math.sin(r(lon2 - lon1) / 2) ** 2;
    return 2 * R * Math.asin(Math.sqrt(a));
  }

  function phoneIntl(p) {
    if (!p) return "";
    let s = String(p).replace(/[^\d+]/g, "");
    if (s.startsWith("+")) s = s.slice(1);
    if (s.startsWith("00")) s = s.slice(2);
    if (/^05\d{8}$/.test(s)) s = "966" + s.slice(1);
    if (/^5\d{8}$/.test(s)) s = "966" + s;
    return s;
  }
  const telLink = (p) => (p ? `tel:+${phoneIntl(p)}` : "#");
  const waLink = (p, msg = "") => (p ? `https://wa.me/${phoneIntl(p)}${msg ? "?text=" + encodeURIComponent(msg) : ""}` : "#");
  const mapsLink = (lat, lon) => (lat ? `https://www.google.com/maps/search/?api=1&query=${lat},${lon}` : "#");
  const navLink = (lat, lon) => (lat ? `https://www.google.com/maps/dir/?api=1&destination=${lat},${lon}&travelmode=driving` : "#");

  // استخراج الإحداثيات من رابط قوقل ماب أو نص "lat, lon"
  function parseCoords(text) {
    if (!text) return null;
    let s = String(text).trim();
    try { s = decodeURIComponent(s); } catch (_) {}
    const pats = [/!3d(-?\d+\.\d+)!4d(-?\d+\.\d+)/, /@(-?\d+\.\d+),(-?\d+\.\d+)/, /[?&](?:q|ll|query|destination|center)=\+?(-?\d+\.\d+),\s*\+?(-?\d+\.\d+)/,
      /(-?\d{1,2}\.\d{3,})\s*[,،\s]\s*(-?\d{1,3}\.\d{3,})/];
    for (const p of pats) {
      const m = s.match(p);
      if (m) { const lat = parseFloat(m[1]), lon = parseFloat(m[2]); if (Math.abs(lat) <= 90 && Math.abs(lon) <= 180) return { lat, lon }; }
    }
    return null;
  }

  // يحاول محلياً، وإن كان رابطاً قصيراً (maps.app.goo.gl) يفكّه عبر السيرفر
  async function resolveCoords(text) {
    const c = parseCoords(text);
    if (c) return c;
    const t = String(text || "").trim();
    if (!/^https?:\/\//i.test(t)) return null;
    try { const r = await callFn("zid", { url: t }, "?action=resolve_map"); return r && r.lat != null ? { lat: r.lat, lon: r.lon } : null; } catch (_) { return null; }
  }

  // ---------------------------------------------------------------- UI helpers
  // نسخ موثوق: Clipboard API ثم طريقة بديلة، ورسالة صحيحة حسب النتيجة
  async function copy(text, okMsg = "تم النسخ") {
    const t = String(text ?? "");
    let done = false;
    try { if (navigator.clipboard && window.isSecureContext) { await navigator.clipboard.writeText(t); done = true; } } catch (_) {}
    if (!done) {
      try {
        const ta = document.createElement("textarea");
        ta.value = t; ta.setAttribute("readonly", ""); ta.style.cssText = "position:fixed;top:-1000px;opacity:0";
        document.body.appendChild(ta); ta.select(); done = document.execCommand("copy"); ta.remove();
      } catch (_) {}
    }
    if (done) toast(okMsg, "ok"); else promptBox("انسخ النص", "المتصفح منع النسخ التلقائي — حدّد النص وانسخه", { value: t, okLabel: "تم" });
    return done;
  }
  function toast(msg, type = "info", ms = 3500) {
    let box = $("#toasts");
    if (!box) { box = document.createElement("div"); box.id = "toasts"; document.body.appendChild(box); }
    const t = document.createElement("div");
    t.className = `toast toast-${type}`;
    t.textContent = msg;
    box.appendChild(t);
    setTimeout(() => t.classList.add("hide"), ms);
    setTimeout(() => t.remove(), ms + 400);
  }

  function modal({ title, body, actions = [], wide = false, onClose }) {
    const wrap = document.createElement("div");
    wrap.className = "modal-wrap";
    wrap.innerHTML = `<div class="modal ${wide ? "modal-wide" : ""}" role="dialog" aria-modal="true">
      <div class="modal-head"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="إغلاق">✕</button></div>
      <div class="modal-body"></div><div class="modal-foot"></div></div>`;
    const bodyEl = $(".modal-body", wrap);
    if (typeof body === "string") bodyEl.innerHTML = body; else if (body) bodyEl.appendChild(body);
    const foot = $(".modal-foot", wrap);
    const close = () => { wrap.remove(); onClose && onClose(); };
    actions.forEach((a) => {
      const b = document.createElement("button");
      b.className = `btn ${a.cls || ""}`;
      b.textContent = a.label;
      b.onclick = async () => {
        if (a.onClick) {
          b.disabled = true;
          try { const r = await a.onClick(wrap); if (r !== false) close(); }
          catch (e) { toast(errMsg(e), "error"); }
          finally { b.disabled = false; }
        } else close();
      };
      foot.appendChild(b);
    });
    if (!actions.length) foot.remove();
    wrap.addEventListener("click", (e) => { if (e.target === wrap || e.target.closest("[data-close]")) close(); });
    document.body.appendChild(wrap);
    return { el: wrap, close };
  }

  function confirmBox(title, text, okLabel = "تأكيد", cls = "btn-primary") {
    return new Promise((resolve) => {
      let done = false;
      modal({
        title, body: `<p class="lead">${esc(text)}</p>`,
        actions: [
          { label: "إلغاء", cls: "btn-ghost", onClick: () => { done = true; resolve(false); } },
          { label: okLabel, cls, onClick: () => { done = true; resolve(true); } },
        ],
        onClose: () => { if (!done) resolve(false); },
      });
    });
  }

  function promptBox(title, label, { placeholder = "", required = false, okLabel = "حفظ", value = "" } = {}) {
    return new Promise((resolve) => {
      let done = false;
      modal({
        title,
        body: `<label class="field"><span>${esc(label)}</span><textarea rows="3" placeholder="${esc(placeholder)}">${esc(value)}</textarea></label>`,
        actions: [
          { label: "إلغاء", cls: "btn-ghost", onClick: () => { done = true; resolve(null); } },
          { label: okLabel, cls: "btn-primary", onClick: (w) => {
              const v = $("textarea", w).value.trim();
              if (required && !v) { toast("هذا الحقل مطلوب", "error"); return false; }
              done = true; resolve(v); } },
        ],
        onClose: () => { if (!done) resolve(null); },
      });
      setTimeout(() => $(".modal-wrap:last-child textarea")?.focus(), 50);
    });
  }

  function errMsg(e) {
    const m = e?.message || e?.error_description || e?.error || String(e);
    if (/Invalid login credentials/i.test(m)) return "اسم المستخدم أو كلمة المرور غير صحيحة";
    if (/signups? not allowed/i.test(m)) return "حساب قوقل هذا غير مسجّل في مسار — ادخل بكلمة المرور، أو اطلب دعوة من مدير المتجر";
    if (/nonce|id_token|Unacceptable audience|provider is not enabled/i.test(m)) return "تعذّر الدخول بقوقل — جرّب مرة ثانية أو ادخل بكلمة المرور";
    if (/Failed to fetch|NetworkError|network/i.test(m)) return "تعذر الاتصال بالإنترنت";
    if (/JWT expired/i.test(m)) return "انتهت الجلسة، سجل الدخول من جديد";
    return m;
  }

  async function rpc(fn, args) {
    const { data, error } = await sb.rpc(fn, args);
    if (error) throw error;
    return data;
  }

  async function callFn(name, body, query = "") {
    const { data: { session } } = await sb.auth.getSession();
    const res = await fetch(`${C.SUPABASE_URL}/functions/v1/${name}${query}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: C.SUPABASE_ANON_KEY, Authorization: `Bearer ${session?.access_token || C.SUPABASE_ANON_KEY}` },
      body: JSON.stringify(body || {}),
    });
    const j = await res.json().catch(() => ({}));
    if (!res.ok || j.error) throw new Error(j.error || `خطأ ${res.status}`);
    return j;
  }

  // ---------------------------------------------------------------- auth
  // الدخول: رمز المتجر + اسم المستخدم (البريد داخلي: user@store.msar.app)
  const cleanCode = (c) => String(c || "").trim().toLowerCase();
  const toEmail = (u, code) => (String(u).includes("@") ? String(u).trim() : `${String(u).trim().toLowerCase()}@${cleanCode(code)}.${C.EMAIL_DOMAIN}`);
  const savedStore = () => { try { return new URLSearchParams(location.search).get("store") || localStorage.getItem("msar-store") || ""; } catch (_) { return ""; } };
  async function login(username, password, code) {
    const { data, error } = await sb.auth.signInWithPassword({ email: toEmail(username, code), password });
    if (error) throw error;
    try { localStorage.setItem("msar-store", cleanCode(code)); } catch (_) {}
    return data;
  }
  async function myProfile() {
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return null;
    const { data, error } = await sb.from("profiles").select("*, branch:branches(id,name,city,lat,lon,phone)").eq("id", session.user.id).maybeSingle();
    if (error) throw error;
    if (data?.store_id) {
      const { data: st } = await sb.rpc("my_store_info");
      if (st) { window.AZM.store = st; C.STORE_NAME = st.name; C.STORE_URL = st.store_url || ""; C.PLATFORM = st.platform || "zid"; }
    }
    return data;
  }
  async function logout() { try { await sb.auth.signOut(); } catch (_) {} location.reload(); }

  const GOOGLE_SVG = `<svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true"><path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z"/></svg>`;
  // ---------------------------------------------------------------- الهوية الموحّدة
  const BASE = location.href.split("#")[0].split("?")[0].replace(/[^/]*$/, "");
  const isInternalEmail = (e) => !e || /\.msar\.app$/i.test(e);
  async function googleLogin(returnTo) {
    const { error } = await sb.auth.signInWithOAuth({ provider: "google", options: { redirectTo: returnTo || location.href.split("#")[0] } });
    if (error) throw error;
  }
  // الدخول بقوقل عبر زر قوقل الرسمي على نطاق msarpro.com نفسه (Google Identity Services)
  // قوقل يعرض اسم موقعنا بدل نطاق Supabase، والجلسة تنشأ بدون تحويل للصفحة
  let gsiLoading = null;
  function loadGsi() {
    if (window.google?.accounts?.id) return Promise.resolve();
    if (gsiLoading) return gsiLoading;
    gsiLoading = new Promise((res, rej) => {
      const sc = document.createElement("script");
      sc.src = "https://accounts.google.com/gsi/client"; sc.async = true; sc.defer = true;
      sc.onload = () => res(); sc.onerror = () => { gsiLoading = null; rej(new Error("gsi")); };
      document.head.appendChild(sc);
      setTimeout(() => { if (!window.google?.accounts?.id) { gsiLoading = null; rej(new Error("gsi timeout")); } }, 8000);
    });
    return gsiLoading;
  }
  async function sha256hex(t) {
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t));
    return [...new Uint8Array(b)].map((x) => x.toString(16).padStart(2, "0")).join("");
  }
  // يرسم زر قوقل داخل box. before(): خطوة قبل إنشاء الجلسة (ترجع false للإلغاء). after(): بعد نجاح الدخول
  async function googleButton(box, { before, after, text = "continue_with" } = {}) {
    if (!box) return;
    const fallback = () => {
      box.innerHTML = `<button type="button" class="btn btn-block btn-google">${GOOGLE_SVG} الدخول بقوقل</button>`;
      box.firstChild.onclick = async () => {
        try { if (before && (await before()) === false) return; await googleLogin(); } catch (e) { toast(errMsg(e), "error"); }
      };
    };
    if (!C.GOOGLE_CLIENT_ID || !window.crypto?.subtle) return fallback();
    box.innerHTML = `<div class="g-wait">${GOOGLE_SVG}</div>`;
    try { await loadGsi(); } catch (_) { return fallback(); }
    const raw = Array.from(crypto.getRandomValues(new Uint8Array(24)), (x) => x.toString(16).padStart(2, "0")).join("");
    const hashed = await sha256hex(raw);
    let busy = false;
    google.accounts.id.initialize({
      client_id: C.GOOGLE_CLIENT_ID, nonce: hashed, ux_mode: "popup", auto_select: false, itp_support: true,
      use_fedcm_for_button: true, context: "signin",
      callback: async (resp) => {
        if (busy || !resp?.credential) return; busy = true;
        try {
          if (before && (await before()) === false) { busy = false; return; }
          const { error } = await sb.auth.signInWithIdToken({ provider: "google", token: resp.credential, nonce: raw });
          if (error) throw error;
          if (after) await after(); else location.replace(location.pathname + location.search);
        } catch (e) { toast(errMsg(e), "error", 7000); busy = false; }
      },
    });
    box.innerHTML = "";
    const w = Math.max(220, Math.min(400, Math.round(box.getBoundingClientRect().width || 320)));
    google.accounts.id.renderButton(box, { type: "standard", theme: "outline", size: "large", shape: "rectangular", text, locale: "ar", logo_alignment: "center", width: w });
  }
  async function sendReset(email) {
    const { error } = await sb.auth.resetPasswordForEmail(String(email).trim(), { redirectTo: BASE + "reset" });
    if (error) throw error;
  }
  async function memberships() { return (await rpc("my_memberships")) || []; }
  async function switchStore(storeId) { await rpc("switch_store", { p_store: storeId }); }
  async function changePassword(pw) {
    if (!pw || String(pw).length < 8) throw new Error("كلمة المرور لازم تكون 8 أحرف أو أكثر");
    const { error } = await sb.auth.updateUser({ password: String(pw) });
    if (error) throw error;
  }
  // يرجّع الملف النشط، ويختار المتجر تلقائياً أو يعرض قائمة المتاجر لو الشخص عضو في أكثر من متجر
  async function resolveProfile({ allowRoles } = {}) {
    let me = await myProfile();
    if (me?.role === "owner") return me;
    if (me && me.is_active && me.store_id) return me;
    const list = (await memberships()).filter((m) => !allowRoles || allowRoles.includes(m.role));
    if (!list.length) return me && me.is_active ? me : null;
    const pick = list.length === 1 ? list[0] : await pickStore(list);
    if (!pick) return null;
    await switchStore(pick.store_id);
    return myProfile();
  }
  function pickStore(list) {
    return new Promise((resolve) => {
      let done = false;
      const m = modal({
        title: "اختر المتجر",
        body: `<p class="muted">حسابك مرتبط بأكثر من متجر:</p><div class="stack" style="gap:8px">${list.map((x, i) => `
          <button class="btn btn-block" data-i="${i}" style="justify-content:space-between">
            <b>${esc(x.store_name)}</b><span class="small muted">${esc(ROLES[x.role] || x.role)}${x.branch_name ? " · " + esc(x.branch_name) : ""}</span></button>`).join("")}</div>`,
        onClose: () => { if (!done) resolve(null); },
      });
      $$("[data-i]", m.el).forEach((b) => b.onclick = () => { done = true; m.close(); resolve(list[Number(b.dataset.i)]); });
    });
  }
  // نافذة "حسابي": الإيميل، تغيير كلمة المرور، التنقل بين المتاجر، الخروج
  async function accountDialog() {
    const { data: { user } } = await sb.auth.getUser();
    const email = user?.email || "";
    const list = await memberships().catch(() => []);
    const google = (user?.identities || []).some((i) => i.provider === "google");
    const m = modal({
      title: "👤 حسابي",
      body: `
        <div class="card" style="box-shadow:none;background:var(--brand-soft);padding:12px;margin:0 0 12px">
          ${isInternalEmail(email)
            ? `<b>ما عندك إيميل مربوط</b><p class="small muted" style="margin:4px 0 8px">اربط إيميلك عشان تقدر تدخل بقوقل وتستعيد كلمة المرور لو نسيتها. بعد الربط تدخل بالإيميل بدل اسم المستخدم.</p>
               <div class="row"><input id="acc-email" type="email" dir="ltr" placeholder="name@gmail.com" class="grow"><button class="btn btn-primary" id="acc-link">ربط</button></div>`
            : `<div class="small muted">الإيميل</div><b dir="ltr">${esc(email)}</b>${google ? ` <span class="chip chip-paid">مربوط بقوقل</span>` : `<div class="small muted" style="margin-top:4px">تقدر تدخل بزر "الدخول بقوقل" بنفس هذا الإيميل.</div>`}`}
        </div>
        <label class="field"><span>كلمة مرور جديدة (8 أحرف أو أكثر)</span><input id="acc-pw" type="password" dir="ltr" autocomplete="new-password"></label>
        <button class="btn btn-block" id="acc-pw-save">🔑 تغيير كلمة المرور</button>
        ${list.length > 1 ? `<h4 style="margin:18px 0 8px">متاجري</h4><div class="stack" style="gap:6px">${list.map((x) => `
          <button class="btn btn-block" data-sw="${x.store_id}" ${x.current ? "disabled" : ""} style="justify-content:space-between">
            <b>${esc(x.store_name)}</b><span class="small muted">${x.current ? "✓ الحالي" : esc(ROLES[x.role] || x.role)}</span></button>`).join("")}</div>` : ""}`,
      actions: [{ label: "تسجيل خروج", cls: "btn-ghost", onClick: () => logout() }, { label: "إغلاق", cls: "btn-primary" }],
    });
    $("#acc-pw-save", m.el).onclick = async (e) => {
      e.target.disabled = true;
      try { await changePassword($("#acc-pw", m.el).value); toast("تم تغيير كلمة المرور ✅", "ok"); $("#acc-pw", m.el).value = ""; }
      catch (er) { toast(errMsg(er), "error"); }
      e.target.disabled = false;
    };
    const link = $("#acc-link", m.el);
    if (link) link.onclick = async () => {
      link.disabled = true;
      try {
        const r = await callFn("admin", { action: "set_my_email", email: $("#acc-email", m.el).value });
        toast(`تم ربط ${r.email} — من الحين ادخل بالإيميل`, "ok"); m.close();
      } catch (er) { toast(errMsg(er), "error"); link.disabled = false; }
    };
    $$("[data-sw]", m.el).forEach((b) => b.onclick = async () => {
      try { await switchStore(Number(b.dataset.sw)); location.reload(); } catch (er) { toast(errMsg(er), "error"); }
    });
  }
  // أزرار مشتركة لصفحة الدخول: قوقل + نسيت كلمة المرور
  function authExtrasHtml() {
    return `<div class="or-sep"><span>أو</span></div>
      <div class="g-box" id="g-login"></div>
      <p class="small" style="text-align:center;margin:12px 0 0"><a href="#" id="forgot">نسيت كلمة المرور؟</a></p>`;
  }
  function bindAuthExtras(root, getEmail) {
    const g = $("#g-login", root);
    if (g) googleButton(g);
    const f = $("#forgot", root);
    if (f) f.onclick = (e) => {
      e.preventDefault();
      const pre = (getEmail && getEmail()) || "";
      modal({
        title: "استعادة كلمة المرور",
        body: `<p class="small muted">اكتب الإيميل المربوط بحسابك ويوصلك رابط تختار فيه كلمة مرور جديدة.</p>
          <label class="field"><span>الإيميل</span><input id="rs-email" type="email" dir="ltr" value="${esc(pre.includes("@") ? pre : "")}"></label>
          <p class="small muted">ما عندك إيميل مربوط (دخول برمز المتجر واسم المستخدم)؟ اطلب من مدير المتجر يغيّر لك كلمة المرور.</p>`,
        actions: [{ label: "إلغاء", cls: "btn-ghost" }, { label: "أرسل الرابط", cls: "btn-primary", onClick: async (w) => {
          const em = $("#rs-email", w).value.trim();
          if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(em)) throw new Error("اكتب إيميل صحيح");
          await sendReset(em);
          toast("إذا الإيميل مسجّل عندنا بيوصلك رابط خلال دقائق 📧", "ok");
        } }],
      });
    };
  }

  // ---------------------------------------------------------------- sound
  let audioCtx = null, alarmTimer = null;
  function beep(times = 3) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === "suspended") audioCtx.resume();
      for (let i = 0; i < times; i++) {
        [880, 1175].forEach((f, j) => {
          const o = audioCtx.createOscillator(), g = audioCtx.createGain();
          o.type = "sine"; o.frequency.value = f;
          const t0 = audioCtx.currentTime + i * 0.6 + j * 0.18;
          g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(0.5, t0 + 0.02);
          g.gain.exponentialRampToValueAtTime(0.0001, t0 + 0.16);
          o.connect(g).connect(audioCtx.destination); o.start(t0); o.stop(t0 + 0.18);
        });
      }
    } catch (_) {}
  }
  // أصوات التنبيه (ملفات عالية وواضحة): order = لوحة التحكم/الكاشير، driver = جوال المندوب
  const SOUND_FILES = { order: "sounds/order.wav", driver: "sounds/driver.wav" };
  const audios = {};
  function getAudio(name) {
    if (!audios[name]) { const a = new Audio(SOUND_FILES[name] || SOUND_FILES.order); a.preload = "auto"; a.volume = 1; audios[name] = a; }
    return audios[name];
  }
  function playSound(name = "order", { loop = false } = {}) {
    try {
      const a = getAudio(name); a.loop = loop; a.volume = 1; a.currentTime = 0;
      const p = a.play(); if (p && p.catch) p.catch(() => beep(4));
    } catch (_) { beep(4); }
  }
  function stopSound() { Object.values(audios).forEach((a) => { try { a.pause(); a.currentTime = 0; a.loop = false; } catch (_) {} }); }
  function startAlarm(name = "driver") { stopAlarm(); playSound(name, { loop: true }); }
  function stopAlarm() { if (alarmTimer) clearInterval(alarmTimer); alarmTimer = null; stopSound(); }
  function unlockAudio() {
    const f = () => {
      try { audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)(); audioCtx.resume(); } catch (_) {}
      // تهيئة ملفات الصوت بعد أول لمسة (شرط المتصفحات للسماح بالتشغيل التلقائي)
      Object.keys(SOUND_FILES).forEach((n) => { const a = getAudio(n); a.muted = true; const p = a.play(); if (p && p.then) p.then(() => { a.pause(); a.currentTime = 0; a.muted = false; }).catch(() => { a.muted = false; }); else a.muted = false; });
    };
    document.addEventListener("click", f, { once: true }); document.addEventListener("touchstart", f, { once: true });
    Object.keys(SOUND_FILES).forEach(getAudio);
  }

  async function notify(title, body) {
    try {
      if (!("Notification" in window)) return;
      if (Notification.permission === "default") await Notification.requestPermission();
      if (Notification.permission === "granted") {
        const reg = await navigator.serviceWorker?.getRegistration?.();
        if (reg) reg.showNotification(title, { body, icon: "icons/icon-192.png", badge: "icons/icon-192.png", vibrate: [300, 100, 300], tag: "msar-" + Date.now() });
        else new Notification(title, { body, icon: "icons/icon-192.png" });
      }
    } catch (_) {}
  }

  // رابط المنتج في المتجر (بالمعرّف إن وجد، وإلا بحث بالاسم)
  function productUrl(it) {
    const base = (C.STORE_URL || "").replace(/\/$/, "");
    if (!base) return null;
    if (it.product_id) return `${base}/products/${encodeURIComponent(it.product_id)}`;
    return `${base}/products?search=${encodeURIComponent(it.name || it.sku || "")}`;
  }

  function itemsHtml(items) {
    if (!items?.length) return `<p class="muted">لا توجد منتجات</p>`;
    return `<ul class="items">${items.map((it) => `
      <li>
        ${it.image ? `<img src="${esc(it.image)}" alt="" loading="lazy" onerror="this.remove()">` : `<span class="item-ph">🛒</span>`}
        <div class="item-info"><b>${esc(it.name)}</b>
          ${it.options?.length ? `<small>${it.options.map(esc).join(" · ")}</small>` : ""}
          ${it.sku ? `<small class="muted">SKU: ${esc(it.sku)}</small>` : ""}</div>
        <span class="qty">× ${num(it.quantity)}</span>
        <span class="price">${it.total != null ? money(it.total) : ""}</span>
        ${productUrl(it) ? `<a class="item-link" href="${esc(productUrl(it))}" target="_blank" rel="noopener" title="عرض المنتج في المتجر">🔗<span>المتجر</span></a>` : ""}
      </li>`).join("")}</ul>`;
  }

  // ---- طريقة الدفع: مدفوع مسبقاً / عند الاستلام (نقداً أو شبكة)
  function payInfo(o) {
    if (!o?.is_cod) return { kind: "prepaid", icon: "✅", label: "مدفوع مسبقاً", cls: "chip-paid" };
    if (o.cod_method === "card") return { kind: "card", icon: "💳", label: "شبكة عند الاستلام", cls: "chip-card" };
    if (o.cod_method === "cash") return { kind: "cash", icon: "💵", label: "نقداً عند الاستلام", cls: "chip-cod" };
    return { kind: "cod", icon: "💵", label: "عند الاستلام", cls: "chip-cod" };
  }
  function payChip(o, withAmount = true) {
    const p = payInfo(o);
    const amt = withAmount ? " " + money(o.is_cod ? (o.cod_amount || o.total) : o.total) : "";
    return `<span class="chip ${p.cls}" title="${esc(o.payment_method || p.label)}">${p.icon} ${p.label}${amt}</span>`;
  }
  function payToggle(o) {
    if (!o?.is_cod) return "";
    const m = o.cod_method || "";
    return `<div class="pay-seg" role="radiogroup" aria-label="طريقة التحصيل" data-pay-for="${o.id}">
      <button type="button" data-m="cash" class="${m === "cash" ? "on" : ""}" aria-pressed="${m === "cash"}">💵 نقداً</button>
      <button type="button" data-m="card" class="${m === "card" ? "on" : ""}" aria-pressed="${m === "card"}">💳 شبكة / بطاقة</button></div>`;
  }
  // يربط أزرار نقداً/شبكة داخل عنصر — onDone(order) بعد الحفظ
  function bindPayToggle(root, onDone) {
    root.querySelectorAll(".pay-seg[data-pay-for] button[data-m]").forEach((b) => b.onclick = async (ev) => {
      ev.stopPropagation();
      const seg = b.closest(".pay-seg"); const id = Number(seg.dataset.payFor);
      if (b.classList.contains("on")) return;
      seg.querySelectorAll("button").forEach((x) => { x.disabled = true; });
      try {
        const o = await rpc("set_cod_method", { p_order_id: id, p_method: b.dataset.m });
        seg.querySelectorAll("button").forEach((x) => { x.classList.toggle("on", x === b); x.setAttribute("aria-pressed", x === b); });
        toast(b.dataset.m === "card" ? "تم: الدفع بالشبكة 💳" : "تم: الدفع نقداً 💵", "ok");
        onDone && onDone(o);
      } catch (e) { toast(errMsg(e), "error"); }
      finally { seg.querySelectorAll("button").forEach((x) => { x.disabled = false; }); }
    });
  }

  function statusBadge(s) {
    const st = STATUS[s] || { label: s, color: "#555", bg: "#eee" };
    return `<span class="badge" style="color:${st.color};background:${st.bg}">${st.icon || ""} ${st.label}</span>`;
  }

  // اسم منصة المتجر (زد / سلة)
  const platformName = () => ((window.AZM?.store?.platform || C.PLATFORM) === "salla" ? "سلة" : "زد");
  const isSalla = () => (window.AZM?.store?.platform || C.PLATFORM) === "salla";
  window.AZM = { platformName, isSalla,
    oauthErrorMsg,
    sb, C, STATUS, ROLES, ACTIVE, $, $$, esc, money, num, fmtTime, fmtDateTime, ago, minutesSince, haversine,
    phoneIntl, telLink, waLink, copy, mapsLink, navLink, productUrl, parseCoords, resolveCoords, toast, modal, confirmBox, promptBox, errMsg,
    rpc, callFn, login, myProfile, savedStore, store: null, logout,
    BASE, isInternalEmail, googleLogin, googleButton, GOOGLE_SVG, sendReset, memberships, switchStore, changePassword, resolveProfile, accountDialog, authExtrasHtml, bindAuthExtras, beep, playSound, stopSound, startAlarm, stopAlarm, unlockAudio, notify, itemsHtml, statusBadge, toEmail, payInfo, payChip, payToggle, bindPayToggle,
  };
})();
