/* مسار — لوحة صاحب المنصة: تذاكر الدعم الفني + قاعدة معرفة المساعد الذكي */
(function () {
  const A = window.AZM, { sb, $, $$, esc, toast } = A;
  const ST = { open: ["🔵 مفتوحة", "#dbeafe", "#1d4ed8"], answered: ["✅ تم الرد", "#dcfce7", "#166534"], closed: ["⚪ مغلقة", "#f1f5f9", "#475569"] };
  const ROLE = { admin: "مدير", cashier: "كاشير", driver: "مندوب" };
  let filter = "open", q = "", current = null, mode = "tickets";
  const fmt = (t) => esc(t).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>").replace(/\n/g, "<br>");

  async function attHtml(list) {
    if (!list?.length) return "";
    const items = await Promise.all(list.map(async (a) => {
      const { data } = await sb.storage.from("support").createSignedUrl(a.path, 3600);
      const u = data?.signedUrl; if (!u) return `<span class="chip">📎 ${esc(a.name)}</span>`;
      return /image/.test(a.type) || /\.(png|jpe?g|webp|gif)$/i.test(a.path) ? `<a href="${u}" target="_blank" rel="noopener"><img src="${u}" alt="" style="width:140px;height:100px;object-fit:cover;border-radius:10px;border:1px solid var(--line)"></a>` : `<a class="chip" href="${u}" target="_blank" rel="noopener">📎 ${esc(a.name)}</a>`;
    }));
    return `<div class="row" style="margin-top:8px">${items.join("")}</div>`;
  }

  async function render(view) {
    view.innerHTML = `<div class="row" style="margin-bottom:12px">
        <button class="btn ${mode === "tickets" ? "btn-primary" : ""}" data-m="tickets">🎫 التذاكر</button>
        <button class="btn ${mode === "kb" ? "btn-primary" : ""}" data-m="kb">🧠 قاعدة معرفة المساعد</button><span class="spacer"></span><span id="ai-st" class="small muted"></span></div><div id="sv"></div>`;
    $$("[data-m]", view).forEach((b) => b.onclick = () => { mode = b.dataset.m; current = null; render(view); });
    A.callFn("support", { action: "status" }).then((r) => {
      const st = $("#ai-st", view); if (!st) return;
      st.innerHTML = r.provider ? `🤖 المساعد يعمل بـ <b>${esc(r.provider)}</b> (${esc(r.model)})` : `🤖 المساعد يعمل بوضع <b>البحث في الدليل</b> — أضف مفتاح ذكاء اصطناعي لإجابات أذكى`;
    }).catch(() => { const st = $("#ai-st", view); if (st) st.textContent = "⚠️ دالة الدعم غير منشورة بعد"; });
    if (mode === "kb") return kbEditor($("#sv", view));
    if (current) return thread($("#sv", view), current);
    return list($("#sv", view));
  }

  async function list(el) {
    el.innerHTML = `<div class="card"><div class="row" style="margin-bottom:10px">${Object.entries({ open: "المفتوحة", answered: "تم الرد", closed: "المغلقة", all: "الكل" }).map(([k, l]) => `<button class="btn btn-sm ${filter === k ? "btn-primary" : ""}" data-f="${k}">${l}</button>`).join("")}
      <span class="spacer"></span><input id="tq" placeholder="🔍 بحث بالعنوان أو المتجر أو الاسم" value="${esc(q)}" style="max-width:280px"></div><div id="tl"><div class="empty">جاري التحميل…</div></div></div>`;
    $$("[data-f]", el).forEach((b) => b.onclick = () => { filter = b.dataset.f; list(el); });
    $("#tq", el).onchange = (e) => { q = e.target.value.trim(); list(el); };
    let qq = sb.from("support_tickets").select("*").order("staff_unread", { ascending: false }).order("updated_at", { ascending: false }).limit(200);
    if (filter !== "all") qq = qq.eq("status", filter);
    if (q) qq = qq.or(`subject.ilike.%${q.replace(/[%,()]/g, "")}%,store_name.ilike.%${q.replace(/[%,()]/g, "")}%,user_name.ilike.%${q.replace(/[%,()]/g, "")}%`);
    const { data, error } = await qq;
    if (error) { $("#tl", el).innerHTML = `<p class="chip chip-warn">${esc(error.message)} — شغّل ترقية قاعدة البيانات 006</p>`; return; }
    $("#tl", el).innerHTML = data.length ? `<div class="table-wrap"><table><thead><tr><th>#</th><th>العنوان</th><th>المتجر</th><th>المرسل</th><th>المصدر</th><th>الحالة</th><th>آخر تحديث</th></tr></thead><tbody>
      ${data.map((t) => { const s = ST[t.status] || ST.open; return `<tr data-id="${t.id}" style="cursor:pointer;${t.staff_unread ? "font-weight:700;background:#fffbea" : ""}">
        <td>${t.id}${t.staff_unread ? " 🟠" : ""}</td><td>${esc(t.subject)}</td><td class="small">${esc(t.store_name || "—")}</td>
        <td class="small">${esc(t.user_name || "")}<div class="muted">${esc(ROLE[t.user_role] || t.user_role || "")} · <span dir="ltr">${esc(t.user_email || "")}</span></div></td>
        <td class="small">${t.source === "ai" ? "🤖 من المساعد" : "📝 مباشرة"}</td>
        <td><span class="badge" style="background:${s[1]};color:${s[2]}">${s[0]}</span></td><td class="small">${A.fmtDateTime(t.updated_at)}</td></tr>`; }).join("")}</tbody></table></div>`
      : `<div class="empty">لا توجد تذاكر ${filter === "open" ? "مفتوحة 🎉" : ""}</div>`;
    $$("[data-id]", el).forEach((r) => r.onclick = () => { current = Number(r.dataset.id); thread(el, current); });
  }

  async function thread(el, id) {
    el.innerHTML = `<div class="card"><div class="empty">جاري التحميل…</div></div>`;
    const [{ data: t }, { data: ms }] = await Promise.all([sb.from("support_tickets").select("*").eq("id", id).single(), sb.from("support_messages").select("*").eq("ticket_id", id).order("id")]);
    A.rpc("support_ticket_seen", { p_ticket: id }).catch(() => {});
    if (!t) { el.innerHTML = `<div class="card">التذكرة غير موجودة</div>`; return; }
    const s = ST[t.status] || ST.open;
    el.innerHTML = `<div class="card"><div class="card-head"><button class="btn btn-sm" id="back">→ كل التذاكر</button><h3 style="margin:0 10px">#${t.id} · ${esc(t.subject)}</h3>
        <span class="badge" style="background:${s[1]};color:${s[2]}">${s[0]}</span><span class="spacer"></span>
        <select id="tst">${Object.entries(ST).map(([k, v]) => `<option value="${k}" ${k === t.status ? "selected" : ""}>${v[0]}</option>`).join("")}</select></div>
      <p class="small muted" style="margin-top:0">🏪 ${esc(t.store_name || "—")} · 👤 ${esc(t.user_name || "")} (${esc(ROLE[t.user_role] || t.user_role || "")}) · <span dir="ltr">${esc(t.user_email || "")}</span> · 📍 ${esc(t.page || "—")} · ${A.fmtDateTime(t.created_at)}</p>
      <div id="msgs" style="display:flex;flex-direction:column;gap:10px">${(ms || []).map((m, i) => `<div style="max-width:78%;padding:12px 14px;border-radius:14px;${m.sender === "staff" ? "align-self:flex-end;background:#e7f4fa;border:1px solid #cfe4ee" : m.sender === "ai" ? "background:#f8fafc;border:1px dashed #cbd5e1" : "background:#fff;border:1px solid var(--line)"}">
        <div class="small muted" style="font-weight:700">${m.sender === "staff" ? "🛟 فريق الدعم" : m.sender === "ai" ? "🤖 المساعد" : "👤 " + esc(t.user_name || "العميل")} · ${A.fmtDateTime(m.created_at)}</div>
        <div style="line-height:1.8">${fmt(m.body)}</div><div data-att="${i}"></div></div>`).join("")}</div>
      <div style="margin-top:14px"><textarea id="rt" rows="4" style="width:100%;border:1px solid var(--line);border-radius:12px;padding:10px;font:inherit" placeholder="اكتب ردك للعميل…"></textarea>
        <div class="row" style="margin-top:8px"><button class="btn btn-primary" id="rs">📨 إرسال الرد</button><button class="btn" id="rsc">📨 إرسال وإغلاق</button>
        ${t.user_email && !/\.msar\.app$/.test(t.user_email) ? `<a class="btn btn-ghost" href="mailto:${esc(t.user_email)}?subject=${encodeURIComponent("دعم مسار — تذكرة #" + t.id)}">✉️ إيميل</a>` : ""}</div></div></div>`;
    $("#back", el).onclick = () => { current = null; list(el); };
    (ms || []).forEach(async (m, i) => { if (m.attachments?.length) { const n = $(`[data-att="${i}"]`, el); if (n) n.innerHTML = await attHtml(m.attachments); } });
    $("#tst", el).onchange = async (e) => { try { await A.rpc("support_ticket_status", { p_ticket: id, p_status: e.target.value }); toast("تم التحديث", "ok"); } catch (er) { toast(A.errMsg(er), "error"); } };
    const send = async (closeAfter) => {
      const txt = $("#rt", el).value.trim(); if (!txt) return toast("اكتب الرد", "error");
      try { await A.rpc("support_ticket_reply", { p_ticket: id, p_body: txt, p_attachments: [] }); if (closeAfter) await A.rpc("support_ticket_status", { p_ticket: id, p_status: "closed" }); toast("تم إرسال الرد ✅", "ok"); thread(el, id); }
      catch (er) { toast(A.errMsg(er), "error"); }
    };
    $("#rs", el).onclick = () => send(false);
    $("#rsc", el).onclick = () => send(true);
  }

  async function kbEditor(el) {
    const { data } = await sb.from("site_content").select("data, updated_at").eq("key", "support_kb").maybeSingle();
    const cur = String(data?.data?.text || "");
    el.innerHTML = `<div class="card"><div class="card-head"><h3>🧠 قاعدة معرفة المساعد الذكي</h3></div>
      <p class="small muted" style="margin-top:0">المساعد يجاوب <b>فقط</b> من هذا النص (ومن بيانات حساب المستخدم الحقيقية). اكتب معلومات صحيحة ومحدّثة: الأسعار، الخطوات، الحلول. استخدم <code>## عنوان</code> لكل قسم.
      ${cur ? "" : "<br>⚠️ حالياً يستخدم النص الافتراضي المدمج في الدالة — اضغط \"تحميل النص الافتراضي\" لتعديله."}</p>
      <textarea id="kb" rows="26" style="width:100%;border:1px solid var(--line);border-radius:12px;padding:12px;font-family:ui-monospace,Consolas,monospace;font-size:13px;line-height:1.7">${esc(cur)}</textarea>
      <div class="row" style="margin-top:10px"><button class="btn btn-primary" id="kbs">💾 حفظ</button>${cur ? "" : `<button class="btn" id="kbl">📥 تحميل النص الافتراضي</button>`}
        ${cur ? `<button class="btn btn-ghost" id="kbr">↩️ الرجوع للنص الافتراضي</button>` : ""}<span class="spacer"></span><span class="small muted">${data?.updated_at ? "آخر تعديل " + A.fmtDateTime(data.updated_at) : ""}</span></div></div>
      <div class="card"><div class="card-head"><h3>🔑 تشغيل الذكاء الاصطناعي</h3></div>
      <ol class="small" style="line-height:2;margin:0">
        <li>أنشئ مفتاح من <a href="https://aistudio.google.com/apikey" target="_blank" rel="noopener">Google AI Studio</a> (Gemini — فيه خطة مجانية) أو من Anthropic / OpenAI.</li>
        <li>في Supabase ← Edge Functions ← Secrets أضف <code>GEMINI_API_KEY</code> (أو <code>ANTHROPIC_API_KEY</code> / <code>OPENAI_API_KEY</code>).</li>
        <li>اختياري: <code>SUPPORT_MODEL</code> لتحديد الموديل، و <code>SUPPORT_AI_DAILY</code> لعدد الأسئلة اليومية لكل مستخدم (الافتراضي 60).</li></ol>
      <p class="small muted">بدون مفتاح: المساعد يبحث في هذا الدليل ويعرض أقرب قسم، ويحوّل للتذكرة عند عدم الإيجاد.</p></div>`;
    $("#kbs", el).onclick = async () => {
      const text = $("#kb", el).value.trim();
      if (text && text.length < 200) return toast("النص قصير جداً", "error");
      try { await A.rpc("owner_site_save", { p_key: "support_kb", p_data: text ? { text } : {} }); toast("تم حفظ قاعدة المعرفة ✅", "ok"); kbEditor(el); } catch (e) { toast(A.errMsg(e), "error"); }
    };
    const kl = $("#kbl", el); if (kl) kl.onclick = async () => { const r = await fetch("setup/functions/support/index.ts").then((x) => x.ok ? x.text() : "").catch(() => ""); const m = r.match(/const KB_DEFAULT = `([\s\S]*?)`;/); if (m) $("#kb", el).value = m[1]; else toast("ما قدرت أحمّل النص — انسخه من ملف الدالة", "error"); };
    const kr = $("#kbr", el); if (kr) kr.onclick = async () => { if (!confirm("نرجع للنص الافتراضي المدمج؟")) return; await A.rpc("owner_site_save", { p_key: "support_kb", p_data: {} }); kbEditor(el); };
  }

  window.MSAR_OWNER_SUPPORT = { render };
})();
