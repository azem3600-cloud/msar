/* مسار — لوحة صاحب المنصة: إدارة الموقع التعريفي (المحتوى، الشكل، SEO، الصفحات، طلبات التواصل) */
(function () {
  const A = window.AZM, { sb, $, $$, esc, toast } = A;
  const DEF = window.MSAR_DEFAULTS, DOCS = window.MSAR_DOCS, R = window.MSAR_SITE;
  const clone = (x) => JSON.parse(JSON.stringify(x));
  const isObj = (x) => x && typeof x === "object" && !Array.isArray(x);
  let W = null, RAW = {}, sub = "general", dirty = false;

  // الفرق بين القيم الحالية والافتراضية (نحفظ التعديلات فقط عشان تحديثات الكود توصل)
  function diff(cur, def) {
    if (Array.isArray(cur) || !isObj(cur)) return JSON.stringify(cur) === JSON.stringify(def) ? undefined : cur;
    const o = {};
    for (const k of Object.keys(cur)) { const d = diff(cur[k], def ? def[k] : undefined); if (d !== undefined) o[k] = d; }
    return Object.keys(o).length ? o : undefined;
  }
  const get = (o, p) => p.split(".").reduce((x, k) => (x == null ? x : x[k]), o);
  const set = (o, p, v) => { const ks = p.split("."); let x = o; ks.slice(0, -1).forEach((k) => { if (!isObj(x[k])) x[k] = {}; x = x[k]; }); x[ks[ks.length - 1]] = v; };

  async function loadAll() {
    const { data, error } = await sb.from("site_content").select("key,data,updated_at");
    if (error) throw error;
    RAW = {}; (data || []).forEach((r) => (RAW[r.key] = r));
    W = R.merge(clone(DEF), RAW.site?.data || {});
  }
  async function saveSite() {
    const d = diff(W, DEF) || {};
    await A.rpc("owner_site_save", { p_key: "site", p_data: d });
    RAW.site = { key: "site", data: d, updated_at: new Date().toISOString() };
    dirty = false; toast("تم الحفظ ✅ — التغييرات ظاهرة في الموقع الآن", "ok");
  }

  // ------------------------------------------------------------------ عناصر النموذج
  const ICONS = Object.keys(R.P).filter((k) => !/_social|insta|linkedin|tiktok|snap|youtube|menu|arrow|x$/.test(k));
  function field(f) {
    const v = get(W, f.k) ?? "";
    const id = "f_" + f.k.replace(/\W/g, "_");
    const lab = `<span>${esc(f.label)}${f.hint ? ` <small class="muted">${esc(f.hint)}</small>` : ""}</span>`;
    const dir = f.en ? ' dir="ltr"' : f.ltr ? ' dir="ltr"' : "";
    if (f.type === "toggle") return `<label class="row ws-tg"><input type="checkbox" data-k="${f.k}" data-t="bool" ${v ? "checked" : ""}> ${esc(f.label)}</label>`;
    if (f.type === "textarea") return `<label class="field">${lab}<textarea id="${id}" data-k="${f.k}" rows="${f.rows || 3}"${dir}>${esc(v)}</textarea></label>`;
    if (f.type === "color") return `<label class="field ws-color">${lab}<div class="row"><input type="color" data-k="${f.k}" value="${esc(v || "#000000")}"><input data-k="${f.k}" value="${esc(v)}" dir="ltr" maxlength="9" style="width:110px"></div></label>`;
    if (f.type === "number") return `<label class="field">${lab}<input type="number" data-k="${f.k}" data-t="num" value="${esc(v)}" ${f.min != null ? `min="${f.min}"` : ""} ${f.max != null ? `max="${f.max}"` : ""}></label>`;
    if (f.type === "image") return `<div class="field">${lab}<div class="ws-img"><img src="${esc(v || "")}" alt="" onerror="this.style.visibility='hidden'" onload="this.style.visibility='visible'">
      <div class="grow"><input data-k="${f.k}" value="${esc(v)}" dir="ltr" placeholder="img/... أو رابط https://">
      <div class="row" style="margin-top:6px"><label class="btn btn-sm">⬆️ رفع صورة<input type="file" accept="image/*" data-up="${f.k}" hidden></label>
      ${get(DEF, f.k) ? `<button type="button" class="btn btn-sm btn-ghost" data-reset-img="${f.k}">↩️ الافتراضي</button>` : ""}</div></div></div></div>`;
    return `<label class="field">${lab}<input data-k="${f.k}" value="${esc(v)}"${dir}${f.max ? ` maxlength="${f.max}"` : ""}></label>`;
  }
  const pair = (k, label, type, extra = {}) => `<div class="grid-2">${field({ k: k + "_ar", label: label + " (عربي)", type, ...extra })}${field({ k: k + "_en", label: label + " (English)", type, en: true, ...extra })}</div>`;

  // محرر قوائم عام: كل عنصر بطاقة قابلة للطي مع ترتيب وحذف
  function listEditor(path, itemFields, titleOf, blank) {
    const arr = get(W, path) || [];
    return `<div class="ws-list" data-list="${path}">${arr.map((it, i) => `<details class="ws-item" ${arr.length <= 3 ? "open" : ""}>
        <summary><b>${i + 1}.</b> ${esc(titleOf(it) || "—")}<span class="spacer"></span>
          <button type="button" class="icon-btn" data-mv="${path}|${i}|-1" title="لأعلى">⬆️</button><button type="button" class="icon-btn" data-mv="${path}|${i}|1" title="لأسفل">⬇️</button><button type="button" class="icon-btn" data-rm="${path}|${i}" title="حذف">🗑️</button></summary>
        <div class="ws-item-body">${itemFields.map((f) => (typeof f === "function" ? f(`${path}.${i}`, it) : field({ ...f, k: `${path}.${i}.${f.k}` }))).join("")}</div></details>`).join("")}
      <button type="button" class="btn btn-sm" data-add="${path}">➕ إضافة</button></div>`;
  }
  // قائمة نصوص (سطر لكل عنصر)
  const linesField = (k, label, en) => `<label class="field"><span>${esc(label)} <small class="muted">— سطر لكل عنصر</small></span><textarea data-k="${k}" data-t="lines" rows="5"${en ? ' dir="ltr"' : ""}>${esc((get(W, k) || []).join("\n"))}</textarea></label>`;
  const iconSel = (base, it) => `<label class="field"><span>الأيقونة</span><div class="ws-icons">${ICONS.map((n) => `<button type="button" class="ws-ic ${it.icon === n ? "on" : ""}" data-icon="${base}.icon|${n}" title="${n}">${R.ic(n)}</button>`).join("")}</div></label>`;

  // ------------------------------------------------------------------ الأقسام
  const SECTIONS = [
    ["general", "⚙️ عام والهوية"], ["seo", "🔎 SEO ومحركات البحث"], ["hero", "🚀 الواجهة الرئيسية"], ["sections", "🧩 إظهار الأقسام"],
    ["features", "✨ المميزات والخطوات"], ["roles", "👥 الأدوار والمشكلة"], ["pricing", "💳 الباقات والأسعار"], ["faq", "❓ الأسئلة الشائعة"],
    ["more", "📊 الأرقام والأمان والتكاملات"], ["links", "📞 التواصل والروابط"], ["pages", "📄 الصفحات"], ["leads", "📨 طلبات التواصل"],
  ];
  const SEC_NAMES = { announce: "شريط الإعلان العلوي", hero: "الواجهة الرئيسية", trust: "شريط المزايا المتحرك", problem: "المشكلة والحل", features: "المميزات", how: "كيف يعمل", roles: "لمن مسار", demo: "المحاكاة الحية", stats: "الأرقام", integrations: "التكاملات", pricing: "الأسعار", security: "الأمان", faq: "الأسئلة الشائعة", contact: "نموذج التواصل", cta: "الدعوة الختامية" };

  function panel(s) {
    if (s === "general") return `
      <div class="card"><div class="card-head"><h3>🏷️ الاسم والشعار</h3></div>
        ${pair("brand.name", "اسم المنصة")}${pair("brand.tagline", "الشعار اللفظي (السلوجن)")}
        ${field({ k: "brand.logo", label: "الشعار (مربع، يفضّل PNG شفاف)", type: "image" })}</div>
      <div class="card"><div class="card-head"><h3>🎨 الألوان والخط</h3><button type="button" class="btn btn-sm btn-ghost" data-reset="theme">↩️ ألوان الهوية الأصلية</button></div>
        <div class="grid-3">${[["blue", "الأزرق الأساسي"], ["green", "الأخضر"], ["navy", "الكحلي"], ["orange", "البرتقالي (للتنبيه)"], ["cloud", "لون الخلفية"], ["ink", "لون النص"]].map(([k, l]) => field({ k: "theme." + k, label: l, type: "color" })).join("")}</div>
        ${field({ k: "theme.font", label: "اسم الخط (اختياري)", hint: "اتركه فاضي لاستخدام IBM Plex Sans Arabic", ltr: true })}</div>
      <div class="card"><div class="card-head"><h3>📣 شريط الإعلان العلوي</h3></div>
        ${field({ k: "announce.on", label: "إظهار شريط الإعلان", type: "toggle" })}
        <div class="grid-2">${field({ k: "announce.ar", label: "النص (عربي)" })}${field({ k: "announce.en", label: "النص (English)", en: true })}</div>
        ${field({ k: "announce.link", label: "الرابط عند الضغط", ltr: true, hint: "مثال: #pricing أو رابط كامل" })}</div>`;
    if (s === "seo") return `
      <div class="card"><div class="card-head"><h3>🔎 الظهور في قوقل ومحركات البحث والذكاء الاصطناعي</h3></div>
        <p class="small muted" style="margin-top:0">العنوان يفضّل أقل من 60 حرف، والوصف بين 120 و160 حرف. الكلمات المفتاحية مفصولة بفواصل.</p>
        ${pair("seo.title", "عنوان الصفحة", "text", { max: 90 })}${pair("seo.desc", "الوصف", "textarea", { rows: 3 })}${pair("seo.keywords", "الكلمات المفتاحية", "textarea", { rows: 2 })}
        ${field({ k: "seo.og_image", label: "صورة المشاركة في السوشال (1200×630)", type: "image" })}
        <div id="ws-serp"></div></div>
      <div class="card"><div class="card-head"><h3>🧭 ملفات محركات البحث</h3></div>
        <div class="row">${["sitemap.xml", "robots.txt", "llms.txt"].map((f) => `<a class="btn btn-sm" target="_blank" href="${f}">${f}</a>`).join("")}</div>
        <p class="small muted">تمت تهيئة البيانات المنظّمة (Schema) للمنظمة والتطبيق والأسئلة الشائعة والخطوات تلقائياً، وملف llms.txt لمحركات الذكاء الاصطناعي. سجّل الموقع في <a href="https://search.google.com/search-console" target="_blank" rel="noopener">Google Search Console</a> وأضف sitemap.xml.</p></div>`;
    if (s === "hero") return `
      <div class="card"><div class="card-head"><h3>🚀 الواجهة الرئيسية</h3></div>
        ${pair("hero.badge", "الشارة الصغيرة")}${pair("hero.title", "العنوان الكبير", "text", { hint: "آخر كلمة تتلوّن تلقائياً" })}${pair("hero.sub", "الوصف", "textarea")}
        ${pair("hero.cta1", "نص الزر الأساسي")}${pair("hero.cta2", "نص الزر الثانوي")}
        ${field({ k: "hero.image", label: "الصورة الرئيسية (4:3)", type: "image" })}</div>
      <div class="card"><div class="card-head"><h3>✅ شريط المزايا المتحرك</h3></div><div class="grid-2">${linesField("trust.ar", "عربي")}${linesField("trust.en", "English", true)}</div></div>
      <div class="card"><div class="card-head"><h3>🏁 الدعوة الختامية</h3></div>${pair("cta.title", "العنوان")}${pair("cta.sub", "الوصف")}${field({ k: "cta.img", label: "صورة الخلفية", type: "image" })}</div>`;
    if (s === "sections") return `
      <div class="card"><div class="card-head"><h3>🧩 الأقسام الظاهرة في الصفحة الرئيسية</h3></div>
        <div class="ws-secs">${Object.keys(SEC_NAMES).map((k) => k === "announce" ? field({ k: "announce.on", label: SEC_NAMES[k], type: "toggle" }) : field({ k: "sections." + k, label: SEC_NAMES[k], type: "toggle" })).join("")}</div></div>`;
    if (s === "features") return `
      <div class="card"><div class="card-head"><h3>✨ المميزات</h3></div>${listEditor("features", [iconSel, { k: "t_ar", label: "العنوان (عربي)" }, { k: "d_ar", label: "الوصف (عربي)", type: "textarea", rows: 2 }, { k: "t_en", label: "Title (English)", en: true }, { k: "d_en", label: "Description (English)", type: "textarea", rows: 2, en: true }], (x) => x.t_ar, { icon: "zap", t_ar: "ميزة جديدة", d_ar: "", t_en: "New feature", d_en: "" })}</div>
      <div class="card"><div class="card-head"><h3>🪜 خطوات البدء</h3></div>${listEditor("steps", [{ k: "t_ar", label: "العنوان (عربي)" }, { k: "d_ar", label: "الوصف (عربي)" }, { k: "t_en", label: "Title", en: true }, { k: "d_en", label: "Description", en: true }], (x) => x.t_ar, { t_ar: "خطوة", d_ar: "", t_en: "Step", d_en: "" })}</div>`;
    if (s === "roles") return `
      <div class="card"><div class="card-head"><h3>👥 لمن مسار (التبويبات)</h3></div>${listEditor("roles", [iconSel, { k: "t_ar", label: "العنوان (عربي)" }, { k: "t_en", label: "Title", en: true }, { k: "img", label: "الصورة", type: "image" }, (b) => `<div class="grid-2">${linesField(b + ".ar", "النقاط (عربي)")}${linesField(b + ".en", "Points (English)", true)}</div>`], (x) => x.t_ar, { key: "x", icon: "users", t_ar: "دور جديد", t_en: "New role", img: "", ar: [], en: [] })}</div>
      <div class="card"><div class="card-head"><h3>⚖️ المشكلة والحل</h3></div>${pair("problem.title", "عنوان القسم")}
        ${listEditor("problem.items", [{ k: "bad_ar", label: "قبل (عربي)" }, { k: "good_ar", label: "بعد (عربي)" }, { k: "bad_en", label: "Before", en: true }, { k: "good_en", label: "After", en: true }], (x) => x.good_ar, { bad_ar: "", good_ar: "", bad_en: "", good_en: "" })}</div>`;
    if (s === "pricing") return `
      <div class="card"><div class="card-head"><h3>💳 إعدادات الأسعار</h3></div>
        <div class="grid-3">${field({ k: "pricing.currency_ar", label: "العملة (عربي)" })}${field({ k: "pricing.currency_en", label: "Currency", en: true })}${field({ k: "pricing.yearly_discount", label: "خصم الاشتراك السنوي %", type: "number", min: 0, max: 90 })}</div>
        ${pair("pricing.note", "ملاحظة أسفل الباقات", "textarea", { rows: 2 })}</div>
      <div class="card"><div class="card-head"><h3>📦 الباقات</h3></div><p class="small muted" style="margin-top:0">اترك السعر فاضي لعرض "حسب الطلب". فعّل "مميّزة" لإبراز الباقة.</p>
        ${listEditor("pricing.plans", [
          (b, it) => `<div class="grid-3">${field({ k: b + ".name_ar", label: "الاسم (عربي)" })}${field({ k: b + ".name_en", label: "Name", en: true })}<label class="field"><span>السعر الشهري</span><input type="number" min="0" data-k="${b}.price" data-t="numnull" value="${it.price ?? ""}" placeholder="حسب الطلب"></label></div>`,
          { k: "featured", label: "باقة مميّزة (الأكثر طلباً)", type: "toggle" },
          (b) => `<div class="grid-2">${field({ k: b + ".desc_ar", label: "وصف قصير (عربي)" })}${field({ k: b + ".desc_en", label: "Short description", en: true })}</div>`,
          (b) => `<div class="grid-2">${linesField(b + ".f_ar", "المزايا (عربي)")}${linesField(b + ".f_en", "Features (English)", true)}</div>`,
          (b) => `<div class="grid-2">${field({ k: b + ".cta_ar", label: "نص الزر (عربي)" })}${field({ k: b + ".cta_en", label: "Button", en: true })}</div>`,
        ], (x) => `${x.name_ar} — ${x.price ?? "حسب الطلب"}`, { name_ar: "باقة جديدة", name_en: "New plan", price: 0, desc_ar: "", desc_en: "", featured: false, f_ar: [], f_en: [], cta_ar: "ابدأ التجربة", cta_en: "Start trial" })}</div>`;
    if (s === "faq") return `<div class="card"><div class="card-head"><h3>❓ الأسئلة الشائعة</h3></div><p class="small muted" style="margin-top:0">تظهر في الموقع وتُضاف تلقائياً لنتائج قوقل كأسئلة شائعة (FAQ Schema).</p>
      ${listEditor("faq", [{ k: "q_ar", label: "السؤال (عربي)" }, { k: "a_ar", label: "الجواب (عربي)", type: "textarea" }, { k: "q_en", label: "Question", en: true }, { k: "a_en", label: "Answer", type: "textarea", en: true }], (x) => x.q_ar, { q_ar: "سؤال جديد؟", a_ar: "", q_en: "New question?", a_en: "" })}</div>`;
    if (s === "more") return `
      <div class="card"><div class="card-head"><h3>📊 الأرقام</h3></div>${listEditor("stats", [(b) => `<div class="grid-3">${field({ k: b + ".v", label: "الرقم" })}${field({ k: b + ".s_ar", label: "الوحدة (عربي)" })}${field({ k: b + ".s_en", label: "Unit", en: true })}</div>`, { k: "l_ar", label: "الوصف (عربي)" }, { k: "l_en", label: "Label", en: true }], (x) => `${x.v} ${x.s_ar}`, { v: "0", s_ar: "", s_en: "", l_ar: "", l_en: "" })}</div>
      <div class="card"><div class="card-head"><h3>🔐 الأمان</h3></div>${field({ k: "security.img", label: "الصورة", type: "image" })}
        <div class="grid-2"><div><b class="small">عربي</b>${listEditor("security.ar", [{ k: "t", label: "العنوان" }, { k: "d", label: "الوصف", type: "textarea", rows: 2 }], (x) => x.t, { t: "", d: "" })}</div>
        <div><b class="small">English</b>${listEditor("security.en", [{ k: "t", label: "Title", en: true }, { k: "d", label: "Text", type: "textarea", rows: 2, en: true }], (x) => x.t, { t: "", d: "" })}</div></div></div>
      <div class="card"><div class="card-head"><h3>🔌 التكاملات</h3></div>${field({ k: "integrations.img", label: "الصورة", type: "image" })}
        <div class="grid-2"><div><b class="small">عربي</b>${listEditor("integrations.ar", [{ k: "n", label: "الاسم" }, { k: "s", label: "الحالة" }], (x) => x.n, { n: "", s: "" })}</div>
        <div><b class="small">English</b>${listEditor("integrations.en", [{ k: "n", label: "Name", en: true }, { k: "s", label: "Status", en: true }], (x) => x.n, { n: "", s: "" })}</div></div></div>
      <div class="card"><div class="card-head"><h3>📝 نموذج التواصل</h3></div>${pair("contact.title", "العنوان")}${pair("contact.sub", "الوصف", "textarea", { rows: 2 })}</div>`;
    if (s === "links") return `
      <div class="card"><div class="card-head"><h3>🔗 أزرار الموقع</h3></div>
        ${field({ k: "links.zid_app", label: "رابط تطبيق مسار في متجر تطبيقات زد", ltr: true, hint: "زر \"ابدأ مجاناً\" يروح له. إذا فاضي يروح لنموذج التواصل" })}
        ${field({ k: "links.login", label: "رابط تسجيل الدخول", ltr: true })}</div>
      <div class="card"><div class="card-head"><h3>📞 بيانات التواصل</h3></div>
        <div class="grid-3">${field({ k: "links.email", label: "الإيميل", ltr: true })}${field({ k: "links.whatsapp", label: "واتساب (مع رمز الدولة)", ltr: true, hint: "يظهر زر واتساب عائم" })}${field({ k: "links.phone", label: "رقم الهاتف", ltr: true })}</div></div>
      <div class="card"><div class="card-head"><h3>📱 حسابات السوشال ميديا</h3></div>
        <div class="grid-3">${[["twitter", "X (تويتر)"], ["instagram", "انستقرام"], ["linkedin", "لينكدإن"], ["tiktok", "تيك توك"], ["snapchat", "سناب شات"], ["youtube", "يوتيوب"]].map(([k, l]) => field({ k: "links." + k, label: l, ltr: true })).join("")}</div></div>`;
    return "";
  }

  // ------------------------------------------------------------------ الصفحات (شروط/خصوصية/دليل)
  let pageKey = "terms", pageLang = "ar";
  function pagesPanel() {
    const cur = R.merge(clone(DOCS[pageKey]), RAW["page:" + pageKey]?.data || {});
    return `<div class="card"><div class="card-head"><h3>📄 تحرير الصفحات</h3>
        <div class="row">${[["terms", "شروط الاستخدام"], ["privacy", "سياسة الخصوصية"], ["guide", "دليل الاستخدام"]].map(([k, l]) => `<button type="button" class="btn btn-sm ${k === pageKey ? "btn-primary" : ""}" data-pg="${k}">${l}</button>`).join("")}</div></div>
      <div class="grid-3"><label class="field"><span>العنوان (عربي)</span><input id="pg-tar" value="${esc(cur.title_ar)}"></label><label class="field"><span>Title (English)</span><input id="pg-ten" dir="ltr" value="${esc(cur.title_en)}"></label>
        <label class="field"><span>تاريخ آخر تحديث</span><input id="pg-upd" type="date" value="${esc(cur.updated || "")}"></label></div>
      <div class="row" style="margin-bottom:8px"><button type="button" class="btn btn-sm ${pageLang === "ar" ? "btn-primary" : ""}" data-pl="ar">النص العربي</button><button type="button" class="btn btn-sm ${pageLang === "en" ? "btn-primary" : ""}" data-pl="en">English text</button>
        <span class="spacer"></span><span class="small muted">## عنوان · - نقطة · 1. رقم · **عريض** · [نص](رابط) · &gt; ملاحظة</span></div>
      <div class="ws-md"><textarea id="pg-body" rows="24" ${pageLang === "en" ? 'dir="ltr"' : ""}>${esc(cur[pageLang] || "")}</textarea><div class="ws-prev doc" id="pg-prev"></div></div>
      <div class="row" style="margin-top:12px"><button type="button" class="btn btn-primary" id="pg-save">💾 حفظ الصفحة</button>
        <a class="btn" target="_blank" href="${pageKey}${pageLang === "en" ? "?lang=en" : ""}">👁️ فتح الصفحة</a>
        ${RAW["page:" + pageKey] ? `<button type="button" class="btn btn-ghost" id="pg-reset">↩️ استرجاع النص الافتراضي</button>` : ""}</div></div>`;
  }
  function bindPages(view) {
    const cur = R.merge(clone(DOCS[pageKey]), RAW["page:" + pageKey]?.data || {});
    const prev = () => { $("#pg-prev", view).innerHTML = R.md($("#pg-body", view).value).html; $("#pg-prev", view).dir = pageLang === "en" ? "ltr" : "rtl"; };
    prev();
    $("#pg-body", view).oninput = () => { cur[pageLang] = $("#pg-body", view).value; prev(); };
    $$("[data-pg]", view).forEach((b) => b.onclick = () => { pageKey = b.dataset.pg; draw(view); });
    $$("[data-pl]", view).forEach((b) => b.onclick = () => { stash(); pageLang = b.dataset.pl; draw(view); });
    function stash() { // نحفظ النص المكتوب مؤقتاً عند تبديل اللغة
      cur[pageLang] = $("#pg-body", view).value;
      RAW["page:" + pageKey] = { data: { ...(RAW["page:" + pageKey]?.data || {}), [pageLang]: cur[pageLang], title_ar: $("#pg-tar", view).value, title_en: $("#pg-ten", view).value, updated: $("#pg-upd", view).value }, draft: true };
    }
    $("#pg-save", view).onclick = async () => {
      stash();
      const d = diff(R.merge(clone(DOCS[pageKey]), RAW["page:" + pageKey].data), DOCS[pageKey]) || {};
      try { await A.rpc("owner_site_save", { p_key: "page:" + pageKey, p_data: d }); RAW["page:" + pageKey] = { data: d }; toast("تم حفظ الصفحة ✅", "ok"); draw(view); }
      catch (e) { toast(A.errMsg(e), "error"); }
    };
    const rs = $("#pg-reset", view);
    if (rs) rs.onclick = async () => {
      if (!confirm("نرجع نص الصفحة للنسخة الافتراضية؟")) return;
      try { await A.rpc("owner_site_save", { p_key: "page:" + pageKey, p_data: {} }); delete RAW["page:" + pageKey]; toast("تم الاسترجاع", "ok"); draw(view); } catch (e) { toast(A.errMsg(e), "error"); }
    };
  }

  // ------------------------------------------------------------------ طلبات التواصل
  const LS = { new: ["🆕 جديد", "#dbeafe", "#1d4ed8"], contacted: ["📞 تم التواصل", "#fef3c7", "#92400e"], closed: ["✅ مغلق", "#dcfce7", "#166534"] };
  async function leadsPanel(view) {
    $("#ws-body", view).innerHTML = `<div class="card"><div class="empty">جاري التحميل…</div></div>`;
    let rows = [];
    try { rows = await A.rpc("owner_leads", { p_limit: 300 }); } catch (e) { $("#ws-body", view).innerHTML = `<div class="card"><p class="chip chip-warn">${esc(A.errMsg(e))} — تأكد إنك شغّلت ترقية قاعدة البيانات 005</p></div>`; return; }
    $("#ws-body", view).innerHTML = `<div class="card"><div class="card-head"><h3>📨 طلبات التواصل من الموقع (${rows.length})</h3></div><div class="table-wrap"><table><thead><tr>
      <th>التاريخ</th><th>الاسم</th><th>الجوال</th><th>الإيميل</th><th>المتجر</th><th>فروع</th><th>الرسالة</th><th>الحالة</th><th></th></tr></thead><tbody>
      ${rows.map((r) => { const st = LS[r.status] || LS.new; const wa = r.phone ? A.waLink(r.phone, `هلا ${r.name}، معك فريق مسار بخصوص طلبك من الموقع 👋`) : ""; return `<tr>
        <td class="small">${A.fmtDateTime(r.created_at)}</td><td><b>${esc(r.name)}</b> <span class="chip">${esc(r.lang || "")}</span></td>
        <td class="mono small">${esc(r.phone || "—")}</td><td class="small" dir="ltr">${r.email ? `<a href="mailto:${esc(r.email)}">${esc(r.email)}</a>` : "—"}</td>
        <td class="small">${r.store_url ? `<a target="_blank" rel="noopener" href="${esc(R.safeUrl(r.store_url))}">${esc(r.store_url.replace(/^https?:\/\//, "").slice(0, 30))}</a>` : "—"}</td>
        <td>${r.branches ?? "—"}</td><td class="small" style="max-width:280px">${esc(r.message || "")}</td>
        <td><select data-ls="${r.id}">${Object.entries(LS).map(([k, v]) => `<option value="${k}" ${k === r.status ? "selected" : ""}>${v[0]}</option>`).join("")}</select></td>
        <td>${wa ? `<a class="btn btn-sm btn-primary" target="_blank" href="${wa}">واتساب</a>` : ""}</td></tr>`; }).join("") || `<tr><td colspan="9" class="empty">ما في طلبات بعد — أول ما يعبّي زائر نموذج التواصل بيظهر هنا</td></tr>`}
      </tbody></table></div></div>`;
    $$("[data-ls]", view).forEach((s) => s.onchange = async () => { try { await A.rpc("owner_lead_status", { p_id: Number(s.dataset.ls), p_status: s.value }); toast("تم التحديث", "ok"); } catch (e) { toast(A.errMsg(e), "error"); } });
  }

  // ------------------------------------------------------------------ الرسم والربط
  function draw(view) {
    view.innerHTML = `<div class="ws">
      <aside class="ws-nav">${SECTIONS.map(([k, l]) => `<button type="button" data-s="${k}" class="${k === sub ? "on" : ""}">${l}</button>`).join("")}
        <a class="btn btn-block" target="_blank" href="./" style="margin-top:10px">👁️ فتح الموقع</a><a class="btn btn-block" target="_blank" href="en">👁️ النسخة الإنجليزية</a></aside>
      <div class="ws-main"><div id="ws-body">${sub === "pages" ? pagesPanel() : sub === "leads" ? "" : panel(sub)}</div>
        ${sub === "pages" || sub === "leads" ? "" : `<div class="ws-bar"><span class="small muted" id="ws-state">${RAW.site?.updated_at ? "آخر حفظ: " + A.fmtDateTime(RAW.site.updated_at) : "يستخدم المحتوى الافتراضي"}</span><span class="spacer"></span>
          <button type="button" class="btn btn-ghost" id="ws-reset-sec">↩️ استرجاع هذا القسم</button><button type="button" class="btn btn-primary" id="ws-save">💾 حفظ ونشر</button></div>`}</div></div>`;
    $$(".ws-nav [data-s]", view).forEach((b) => b.onclick = () => { if (dirty && !confirm("في تعديلات ما انحفظت. تبي تتركها؟")) return; if (dirty) { W = R.merge(clone(DEF), RAW.site?.data || {}); dirty = false; } sub = b.dataset.s; draw(view); });
    if (sub === "pages") return bindPages(view);
    if (sub === "leads") return leadsPanel(view);
    bindForm(view);
  }

  const SEC_KEYS = { general: ["brand", "theme", "announce"], seo: ["seo"], hero: ["hero", "trust", "cta"], sections: ["sections", "announce"], features: ["features", "steps"], roles: ["roles", "problem"], pricing: ["pricing"], faq: ["faq"], more: ["stats", "security", "integrations", "contact"], links: ["links"] };

  function bindForm(view) {
    const body = $("#ws-body", view);
    const mark = () => { dirty = true; const s = $("#ws-state", view); if (s) s.innerHTML = `<b style="color:var(--warn)">● تعديلات غير محفوظة</b>`; serp(); };
    body.addEventListener("input", (e) => {
      const el = e.target, k = el.dataset.k; if (!k) return;
      let v = el.value;
      if (el.dataset.t === "bool") v = el.checked;
      else if (el.dataset.t === "num") v = v === "" ? 0 : Number(v);
      else if (el.dataset.t === "numnull") v = v === "" ? null : Number(v);
      else if (el.dataset.t === "lines") v = v.split("\n").map((x) => x.trim()).filter(Boolean);
      set(W, k, v);
      if (el.type === "color") $$(`input[data-k="${k}"]:not([type=color])`, body).forEach((x) => (x.value = v));
      else if (/^#[0-9a-f]{6}$/i.test(v)) $$(`input[type=color][data-k="${k}"]`, body).forEach((x) => (x.value = v));
      if (el.closest(".ws-img")) { const im = $("img", el.closest(".ws-img")); im.src = v; }
      mark();
    });
    body.addEventListener("click", async (e) => {
      const b = e.target.closest("button"); if (!b) return;
      if (b.dataset.icon) { const [k, n] = b.dataset.icon.split("|"); set(W, k, n); mark(); return redraw(); }
      if (b.dataset.add) { e.preventDefault(); const arr = get(W, b.dataset.add) || []; const tmpl = findBlank(b.dataset.add); arr.push(clone(tmpl)); set(W, b.dataset.add, arr); mark(); return redraw(); }
      if (b.dataset.rm) { e.preventDefault(); e.stopPropagation(); const [p, i] = b.dataset.rm.split("|"); if (!confirm("حذف هذا العنصر؟")) return; get(W, p).splice(Number(i), 1); mark(); return redraw(); }
      if (b.dataset.mv) { e.preventDefault(); e.stopPropagation(); const [p, i, d] = b.dataset.mv.split("|"); const a = get(W, p), x = Number(i), y = x + Number(d); if (y < 0 || y >= a.length) return; [a[x], a[y]] = [a[y], a[x]]; mark(); return redraw(); }
      if (b.dataset.resetImg) { set(W, b.dataset.resetImg, get(DEF, b.dataset.resetImg)); mark(); return redraw(); }
      if (b.dataset.reset) { set(W, b.dataset.reset, clone(get(DEF, b.dataset.reset))); mark(); return redraw(); }
    });
    // رفع الصور إلى مخزن الموقع
    body.addEventListener("change", async (e) => {
      const inp = e.target; if (!inp.dataset.up || !inp.files?.[0]) return;
      const f = inp.files[0];
      if (f.size > 5 * 1024 * 1024) return toast("الحد الأقصى 5MB", "error");
      const ext = (f.name.split(".").pop() || "png").toLowerCase().replace(/[^a-z0-9]/g, "");
      const path = `${inp.dataset.up.replace(/\W+/g, "-")}-${Date.now()}.${ext}`;
      toast("جاري الرفع…");
      const { error } = await sb.storage.from("site").upload(path, f, { upsert: true, contentType: f.type });
      if (error) return toast("تعذر الرفع: " + error.message, "error");
      const url = `${A.C.SUPABASE_URL}/storage/v1/object/public/site/${path}`;
      set(W, inp.dataset.up, url); mark(); redraw(); toast("تم رفع الصورة ✅ — اضغط حفظ ونشر", "ok");
    });
    function redraw() { const y = scrollY; body.innerHTML = panel(sub); scrollTo(0, y); serp(); }
    function findBlank(path) {
      const blanks = { features: { icon: "zap", t_ar: "ميزة جديدة", d_ar: "", t_en: "New feature", d_en: "" }, steps: { t_ar: "خطوة", d_ar: "", t_en: "Step", d_en: "" },
        roles: { key: "x" + Date.now(), icon: "users", t_ar: "دور جديد", t_en: "New role", img: "", ar: [], en: [] }, "problem.items": { bad_ar: "", good_ar: "", bad_en: "", good_en: "" },
        "pricing.plans": { name_ar: "باقة جديدة", name_en: "New plan", price: 0, desc_ar: "", desc_en: "", featured: false, f_ar: [], f_en: [], cta_ar: "ابدأ التجربة", cta_en: "Start trial" },
        faq: { q_ar: "سؤال جديد؟", a_ar: "", q_en: "New question?", a_en: "" }, stats: { v: "0", s_ar: "", s_en: "", l_ar: "", l_en: "" } };
      return blanks[path] || (/security/.test(path) ? { t: "", d: "" } : { n: "", s: "" });
    }
    function serp() {
      const el = $("#ws-serp", view); if (!el) return;
      el.innerHTML = `<div class="ws-serp"><div class="small muted">معاينة نتيجة قوقل:</div><div class="u">msarpro.com</div><div class="t">${esc(W.seo.title_ar)}</div><div class="d">${esc(W.seo.desc_ar)}</div>
        <div class="small ${W.seo.title_ar.length > 65 ? "bad" : "ok"}">العنوان ${W.seo.title_ar.length} حرف</div><div class="small ${W.seo.desc_ar.length > 170 || W.seo.desc_ar.length < 90 ? "bad" : "ok"}">الوصف ${W.seo.desc_ar.length} حرف</div></div>`;
    }
    serp();
    $("#ws-save", view).onclick = async (e) => { e.target.disabled = true; try { await saveSite(); draw(view); } catch (er) { toast(A.errMsg(er), "error"); e.target.disabled = false; } };
    $("#ws-reset-sec", view).onclick = () => { if (!confirm("نرجع محتوى هذا القسم للافتراضي؟ (ما ينحفظ إلا لما تضغط حفظ)")) return; (SEC_KEYS[sub] || []).forEach((k) => (W[k] = clone(DEF[k]))); mark(); redraw(); };
  }

  async function render(view, s) {
    if (s === "leads") sub = "leads"; else if (sub === "leads") sub = "general";
    view.innerHTML = `<div class="card"><div class="empty">جاري التحميل…</div></div>`;
    try { await loadAll(); } catch (e) {
      view.innerHTML = `<div class="card"><h3>⚠️ إدارة الموقع تحتاج ترقية قاعدة البيانات</h3><p>شغّل ملف <b>005_site.sql</b> في Supabase ← SQL Editor ثم حدّث الصفحة.</p><p class="small muted">${esc(A.errMsg(e))}</p></div>`;
      return;
    }
    draw(view);
  }
  addEventListener("beforeunload", (e) => { if (dirty) { e.preventDefault(); e.returnValue = ""; } });
  window.MSAR_OWNER_SITE = { render };
})();
