/* مسار — تفاعل صفحات المدونة (خفيف: قائمة الجوال، شريط التقدم، زر الأعلى، تمييز العنوان الحالي في الفهرس) */
(function () {
  "use strict";
  var $ = function (s, r) { return (r || document).querySelector(s); }, $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var hdr = $("#hdr"), prog = $(".progress"), top = $(".to-top"), nav = $("#nav"), bg = $("#burger");
  function onScroll() {
    var y = window.scrollY;
    if (hdr) hdr.classList.toggle("scrolled", y > 10);
    if (top) top.classList.toggle("show", y > 900);
    if (prog) { var h = document.documentElement.scrollHeight - window.innerHeight; prog.style.transform = "scaleX(" + (h > 0 ? y / h : 0) + ")"; }
  }
  window.addEventListener("scroll", onScroll, { passive: true }); onScroll();
  if (top) top.onclick = function () { window.scrollTo({ top: 0, behavior: "smooth" }); };
  if (bg && nav) {
    bg.onclick = function () { var o = nav.classList.toggle("open"); bg.setAttribute("aria-expanded", o); };
    $$("#nav a").forEach(function (a) { a.addEventListener("click", function () { nav.classList.remove("open"); bg.setAttribute("aria-expanded", "false"); }); });
  }
  $$("[data-year]").forEach(function (x) { x.textContent = new Date().getFullYear(); });
  var links = $$(".doc-toc a"), heads = links.map(function (a) { return document.getElementById(a.getAttribute("href").slice(1)); }).filter(Boolean);
  if (heads.length) window.addEventListener("scroll", function () {
    var cur = heads[0];
    heads.forEach(function (h) { if (h.getBoundingClientRect().top < 140) cur = h; });
    links.forEach(function (a) { a.classList.toggle("on", a.getAttribute("href") === "#" + cur.id); });
  }, { passive: true });
})();
