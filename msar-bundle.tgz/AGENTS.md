# AGENTS.md — MSAR (مسار) project guide for AI coding agents

> Read this whole file before changing anything. It is the single source of truth for
> ChatGPT/Codex, Gemini/Jules, Claude and any other agent working on this repo.
> The business plan and roadmap are in [`docs/PLAN.md`](docs/PLAN.md) (Arabic).

## 1. What MSAR is

MSAR (مسار, "route") is a multi-tenant SaaS app for **Zid** merchants (Saudi e-commerce platform).
When a Zid store receives an order, MSAR:

1. receives it in real time (Zid webhook) or via a periodic backup sync,
2. routes it automatically to the **nearest branch** within a radius (km) using the customer's coordinates,
3. shows it on that branch's **cashier screen** (sound alert),
4. dispatches it to a **driver** (Android app, live location tracking, cash-on-delivery handling),
5. optionally pushes the order status back to Zid (off by default per store: `settings.push_status = false`).

Users: platform owner (us), store admin, cashier (per branch), driver (per branch).
UI language: **Arabic, RTL, Saudi dialect**, mobile-first.

## 2. Architecture

| Layer | Tech | Where |
|---|---|---|
| Web apps (static) | Vanilla HTML/CSS/JS, no framework, no bundler | `web/` → GitHub Pages `https://azem3600-cloud.github.io/msar/` |
| Database + auth | Supabase Postgres, RLS per store, RPC functions | `supabase/schema.sql`, `supabase/migrations/*.sql` |
| Scheduled jobs | `pg_cron` + `pg_net` calling the `zid` edge function every minute | `supabase/cron.sql` |
| Server logic | Supabase Edge Functions (Deno, TypeScript), deployed **without Verify JWT** | `supabase/functions/zid`, `supabase/functions/admin` |
| Driver app | Capacitor Android wrapper around `web/driver.html` | `android/`, built by `ci/build.sh` |
| CI/CD | GitHub Actions builds vendor libs, sounds, signed APK, deploys Pages | `.github/workflows/build.yml`, `ci/build.sh` |

Supabase project ref: `ydfsevhzjztnyfdbmzdb`. The anon key in `web/js/config.js` is public by design (RLS protects data).

### Web pages (`web/`)
- `index.html` + `js/app.js` — store dashboard (admin) and cashier screen. Login = store code + username + password
  (internal email `username@<store_code>.msar.app`).
- `driver.html` + `js/driver.js` — driver app (also packaged as the APK).
- `owner.html` + `js/owner.js` — platform-owner panel (stores, Zid app keys, logs, system health). Owner email `username@owner.msar.app`.
- `setup.html` — first-time store admin creation after installing from Zid (one-time setup token).
- `msg.html` — message page; edge functions redirect here because Supabase serves HTML from functions as plain text.
- `privacy.html`, `support.html` — public pages linked from the Zid app listing.
- `js/common.js` — shared client (`window.AZM`: supabase client, `rpc`, `callFn`, auth, helpers, sounds).

### Database (`supabase/schema.sql`, then migrations in order)
Tables: `stores`, `store_secrets` (Zid tokens, setup token — server only), `branches`, `profiles`, `orders`,
`order_events`, `driver_locations`, `app_settings`, `zid_outbox` (status pushes to Zid), `zid_log`.
Key RPCs: `set_order_status`, `dispatch_order`, `reroute_order`, `nearest_branch`, `create_manual_order`,
`driver_ping`, `dashboard_stats`, `owner_overview`, `owner_health`, `zid_upsert_order(p_store, p, p_force)`, `housekeeping()`.
RLS: every row is scoped to `my_store()`; owner sees all via `is_owner()`. Never weaken RLS.

### Edge function `zid` (actions via `?action=`)
- `install` → redirects to Zid OAuth `https://oauth.zid.sa/oauth/authorize` with a signed `state` (HMAC, 30 min).
- `callback` → verifies `state`, exchanges code, creates/updates store, registers order webhooks, initial sync,
  redirects to `setup.html?t=…` (reuses a still-valid setup token; duplicate callbacks within 2 min are no-ops).
- `webhook` → order events from Zid. URL form: `/functions/v1/zid/wh/<store_id>/<webhook_key>` (legacy `?store=&key=` still accepted).
  Empty payloads are Zid verification pings → 200.
- `app_event` → Zid app events (install/uninstall/subscription) configured in the Partner Dashboard.
  Uninstall is verified against Zid (token must be revoked) before marking the store `uninstalled`.
- `cron` (x-cron-key) → push outbox, then batch sync: up to 60 due stores/min, 8 concurrent, 45 s budget,
  each store every ~15 min (webhooks are primary). Heartbeat in `app_settings.cron_last_run`.
- `health` → public `{ok, cron_age_s, outbox_stuck}`; 503 when unhealthy (for uptime monitors).
- `push`, `sync`, `import`, `webhooks`, `status`, `setup_info`, `setup`.

Zid API notes (verified):
- Headers: `Authorization: Bearer <authorization>` + `X-Manager-Token: <access_token>`.
- **Zid timestamps are UTC without a zone marker** (`"2026-10-27 10:43:02"`). Parse as UTC.
- App icon in the Partner Dashboard must be **≤ 250×250 px**, otherwise "save app details" fails silently.
- A public (draft) app needs at least one plan before a store can activate it.

### Edge function `admin`
`owner_status`, `owner_bootstrap`, `owner_create_store`, `create_user`, `set_password`, `delete_user`, `set_active`.

## 3. Environments and IDs (not secrets)
- Zid partner id `9957`. Zid apps: **8433** "مسار" (private, bound to the real store Azm Market `850719`, requires the
  merchant's "Direct API" add-on); **8546** "مسار تجريبي" (public draft, Client ID `8376`) used for testing.
- Test (development) store: **azem market2**, Zid store id `3206909`, MSAR store code `udsplk`.
- **Do not touch** the separate production system of Azm Market (Supabase project/GitHub repo `azm-delivery`).

## 4. Hard rules for agents
1. **Never commit or paste secrets**: Supabase service-role key, Zid client secret, keystore, passwords, tokens.
   The repo is public. APK signing uses GitHub Actions secrets `KEYSTORE_B64`, `KEYSTORE_PASS`.
2. Don't weaken RLS, don't expose `store_secrets`, don't log tokens.
3. Database changes go in a **new numbered, idempotent migration** `supabase/migrations/00N_name.sql`
   (re-runnable; end with `select 'msar migration 00N ok'`). Never edit already-applied migrations.
4. Keep the web app framework-free and build-free; Arabic RTL copy; test at phone width.
5. `push_status` stays **off by default**; never change Zid order status for a store that didn't enable it.
6. Small, focused pull requests with a clear description of what changed and how it was tested.
7. Edge functions must keep working **without Verify JWT** and must authenticate requests themselves
   (webhook key, cron key, signed state, user JWT + role checks).

## 5. How to check your work
```bash
bash ci/check.sh          # syntax checks: web JS, build script, edge functions (TypeScript)
```
For SQL, run `supabase/schema.sql` then all migrations on a local Postgres 16 with a stub `auth` schema
(see `ci/check.sh` comments). Deploys are manual by the owner:
SQL → Supabase SQL Editor; functions → Supabase dashboard (Code tab → Deploy); web → push to `main` (GitHub Actions).

## 6. Current status (2026-10-27)
Working end-to-end on the dev store: install/OAuth, setup, real-time order webhooks (~12 s), backup sync,
uninstall handling, health endpoint, privacy/support pages, signed APK from secrets.
Not yet done: routing test with real branches, driver app field test, billing/subscriptions, landing page,
Supabase paid plan + backups, external uptime alerts, `owner_overview` pagination for thousands of stores,
publishing the Zid app (review).
