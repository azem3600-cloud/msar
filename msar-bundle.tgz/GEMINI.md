# GEMINI.md

Gemini (CLI / Code Assist / Jules): the full project guide is in [`AGENTS.md`](AGENTS.md) and the
business plan in [`docs/PLAN.md`](docs/PLAN.md). Read both before making changes and follow the
"Hard rules for agents" in AGENTS.md (no secrets, keep RLS, numbered idempotent migrations, Arabic RTL UI).
