// =====================================================================
//  مسار (MSAR) — طلبات الواتساب (Supabase Edge Function: whatsapp)
//  يربط رقم التاجر مع Meta WhatsApp Cloud API مباشرة:
//    GET  ?hub.mode=subscribe...   → التحقق من الويب هوك (Meta)
//    POST (بدون action)            → رسائل العملاء من Meta (موقّعة بـ X-Hub-Signature-256)
//    GET  ?action=web_menu&t=      → بيانات صفحة المنيو الكامل (m.html)
//    POST ?action=web_submit       → إرسال الطلب من صفحة المنيو
//    POST ?action=reply            → رد الموظف من لوحة التاجر (JWT)
//    POST ?action=flush            → إرسال تحديثات الحالة للعملاء (x-cron-key)
//    GET  ?action=health
//  الأسرار (Supabase → Edge Functions → Secrets): WA_VERIFY_TOKEN, WA_APP_SECRET
//    اختياري: WA_ACCESS_TOKEN (توكن احتياطي لكل القنوات)، WA_GRAPH_VERSION (الافتراضي v23.0)،
//    GEMINI_API_KEY (لفهم الكتابة الحرة)، SITE_URL (الافتراضي https://msarpro.com)
//  انشر بدون "Verify JWT" — الدالة تتحقق بنفسها (توقيع ميتا / رمز الجلسة / JWT / مفتاح الكرون).
// =====================================================================
import { createClient } from "jsr:@supabase/supabase-js@2";
import { step, webSubmitted, orderDoneOut, statusText, mergeCfg, subtotal } from "./engine.ts";
import type { Out, Menu, Sess, In, Cfg } from "./engine.ts";

const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false, autoRefreshToken: false } });
const CORS = { "Access-Control-Allow-Origin": "*", "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-cron-key", "Access-Control-Allow-Methods": "GET, POST, OPTIONS" };
const json = (b: unknown, status = 200) => new Response(JSON.stringify(b), { status, headers: { ...CORS, "Content-Type": "application/json; charset=utf-8" } });
const env = (k: string) => Deno.env.get(k) || "";
const GRAPH = () => `https://graph.facebook.com/${env("WA_GRAPH_VERSION") || "v23.0"}`;
const SITE = () => (env("SITE_URL") || "https://msarpro.com").replace(/\/+$/, "");

async function logErr(store_id: number | null, kind: string, ok: boolean, message: string) {
  try { await db.from("zid_log").insert({ store_id, kind, ok, message: String(message).slice(0, 900) }); } catch { /* */ }
}

// ---------- التوقيع ----------
async function validSignature(raw: string, header: string | null) {
  const secret = env("WA_APP_SECRET");
  if (!secret || !header || !header.startsWith("sha256=")) return false;
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  const sig = new Uint8Array(await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(raw)));
  const hex = [...sig].map((b) => b.toString(16).padStart(2, "0")).join("");
  const given = header.slice(7);
  if (given.length !== hex.length) return false;
  let d = 0; for (let i = 0; i < hex.length; i++) d |= hex.charCodeAt(i) ^ given.charCodeAt(i);
  return d === 0;
}
async function cronOk(req: Request) {
  const { data } = await db.from("app_settings").select("value").eq("key", "cron_key").maybeSingle();
  const key = data?.value as string | undefined;
  return !!key && req.headers.get("x-cron-key") === key;
}

// ---------- تحميل بيانات المتجر ----------
async function loadStore(store_id: number) {
  const [st, cats, items, br, cf] = await Promise.all([
    db.from("stores").select("name").eq("id", store_id).maybeSingle(),
    db.from("wa_categories").select("id,name,emoji,sort,is_active").eq("store_id", store_id).eq("is_active", true).order("sort").order("id"),
    db.from("wa_items").select("id,category_id,name,description,price,image_url,emoji,is_popular,aliases,sort").eq("store_id", store_id).eq("is_active", true).order("sort").order("id"),
    db.from("branches").select("name,lat,lon,city").eq("store_id", store_id).eq("is_active", true).limit(10),
    db.from("wa_config").select("config").eq("store_id", store_id).maybeSingle(),
  ]);
  const catIds = new Set((cats.data || []).map((c: any) => c.id));
  const menu: Menu = {
    store: st.data?.name || "المتجر",
    cats: (cats.data || []).map((c: any) => ({ id: c.id, name: c.name, emoji: c.emoji })),
    items: (items.data || []).filter((i: any) => i.category_id == null || catIds.has(i.category_id)).map((i: any) => ({
      id: i.id, cat: i.category_id, name: i.name, desc: i.description, price: Number(i.price), img: i.image_url, emoji: i.emoji, pop: i.is_popular, aliases: i.aliases })),
    branches: br.data || [],
  };
  return { menu, cfg: mergeCfg(cf.data?.config) };
}

// ---------- الإرسال لميتا ----------
const tokenCache = new Map<number, string>();
async function channelToken(channel_id: number) {
  if (tokenCache.has(channel_id)) return tokenCache.get(channel_id)!;
  const { data } = await db.from("wa_secrets").select("access_token").eq("channel_id", channel_id).maybeSingle();
  const t = data?.access_token || env("WA_ACCESS_TOKEN");
  if (t) tokenCache.set(channel_id, t);
  return t;
}
function toPayload(to: string, o: Out): any {
  const base = { messaging_product: "whatsapp", recipient_type: "individual", to };
  if (o.t === "text") return { ...base, type: "text", text: { body: o.body.slice(0, 4000), preview_url: false } };
  if (o.t === "loc") return { ...base, type: "location", location: { latitude: o.lat, longitude: o.lon, name: o.name, address: o.address } };
  if (o.t === "buttons") return { ...base, type: "interactive", interactive: {
    type: "button", ...(o.img ? { header: { type: "image", image: { link: o.img } } } : {}),
    body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { buttons: o.buttons.slice(0, 3).map((b) => ({ type: "reply", reply: { id: b.id.slice(0, 256), title: b.title.slice(0, 20) } })) } } };
  if (o.t === "list") return { ...base, type: "interactive", interactive: {
    type: "list", body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { button: o.button.slice(0, 20), sections: o.sections.map((s) => ({ ...(s.title ? { title: s.title.slice(0, 24) } : {}), rows: s.rows.map((r) => ({ id: r.id.slice(0, 200), title: r.title.slice(0, 24), ...(r.desc ? { description: r.desc.slice(0, 72) } : {}) })) })) } } };
  return { ...base, type: "interactive", interactive: {
    type: "cta_url", body: { text: o.body.slice(0, 1024) }, ...(o.footer ? { footer: { text: o.footer.slice(0, 60) } } : {}),
    action: { name: "cta_url", parameters: { display_text: o.label.slice(0, 20), url: o.url } } } };
}
const summary = (o: Out) => o.t === "text" ? o.body : o.t === "loc" ? "📍 موقع" : o.t === "list" ? `${o.body}\n[قائمة: ${o.button}]` : o.t === "cta" ? `${o.body}\n[رابط: ${o.label}]` : `${o.body}\n[${o.buttons.map((b) => b.title).join(" | ")}]`;

async function sendOut(ch: { id: number; phone_number_id: string; store_id: number }, session_id: number, to: string, outs: Out[], kind = "bot") {
  const token = await channelToken(ch.id);
  if (!token) { await logErr(ch.store_id, "wa_send", false, "لا يوجد توكن للقناة " + ch.phone_number_id); return false; }
  let okAll = true;
  for (const o of outs) {
    let wamid: string | null = null, ok = false;
    try {
      const r = await fetch(`${GRAPH()}/${ch.phone_number_id}/messages`, { method: "POST", signal: AbortSignal.timeout(12000),
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(toPayload(to, o)) });
      const j = await r.json().catch(() => ({}));
      ok = r.ok; wamid = j?.messages?.[0]?.id || null;
      if (!r.ok) { okAll = false; await logErr(ch.store_id, "wa_send", false, `${r.status} ${JSON.stringify(j?.error || j).slice(0, 600)}`); if (r.status === 401 || r.status === 190) tokenCache.delete(ch.id); }
    } catch (e) { okAll = false; await logErr(ch.store_id, "wa_send", false, String(e)); }
    await db.from("wa_messages").insert({ store_id: ch.store_id, session_id, dir: "out", kind, body: summary(o), payload: ok ? null : { failed: true }, wamid });
  }
  return okAll;
}

// ---------- فهم النص بالذكاء الاصطناعي (اختياري) ----------
async function aiParse(text: string, menu: Menu) {
  const key = env("GEMINI_API_KEY"); if (!key) return null;
  const list = menu.items.slice(0, 120).map((i) => `${i.id}|${i.name}${i.aliases ? "|" + i.aliases : ""}`).join("\n");
  const prompt = `أنت تستخرج طلب عميل من رسالة واتساب لمطعم. القائمة (id|الاسم|أسماء بديلة):\n${list}\n\nرسالة العميل: """${text.slice(0, 500)}"""\n\nأرجع JSON فقط بالشكل {"items":[{"id":رقم,"qty":رقم}]} وبس الأصناف الموجودة في القائمة. لو ما فهمت أي صنف أرجع {"items":[]}.`;
  const call = async (thinking: boolean) => fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=${key}`, {
    method: "POST", headers: { "Content-Type": "application/json" }, signal: AbortSignal.timeout(8000),
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { temperature: 0, responseMimeType: "application/json", ...(thinking ? { thinkingConfig: { thinkingBudget: 0 } } : {}) } }) });
  let r = await call(true); if (r.status === 400) r = await call(false);
  if (!r.ok) return null;
  const j = await r.json(); const t = j?.candidates?.[0]?.content?.parts?.[0]?.text || "";
  try { const p = JSON.parse(t); return (p.items || []).map((x: any) => ({ id: Number(x.id), qty: Math.max(1, Math.min(30, Number(x.qty) || 1)) })).filter((x: any) => menu.items.some((i) => i.id === x.id)); } catch { return null; }
}

// ---------- الجلسة ----------
const toSess = (r: any): Sess => ({ state: r.state, cart: r.cart || [], ctx: r.ctx || {}, name: r.name, human: r.human, webToken: r.web_token,
  lastCart: r.last_cart, lastLat: r.last_lat, lastLon: r.last_lon, lastAddress: r.last_address });
async function saveSess(id: number, s: Sess, extra: Record<string, unknown> = {}) {
  await db.from("wa_sessions").update({ state: s.state, cart: s.cart, ctx: s.ctx, human: !!s.human, name: s.name ?? null, last_msg_at: new Date().toISOString(), ...extra }).eq("id", id);
}

// ---------- معالجة رسالة واردة ----------
async function handleMessage(ch: any, m: any, contactName: string | null) {
  const from = String(m.from || "");
  if (!from) return;
  const type = m.type;
  let inp: In = { kind: "other" }, logBody = `[${type}]`;
  if (type === "text") { inp = { kind: "text", text: String(m.text?.body || "") }; logBody = inp.text!; }
  else if (type === "interactive") {
    const b = m.interactive?.button_reply, l = m.interactive?.list_reply;
    if (b) { inp = { kind: "button", id: b.id }; logBody = "🔘 " + b.title; }
    else if (l) { inp = { kind: "list", id: l.id }; logBody = "📋 " + l.title; }
  } else if (type === "button") { inp = { kind: "button", id: m.button?.payload || "" }; logBody = m.button?.text || "[button]"; }
  else if (type === "location") { inp = { kind: "location", lat: Number(m.location?.latitude), lon: Number(m.location?.longitude), addr: [m.location?.name, m.location?.address].filter(Boolean).join(" — ") || undefined }; logBody = "📍 موقع"; }

  // جلسة (إنشاء/جلب)
  let { data: row } = await db.from("wa_sessions").select("*").eq("channel_id", ch.id).eq("wa_id", from).maybeSingle();
  if (!row) {
    const ins = await db.from("wa_sessions").insert({ store_id: ch.store_id, channel_id: ch.id, wa_id: from, name: contactName }).select("*").single();
    row = ins.data;
    if (!row) { const again = await db.from("wa_sessions").select("*").eq("channel_id", ch.id).eq("wa_id", from).maybeSingle(); row = again.data; }
  }
  if (!row) return;
  // منع التكرار (ميتا تعيد الإرسال أحياناً)
  const dup = await db.from("wa_messages").insert({ store_id: ch.store_id, session_id: row.id, dir: "in", kind: type, body: logBody.slice(0, 2000), wamid: m.id || null });
  if (dup.error) { if (String(dup.error.code) === "23505") return; }
  await db.from("wa_sessions").update({ last_in_at: new Date().toISOString(), last_msg_at: new Date().toISOString(), name: contactName || row.name }).eq("id", row.id);

  if (row.human) return; // الموظف يرد من اللوحة
  const { menu, cfg } = await loadStore(ch.store_id);
  const sess = toSess(row); if (!sess.name && contactName) sess.name = contactName;
  const res = await step(cfg, menu, sess, inp, {
    webUrl: (t) => `${SITE()}/m?t=${t}`,
    checkLoc: async (lat, lon) => {
      const { data } = await db.rpc("wa_check_location", { p_store: ch.store_id, p_lat: lat, p_lon: lon });
      if (!data || data.nearest_id == null) return null;
      return { ok: data.branch_id != null, km: data.nearest_km != null ? Number(data.nearest_km) : null };
    },
    ai: aiParse,
  });
  await saveSess(row.id, res.sess);
  if (res.out.length) await sendOut(ch, row.id, from, res.out);

  if (res.action?.type === "create_order") {
    const a = res.action;
    const { data, error } = await db.rpc("wa_create_order", { p_session: row.id, p: {
      customer_name: res.sess.name || contactName, address_text: a.address, lat: a.lat, lon: a.lon, subtotal: a.subtotal, shipping_fee: a.fee,
      items: a.lines.map((l) => ({ name: l.name, quantity: l.qty, price: l.price, total: l.qty * l.price })), cart: a.lines } });
    if (error || !data) { await logErr(ch.store_id, "wa_order", false, error?.message || "فشل إنشاء الطلب"); await sendOut(ch, row.id, from, [{ t: "text", body: "عذراً صار خلل في تسجيل الطلب 🙏 حاول مرة ثانية أو كلمنا." }]); return; }
    await sendOut(ch, row.id, from, orderDoneOut(cfg, data.invoice, a.subtotal + a.fee, data.track_token ? `${SITE()}/track?t=${data.track_token}` : undefined));
  } else if (res.action?.type === "handoff") {
    await db.from("wa_sessions").update({ human: true }).eq("id", row.id);
  }
}

async function handleWebhook(req: Request) {
  const raw = await req.text();
  if (!(await validSignature(raw, req.headers.get("x-hub-signature-256")))) return json({ error: "bad signature" }, 401);
  let body: any; try { body = JSON.parse(raw); } catch { return json({ ok: true }); }
  if (body?.object !== "whatsapp_business_account") return json({ ok: true });
  const work: Promise<void>[] = [];
  for (const e of body.entry || []) for (const c of e.changes || []) {
    const v = c.value || {}; const pnid = String(v.metadata?.phone_number_id || "");
    if (!pnid) continue;
    const names = new Map<string, string>((v.contacts || []).map((x: any) => [String(x.wa_id), String(x.profile?.name || "")]));
    for (const m of v.messages || []) {
      work.push((async () => {
        try {
          const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,status").eq("phone_number_id", pnid).maybeSingle();
          if (!ch || ch.status !== "active") return;
          const { data: on } = await db.rpc("wa_enabled_for", { p_store: ch.store_id });
          if (!on) return;
          await handleMessage(ch, m, names.get(String(m.from)) || null);
        } catch (err) { await logErr(null, "wa_webhook", false, String(err)); }
      })());
    }
  }
  const all = Promise.allSettled(work);
  // @ts-ignore EdgeRuntime موجود في Supabase
  if (typeof EdgeRuntime !== "undefined" && EdgeRuntime?.waitUntil) EdgeRuntime.waitUntil(all); else await all;
  return json({ ok: true });
}

// ---------- صفحة المنيو الكامل ----------
async function sessionByToken(t: string) {
  if (!/^[a-f0-9]{32}$/.test(t)) return null;
  const { data } = await db.from("wa_sessions").select("*").eq("web_token", t).maybeSingle();
  if (!data) return null;
  const { data: on } = await db.rpc("wa_enabled_for", { p_store: data.store_id });
  return on ? data : null;
}
async function webMenu(url: URL) {
  const row = await sessionByToken(url.searchParams.get("t") || "");
  if (!row) return json({ error: "الرابط غير صالح أو منتهي" }, 404);
  const { menu, cfg } = await loadStore(row.store_id);
  return json({ store: menu.store, cats: menu.cats, items: menu.items.map((i) => ({ id: i.id, cat: i.cat, name: i.name, desc: i.desc, price: i.price, img: i.img, emoji: i.emoji })), fee: cfg.delivery_fee, free_over: cfg.free_over, min_order: cfg.min_order });
}
async function webSubmit(req: Request) {
  const b = await req.json().catch(() => ({}));
  const row = await sessionByToken(String(b.t || ""));
  if (!row) return json({ error: "الرابط غير صالح أو منتهي" }, 404);
  const lines = (Array.isArray(b.lines) ? b.lines : []).map((l: any) => ({ id: Number(l.id), qty: Number(l.qty) })).filter((l: any) => l.id > 0 && l.qty > 0).slice(0, 60);
  if (!lines.length) return json({ error: "السلة فاضية" }, 400);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id,status").eq("id", row.channel_id).maybeSingle();
  if (!ch || ch.status !== "active") return json({ error: "القناة غير متاحة" }, 400);
  const { menu, cfg } = await loadStore(row.store_id);
  const sess = toSess(row);
  const outs = webSubmitted(cfg, menu, sess, lines);
  if (!sess.cart.length) return json({ error: "الأصناف غير متاحة" }, 400);
  await saveSess(row.id, sess);
  await db.from("wa_messages").insert({ store_id: row.store_id, session_id: row.id, dir: "in", kind: "web_order", body: "🌐 طلب من المنيو الكامل: " + sess.cart.map((l) => `${l.qty}×${l.name}`).join("، ") });
  await sendOut(ch as any, row.id, row.wa_id, outs);
  return json({ ok: true });
}

// ---------- رد الموظف ----------
async function agentReply(req: Request) {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return json({ error: "غير مصرح" }, 401);
  const { data: u } = await db.auth.getUser(token);
  if (!u?.user) return json({ error: "غير مصرح" }, 401);
  const { data: p } = await db.from("profiles").select("store_id,role,is_active,full_name").eq("id", u.user.id).maybeSingle();
  if (!p?.is_active || !["admin", "cashier"].includes(p.role)) return json({ error: "غير مصرح" }, 403);
  const b = await req.json().catch(() => ({}));
  const text = String(b.text || "").trim().slice(0, 1500);
  if (!text) return json({ error: "الرسالة فاضية" }, 400);
  const { data: s } = await db.from("wa_sessions").select("*").eq("id", Number(b.session_id)).maybeSingle();
  if (!s || s.store_id !== p.store_id) return json({ error: "المحادثة غير موجودة" }, 404);
  const { data: on } = await db.rpc("wa_enabled_for", { p_store: s.store_id });
  if (!on) return json({ error: "الميزة غير مفعلة" }, 403);
  if (!s.last_in_at || Date.now() - new Date(s.last_in_at).getTime() > 24 * 3600 * 1000)
    return json({ error: "مرّت أكثر من 24 ساعة على آخر رسالة من العميل، ميتا تمنع الرد الحر. انتظر رسالة جديدة منه." }, 400);
  const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id").eq("id", s.channel_id).maybeSingle();
  if (!ch) return json({ error: "القناة غير موجودة" }, 404);
  const ok = await sendOut(ch as any, s.id, s.wa_id, [{ t: "text", body: text }], "agent");
  await db.from("wa_sessions").update({ last_msg_at: new Date().toISOString() }).eq("id", s.id);
  return json({ ok });
}

// ---------- تحديثات الحالة ----------
async function flush() {
  const { data: rows } = await db.from("wa_outbox").select("*").is("sent_at", null).lt("tries", 5).order("id").limit(40);
  let sent = 0;
  for (const r of rows || []) {
    try {
      await db.from("wa_outbox").update({ tries: r.tries + 1 }).eq("id", r.id);
      const [{ data: o }, { data: s }] = await Promise.all([
        db.from("orders").select("invoice_number,status").eq("id", r.order_id).maybeSingle(),
        db.from("wa_sessions").select("*").eq("id", r.session_id).maybeSingle()]);
      if (!o || !s) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "no order/session" }).eq("id", r.id); continue; }
      if (!s.last_in_at || Date.now() - new Date(s.last_in_at).getTime() > 24 * 3600 * 1000) {
        await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "خارج نافذة 24 ساعة (يحتاج قالب معتمد)" }).eq("id", r.id); continue; }
      const { cfg } = await loadStore(s.store_id);
      const txt = statusText(cfg, r.status, o.invoice_number || String(r.order_id));
      const { data: ch } = await db.from("wa_channels").select("id,store_id,phone_number_id").eq("id", s.channel_id).maybeSingle();
      if (!txt || !ch) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: "skip" }).eq("id", r.id); continue; }
      const ok = await sendOut(ch as any, s.id, s.wa_id, [{ t: "text", body: txt }], "status");
      if (ok) { await db.from("wa_outbox").update({ sent_at: new Date().toISOString(), error: null }).eq("id", r.id); sent++; }
      else await db.from("wa_outbox").update({ error: "فشل الإرسال" }).eq("id", r.id);
    } catch (e) { await db.from("wa_outbox").update({ error: String(e).slice(0, 300) }).eq("id", r.id); }
  }
  return json({ ok: true, sent, pending: (rows || []).length });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: CORS });
  const url = new URL(req.url);
  const action = url.searchParams.get("action") || "";
  try {
    if (req.method === "GET" && url.searchParams.get("hub.mode") === "subscribe") {
      const ok = env("WA_VERIFY_TOKEN") && url.searchParams.get("hub.verify_token") === env("WA_VERIFY_TOKEN");
      return ok ? new Response(url.searchParams.get("hub.challenge") || "", { status: 200 }) : new Response("forbidden", { status: 403 });
    }
    if (action === "health") return json({ ok: true, secrets: { verify: !!env("WA_VERIFY_TOKEN"), app_secret: !!env("WA_APP_SECRET"), token: !!env("WA_ACCESS_TOKEN"), ai: !!env("GEMINI_API_KEY") } });
    if (action === "web_menu" && req.method === "GET") return await webMenu(url);
    if (action === "web_submit" && req.method === "POST") return await webSubmit(req);
    if (action === "reply" && req.method === "POST") return await agentReply(req);
    if (action === "flush") return (await cronOk(req)) ? await flush() : json({ error: "forbidden" }, 403);
    if (req.method === "POST" && !action) return await handleWebhook(req);
    return json({ error: "unknown" }, 404);
  } catch (e) { await logErr(null, "wa_fatal", false, String(e)); return json({ error: "server" }, 500); }
});
